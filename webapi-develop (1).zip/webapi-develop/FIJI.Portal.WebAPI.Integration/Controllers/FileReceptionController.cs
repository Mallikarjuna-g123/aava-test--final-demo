﻿using Microsoft.AspNetCore.Mvc;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    public class FileReceptionController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
