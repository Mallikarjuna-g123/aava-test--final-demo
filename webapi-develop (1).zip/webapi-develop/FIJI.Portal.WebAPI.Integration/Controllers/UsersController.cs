﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class UsersController : Controller
    {
        private readonly SystemUser _systemuser;
        private readonly ILogger<UsersController> _logger;
        private readonly string _token;

        public UsersController(SystemUser systemuser, ILogger<UsersController> logger, Task<string> token)
        {
            _systemuser = systemuser;
            _logger = logger;
            _token = token.Result;
        }

        [HttpGet(RouteConstants.ListFSPMUsers)]
        public async Task<IActionResult> ListFSPMUsers()
        {
            try
            {
                var fspmUsers = _systemuser.ListFSPMUsers(_token);
                if (string.IsNullOrEmpty(fspmUsers))
                {
                    _logger.LogInformation("ListFSPMUsers failed with correlation ID {CorrelationID} - {Error}", HttpContext.TraceIdentifier, "FSPM Users not found");
                    return Ok("");
                }
                return Ok(fspmUsers);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ListFSPMUsers failed with correlation ID {CorrelationID} - {Error}", HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Listing FSPM users failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
