﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Responses.ServiceRevision;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{

    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class ServiceRevisionController : Controller
    {
        private readonly ServiceSnapshot _ServiceSnapshotService;
        private readonly ILogger<ServiceRevisionController> _logger;

        public ServiceRevisionController(ServiceSnapshot serviceSnapshotService, ILogger<ServiceRevisionController> logger)
        {
            _ServiceSnapshotService = serviceSnapshotService;
            _logger = logger;
        }

        // PBI 359074 need to to be implmented in it.
        [HttpPost(RouteConstants.Update)]
        [ProducesResponseType(typeof(ServiceRevisionUpdateResponse), 201)]
        public IActionResult Update(Requests.ServiceRevision.ServiceRevisionUpdateRequest value)
        {
            try
            {
                ServiceRevisionUpdateResponse response = new ServiceRevisionUpdateResponse();
                response = _ServiceSnapshotService.UpdateServiceRevision(value);

                if (response.Error != null)
                {
                    _logger.LogError("Service revision update failed for service revision {ServiceRevisionId} with correlation ID {CorrelationID} - {Error}", value?.ServiceRevisionId, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service revision update failed for service revision {ServiceRevisionId} with correlation ID {CorrelationID} - {Error}", value?.ServiceRevisionId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Service revision update failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
