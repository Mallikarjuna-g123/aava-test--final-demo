﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class FactoryDashboardController : Controller
    {
        private readonly Tasks _taskService;
        private readonly Bookings _bookingService;
        private readonly ILogger<FactoryDashboardController> _logger;

        public FactoryDashboardController(IOrganizationService dataverseService, ILogger<FactoryDashboardController> logger)
        {
            this._taskService = new Tasks(dataverseService);
            this._bookingService = new Bookings(dataverseService);
            _logger = logger;
        }

        [HttpPost(RouteConstants.GetScheduleByUserId)]
        public IActionResult GetScheduleByUserId(ScheduleRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.contact))
                {
                    return BadRequest(Constants.ErrorMessages.InvalidPayload);
                }
                ScheduleResponse scheduleResponse = _taskService.GetFactoryScheduleByUserId(request);
                _logger.LogInformation("GetScheduleByUserId passed for contact {Contact} with correlation ID {CorrelationID}", request?.contact, HttpContext.TraceIdentifier);
                return Ok(scheduleResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetScheduleByUserId failed for contact {Contact} with correlation ID {CorrelationID}", request?.contact, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Schedule retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpPost(RouteConstants.GetTasks)]
        public async Task<IActionResult> GetTasks(TaskRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.TaskType) || request.Contact == null)
                {
                    return BadRequest(Constants.ErrorMessages.EmptyPayload);
                }
                if (string.Equals(request?.Filters?.SearchMode, Constants.ProjectIdSearchMode, StringComparison.OrdinalIgnoreCase) && Tasks.SplitProjectIdInput(request?.Filters?.Search).Count > Constants.MaxProjectIdSearchCount)
                {
                    return BadRequest(Constants.ErrorMessages.ProjectIdSearchLimitExceeded);
                }
                var factoryDashboardResponse = await _taskService.GetFactoryDasboardTasks(request);
                _logger.LogInformation("GetTasks passed for task type {TaskType} and contact {Contact} with correlation ID {CorrelationID}", request?.TaskType, request?.Contact, HttpContext.TraceIdentifier);

                return Ok(factoryDashboardResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetTasks failed for task type {TaskType} and contact {Contact} with correlation ID {CorrelationID}", request?.TaskType, request?.Contact, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Task retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpPost(RouteConstants.UpdateTasks)]
        public async Task<IActionResult> UpdateTasks(UpdateTasksRequest request)
        {
            try
            {
                var factoryDashboardResponse = _taskService.UpdateFactoryDasboardTasks(request);
                _logger.LogInformation("UpdateTasks passed for request {Request} with correlation ID {CorrelationID}", request, HttpContext.TraceIdentifier);

                return Ok(factoryDashboardResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateTasks failed for request {Request} with correlation ID {CorrelationID}", request, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Task update failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // This Web API will get the all the booking records
        [HttpPost(RouteConstants.GetBookingsByUserId)]
        public async Task<IActionResult> GetBookingsByUserId(BookingRequest request)
        {
            if (string.IsNullOrEmpty(request.Tab) || request.Contact == null)
            {
                _logger.LogError("GetBookingsByUserId failed with error {Error} with correlation ID {CorrelationID}", Constants.ErrorMessages.EmptyPayload, HttpContext.TraceIdentifier);
                return BadRequest(Constants.ErrorMessages.EmptyPayload);
            }

            FactoryDashboardBookings response = new FactoryDashboardBookings();
            try
            {
                response = _bookingService.GetFactoryDasboardBookings(request);

                if (response.Error != null)
                {
                    _logger.LogError("GetBookingsByUserId failed with error {Error} with correlation ID {CorrelationID}", response.Error, HttpContext.TraceIdentifier);
                    return BadRequest(response);
                }

                _logger.LogInformation("GetBookingsByUserId passed for tab {Tab} and contact {Contact} with correlation ID {CorrelationID}", request?.Tab, request?.Contact, HttpContext.TraceIdentifier);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetBookingsByUserId failed for tab {Tab} and contact {Contact} with correlation ID {CorrelationID}", request?.Tab, request?.Contact, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Booking retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpPost(RouteConstants.Export)]
        public async Task<IActionResult> Export(TaskRequest request)
        {
            try
            {
                var fileName = "";
                var exportFile = await _taskService.ExportTasks(request);
                var currentDateTime = DateTime.Now;
                var currentDate = currentDateTime.ToString(Constants.ddMMMyyyy);
                var currentTime = currentDateTime.ToString(Constants.HoursMinutes);
                var title = (request.TaskType == Constants.VirtualValidationTaskKey) ? Constants.VirtualValidationTitle : Constants.POCTaskTitle;
                fileName = $"{title}{currentDate}_{currentTime}.xlsx";
                var contentType = Constants.ContentTypeExcel;
                Response.Headers.Add(Constants.AccessControlHeaders, Constants.ContentDisposition);
                return File(exportFile, contentType, fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Export failed for task type {TaskType} and contact {Contact} with correlation ID {CorrelationID}", request?.TaskType, request?.Contact, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Task export failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}