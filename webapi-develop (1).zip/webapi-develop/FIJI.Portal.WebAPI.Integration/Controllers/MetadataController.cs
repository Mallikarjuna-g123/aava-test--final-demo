﻿using FIJI.Portal.WebAPI.Integration.Model.Generic;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]

    public class MetadataController : Controller
    {
        private readonly MetadataRecords metadataRecordsInfra;
        private readonly ILogger<MetadataController> _logger;

        public MetadataController(IOrganizationService dataverseService, ILogger<MetadataController> logger)
        {
            metadataRecordsInfra = new MetadataRecords(dataverseService);
            _logger = logger;
        }

        [HttpGet(RouteConstants.GetOptionSetValues)]
        public async Task<IActionResult> GetOptionSetValues(string table, string optionSet)
        {
            Dictionary<int, string> values;

            try
            {
                if (string.IsNullOrWhiteSpace(table) || string.IsNullOrWhiteSpace(optionSet))
                    throw new Exception(Constants.ErrorMessages.EmptyParameters);

                values = await metadataRecordsInfra.GetOptionSetValues(table, optionSet);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetOptionSetValues failed for table {Table} and option set {OptionSet} with correlation ID {CorrelationID}", table, optionSet, HttpContext.TraceIdentifier);
                return BadRequest(new { error = "Option set lookup failed.", correlationId = HttpContext.TraceIdentifier });
            }

            return Ok(values.ToList());
        }
    }
}
