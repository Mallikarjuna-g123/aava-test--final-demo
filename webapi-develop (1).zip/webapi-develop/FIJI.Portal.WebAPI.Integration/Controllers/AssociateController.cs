﻿using FIJI.Portal.WebAPI.Integration.Model.Generic;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]

    public class AssociateController : Controller
    {


        private readonly AssociateRecords associateRecordsInfra;
        private readonly ILogger<AssociateController> _logger;

        public AssociateController(IOrganizationService dataverseService, ILogger<AssociateController> logger)
        {
            associateRecordsInfra = new AssociateRecords(dataverseService);
            _logger = logger;
        }


        [HttpPost(RouteConstants.Execute)]
        public IActionResult Execute(Requests.AssociateDissociateRecordsRequest request)
        {
            try
            {
                associateRecordsInfra.Execute(request);
            }
            catch (Exception ex)
            {
                if (!ex.Message.Contains(Constants.ErrorMessages.DuplicateKey))
                {
                    _logger.LogError(ex, "Associate execute failed for request {Request} with CorrelationID {CorrelationID}", request, HttpContext.TraceIdentifier);
                    return StatusCode(500, new { error = "Association failed.", correlationId = HttpContext.TraceIdentifier });
                }
            }
            return Ok(new { Status = Constants.ResponseMessages.Ok });
        }
    }
}
