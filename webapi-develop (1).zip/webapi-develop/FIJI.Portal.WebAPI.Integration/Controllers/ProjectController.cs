﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Requests.Project;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Responses.Project;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]

    public class ProjectController : Controller
    {

        private readonly Project _projectService;
        private readonly BOM _bomService;
        private readonly ILogger<ProjectController> _logger;
        private readonly string _token;

        public ProjectController(Project projectService, BOM bomService, ILogger<ProjectController> logger, Task<string> token)
        {
            _projectService = projectService;
            _bomService = bomService;
            _logger = logger;
            _token = token.Result;
        }

        [HttpPost(RouteConstants.Create)]
        public async Task<IActionResult> Create(Requests.CreateProjectRequest value)
        {
            try
            {
                var response = _projectService.CreateProjectAndBomItems(value);

                if (response.Error != null)
                {
                    _logger.LogError("Project create failed for model {ModelId} and customer {CustomerId} with correlation ID {CorrelationID} - {Error}", value?.ModelId, value?.CustomerId, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Project create failed for model {ModelId} and customer {CustomerId} with correlation ID {CorrelationID} - {Error}", value?.ModelId, value?.CustomerId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Project creation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpPost(RouteConstants.AddLocalizationToEcnProject)]
        public async Task<IActionResult> AddLocalizationToEcnProject(AddLocalizationToEcnProjectRequest request)
        {
            try
            {
                var respon = _projectService.AddLocalizationToEcnProject(request);
                if (respon.StatusCode == System.Net.HttpStatusCode.NoContent)
                {
                    return StatusCode(204, respon);
                }
                else if (respon.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return Ok(respon);
                }
                return Ok(respon);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AddLocalizationToEcnProject failed for project {ProjectId} with correlation ID {CorrelationID} - {Error}", request?.projectId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Localization update failed.", correlationId = HttpContext.TraceIdentifier });
            }

        }

        // This is the api endpoint which needs to be updated
        [HttpPost(RouteConstants.UpdateBomItems)]
        public async Task<IActionResult> CreateUpdateBomItems(Requests.CreateUpdateBomItemRquest value)
        {
            try
            {
                //This is the validation implementated to check if the service to be removed is also in the updates service list
                if (value.RemoveService != null && value.RemoveService.Count > 0)
                {
                    foreach (var item in value.RemoveService)
                    {
                        if (value.UpdateServices != null && value.UpdateServices.Count > 0)
                        {
                            if (value.UpdateServices.Any(x => x.BomId.ToString() == item.BomId))
                            {
                                CreateProjectResponse response1 = new CreateProjectResponse();
                                response1.Error = Constants.ErrorMessages.RemoveServiceList;
                                _logger.LogError("UpdateBomItems failed with correlation ID {CorrelationID} - {Error}", HttpContext.TraceIdentifier, response1.Error);
                                return StatusCode(500, response1);
                            }
                        }
                    }
                }

                //Update service check 
                if (value.UpdateServices != null && value.UpdateServices.Count > 0)
                {
                    foreach (var updService in value.UpdateServices)
                    {

                        if (updService.BomId == Guid.Empty)
                        {
                            Responses.BillofMaterial.CreateDeleteBOMResponse fijiResponse = new Responses.BillofMaterial.CreateDeleteBOMResponse();
                            fijiResponse.Message = Constants.ErrorMessages.EmptyBOMId;
                            _logger.LogError("UpdateBomItems failed for BOM {BOMId} with correlation ID {CorrelationID} - {Error}", updService.BomId, HttpContext.TraceIdentifier, fijiResponse.Message);
                            return BadRequest(fijiResponse);
                        }

                        else if (updService.ProductComponentId == Guid.Empty)
                        {
                            Responses.BillofMaterial.CreateDeleteBOMResponse fijiResponse = new Responses.BillofMaterial.CreateDeleteBOMResponse();
                            fijiResponse.Message = Constants.ErrorMessages.EmptyProductComponentId;
                            _logger.LogError("UpdateBomItems failed for ProductComponent {ProductComponentId} with correlation ID {CorrelationID} - {Error}", updService.ProductComponentId, HttpContext.TraceIdentifier, fijiResponse.Message);
                            return BadRequest(fijiResponse);
                        }
                    }
                }

                IDictionary<string, Responses.BillofMaterial.CreateDeleteBOMResponse> response = _bomService.CreateDeleteBomItems(value);

                if ((response.ContainsKey(Constants.NewService) && response[Constants.NewService].Error != null) || (response.ContainsKey(Constants.RemoveService) && response[Constants.RemoveService].Error != null)
                    || (response.ContainsKey(Constants.UpdateService) && response[Constants.UpdateService].Error != null))
                {
                    _logger.LogError("CreateUpdateBomItems failed for project {ProjectId} with correlation ID {CorrelationID} - NewService Error: {NewServiceError}, RemoveService Error: {RemoveServiceError}, UpdateService Error: {UpdateServiceError}",
                        value?.ProjectId, HttpContext.TraceIdentifier,
                        response.ContainsKey(Constants.NewService) ? response[Constants.NewService].Error : "No error",
                        response.ContainsKey(Constants.RemoveService) ? response[Constants.RemoveService].Error : "No error",
                        response.ContainsKey(Constants.UpdateService) ? response[Constants.UpdateService].Error : "No error");
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateUpdateBomItems failed for project {ProjectId} with correlation ID {CorrelationID}", value?.ProjectId, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "BOM update failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // This Web API endpoint provides Integration Foundation – Update PC Platform Status and Service Revision
        [HttpPost(RouteConstants.UpdateCSAV)]
        [ProducesResponseType(typeof(UpdateCSAVResponse), 201)]
        public async Task<IActionResult> UpdateCSAV(Requests.UpdateCSAVRequest value)
        {
            try
            {
                UpdateCSAVResponse response = new UpdateCSAVResponse();
                if (Utils.ValidateGUIDINPayload(value.ProductComponentId, nameof(value.ProductComponentId))
                    && Utils.ValidateGUIDINPayload(value.BomId, nameof(value.BomId))
                    && Utils.ValidateGUIDINPayload(value.ModelId, nameof(value.ModelId)))
                    response = _projectService.UpdateCSAV(value);

                if (response.Error != null)
                {
                    _logger.LogError("UpdateCSAV failed for product component {ProductComponentId} and BOM {BomId} with correlation ID {CorrelationID} - {Error}", value?.ProductComponentId, value?.BomId, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateCSAV failed for product component {ProductComponentId} and BOM {BomId} with correlation ID {CorrelationID}", value?.ProductComponentId, value?.BomId, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "CSAV update failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // This Web API endpoint provides Integration Foundation – Update PC Platform Status and Service Revision
        [HttpPost(RouteConstants.Submit)]
        public async Task<IActionResult> Submit(Requests.Project.SubmitProjectRequest value)
        {
            SubmitProjectResponse response = new SubmitProjectResponse();
            try
            {
                response = _projectService.Submit(value);

                if (response.Error != null)
                {
                    response.Status = Constants.ErrorMessages.Unsuccessful;
                    _logger.LogError("Project submit failed for project {ProjectId} with correlation ID {CorrelationID} - {Error}", value?.ProjectId, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }
                response.Status = Constants.success;
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Project submit failed for project {ProjectId} with correlation ID {CorrelationID} - {Error}", value?.ProjectId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Project submission failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }


        // This Web API will get the Project details based on requestID(Here requestID is projectID)
        [HttpPost(RouteConstants.GetProjectByRequestID)]
        public async Task<IActionResult> GetProjectByRequestID(GetProjectByRequestIDRequest request)
        {
            GetProjectByRequestIDResponse response = new GetProjectByRequestIDResponse();
            try
            {
                if (!string.IsNullOrEmpty(request.RequestID))
                    if (Guid.TryParse(request.RequestID, out _))
                        response = _projectService.GetProjectByRequestID(request);
                    else response.Error = Constants.ErrorMessages.InvalidRequestId;
                else response.Error = Constants.ErrorMessages.EmptyRequestId;

                if (response.Error != null)
                {
                    _logger.LogError("GetProjectByRequestID failed for request {RequestId} with correlation ID {CorrelationID} - {Error}", request?.RequestID, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetProjectByRequestID failed for request {RequestId} with correlation ID {CorrelationID} - {Error}", request?.RequestID, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Project lookup failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        //An API to create bulk projects from inception form.
        [HttpPost(RouteConstants.NewInceptionCreation)]
        [ProducesResponseType(typeof(NewInceptionCreationResponse), 201)]
        public async Task<IActionResult> NewInceptionCreation(Requests.Project.NewInceptionCreationRequest request)
        {
            NewInceptionCreationResponse response = new NewInceptionCreationResponse();
            try
            {
                response = _projectService.NewInceptionCreation(request);

                if (response.Error != null)
                {
                    _logger.LogError("NewInceptionCreation failed for model {ModelId} and customer {CustomerId} with correlation ID {CorrelationID} - {Error}", request?.ModelId, request?.CustomerId, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "NewInceptionCreation failed for model {ModelId} and customer {CustomerId} with correlation ID {CorrelationID} - {Error}", request?.ModelId, request?.CustomerId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "New inception creation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        //An  API to Create bulk ECN projects From Portal
        [HttpPost(RouteConstants.ECNInceptionCreation)]
        [ProducesResponseType(typeof(ECNInceptionCreationResponse), 201)]
        public async Task<IActionResult> ECNInceptionCreation(ECNInceptionCreationRequest request)
        {
            ECNInceptionCreationResponse response = new();

            try
            {
                response = await _projectService.ECNInceptionCreation(request);

                if (response.Error != null || !string.IsNullOrEmpty(response.Message))
                {
                    _logger.LogError("ECNInceptionCreation failed for project {ProjectId} with correlation ID {CorrelationID} - {Error}", request?.ProjectId, HttpContext.TraceIdentifier, response.Error ?? response.Message);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ECNInceptionCreation failed for project {ProjectId} with correlation ID {CorrelationID} - {Error}", request?.ProjectId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "ECN inception creation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }


        //An  API to Create bulk ECN projects From Portal
        [HttpPost(RouteConstants.Duplicate)]
        [ProducesResponseType(typeof(ProjectDuplicateResponse), 201)]
        public async Task<IActionResult> Duplicate(Requests.Project.ProjectDuplicateRequest request)
        {
            ProjectDuplicateResponse response = new ProjectDuplicateResponse();
            try
            {
                response = _projectService.Duplicate(request);

                if (response.Error != null)
                {
                    _logger.LogError("Project duplicate failed for source request {SourceRequestId} with correlation ID {CorrelationID} - {Error}", request?.SourceRequestId, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Project duplicate failed for source request {SourceRequestId} with correlation ID {CorrelationID} - {Error}", request?.SourceRequestId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Project duplication failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpGet(RouteConstants.FetchProjectBySkuNumber)]
        public async Task<IActionResult> FetchProjectBySkuNumber(Guid customerId, string skuNumber)
        {
            try
            {
                var project = _projectService.FetchProjectBySkuNumber(skuNumber, customerId, _token);
                if (string.IsNullOrEmpty(project))
                {
                    _logger.LogInformation("FetchProjectBySkuNumber failed for SKU {SkuNumber} and customer {CustomerId} with correlation ID {CorrelationID} - {Error}", skuNumber, customerId, HttpContext.TraceIdentifier, "Project not found");
                    return Ok("");
                }
                return Ok(project);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "FetchProjectBySkuNumber failed for SKU {SkuNumber} and customer {CustomerId} with correlation ID {CorrelationID} - {Error}", skuNumber, customerId, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Fetching project by SKU number failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
