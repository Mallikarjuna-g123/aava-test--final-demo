﻿using FIJI.Portal.WebAPI.Integration.Integration;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System.Xml;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class OCIController : Controller
    {
        private readonly OCI OCIBaseInfra;
        private readonly ILogger<OCIController> _logger;
        

        //public OCIController()
        //{
        //    OCIBaseInfra = new OCI();
        //}
        public OCIController(IOrganizationService dataverseClient, IMemoryCache cache, IHttpClientFactory httpClientFactory, ILogger<OCIController> logger)
        {
            var httpClient = httpClientFactory.CreateClient("OCI");
            httpClient.DefaultRequestHeaders.UserAgent.ParseAdd(Constants.UserAgentHeaderValue);
            OCIBaseInfra = new OCI(dataverseClient, cache, httpClient);
            _logger = logger;
        }

        [HttpGet(RouteConstants.GetData)]
        public async Task<IActionResult> GetData(string id)
        {
            try
            {
                bool isJsonContentType = false;
                Request.Headers.TryGetValue(Constants.ContentType, out var headerValue);
                if (headerValue == Constants.JsonApplication)
                    isJsonContentType = true;

                string returnValue = await OCIBaseInfra.GetData(id);
                if (!returnValue.TrimStart().StartsWith(Constants.LessThanSymbol))
                    throw new Exception(returnValue);

                if (isJsonContentType)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(returnValue);
                    returnValue = JsonConvert.SerializeXmlNode(doc);
                }

                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                if (ex.Message.TrimStart().StartsWith("{"))
                {
                    return new ContentResult
                    {
                        Content = ex.Message,
                        ContentType = "application/json; charset=utf-8",
                        StatusCode = StatusCodes.Status400BadRequest
                    };
                }
                _logger.LogError(ex, "OCI GetData failed for id {Id} with error {Error} with correlation ID {CorrelationID}", id, ex.Message, HttpContext.TraceIdentifier);
                return BadRequest(new { isConflict = false, message = ex.Message });
            }
        }
    }
}
