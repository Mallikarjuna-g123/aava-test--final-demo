﻿using FIJI.Portal.WebAPI.Integration.Service;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Mvc;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{

    [ApiController]
    [Route(RouteConstants.Authorize)]
    public class AuthController : Controller
    {
        [HttpPost]
        public IActionResult Auth()
        {
            var token = TokenService.GenerateToken();
            return Ok(token);
        }
    }

}



