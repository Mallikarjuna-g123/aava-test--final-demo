﻿using FIJI.Portal.WebAPI.Integration.Model.Generic;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;
using System.Globalization;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]

    public class GetCountOfRecordsController : Controller
    {
        private readonly GetCountOfRecords getCountOfRecordsBaseInfra;
        private readonly ILogger<GetCountOfRecordsController> _logger;

        public GetCountOfRecordsController(IOrganizationService dataverseService, ILogger<GetCountOfRecordsController> logger)
        {
            this.getCountOfRecordsBaseInfra = new GetCountOfRecords(dataverseService);
            _logger = logger;
        }

        [HttpPost(RouteConstants.GetCountofRecords)]
        public async Task<IActionResult> GetCount()
        {
            StreamReader sr = new StreamReader(Request.Body);
            string param = await sr.ReadToEndAsync();
            string entityName = string.Empty;
            string noOfRecords = string.Empty;
            try
            {
                string query = String.Format(CultureInfo.CurrentCulture, SqlQuery.FetchXMLBuilderforAggregate(param));
                noOfRecords = await getCountOfRecordsBaseInfra.CallDynamicsRetrieveCount(query);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetCount failed for request payload with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Record count retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
            return Ok(noOfRecords);
        }

    }
}
