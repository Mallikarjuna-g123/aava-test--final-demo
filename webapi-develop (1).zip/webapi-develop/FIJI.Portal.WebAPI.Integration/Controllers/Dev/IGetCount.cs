﻿namespace FIJI.Portal.WebAPI.Integration.Controllers.Dev
{
    public interface IGetCount
    {
        Task<string> CallDynamicsRetrieveData(string accessToken, string entityName, string fetchxmlquery, string outputvariable, string serviceurl);
        
    }
}