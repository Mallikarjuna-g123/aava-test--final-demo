﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using FIJI.Portal.WebAPI.Integration.Model.Dev;
using FIJI.Portal.WebAPI.Integration.Utilities;

namespace FIJI.Portal.WebAPI.Integration.Controllers.Dev
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]

    public class DevController : Controller
    {
        public IGetCount igetCount;
        private readonly DevBaseInfra devBaseInfra;

        public DevController(IGetCount _count, Task<string> token)
        {
            igetCount = _count;
            devBaseInfra = new DevBaseInfra(null, token.Result);
        }
        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        /// <exception cref="HttpRequestException"></exception>
        [HttpGet(RouteConstants.RetrieveMultipleRecords)]
        public async Task<string> retrieveMultipleRecords(string entityName, string query, int? maxPageSize)
        {
            string retStr = string.Empty;
            try
            {
                retStr = devBaseInfra.retrieveMultipleRecords(entityName, query, maxPageSize).Result;

            }
            catch (Exception ex)
            {
                throw new HttpRequestException(ex.Message);
            }
            return retStr;
        }

        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="id"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        /// <exception cref="HttpRequestException"></exception>
        [HttpGet(RouteConstants.RetrieveRecord)]
        public async Task<string> retrieveRecord(string entityName, string id, string query)
        {
            string retStr = string.Empty;
            try
            {
                retStr = devBaseInfra.retrieveRecord(entityName, id, query).Result;
            }
            catch (Exception ex)
            {
                throw new HttpRequestException(ex.Message);
            }
            return retStr;
        }


        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="responseBody"></param>
        /// <returns></returns>
        /// <exception cref="HttpRequestException"></exception>
        [HttpPost(RouteConstants.CreateRecord)]
        public async Task<ObjectResult> createRecord(string entityName)
        {
            string retStr = string.Empty;
            try
            {
                StreamReader sr = new StreamReader(Request.Body);
                string body = await sr.ReadToEndAsync();
                retStr = await devBaseInfra.createRecord(entityName, body);
            }
            catch (Exception ex)
            {
                throw new HttpRequestException(ex.Message);
            }
            return Ok(new { id = retStr });
        }


        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="responseBody"></param>
        /// <returns></returns>
        /// <exception cref="HttpRequestException"></exception>
        [HttpPatch(RouteConstants.UpdateRecord)]
        public async Task<ObjectResult> updateRecord(string entityName, string id)
        {
            string retStr = string.Empty;
            try
            {
                StreamReader sr = new StreamReader(Request.Body);
                string body = await sr.ReadToEndAsync();
                retStr = await devBaseInfra.updateRecord(entityName, id, body);
            }
            catch (Exception ex)
            {
                throw new HttpRequestException(ex.Message);
            }
            return Ok(new { id = retStr });
        }

        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="responseBody"></param>
        /// <returns></returns>
        /// <exception cref="HttpRequestException"></exception>
        [HttpDelete(RouteConstants.DeleteRecord)]
        public async Task<ObjectResult> deleteRecord(string entityName, string id)
        {
            string retStr = string.Empty;
            try
            {
                retStr = await devBaseInfra.deleteRecord(entityName, id);
            }
            catch (Exception ex)
            {
                throw new HttpRequestException(ex.Message);
            }
            return Ok(new { id = id });
        }
    }
}
