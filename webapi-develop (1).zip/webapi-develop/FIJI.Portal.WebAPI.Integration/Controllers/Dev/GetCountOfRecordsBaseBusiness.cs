﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using FIJI.Portal.FileReception.Commons;

namespace FIJI.Portal.WebAPI.Integration.Controllers.Dev
{
    public class GetCountOfRecordsBaseBusiness : IGetCount
    {
        public GetCountOfRecordsBaseBusiness() { }

        public async Task<string> CallDynamicsRetrieveData(string accessToken, string entityName, string fetchxmlquery, string outputvariable, string serviceurl)
        {
            dynamic returnValue = new { };
            try
            {
                String sqlQuery = string.Empty;
                string outresponse = null;

                sqlQuery = Constants.Generic.ApiQuery + entityName + Constants.Generic.FetchXml + Uri.EscapeDataString(fetchxmlquery);
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Utilities.Constants.UserAgentHeaderValue);
                    client.BaseAddress = new Uri(serviceurl);
                    client.Timeout = new TimeSpan(0, 2, 0);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataMaxVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataVersion, Constants.Generic.Version4); client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(Constants.Generic.JsonApplication));
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, sqlQuery); //Set the access token
                    request.Headers.Authorization = new AuthenticationHeaderValue(Constants.Api.Bearer, accessToken);
                    HttpResponseMessage response = client.SendAsync(request).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        JObject obj = (JObject)JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                        var jsonbody = obj["value"];
                        Dictionary<string, string> lresponsedataset = new Dictionary<string, string>();
                        var str = outputvariable.Split(Constants.Generic.Comma);
                        foreach (var item in jsonbody.ToArray())
                        {
                            foreach (var outparm in str)
                            {
                                if (item[outparm] != null)
                                {
                                    outresponse = item[outparm].ToString();
                                    if (!lresponsedataset.ContainsKey(outparm))
                                    {
                                        lresponsedataset.Add(outparm, outresponse);
                                    }
                                }
                            }
                        }
                        returnValue.statecode = Convert.ToInt32(response.StatusCode);
                        returnValue.status = Constants.Generic.NoContent;
                        returnValue.data = lresponsedataset;
                    }
                    else
                    {
                        returnValue.statecode = Convert.ToInt32(response.StatusCode);
                        returnValue.status = response.ReasonPhrase;
                        returnValue.data = null;
                    }
                }
            }
            catch (Exception ex)
            {
                returnValue.statecode = Convert.ToInt32(HttpStatusCode.BadRequest);
                returnValue.status = ex.Message;
                returnValue.data = null;
            }
            return System.Text.Json.JsonSerializer.Serialize<dynamic>(returnValue);
        }

    }
}
