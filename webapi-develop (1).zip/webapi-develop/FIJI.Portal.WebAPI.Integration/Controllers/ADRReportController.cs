﻿using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.FileReception.Model;
using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Requests.IAMICT;
using FIJI.Portal.WebAPI.Integration.Service;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System.Text;
using Constants = FIJI.Portal.FileReception.Commons.Constants;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ADRReportController : Controller
    {

        private readonly ADRReport _aDRReportService;
        private readonly ILogger _logger;

        public ADRReportController(IOrganizationService dataverseService, ILogger<ADRReportController> logger)
        {
            this._aDRReportService = new ADRReport(dataverseService);
            this._logger = logger;
        }

        [HttpOptions(RouteConstants.UploadADRReport)]
        public IActionResult Options()
        {
            using (var reader = new StreamReader(Request.Body, Encoding.UTF8))
            {
                var webhookRequestOrigin = HttpContext.Request.Headers[Constants.Api.WebHookRequestOrigin].FirstOrDefault();
                var webhookRequestCallback = HttpContext.Request.Headers[Constants.Api.WebHookRequestCallback];
                var webhookRequestRate = HttpContext.Request.Headers[Constants.Api.WebHookRequestRate];
                HttpContext.Response.Headers.Append(Constants.Api.WebHookAllowedRate, Constants.Generic.Star);
                HttpContext.Response.Headers.Append(Constants.Api.WebHookAllowedOrigin, webhookRequestOrigin);
            }

            return Ok();
        }

        [HttpPost(RouteConstants.UploadADRReport)]
        public async Task<IActionResult> ADRReport()
        {
            try
            {
                StreamReader sr = new StreamReader(Request.Body);
                string body = await sr.ReadToEndAsync();
                _logger.LogInformation("ADR report webhook received with payload length {PayloadLength}", body.Length);

                List<QueueMessage> messages = JsonConvert.DeserializeObject<List<QueueMessage>>(body);
                QueueMessage message = messages.FirstOrDefault();

                if (message != null && !string.IsNullOrEmpty(message?.Data?.BlobUrl))
                {
                    string? folderName = _aDRReportService.ExtractFolderName(message.Data?.BlobUrl);
                    if (folderName == Constants.Generic.DeviceRegistrationReportFolder && message.Data.Api == Constants.Api.SftpCommit)
                    {
                        var urlSegments = message?.Data?.BlobUrl?.Split('/') ?? Array.Empty<string>();
                        string customerId = string.Empty;
                        if (urlSegments.Length > 0)
                        {
                            string fileName = urlSegments[^1]; // Get the last element (file name)
                            var parts = fileName.Split('_');
                            if (parts.Length >= 2)
                            {
                                customerId = parts[1];
                                _logger.LogInformation("ADR report payload resolved customer identifier for report processing");
                            }

                            if (!string.IsNullOrEmpty(customerId))
                            {
                                List<string> movedFiles = await _aDRReportService.ProcessADRReportsAsync(customerId, message?.Data?.BlobUrl, fileName);
                                _logger.LogInformation("ADR report payload processed successfully for customer identifier {CustomerId} with correlation ID {CorrelationID}", customerId, HttpContext.TraceIdentifier);
                                return Ok(new { message = Constants.Generic.FileProcessed, movedFiles });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ADR report processing failed with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = Constants.Generic.ErrorProcessingReports, correlationId = HttpContext.TraceIdentifier });
            }
            return StatusCode(200);
        }

        [HttpPost(RouteConstants.GetDownloadADRReportUrl)]
        [Authorize]
        public IActionResult GetDownloadUrl(GetDownloadUrlRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.FileUrl))
                    return new BadRequestObjectResult(Constants.Generic.EmptyFileURL);

                string storageAccountName = Environment.GetEnvironmentVariable(Constants.Generic.AzureADRReportStorageAccount);
                StorageAccountHelper storageHelper = new StorageAccountHelper(storageAccountName, null);

                return new OkObjectResult(new
                {
                    DownloadUrl = storageHelper.GetDownloadUrl($"https://{IAMICTController.GetHostUrl(Request)}/IAMICT/download", new Uri(request.FileUrl))
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ADR report download URL generation failed with correlation {CorrelationId}", HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = Constants.Generic.ErrorProcessingReports, correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpPost(RouteConstants.CreateCustomerFolder)]
        public async Task<IActionResult> CreateCustomerFolder()
        {
            try
            {
                StreamReader sr = new StreamReader(Request.Body);
                string customerAccountNumber = await sr.ReadToEndAsync();
                if (string.IsNullOrEmpty(customerAccountNumber))
                    return new BadRequestObjectResult(Constants.Generic.EmptyCustomerAccountNumber);

                return new OkObjectResult(new
                {
                    FolderCreated = _aDRReportService.CreateCustomerFolder(customerAccountNumber)
                });

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateCustomerFolder failed with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = Constants.Generic.ErrorProcessingReports, correlationId = HttpContext.TraceIdentifier });
            }
        }

    }
}
