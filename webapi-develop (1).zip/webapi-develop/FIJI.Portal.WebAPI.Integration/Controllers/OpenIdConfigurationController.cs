﻿using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route(RouteConstants.OpenIdConfiguration)]
    public class OpenIdConfigurationController : Controller
    {
        private StorageAccountHelper _storageAccountHelper;
        private readonly ILogger<OpenIdConfigurationController> _logger;

        public OpenIdConfigurationController(StorageAccountHelper storageHelper, ILogger<OpenIdConfigurationController> logger)
        {
            _storageAccountHelper = storageHelper;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> OpenIdConfiguration()
        {
            try
            {
                return new OkObjectResult(await _storageAccountHelper.LoadPortalOpenIdConfiguration());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "OpenIdConfiguration retrieval failed with correlation {CorrelationId}", HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "OpenID configuration retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
