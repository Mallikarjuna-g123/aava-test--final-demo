﻿using FIJI.Portal.WebAPI.Integration.Model.Generic;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class DissociateController : Controller
    {
        private readonly DissociateRecords dissociateRecordsInfra;
        private readonly ILogger<DissociateController> _logger;

        public DissociateController(IOrganizationService dataverseService, ILogger<DissociateController> logger)
        {
            dissociateRecordsInfra = new DissociateRecords(dataverseService);
            _logger = logger;
        }


        [HttpPost(RouteConstants.Execute)]
        public IActionResult Execute(Requests.AssociateDissociateRecordsRequest request)
        {
            try
            {
                dissociateRecordsInfra.Execute(request);
            }
            catch (Exception ex)
            {
                if (!ex.Message.Contains(Constants.ErrorMessages.DuplicateKey))
                {
                    _logger.LogError(ex, "Dissociate execute failed for request {Request} with correlation ID {CorrelationID}", request, HttpContext.TraceIdentifier);
                    return StatusCode(500, new { error = "Dissociation failed.", correlationId = HttpContext.TraceIdentifier });
                }
            }
            return Ok(new { Status = Constants.ResponseMessages.Ok });
        }
    }
}
