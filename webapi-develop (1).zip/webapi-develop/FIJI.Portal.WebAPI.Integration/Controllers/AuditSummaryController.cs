﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses.AuditSummary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{

    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class AuditSummaryController : Controller
    {
        private readonly AuditSummary _AuditSummary;
        private readonly ILogger<AuditSummaryController> _logger;

        public AuditSummaryController(IOrganizationService dataverseService, IMemoryCache cache, ILogger<AuditSummaryController> logger)
        {
            this._AuditSummary = new AuditSummary(dataverseService);
            _logger = logger;
        }

        [HttpPost("AuditSummary")]
        public IActionResult AuditSummary(AuditSummaryRequest request)
        {
            try
            {
                string entityName = request.EntityName ?? "fiji_billofmaterials";
                int timeRange = request.TimeRange ?? 1;
                string excludeUser = request.ExcludeUser ?? string.Empty;
                AuditSummaryResponse response = new AuditSummaryResponse();
                response = _AuditSummary.GetAuditSummary(entityName, timeRange, excludeUser);

                if (response.Error != null)
                {
                    return BadRequest(response);
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AuditSummary failed for entity {EntityName}, time range {TimeRange}, exclude user {ExcludeUser} with correlation ID {CorrelationID}", request?.EntityName, request?.TimeRange, request?.ExcludeUser, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Audit summary retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
