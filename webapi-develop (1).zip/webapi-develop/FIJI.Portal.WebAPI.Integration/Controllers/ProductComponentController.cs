using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Model.Generic;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Responses.ProductComponent;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json.Linq;
using System.Globalization;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]

    public class ProductComponentController : Controller
    {
        private readonly RetrieveMultiple retrieveMultipleBaseInfra;
        private readonly ProductComponent _productcomponentServie;
        private readonly GetCountOfRecords getCountOfRecordsBaseInfra;
        private readonly ILogger _logger;
        public ProductComponentController(IOrganizationService dataverseService, IMemoryCache cache, ILogger<ProductComponentController> logger, ILoggerFactory loggerFactory)
        {
            this.retrieveMultipleBaseInfra = new RetrieveMultiple(dataverseService);

            _productcomponentServie = new ProductComponent(dataverseService, cache, loggerFactory.CreateLogger<ProductComponent>());
            this.getCountOfRecordsBaseInfra = new GetCountOfRecords(dataverseService);
            _logger = logger;
        }

        [HttpPost(RouteConstants.GetProductComponents)]
        public async Task<IActionResult> GetProductComponents()
        {
            try
            {
                StreamReader sr = new StreamReader(Request.Body);
                string param = await sr.ReadToEndAsync();
                if (!string.IsNullOrEmpty(param))
                {
                    List<Model.ProductComponent> returnValue = new List<Model.ProductComponent>();

                    EntityCollection genericPCs = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.PCFetchXmlBuilder(param, Constants.GenericProductComponents));
                    var genericComponentTypeIds = genericPCs?.Entities?.Select(service => (Guid?)Utils.GetValue<AliasedValue>(service, "compType.fiji_componenttypeid")?.Value)?.Distinct();
                    if (genericComponentTypeIds?.Count() > 0)
                    {
                        EntityCollection preDefinedPCs = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.PCFetchXmlBuilder(param, Constants.PreDefinedAndPlaceholderProductComponents, genericComponentTypeIds.ToList()));
                        if (preDefinedPCs?.Entities?.Count > 0)
                            genericPCs?.Entities.AddRange(preDefinedPCs.Entities);
                    }

                    List<Entity> orderedList = OrderList(genericPCs);

                    if (orderedList != null && orderedList.Count > 0)
                    {
                        var ctId = new List<string>();
                        var index = 0;
                        ctId = orderedList.Select(item => Utils.GetValue<AliasedValue>(item, "compType.fiji_componenttypeid")?.Value.ToString()).ToList();
                        EntityCollection ctCollection = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.IncompatibleCTFetchXmlBuilder(ctId));

                        var incompatibleServiceCollection = ctCollection != null ? ctCollection.Entities.GroupBy(
                                item => item.Id,
                                item => Utils.GetValue<AliasedValue>(item, "inc.fiji_componenttypeid")?.Value.ToString()
                                ) : null;

                        //Dependent services
                        EntityCollection dgiCTCollection = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.DependentCTFetchXmlBuilder(ctId));
                        var dependentServiceCollection = dgiCTCollection != null ? dgiCTCollection.Entities.GroupBy(
                                item => item.Id
                                ) : null;
                        var dependentServicesList = new List<Model.DependencyGroup>();
                        if (dependentServiceCollection != null)
                        {
                            foreach (var dg in dependentServiceCollection)
                            {
                                var dependentServices = new Model.DependencyGroup();
                                dependentServices.ctId = dg.Key.ToString();
                                dependentServices.groupCondition = Utils.GetValue<string>(dg.First(), "DG.fiji_condition", true);
                                var dependencyGroupList = dg.ToList().GroupBy(
                                    item => Utils.GetValue<AliasedValue>(item, "DGI.fiji_dependency_group_itemid")?.Value.ToString()
                                    );
                                dependentServices.dependentItems = new List<Model.DependencyGroupItem>();
                                foreach (var item in dependencyGroupList)
                                {
                                    var dgi = new Model.DependencyGroupItem();
                                    var ct = new List<string>();
                                    dgi.itemCondition = Utils.GetValue<string>(item.First(), "DGI.fiji_condition", true);
                                    foreach (var ctItem in item)
                                    {
                                        ct.Add(Utils.GetValue<AliasedValue>(ctItem, "CT2.fiji_componenttypeid")?.Value.ToString());

                                    }
                                    dgi.dependentCIds = ct;
                                    dependentServices.dependentItems.Add(dgi);

                                }
                                dependentServicesList.Add(dependentServices);
                            }

                        }
                        foreach (Entity item in orderedList)
                        {
                            Model.ProductComponent newitem = new Model.ProductComponent
                            {
                                Id = item.Id,
                                Name = Utils.GetValue<string>(item, "fiji_name"),
                                ExternalId = Utils.GetValue<string>(item, "fiji_externalid"),
                                ServiceTypeGlobal = Utils.GetValue<OptionSetValue>(item, "fiji_servicetypeglobal")?.Value,
                                MaterialProductLine = Utils.GetValue<string>(item, "fiji_materialproductline"),
                                StatusCode = Utils.GetValue<OptionSetValue>(item, "statuscode")?.Value,
                                PortalDescription = Utils.GetValue<string>(item, "fiji_portaldescription") ?? null,
                                ComponentType = new Model.ComponentType
                                {
                                    Id = (Guid?)(Utils.GetValue<AliasedValue>(item, "compType.fiji_componenttypeid")?.Value),
                                    PortalDescription = Utils.GetValue<AliasedValue>(item, "compType.fiji_portal_description")?.Value.ToString(),
                                    ServiceCategory = Utils.GetValue<string>(item, "compType.fiji_service_category", true),
                                    CanBeAddedMultipleTimesDifConfig = (bool?)Utils.GetValue<AliasedValue>(item, "compType.fiji_can_be_added_multiple_times_dif_confg")?.Value,
                                    IsConfigurable = (bool?)Utils.GetValue<AliasedValue>(item, "compType.fiji_is_configurable")?.Value,
                                    ServiceNumber = Utils.GetValue<AliasedValue>(item, "compType.fiji_servicenumber")?.Value.ToString(),
                                    IncompatibleService = new List<string>(),
                                    DependentService = new Model.DependencyGroup(),
                                    EnableReuse = (bool?)Utils.GetValue<AliasedValue>(item, "compType.fiji_enable_reuse")?.Value,
                                    StatusCode = ((OptionSetValue?)(Utils.GetValue<AliasedValue>(item, "compType.statuscode")?.Value))?.Value,
                                    CanBeUsedAcrossCustomer = (bool?)Utils.GetValue<AliasedValue>(item, "compType.fiji_can_be_used_across_customer")?.Value
                                }
                            };

                            if (item.Contains("getmore.fiji_componenttypeid"))
                            {
                                newitem.ComponentType.GetMoreService = new ComponentType()
                                {
                                    Id = ((Guid)(Utils.GetValue<AliasedValue>(item, "getmore.fiji_componenttypeid")?.Value)),
                                    PortalDescription = Utils.GetValue<AliasedValue>(item, "getmore.fiji_portal_description")?.Value.ToString(),
                                    StatusCode = ((OptionSetValue?)(Utils.GetValue<AliasedValue>(item, "getmore.statuscode")?.Value))?.Value,
                                    IsConfigurable = (bool?)Utils.GetValue<AliasedValue>(item, "getmore.fiji_is_configurable")?.Value,
                                    EnableReuse = (bool?)Utils.GetValue<AliasedValue>(item, "getmore.fiji_enable_reuse")?.Value,
                                    ServiceNumber = Utils.GetValue<AliasedValue>(item, "getmore.fiji_servicenumber")?.Value.ToString(),
                                };
                            }


                            returnValue.Add(newitem);

                            if (incompatibleServiceCollection != null && incompatibleServiceCollection.ToList().Exists(l => l.Key == returnValue[index].ComponentType.Id) == true)
                            {
                                var i = incompatibleServiceCollection.ToList().FindIndex(i => i.Key == returnValue[index].ComponentType.Id);
                                foreach (var value in incompatibleServiceCollection.ToList()[i])
                                {
                                    returnValue[index].ComponentType.IncompatibleService.Add(value);
                                }
                            }
                            if (dependentServicesList != null && dependentServicesList.Exists(l => l.ctId == returnValue[index].ComponentType.Id.ToString()) == true)
                            {
                                var i = dependentServicesList.FindIndex(i => i.ctId == returnValue[index].ComponentType.Id.ToString());
                                returnValue[index].ComponentType.DependentService = dependentServicesList[i];
                            }
                            index++;
                        }
                    }

                    return Ok(returnValue);
                }
                else
                {
                    _logger.LogError("Error to load Product Components with correlation ID {CorrelationID}- {Error}", HttpContext.TraceIdentifier, Constants.ErrorMessages.EmptyParams);
                    return BadRequest(Constants.ErrorMessages.EmptyParams);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error to load Product Components with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return BadRequest(new { error = "Product components retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }

        }

        [HttpPost(RouteConstants.GetCustomerSpecificProductComponents)]
        public async Task<IActionResult> GetCustomerSpecificProductComponents()
        {
            StreamReader sr = new StreamReader(Request.Body);
            string param = await sr.ReadToEndAsync();

            var noOfRecords = string.Empty;

            if (!string.IsNullOrEmpty(param))
            {
                JObject response = null;
                JObject filteredCount = null;

                try
                {
                    JObject jObj = JObject.Parse(param);
                    if ((bool)jObj["ShowAllModels"] == false)
                    {
                        List<CustomerSpecificProductComponents> customerSpecificProductComponents = await _productcomponentServie.GetCustomerSpecificProductComponents(param);

                        //get count of records - using aggregate specific to this query
                        string query = String.Format(CultureInfo.CurrentCulture, SqlQuery.GetSpecificPCFetchXmlBuilderforAggregate(param));
                        noOfRecords = await getCountOfRecordsBaseInfra.CallDynamicsRetrieveCount(query);
                        response = JObject.Parse(noOfRecords);

                        response.Add(Constants.Result, System.Text.Json.JsonSerializer.Serialize(customerSpecificProductComponents));
                    }
                    else if ((bool)jObj["ShowAllModels"] == true)
                    {
                        const int pageSize = 20;
                        int pageNumber = 1; // Default page number

                        if (jObj.ContainsKey("pageNumber") && jObj["pageNumber"] != null && int.TryParse(jObj["pageNumber"].ToString(), out int parsedPageNumber))
                        {
                            pageNumber = parsedPageNumber;
                        }

                        List<CustomerSpecificProductComponents> customerSpecificProductComponents = await _productcomponentServie.GetCustomerSpecificProductComponentsWithExtendedModels(param);

                        // Apply Pagination
                        var paginatedRecords = customerSpecificProductComponents.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

                        // Get total count
                        int totalRecords = customerSpecificProductComponents.Count;
                        int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                        response = new JObject
                        {
                            [Constants.Count] = totalRecords,
                            [Constants.Result] = System.Text.Json.JsonSerializer.Serialize(paginatedRecords)
                        };
                    }
                    else
                    {
                        response = new JObject
                        {
                            [Constants.Count] = 0,
                            [Constants.Result] = Constants.ErrorMessages.NoRecord
                        };
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "GetCustomerSpecificProductComponents failed for request payload with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                    return BadRequest(new { error = "Customer-specific product component retrieval failed.", correlationId = HttpContext.TraceIdentifier });
                }
                return Ok(response.ToString());
            }
            else
            {
                return BadRequest(Constants.ErrorMessages.EmptyParams);
            }
        }

        [HttpPost(RouteConstants.GetCSAVToPreSelectBasedOnOCCID)]
        public async Task<IActionResult> GetCSAVToPreSelectBasedOnOCCID()
        {
            StreamReader sr = new StreamReader(Request.Body);
            string param = await sr.ReadToEndAsync();
            if (!string.IsNullOrEmpty(param))
            {
                List<Model.ProductComponent> returnValue = new List<Model.ProductComponent>();
                try
                {
                    JObject jObj = JObject.Parse(param);
                    string? customerId = (string?)jObj["customerId"];
                    if (string.IsNullOrWhiteSpace(customerId))
                        return BadRequest(Constants.ErrorMessages.EmptyCustomerId);

                    EntityCollection customerSpecificPCs = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.PCCSAVFetchXmlBuilder(param));
                    if (customerSpecificPCs?.Entities?.Count > 0)
                    {
                        var groupedByProductComponent = customerSpecificPCs.Entities.GroupBy(x => x["fiji_productcomponentid"]);
                        if (groupedByProductComponent?.Count() > 0)
                        {
                            foreach (var serviceGroup in groupedByProductComponent)
                            {
                                if (serviceGroup == null || serviceGroup.Count() == 0)
                                    continue;

                                Entity firstService = serviceGroup.FirstOrDefault();

                                returnValue.Add(new Model.ProductComponent
                                {
                                    Id = serviceGroup.FirstOrDefault()?.Id,
                                    Name = Utils.GetValue<string>(firstService, "fiji_name"),
                                    ExternalId = Utils.GetValue<string>(firstService, "fiji_externalid"),
                                    ServiceTypeGlobal = Utils.GetValue<OptionSetValue>(firstService, "fiji_servicetypeglobal")?.Value,
                                    StateCode = Utils.GetValue<OptionSetValue>(firstService, "statecode")?.Value,
                                    StatusCode = Utils.GetValue<OptionSetValue>(firstService, "statuscode")?.Value,
                                    PortalDescription = Utils.GetValue<string>(firstService, "fiji_portaldescription") ?? null,
                                    ComponentType = new Model.ComponentType
                                    {
                                        Id = Utils.GetValue<EntityReference>(firstService, "fiji_componenttype")?.Id,
                                        ServiceNumber = Utils.GetValue<AliasedValue>(firstService, "compType.fiji_servicenumber")?.Value.ToString(),
                                        PortalDescription = Utils.GetValue<AliasedValue>(firstService, "compType.fiji_portal_description")?.Value.ToString(),
                                    }
                                });

                                if (!serviceGroup.Any(x => x.Contains("customer.accountid")))
                                    continue;

                                returnValue.Last().CustomerList = serviceGroup.Select(service => new Account
                                {
                                    Id = (Guid?)(Utils.GetValue<AliasedValue>(service, "customer.accountid")?.Value)
                                }).ToList();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "GetCSAVToPreSelectBasedOnOCCID failed for request payload with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                    return BadRequest(new { error = "CSAV preselection retrieval failed.", correlationId = HttpContext.TraceIdentifier });
                }
                return Ok(returnValue);
            }
            else
            {
                _logger.LogError("GetCSAVToPreSelectBasedOnOCCID failed for request payload with correlation ID {CorrelationID} - {Error}", HttpContext.TraceIdentifier, Constants.ErrorMessages.EmptyParams);
                return BadRequest(Constants.ErrorMessages.EmptyParams);
            }
        }

        private List<Entity> OrderList(EntityCollection productComponentList)
        {
            if (productComponentList == null || productComponentList?.Entities.Count == 0)
                return new List<Entity>();

            var groupByServiceCategory = productComponentList.Entities.GroupBy(x => x.GetAttributeValue<AliasedValue>("svcCategory.fiji_name")?.Value ?? "");
            if (!groupByServiceCategory.Any())
                return productComponentList.Entities.ToList();

            var orderedServiceCategoryGroup = groupByServiceCategory.OrderBy(group => group.First()?.GetAttributeValue<AliasedValue>("svcCategory.fiji_portal_display_order")?.Value);
            if (!orderedServiceCategoryGroup.Any())
                return productComponentList.Entities.ToList();

            var orderedList = new List<List<Entity>>();
            foreach (var item in orderedServiceCategoryGroup)
            {
                var orderByComponentTypeDisplayOrder = item.Where(service => service.Contains("compType.fiji_portal_display_order"))
                                                                    .OrderBy(service => (int)service.GetAttributeValue<AliasedValue>("compType.fiji_portal_display_order").Value).ToList();

                var orderByComponentTypeName = item.Where(service => !service.Contains("compType.fiji_portal_display_order"))
                                                                .OrderBy(service => (string?)service.GetAttributeValue<AliasedValue>("compType.fiji_name")?.Value ?? "").ToList();

                if (orderByComponentTypeName.Count > 0)
                    orderByComponentTypeDisplayOrder.AddRange(orderByComponentTypeName);

                orderedList.Add(orderByComponentTypeDisplayOrder);
            }

            var result = orderedList.SelectMany(item => item).ToList();
            return result;
        }

        // This Web API endpoint is used to create product component and realted records
        [HttpPost(RouteConstants.ConfigureNew)]
        [ProducesResponseType(typeof(ProductComponentResponse), 201)]
        public async Task<IActionResult> ConfigureNew(Requests.ProductComponentRequest value)
        {
            try
            {
                ProductComponentResponse response = new ProductComponentResponse();
                response = _productcomponentServie.CreateProductComponent(value);
                if (response.Error != null)
                {
                    _logger.LogError("ConfigureNew failed for request {Request} with correlation ID {CorrelationID} - {Error}", value, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }
                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ConfigureNew failed for request {Request} with correlation ID {CorrelationID}", value, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Product component creation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // The web API to Duplicate Product Component
        [HttpPost(RouteConstants.Duplicate)]
        [ProducesResponseType(typeof(Responses.ProductComponent.ProductComponent_DuplicateResponse), 201)]
        public async Task<IActionResult> Duplicate(Requests.ProductComponent.ProductComponent_Duplicate_Request value)
        {
            try
            {
                ProductComponent_DuplicateResponse response = new ProductComponent_DuplicateResponse();
                response = _productcomponentServie.Duplicate(value);
                if (response.Error != null)
                {
                    _logger.LogError("Duplicate failed for request {Request} with correlation ID {CorrelationID} - {Error}", value, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }
                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Duplicate failed for request {Request} with correlation ID {CorrelationID}", value, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Product component duplication failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // This Web API endpoint is used to get Bios Configuration details
        [HttpPost(RouteConstants.GetBiosConfigDetails)]
        [ProducesResponseType(typeof(Responses.ProductComponent.ProductComponent_GetBiosConfigDetails_Response), 201)]
        public async Task<IActionResult> GetBiosConfigDetails(Requests.ProductComponent.ProductComponent_GetBiosConfigDetails_Request request)
        {
            ProductComponent_GetBiosConfigDetails_Response response = new();
            try
            {
                var ConfigDetails = await _productcomponentServie.GetBiosConfigDetails(request);
                string responseBody = await ConfigDetails.Content.ReadAsStringAsync();

                if (ConfigDetails.IsSuccessStatusCode)
                {
                    dynamic json = JToken.Parse(responseBody);
                    response.BiosConfigDetails = json.ToString();
                    return Created(string.Empty, response);
                }
                else if (ConfigDetails.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    response.Error = responseBody;
                    _logger.LogError("GetBiosConfigDetails failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }
                else
                {
                    response.Error = responseBody;
                    _logger.LogError("GetBiosConfigDetails failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, response.Error);
                    return StatusCode(500, response);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetBiosConfigDetails failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "BIOS configuration retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // The web API to remove Associated model
        [HttpPost(RouteConstants.RemoveModel)]
        public async Task<IActionResult> RemoveAssociatedModel(Requests.ProductComponent_RemoveAssociatedModel request)
        {
            try
            {
                var response = _productcomponentServie.RemoveAssociatedModel(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RemoveAssociatedModel failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, ex.Message);
                return BadRequest(new { error = "Associated model removal failed.", correlationId = HttpContext.TraceIdentifier });
            }

        }

        // The web API to clear AY103AV Non-BCU comparison
        [HttpPost(RouteConstants.ClearComparison)]
        public async Task<IActionResult> ClearComparison(Requests.ProductComponent_ClearComparisonModel request)
        {
            try
            {
                var response = await _productcomponentServie.ClearComparison(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ClearComparison failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, ex.Message);
                return BadRequest(new { error = "Comparison clear failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // The web API to create CSAV with new platform
        [HttpPost(RouteConstants.DuplicateV1)]
        public async Task<IActionResult> DuplicateV1(Requests.ProductComponent_DuplicateV1_Request request)
        {
            try
            {
                ProductComponent_DuplicateV1Response response = new ProductComponent_DuplicateV1Response();
                response = _productcomponentServie.DuplicateV1(request);
                if (response.Error != null)
                {
                    _logger.LogError("DuplicateV1 failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }
                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DuplicateV1 failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Product component duplication failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        // The web API to Get Header Details
        [HttpPost(RouteConstants.GetHeaderDetails)]
        public async Task<IActionResult> GetHeaderDetails(Requests.ProductComponent_HeaderDetails_Request request)
        {
            try
            {
                ProductComponent_HeaderDetails_Response response = new ProductComponent_HeaderDetails_Response();
                response = _productcomponentServie.GetHeaderDetails(request);
                if (response.Error != null)
                {
                    _logger.LogError("GetHeaderDetails failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetHeaderDetails failed for request {Request} with correlation ID {CorrelationID} - {Error}", request, HttpContext.TraceIdentifier, ex.Message);
                return StatusCode(500, new { error = "Header details retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpPost(RouteConstants.CreateNewService)]
        public IActionResult CreateNewService([FromBody] Requests.ProductComponentRequest request)
        {
            try
            {
                var response = _productcomponentServie.CreateNewService(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateNewService failed with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Service creation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
