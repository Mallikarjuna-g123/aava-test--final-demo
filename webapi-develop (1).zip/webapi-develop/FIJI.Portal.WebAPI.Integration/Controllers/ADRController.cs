﻿using FIJI.Portal.WebAPI.Integration.Integration;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class ADRController : Controller
    {
        private readonly ADRConsent ADRBaseInfra;
        private readonly IOrganizationService _dataverseClient;
        private readonly ILogger<ADRController> _logger;
        private readonly IConfiguration _configuration;
        public ADRController(IOrganizationService dataverseClient, IMemoryCache cache, IHttpClientFactory httpClientFactory, IConfiguration configuration, ILogger<ADRController> logger)
        {
            var httpClient = httpClientFactory.CreateClient("ADRConsent");
            httpClient.DefaultRequestHeaders.UserAgent.ParseAdd(Constants.UserAgentHeaderValue);
            ADRBaseInfra = new ADRConsent(dataverseClient, cache, httpClient, configuration);
            _dataverseClient = dataverseClient;
            _logger = logger;
        }

        [HttpPost(RouteConstants.CheckTenantConsent)]
        public async Task<IActionResult> CheckTenantConsent(CheckTenantConsentRequest request)
        {
            string requestJson = JsonConvert.SerializeObject(request);

            try
            {
                if (request == null || string.IsNullOrWhiteSpace(request.TenantId) || string.IsNullOrWhiteSpace(request.TenantDomain))
                {
                    string validationMessage = "TenantId and TenantDomain are required";
                    Utils.WebApiTransactionLog(_dataverseClient, "ADR Check Tenant Consent", requestJson, validationMessage, "Validation failed");
                    return BadRequest(validationMessage);
                }

                if (!Guid.TryParse(request.TenantId, out _))
                {
                    string validationMessage = "TenantId must be a valid GUID";
                    Utils.WebApiTransactionLog(_dataverseClient, "ADR Check Tenant Consent", requestJson, validationMessage, "Validation failed");
                    return BadRequest(validationMessage);
                }

                var result = await ADRBaseInfra.CheckTenantConsent(request);
                string responseJson = JsonConvert.SerializeObject(result);
                Utils.WebApiTransactionLog(_dataverseClient, "ADR Check Tenant Consent", requestJson, responseJson, result.ConsentConfirmed ? "Consent confirmed" : "Consent not confirmed");

                return Ok(new
                {
                    consentConfirmed = result.ConsentConfirmed,
                    result
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ADR CheckTenantConsent failed with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                Utils.WebApiTransactionLog(_dataverseClient, "ADR Check Tenant Consent", requestJson, string.Empty, ex.Message);

                return BadRequest(new
                {

                    message = ex.Message,
                    correlationId = HttpContext.TraceIdentifier
                });
            }
        }
    }
}