﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Responses.Customer;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class CustomerController : Controller
    {
        private readonly Contact _contactService;
        private readonly ILogger<CustomerController> _logger;
        //private readonly Account _accountService;
        private readonly string _token;

        public CustomerController(IOrganizationService dataverseService, IMemoryCache cache, ILogger<CustomerController> logger, Task<string> token)
        {
            this._contactService = new Contact(dataverseService, cache);
            _logger = logger;
            _token = token.Result;
            //this._accountService = new Account(dataverseService);
        }

        //An  API to list the requests by Customer
        [HttpPost(RouteConstants.CustomerRequest)]
        [ProducesResponseType(typeof(CustomerRequestPayloadResponse), 201)]
        public async Task<IActionResult> CustomerRequest(Requests.Customer.CustomerRequestPayloadRequest request)
        {
            CustomerRequestPayloadResponse response = new CustomerRequestPayloadResponse();
            try
            {
                response = _contactService.GetRequestListbyCustomer(request);

                if (response.Error != null)
                {
                    _logger.LogError("CustomerRequest failed for request {Request} with correlation ID {CorrelationID}. Error: {Error}", request, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CustomerRequest failed for request {Request} with correlation ID {CorrelationID}", request, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Customer request retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }


        //An  API to list the Services by Customer
        [HttpPost(RouteConstants.CustomerServices)]
        [ProducesResponseType(typeof(CustomerServicesResponse), 201)]
        public async Task<IActionResult> CustomerServices(Requests.Customer.CustomerServicesRequest request)
        {
            CustomerServicesResponse response = new CustomerServicesResponse();
            try
            {
                response = _contactService.GetServicesListbyCustomer(request);

                if (response.Error != null)
                {
                    _logger.LogError("CustomerServices failed for request {Request} with correlation ID {CorrelationID}. Error: {Error}", request, HttpContext.TraceIdentifier, response.Error);
                    return BadRequest(response);
                }

                return Created("", response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CustomerServices failed for request {Request} with correlation ID {CorrelationID}", request, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Customer services retrieval failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        //[HttpPost(RouteConstants.CreateFileContainer)]
        //public async Task<IActionResult> CreateFileContainer(string? accountId)
        //{
        //    try
        //    {

        //        string folderCreated = await _accountService.InitiateCreateFolder(accountId);

        //        return new OkObjectResult(new
        //        {
        //            FolderCreated = folderCreated
        //        });

        //    }
        //    catch (Exception ex)
        //    {
        //        return new BadRequestObjectResult(ex);
        //    }
        //}

        [HttpGet(RouteConstants.GetFSPMUsingCustomerID)]
        public async Task<IActionResult> GetFSPMUsingCustomerID(string customerId)
        {
            try
            {
                var fspmUser = _contactService.GetFSPMUsingCustomerID(customerId, _token);
                if (fspmUser == null)
                {
                    _logger.LogInformation("GetFSPMUsingCustomerID failed for customerId {CustomerId} with correlation ID {CorrelationID} - {Error}", customerId, HttpContext.TraceIdentifier, "FSPM User not found");
                    return Ok("");
                }
                return Ok(fspmUser);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetFSPMUsingCustomerID failed for customerId {CustomerId} with correlation ID {CorrelationID}", customerId, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Retrieving FSPM user failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [HttpGet(RouteConstants.FetchVolumeLicenseManager)]
        public async Task<IActionResult> FetchVolumeLicenseManager(string customerId)
        {
            try
            {
                var vlmColl = _contactService.FetchVolumeLicenseManager(customerId, _token);
                if (vlmColl == null)
                {
                    _logger.LogInformation("FetchVolumeLicenseManager failed for customerId {CustomerId} with correlation ID {CorrelationID} - {Error}", customerId, HttpContext.TraceIdentifier, "VLM Collection not found");
                    return Ok("");
                }
                return Ok(vlmColl);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "FetchVolumeLicenseManager failed for customerId {CustomerId} with correlation ID {CorrelationID}", customerId, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "Retrieving VLM collection failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }
    }
}
