﻿using Azure.Storage.Blobs;
using Azure;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.FileReception.Commons.Model;
using FIJI.Portal.WebAPI.Integration.Requests.IAMICT;
using FIJI.Portal.WebAPI.Integration.Responses.IAMICT;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Constants = FIJI.Portal.FileReception.Commons.Constants;

using System.Xml;
using Microsoft.Crm.Sdk.Messages;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "IAM & ICT")]

    public class IAMICTController : Controller
    {
        private StorageAccountHelper _storageAccountHelper;
        private ServiceClient _dataverseService;
        private FileReceptionNotification _fileReception;
        private readonly ILogger<IAMICTController> _logger;


        public IAMICTController(StorageAccountHelper storageHelper, ServiceClient dataverseService, FileReceptionNotification fileReception, ILogger<IAMICTController> logger)
        {
            _storageAccountHelper = storageHelper;
            _dataverseService = dataverseService;
            _fileReception = fileReception;
            _logger = logger;
        }

        internal static string? GetHostUrl(HttpRequest request) => request.Headers["X-Forwarded-Host"].FirstOrDefault() ?? request.Host.Value;


        [HttpGet(RouteConstants.Download)]
        [HttpHead(RouteConstants.Download)]
        [HttpPost(RouteConstants.Download)]
        public async Task<IActionResult> Download(string container, string file, CancellationToken ct)
        {
            Response.Headers.AcceptRanges = "bytes";
            Response.Headers.ETag = Utilities.Constants.ImmutableEtag;
            Response.Headers.CacheControl = Utilities.Constants.CacheControl;

            if (string.IsNullOrEmpty(file))
                return NotFound();

            try
            {
                string adrStorageAccount = string.Empty;
                if (container.Equals(Constants.Generic.ADRContainer))
                {
                    adrStorageAccount = Environment.GetEnvironmentVariable(Constants.Generic.AzureADRReportStorageAccount);
                    var blob = await _storageAccountHelper.DownloadADRStreamingAsync(container, file, ct, adrStorageAccount);
                    return new Utilities.BlobStreamResult(file, blob.GetRawResponse().Status, blob);
                }
                else
                {
                    var blob = await _storageAccountHelper.DownloadStreamingAsync(container, file, ct);
                    return new Utilities.BlobStreamResult(file, blob.GetRawResponse().Status, blob);
                }
            }
            catch (RequestFailedException ex) when (ex.Status == StatusCodes.Status404NotFound)
            {
                Response.Headers.Clear();
                return NotFound();
            }
        }

        
        [Authorize]
        [HttpPut(RouteConstants.UploadIAM)]
        public async Task<IActionResult> Upload(string container, string comp, string file, string? blockid)
        {

            if (string.IsNullOrEmpty(comp))
                return BadRequest("Comp not provided!");

            if (string.IsNullOrEmpty(file))
                return BadRequest("File not provided!");

            try
            {
                if (comp == "block")
                {
                    if (string.IsNullOrEmpty(blockid))
                        return BadRequest("Blockid not provided!");

                    StreamContent sr = new StreamContent(Request.Body);
                    MemoryStream mem = new MemoryStream(await sr.ReadAsByteArrayAsync());
                    await _storageAccountHelper.StageBlock(container, file, mem, blockid);
                }

                else if (comp == "blocklist")
                {
                    StreamReader sr = new StreamReader(Request.Body);
                    string xmlBlock = await sr.ReadToEndAsync();
                    if (string.IsNullOrEmpty(xmlBlock))
                        return BadRequest("BlockList not provided!");

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(xmlBlock);

                    List<string> blockList = new List<string>();

                    foreach (XmlNode node in xmlDoc.SelectNodes("/BlockList/Latest"))
                        blockList.Add(node.InnerText);

                    await _storageAccountHelper.CommitBlockList(container, file, blockList);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IAM upload failed for container {Container} and file {File} with correlation ID {CorrelationID}", container, file, HttpContext.TraceIdentifier);
                return BadRequest(new { error = "Upload failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [Authorize]
        [HttpPost(RouteConstants.GetDownloadUrl)]
        public IActionResult GetDownloadUrl(GetDownloadUrlRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.FileUrl))
                    return new BadRequestObjectResult(Constants.Generic.EmptyFileURL);

                return new OkObjectResult(new
                {
                    DownloadUrl = _storageAccountHelper.GetDownloadUrl($"https://{IAMICTController.GetHostUrl(Request)}/IAMICT/download", new Uri(request.FileUrl))
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IAM download URL generation failed with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = "Download URL generation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [Authorize]
        [HttpGet(RouteConstants.GetIAMValidExtensions)]
        public IActionResult GetIAMValidExtensions()
        {
            try
            {
                return new OkObjectResult(new
                {
                    extensions = Utility.LoadIAMValidExtensions(_dataverseService)
                });
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, "IAM valid extensions lookup failed with correlation ID {CorrelationID}", HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = "Extensions lookup failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [Authorize]
        [HttpPost(RouteConstants.GenerateUploadUrl)]
        public IActionResult GenerateUploadUrl(GenerateUploadUrlRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.AccountId) || string.IsNullOrEmpty(request.FileName))
                    return new BadRequestObjectResult(Constants.Generic.EmptyCustomerID);

                Guid? fileId = null;
                string storageFileUrl = "";
                Uri url = _storageAccountHelper.CreateFileAndGenerateSASUri($"https://{IAMICTController.GetHostUrl(Request)}/IAMICT/upload", request.AccountId, request.FileName, request.FileType, out fileId, out storageFileUrl);

                return new OkObjectResult(new GenerateUploadUrlResponse(fileId, url.ToString(), storageFileUrl));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "IAM upload URL generation failed for account {AccountId} and file {FileName} with correlation ID {CorrelationID}", request?.AccountId, request?.FileName, HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = "Upload URL generation failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [Authorize]
        [HttpPatch(RouteConstants.SetSHA256)]
        public IActionResult SetSHA256(SetSHA256Request request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.SHA256))
                    return new BadRequestObjectResult(Constants.Generic.SHA256MustBeProvided);

                PortalManagementInfo managementInfo = new PortalManagementInfo(_dataverseService);
                managementInfo.SetSHA256(request.FileId, request.SHA256);
                _fileReception.TriggerServiceToValidateSHA256(request.FileId);
                return new OkObjectResult(new { result = Constants.Generic.OK });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SetSHA256 failed for file {FileId} with correlation ID {CorrelationID}", request?.FileId, HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = "SHA256 update failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        [Authorize]
        [HttpDelete(RouteConstants.Delete)]
        public IActionResult Delete(string fileUrl, Guid? fileId)
        {
            if (string.IsNullOrEmpty(fileUrl))
                return new BadRequestObjectResult(Constants.Generic.FileUrlMustBeProvided);

            try
            {
                if (fileId != null)
                {
                    PortalManagementInfo managementInfo = new PortalManagementInfo(_dataverseService);
                    managementInfo.Delete(fileId);
                }
                _storageAccountHelper.Delete(fileUrl);

                return new OkObjectResult(new { result = Constants.Generic.OK });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Delete failed for file URL {FileUrl} and file id {FileId} with correlation ID {CorrelationID}", fileUrl, fileId, HttpContext.TraceIdentifier);
                return new BadRequestObjectResult(new { error = "Delete failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }


        
    }
}


