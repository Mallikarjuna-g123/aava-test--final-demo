using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Playwright;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PdfController : Controller
    {
        private readonly IBrowserService _browserService;
        private readonly BrowserServiceOptions _options;
        private readonly ILogger<PdfController> _logger;

        public PdfController(
            IBrowserService browserService,
            IOptions<BrowserServiceOptions> options,
            ILogger<PdfController> logger)
        {
            _browserService = browserService;
            _options = options.Value;
            _logger = logger;
        }

        /// <summary>
        /// Generates a PDF from the provided HTML content.
        /// </summary>
        /// <param name="request">Request body containing HTML content and PDF options.</param>
        /// <returns>PDF file as a binary stream.</returns>
        [HttpPost(RouteConstants.Generate)]
        [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GeneratePdf([FromBody] GeneratePdfRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.HtmlContent))
                return BadRequest("HtmlContent must not be empty.");

            using var timeoutCts = new CancellationTokenSource(
                TimeSpan.FromSeconds(_options.RenderTimeoutSeconds));
            using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(
                HttpContext.RequestAborted, timeoutCts.Token);

            try
            {
                _logger.LogInformation("PDF generation requested.");

                var paperFormat = ResolvePaperFormat.FromString(request.Format);
                var pdfOptions = new PagePdfOptions
                {
                    Format = paperFormat,
                    Landscape = request.Landscape,
                    PrintBackground = true,
                    DisplayHeaderFooter = request.DisplayHeaderFooter,
                    HeaderTemplate = request.HeaderTemplate ?? string.Empty,
                    FooterTemplate = request.FooterTemplate ?? string.Empty,
                    Margin = new Margin
                    {
                        Top = request.MarginTop.HasValue ? $"{request.MarginTop}px" : "20px",
                        Bottom = request.MarginBottom.HasValue ? $"{request.MarginBottom}px" : "20px",
                        Left = request.MarginLeft.HasValue ? $"{request.MarginLeft}px" : "20px",
                        Right = request.MarginRight.HasValue ? $"{request.MarginRight}px" : "20px"
                    }
                };

                // AcquireContextAsync blocks if MaxConcurrentPages are already in flight.
                await using var contextHandle = await _browserService.AcquireContextAsync(linkedCts.Token);
                var page = await contextHandle.NewPageAsync();

                await page.SetContentAsync(request.HtmlContent, new PageSetContentOptions
                {
                    WaitUntil = WaitUntilState.NetworkIdle
                });

                var pdfBytes = await page.PdfAsync(pdfOptions);

                _logger.LogInformation("PDF generation completed successfully. Size={Bytes} bytes.", pdfBytes.Length);

                return File(pdfBytes, "application/pdf", "output.pdf");
            }
            catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested)
            {
                _logger.LogWarning("PDF generation timed out after {Seconds}s.", _options.RenderTimeoutSeconds);
                return StatusCode(StatusCodes.Status408RequestTimeout,
                    $"PDF generation timed out after {_options.RenderTimeoutSeconds} seconds.");
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("PDF generation cancelled by client.");
                return StatusCode(499, "Request cancelled by client.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while generating the PDF.");
                return StatusCode(StatusCodes.Status500InternalServerError,
                    $"An unexpected error occurred while generating the PDF: {ex.Message}");
            }
        }
    }
}

