﻿using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Xrm.Sdk;
using System.Runtime.Caching;
using System.Text;
using static Microsoft.Extensions.Logging.EventSource.LoggingEventSource;

namespace FIJI.Portal.WebAPI.Integration.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class FileController : Controller
    {
        private readonly FileModel _fileModel;
        private readonly StorageAccountHelper _storageAccountHelper;
        private readonly IMemoryCache _memoryCache;
        private readonly ILogger<FileController> _logger;

        public FileController(IOrganizationService service, StorageAccountHelper storageHelper, IMemoryCache memoryCache, ILogger<FileController> logger)
        {
            _storageAccountHelper = storageHelper;
            _fileModel = new FileModel(service, storageHelper, Utils.EnableVirusCheck);
            _memoryCache = memoryCache;
            _logger = logger;
        }

        [HttpPost(RouteConstants.Upload)]
        [Authorize]
        public async Task<IActionResult> UploadFile([FromForm] FileUploadRequest fileUploadRequest)
        {
            FileUploadResponse fileUploadResponse = new FileUploadResponse();
            try
            {
                if (fileUploadRequest?.FileType == null)
                {
                    fileUploadRequest.FileType = FileReception.Model.BlobFile.eFileType.Default;
                }

                string? fileTextContent = null;
                string? fileExtension = Path.GetExtension(fileUploadRequest.FileContent.FileName)?.ToLowerInvariant();

                if (fileExtension == ".txt" || fileExtension == ".csv" || fileExtension == ".json" || fileExtension == ".xml")
                {
                    using (var reader = new StreamReader(fileUploadRequest.FileContent.OpenReadStream(), Encoding.UTF8, detectEncodingFromByteOrderMarks: true))
                    {
                        fileTextContent = await reader.ReadToEndAsync();
                    }
                }
                else if (fileExtension == ".docx")
                {
                    using (var stream = fileUploadRequest.FileContent.OpenReadStream())
                    using (var wordDoc = DocumentFormat.OpenXml.Packaging.WordprocessingDocument.Open(stream, false))
                    {
                        var body = wordDoc.MainDocumentPart?.Document.Body;
                        fileTextContent = body?.InnerText;
                    }
                }
                else if (fileExtension == ".pdf")
                {
                    using (var stream = fileUploadRequest.FileContent.OpenReadStream())
                    {
                        var pdf = UglyToad.PdfPig.PdfDocument.Open(stream);
                        var textBuilder = new StringBuilder();
                        foreach (var page in pdf.GetPages())
                        {
                            textBuilder.AppendLine(page.Text);
                        }
                        fileTextContent = textBuilder.ToString();
                    }
                }

                string? maliciousKeywordsCsv = _memoryCache.Get(Constants.CachedMaliciousKeywordsKey) as string;
                string[] maliciousKeywordsCsvArray;
                if (!string.IsNullOrEmpty(maliciousKeywordsCsv))
                {
                    string cleanedKeywords = maliciousKeywordsCsv.Replace("\"", string.Empty).Replace(@"""", string.Empty).Trim();
                    if (string.IsNullOrWhiteSpace(cleanedKeywords))
                    {
                        maliciousKeywordsCsvArray = GetDefaultSuspiciousPatterns();
                    }
                    maliciousKeywordsCsvArray = cleanedKeywords.Split(',', StringSplitOptions.RemoveEmptyEntries);
                }
                else
                {
                    maliciousKeywordsCsvArray = GetDefaultSuspiciousPatterns();
                }

                List<string> foundPatterns = new();

                if (!string.IsNullOrEmpty(fileTextContent))
                {
                    foreach (var pattern in maliciousKeywordsCsvArray)
                    {
                        if (fileTextContent.Contains(pattern.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            foundPatterns.Add(pattern);
                        }
                    }

                    if (foundPatterns.Any())
                    {
                        fileUploadResponse.Error = $"File contains potentially malicious content: {string.Join(", ", foundPatterns)}";
                        _logger.LogError("UploadFile failed with error {Error} with correlation ID {CorrelationID}", fileUploadResponse.Error, HttpContext.TraceIdentifier);
                        return BadRequest(fileUploadResponse);
                    }
                }

                fileUploadResponse = _fileModel.UploadAndVirusCheck(fileUploadRequest.FileContent, fileUploadRequest.FileName, fileUploadRequest.AccountId, "files/", (FileReception.Model.BlobFile.eFileType)(fileUploadRequest.FileType));

                string modifiedFileName = fileUploadResponse.fileName;
                string OriginalFileName = fileUploadRequest.FileName;
                fileUploadResponse.fileName = OriginalFileName;
                fileUploadResponse.ModifiedFileName = modifiedFileName;
                return Ok(fileUploadResponse);
            }
            catch (ArgumentException are)
            {
                fileUploadResponse.Error = are.Message;
                _logger.LogError("UploadFile failed with error {Error} with correlation ID {CorrelationID}", fileUploadResponse.Error, HttpContext.TraceIdentifier);
                return BadRequest(fileUploadResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UploadFile failed for account {AccountId} and file {FileName} with correlation ID {CorrelationID}", fileUploadRequest?.AccountId, fileUploadRequest?.FileName, HttpContext.TraceIdentifier);
                return StatusCode(500, new { error = "File upload failed.", correlationId = HttpContext.TraceIdentifier });
            }
        }

        private static string[] GetDefaultSuspiciousPatterns()
        {
            return new[] { "/JavaScript", "app.alert", "this.submitForm", "oastify.com", "/OpenAction" };
        }

        [HttpGet(RouteConstants.DownloadFileEncodedUrl)]
        public async Task<IActionResult> DownloadFileEncodedUrl(string containerName, string encodedFileUrl)
        {
            byte[]? bytesData = null;
            string decodedUrl = string.Empty;
            if (!string.IsNullOrEmpty(encodedFileUrl) && !string.IsNullOrEmpty(containerName))
            {
                decodedUrl = _fileModel.GetDecodedUrl(encodedFileUrl);
                bytesData = _fileModel.FileDataDownload(containerName, decodedUrl);
            }

            if (bytesData == null)
                return NoContent();

            return File(new MemoryStream(bytesData), Constants.ApplicationOctetStream, Path.GetFileName(decodedUrl));
        }

        [HttpGet(RouteConstants.DownloadFile)]
        public async Task<IActionResult> DownloadFile(string containerName, string Folder, string FileName)
        {
            byte[]? bytesData = _fileModel.FileDataDownload(containerName, Folder + "/" + FileName);
            if (bytesData == null)
            {
                return NoContent();
            }

            return File(new MemoryStream(bytesData), Constants.ApplicationOctetStream, FileName);
        }

        [HttpGet(RouteConstants.DownloadPortalFile)]
        public IActionResult DownloadPortalFile(string fileName)
        {
            return Redirect(_storageAccountHelper.GetPortalWebFilesDownloadUrl($"https://{IAMICTController.GetHostUrl(Request)}/IAMICT/download", fileName).ToString());
        }
    }
}