# Dataverse Integration Guidance

Back to index: [Project Guidance Index](../README.md)

## Purpose

Provide a repeatable approach for implementing and reviewing Dataverse-bound logic in this middleware.

## Key Files

- Startup and DI: [Program.cs](../../../Program.cs)
- Main model layer: [Model](../../../Model)
- Generic Dataverse helpers: [Model/Generic](../../../Model/Generic)
- Query builder utilities: [Utilities/SqlQuery.cs](../../../Utilities/SqlQuery.cs)

## Implementation Instructions

1. Define request and response contracts first.
- Add request DTO under [Requests](../../../Requests).
- Add response DTO under [Responses](../../../Responses).

2. Keep controllers thin.
- Validate required fields in controller.
- Delegate business logic to model class methods.

3. Add or update model methods.
- Place business logic in relevant model class under [Model](../../../Model).
- Reuse generic model helpers where possible.

4. Use centralized query utilities.
- Add reusable query builders in [Utilities/SqlQuery.cs](../../../Utilities/SqlQuery.cs) when needed.

5. Error handling and response contract.
- Return business validation errors as `400`.
- Return unexpected errors as `500` with typed error payload.

## Testing Guidance

- Validate positive path with realistic Dataverse IDs.
- Validate invalid IDs, missing fields, and cross-environment payload mismatch.
- Validate behavior when Dataverse throws plugin/workflow exceptions.

## Review Checklist

- Endpoint route defined by [Utilities/RouteConstants.cs](../../../Utilities/RouteConstants.cs).
- DTOs in correct folders and names are unique.
- Model logic avoids duplicate hard-coded query fragments.
- Error messages are actionable for API consumers and QA.
