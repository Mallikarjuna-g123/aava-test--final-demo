# Security and Configuration Guidance

Back to index: [Project Guidance Index](../README.md)

## Purpose

Define safe practices for authentication, authorization, and configuration handling in this middleware.

## Security Controls In Code

- JWT authentication configured in [Program.cs](../../../Program.cs).
- Authorized endpoints use `[Authorize]` in controllers.

## Configuration Hygiene Instructions

1. Keep secrets out of source-controlled files.
- Move client secrets, JWT secrets, service bus keys, and storage keys to secure providers.

2. Use environment-based configuration.
- Prefer App Service configuration and managed identity where possible.

3. Restrict CORS by environment.
- Avoid permissive cross-origin configuration in production.

4. Review anonymous/public endpoints.
- Explicitly document and justify any endpoint without `[Authorize]`.

5. Rotate and monitor credentials.
- Apply regular rotation policy and access review.

## Deployment Safety Checklist

- Verify no plain-text secrets in [appsettings.json](../../../appsettings.json) and [appsettings.Development.json](../../../appsettings.Development.json).
- Verify authentication path through [Controllers/AuthController.cs](../../../Controllers/AuthController.cs).
- Verify production CORS policy and HTTPS enforcement in [Program.cs](../../../Program.cs).
- Verify telemetry and logs do not include confidential data.
