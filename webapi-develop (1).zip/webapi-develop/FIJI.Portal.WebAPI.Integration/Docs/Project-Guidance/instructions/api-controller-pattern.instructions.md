# Controller and Endpoint Guidance

Back to index: [Project Guidance Index](../README.md)

## Purpose

Standardize how new endpoints are implemented and documented for predictable behavior across teams.

## Key Files

- Controllers: [Controllers](../../../Controllers)
- Route constants: [Utilities/RouteConstants.cs](../../../Utilities/RouteConstants.cs)
- Endpoint guidance reference: [api-controller-pattern.instructions.md](./api-controller-pattern.instructions.md)

## Endpoint Implementation Pattern

1. Add route constant.
- Add endpoint path key in [Utilities/RouteConstants.cs](../../../Utilities/RouteConstants.cs).

2. Add request and response DTOs.
- Keep request types in [Requests](../../../Requests).
- Keep response types in [Responses](../../../Responses).

3. Implement controller action.
- Validate inputs early.
- Call model/service layer.
- Return appropriate status code.

4. Authentication and authorization.
- Apply `[Authorize]` unless endpoint is intentionally public.

5. Logging.
- Log business-critical failures and integration boundaries.

## Documentation Update Instructions

For each changed controller:
- Update endpoint behavior notes in this guidance file when patterns change.
- Keep HTTP verb, route constants usage, input validation, and response/error behavior aligned with source code.
- Ensure Swagger/OpenAPI metadata remains accurate for endpoint changes.

## QA Test Cases

- Success path with expected payload.
- Missing required fields.
- Invalid GUID or malformed query data.
- Unauthorized request for protected endpoint.
- Integration dependency failure simulation.
