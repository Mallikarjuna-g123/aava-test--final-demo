# Observability and Logging Guidance

Back to index: [Project Guidance Index](../README.md)

## Purpose

Improve traceability from front-end request through middleware to Dataverse and Azure dependencies.

## Current Baseline

- Azure Monitor OpenTelemetry is enabled at startup in [Program.cs](../../../Program.cs).
- Logging levels are configured in appsettings files.
- Correlation and request duration middleware: [Observability/CorrelationAndRequestLoggingMiddleware.cs](../../../Observability/CorrelationAndRequestLoggingMiddleware.cs).
- Controller action logging filter (global): [Observability/ControllerActionLoggingFilter.cs](../../../Observability/ControllerActionLoggingFilter.cs).
- Dataverse operation instrumentation: [Observability/OrganizationServiceLoggingProxy.cs](../../../Observability/OrganizationServiceLoggingProxy.cs).
- Outbound HTTP call instrumentation: [Observability/OutboundHttpLoggingHandler.cs](../../../Observability/OutboundHttpLoggingHandler.cs) via `IHttpClientFactory`.
- JWT authentication event logging: configured in [Program.cs](../../../Program.cs) for security visibility.
- Startup readiness log: confirms application started successfully.

## Observability Coverage Flow

```mermaid
flowchart TD
    REQ[Incoming Request] --> MW[CorrelationAndRequestLoggingMiddleware]
    MW --> AUTH[JWT Bearer Events]
    AUTH --> FILTER[ControllerActionLoggingFilter]
    FILTER --> CTRL[Controller Action]
    CTRL --> DV[Dataverse via OrganizationServiceLoggingProxy]
    CTRL --> HTTP[Outbound HTTP via OutboundHttpLoggingHandler]
    CTRL -->|unhandled| EXH[Global Exception Handler]
```

## Implementation Instructions

1. Add structured logs at key boundaries.
- Controller action entry/exit/error is handled automatically by the global action filter.
- Dataverse operations are logged by the proxy (no manual logging needed).
- Outbound HTTP calls are logged by the DelegatingHandler when using IHttpClientFactory.
- Authentication failures/challenges are logged automatically via JWT bearer events.
- Before external storage or service bus calls (consider adding named HttpClient when new integrations are introduced).

2. Include correlation context.
- Ensure each major log includes request-level identifiers (request id, operation id, domain entity id).

3. Standardize severity usage.
- Information: normal business milestones.
- Warning: recoverable or suspicious situations.
- Error: failed operation with exception details.

4. Keep logs safe.
- Do not log secrets, tokens, or full sensitive payload content.

5. Follow code and API best practices while implementing logs.
- Keep controllers thin and avoid scattering telemetry code across every endpoint.
- Prefer middleware/filter/proxy instrumentation for consistency and reduced maintenance.
- Keep response contracts and status behavior stable unless requirement explicitly changes them.

## Verification Steps

- Trigger endpoint via Swagger/Postman.
- Confirm request telemetry appears in Application Insights.
- Confirm custom logs are visible and filterable by operation.
- Confirm exceptions include enough context to reproduce failures.

## What Gets Logged (Quick Reference)

This table summarizes what is automatically captured without manual per-endpoint code:

| Event | Component | Log Level | Where to Find |
|-------|-----------|-----------|---------------|
| Request start/end + timing | CorrelationAndRequestLoggingMiddleware | Information | App Insights → Traces |
| Correlation ID propagation | CorrelationAndRequestLoggingMiddleware | — | X-Correlation-ID header |
| Controller action start/end | ControllerActionLoggingFilter | Information | App Insights → Traces |
| Controller action error | ControllerActionLoggingFilter | Error | App Insights → Failures |
| Dataverse call + timing | OrganizationServiceLoggingProxy | Information | App Insights → Traces |
| Dataverse call failure | OrganizationServiceLoggingProxy | Error | App Insights → Failures |
| Outbound HTTP call + timing | OutboundHttpLoggingHandler | Information | App Insights → Dependencies |
| Outbound HTTP failure | OutboundHttpLoggingHandler | Error | App Insights → Failures |
| Auth failure / challenge | JWT bearer events | Warning | App Insights → Traces |
| Unhandled exception | Global exception handler | Error | App Insights → Exceptions |
| Startup readiness | Program.cs | Information | App Insights → Traces |

## When to Add Manual Logging

Only add controller-level or model-level logging when:
- A business rule decision needs audit trail (e.g., file rejected for malicious content).
- A conditional path is not visible from the centralized components.
- A domain entity ID is needed for correlation beyond request scope.

## Troubleshooting Focus

If request telemetry exists but logs are missing:
- Verify logger usage in controller/model paths.
- Verify log-level filtering in [appsettings.json](../../../appsettings.json).
- Verify environment-specific settings in [appsettings.Development.json](../../../appsettings.Development.json) or App Service configuration.
- Verify outbound HTTP clients are registered through `IHttpClientFactory` (not `new HttpClient()`).

## Azure Dashboard Implementation (Ops + Dev)

Use this workflow to build a shared Azure Portal dashboard from current FIJI telemetry.

1. Open Azure portal and create a custom dashboard for the target environment (Dev/UAT/Prod).
2. Open Azure Monitor Logs for the Application Insights resource/workspace.
3. Run each KQL query from the cookbook below and render with a dashboard-supported chart type.
4. Pin each rendered result to the dashboard.
5. Group tiles by audience and actionability:
   - Ops: service health, dependency health, auth/security.
   - Dev: deep troubleshooting and incident drill-down.
6. Publish/share dashboard and grant least-privilege access:
   - Readers: Monitoring Reader.
   - Editors: Monitoring Contributor.

### Scripted deployment (recommended)

```powershell
powershell -ExecutionPolicy Bypass -File .\infra\build-fiji-ops-dev-dashboard.ps1 -ResourceGroupName "EPRID214204-FIJI-DEV-RG" -DashboardName "FIJI-Portal-WebAPI-Dashboard-DEVPhase2" -Location "eastus2" -ApplicationInsightsResourceId "/subscriptions/62534004-d703-4a58-938e-728afcd4796a/resourceGroups/EPRID214204-FIJI-DEV-RG/providers/microsoft.insights/components/appi-fiji-dev-phase2-eastus2-001" -AppName "Portal WebAPI"
```

Notes:
- The script resolves relative output paths against `infra/`, so artifacts are consistently written to `infra/` regardless of current working directory.
- `FIJI OPS - Service Health - Request Volume and Failure Rate` and `FIJI OPS - Dependency Health - Failure Rate by Target` are intentionally pinned as `AnalyticsGrid` (table mode) to avoid Azure dashboard `Invalid input: 'Dimensions'` renderer failures.

### Dashboard sections and ownership

| Section | Primary Audience | Primary Questions |
|--------|------------------|-------------------|
| Service Health | Ops | Are requests failing or slowing down right now? |
| Dependency Health | Ops | Are Dataverse or outbound HTTP dependencies degraded? |
| Security/Auth | Ops | Are auth failures/challenges spiking? |
| Troubleshooting Deep Dive | Dev | Which operation/action caused the incident and why? |

## Investigation KQL Cookbook

Run all queries in Azure Monitor Logs against `requests`, `dependencies`, `traces`, `exceptions`, and `customMetrics`.

Use this variable in queries where appName is supported:

```kusto
let appName = "Portal WebAPI";
```

**Key note on Activity tag naming:** OpenTelemetry Activity tags are exported to `customDimensions` (via `Properties` field) with lowercase+dot naming convention, e.g., `correlation.id`, `action.controller`, `action.name`, `request.duration.ms`. This differs from PascalCase (e.g., `CorrelationId`) used by legacy telemetry. Always check dims for lowercase+dot names first when debugging query results.

### Telemetry inventory from source code

| Signal | Source implementation | Main tables | Key dimensions/fields |
|-------|------------------------|-------------|------------------------|
| Request lifecycle | `CorrelationAndRequestLoggingMiddleware` | `traces`, `requests`, `customMetrics` | `CorrelationId`, `RequestPath`, `RequestMethod`, `appName`, status code, duration |
| Controller action lifecycle | `ControllerActionLoggingFilter` | `traces`, `customMetrics` | `Controller`, `Action`, `CorrelationId`, status code, duration |
| Domain/model operation lifecycle | `OperationTraceHelper` | `traces`, `customMetrics` | `Component`, `Operation`, `appName`, duration, error flag |
| Dataverse dependency | `OrganizationServiceLoggingProxy` | `dependencies`, `traces`, `customMetrics` | operation name, dependency target/type, duration, success/failure |
| Outbound HTTP dependency | `OutboundHttpLoggingHandler` | `dependencies`, `traces`, `customMetrics` | method, host/path, status code, duration, success/failure |
| Retry behavior | `Project.ExecuteWithRetryAsync` (called from `CreateECNProjectsAsync`) | `customMetrics` | `component` (Project), `operation` (CreateECNProjectsAsync), `attempt`, `appName`. **Only recorded on transient failures** (timeout, throttling, temporary errors); normal Dataverse errors do not trigger retry logic |
| Auth and global failures | `Program.cs` JWT events + exception handler | `traces`, `exceptions` | auth error/challenge message, request path/method, correlation id |
| Worker queue processing | `FIJI.Portal.FileReception.WinService/ServiceBus.cs` | `traces` | message prefix (`Received:`, `Finished:`) |

Implementation note: worker traces currently do not emit `appName`, so worker-specific dashboard queries should use message-based filtering rather than appName filtering.

**Note on Meter-based metrics vs Activity tags:**
- Most telemetry uses OpenTelemetry **Activity** tags, which export to customDimensions in `AppRequests`, `AppDependencies`, `AppTraces` tables with lowercase+dot naming (e.g., `dims["correlation.id"]`, `dims["action.controller"]`).
- Retry telemetry uses OpenTelemetry **Meter** counters, which export to `customMetrics` table with different field/table names: query `customMetrics` with `where name in (...)`, extract `customDimensions`, and use tag names without dots (e.g., `dims["component"]`, `dims["operation"]`). Field names are lowercase (`name`, `value` instead of `Name`, `Value`).

### Final naming conventions

- Ops dashboard tiles (pin to dashboard): `FIJI OPS - <Domain> - <Metric>`
- Devs investigation queries (on-demand triage): `FIJI DEVs INV - <Focus>`

### Ops dashboard tiles (pin these)

#### FIJI OPS - Service Health - Request Volume and Failure Rate

```kusto
    requests
    | extend timestamp = column_ifexists("timestamp", datetime(null))
    | extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
    | extend AppName = tostring(dims["appName"])
    | extend SuccessValue = tobool(coalesce(tostring(column_ifexists("success", "")), tostring(column_ifexists("Success", ""))))
    | extend ResultCodeValue = toint(coalesce(tostring(column_ifexists("resultCode", "")), tostring(column_ifexists("ResultCode", ""))))
    | where AppName == "Portal WebAPI"
    | summarize TotalRequests = count(), FailedRequests = countif(SuccessValue == false or ResultCodeValue >= 500) by bin(timestamp, 5m)
    | extend FailureRatePct = iff(TotalRequests == 0, 0.0, round(100.0 * todouble(FailedRequests) / todouble(TotalRequests), 2))
    | project timestamp, TotalRequests = tolong(TotalRequests), FailedRequests = tolong(FailedRequests), FailureRatePct
    | order by timestamp desc
```

#### FIJI OPS - Service Health - Endpoint Latency P50/P95/P99

```kusto
requests
| extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| extend RequestName = coalesce(tostring(column_ifexists("name", "")), tostring(column_ifexists("Name", "")))
| extend DurationMs = coalesce(
    toreal(totimespan(tostring(column_ifexists("duration", ""))) / 1ms),
    todouble(column_ifexists("duration", real(null))),
    todouble(tostring(dims["request.duration.ms"]))
)
| where AppName == "Portal WebAPI"
| where isnotnull(DurationMs)
| summarize P50 = percentile(DurationMs, 50), P95 = percentile(DurationMs, 95), P99 = percentile(DurationMs, 99), Samples = count() by RequestName
| top 15 by P95 desc
```

#### FIJI OPS - Dependency Health - Failure Rate by Target

```kusto
    
    dependencies
    | extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
    | extend AppName = tostring(dims["appName"])
    | extend TypeValue = coalesce(tostring(column_ifexists("type", "")), tostring(column_ifexists("DependencyType", "")), tostring(column_ifexists("Type", "")))
    | extend TargetValue = coalesce(tostring(column_ifexists("target", "")), tostring(column_ifexists("Target", "")))
    | extend SuccessValue = tobool(coalesce(tostring(column_ifexists("success", "")), tostring(column_ifexists("Success", ""))))
    | where AppName == "Portal WebAPI"
    | extend Dependency = strcat(TypeValue, " -> ", TargetValue)
    | summarize Total = count(), Failed = countif(SuccessValue == false) by Dependency
| extend FailureRatePct = iff(Total == 0, 0.0, round(100.0 * todouble(Failed) / todouble(Total), 2))
| project Dependency, Total = tolong(Total), Failed = tolong(Failed), FailureRatePct
| order by Failed desc
```

#### FIJI OPS - Security/Auth - JWT Failure and Challenge Trend

Tracks JWT authentication failures and challenges over time (15-minute aggregation). Visualizes as line chart showing trends in authentication issues, useful for detecting potential security threats or misconfigured clients.

```kusto
    traces
| extend timestamp = column_ifexists("timestamp", datetime(null))
| extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| extend MessageValue = coalesce(tostring(column_ifexists("message", "")), tostring(column_ifexists("Message", "")))
| where AppName == "Portal WebAPI"
| where MessageValue has "JWT authentication failed" or MessageValue has "JWT challenge issued"
| extend Event = tostring(iff(MessageValue has "JWT authentication failed", "AuthFailed", iff(MessageValue has "JWT challenge issued", "AuthChallenge", "Other")))
| order by timestamp desc
```

#### FIJI OPS - Worker Health - Queue Received vs Finished

Tracks message queue processing by counting received vs finished messages over 15-minute intervals. Displayed as table showing stage distribution and count trends.

```kusto
traces
    | extend timestamp = column_ifexists("timestamp", datetime(null))
    | extend MessageValue = coalesce(tostring(column_ifexists("message", "")), tostring(column_ifexists("Message", "")))
    | where MessageValue startswith "Received:" or MessageValue startswith "Finished:"
    | extend Stage = iff(MessageValue startswith "Received:", "Received", "Finished")
    | summarize Count = count() by Stage, bin(timestamp, 15m)
    | project timestamp, Stage, Count
```

#### FIJI OPS - Incident - Exception Trend by Type

Monitors exception frequency by exception type over time (15-minute aggregation). Visualizes as line chart showing which exception types are trending, enabling rapid identification of systemic error patterns.

```kusto
exceptions
| extend timestamp = column_ifexists("timestamp", datetime(null))
| extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| extend ExceptionType = coalesce(tostring(column_ifexists("Type", "")), tostring(column_ifexists("type", "")))
| where AppName == "Portal WebAPI"
| summarize Count = count() by bin(timestamp, 15m), ExceptionType
| order by timestamp desc
```

### Devs investigation-only queries (do not pin by default)

#### FIJI DEVs INV - Top Failing Controller Actions

Queries the requests table for actual HTTP failures (4xx/5xx status codes) with correct controller/action tag names from Activity telemetry.

```kusto
requests
| extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| extend Controller = tostring(dims["action.controller"])
| extend Action = tostring(dims["action.name"])
| extend StatusCode = toint(coalesce(column_ifexists("resultCode", ""), "0"))
| where AppName == "Portal WebAPI"
| where isnotempty(Controller) and isnotempty(Action)
| where StatusCode >= 400
| summarize Failures = count() by Controller, Action, StatusCode
| order by Failures desc
| top 20 by Failures
```

#### FIJI DEVs INV - Slowest Controller Actions by Operation

Identifies slowest controller actions by measuring request duration distributions. Queries the requests table directly for guaranteed data availability, extracting controller and action names from Activity tags and calculating P95/Max latencies.

```kusto
    requests
    | extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
    | extend AppName = tostring(dims["appName"])
    | extend Controller = coalesce(tostring(dims["action.controller"]), "Unknown")
    | extend Action = coalesce(tostring(dims["action.name"]), "Unknown")
    | extend DurationMs = coalesce(
        toreal(totimespan(tostring(column_ifexists("duration", ""))) / 1ms),
        todouble(column_ifexists("duration", real(null))),
        todouble(tostring(dims["request.duration.ms"]))
    )
    | where AppName == "Portal WebAPI"
    | where Controller != "Unknown" and Action != "Unknown"
    | where isnotnull(DurationMs)
    | summarize AvgMs = round(avg(DurationMs), 2), P95Ms = round(percentile(DurationMs, 95), 2), MaxMs = round(max(DurationMs), 2), Samples = count() by Controller, Action
    | order by P95Ms desc
    | top 20 by P95Ms
```

**Output columns:**
- **Controller**: ASP.NET controller name
- **Action**: Controller action method name
- **AvgMs**: Average request duration (milliseconds)
- **P95Ms**: 95th percentile latency (most requests under this)
- **MaxMs**: Maximum observed latency (outlier detection)
- **Samples**: Number of requests in analysis window

Use this to identify:
- Slow endpoints requiring optimization
- Outliers with extreme MaxMs values
- Load imbalance patterns across actions

#### FIJI OPS - Service Health - Request Traffic Volume by Controller Action

Displays request throughput per controller action over 5-minute time buckets in table format. Provides visibility into traffic distribution across endpoints, enabling rapid identification of traffic shifts and abnormal load patterns. Grouped by timestamp, controller, and action (e.g., "ECNProjectsController" → "CreateECNProjectsAsync").

```kusto
    requests
    | extend timestamp = column_ifexists("timestamp", datetime(null))
    | extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
    | extend AppName = tostring(dims["appName"])
    | extend Controller = coalesce(tostring(dims["action.controller"]), "Unknown")
    | extend Action = coalesce(tostring(dims["action.name"]), "Unknown")
    | where AppName == "Portal WebAPI"
    | where Controller != "Unknown" and Action != "Unknown"
    | summarize RequestCount = count() by bin(timestamp, 5m), Controller, Action
    | order by timestamp desc
```

**Table columns:**
- **timestamp**: 5-minute time bucket
- **Controller**: ASP.NET controller name (e.g., ECNProjectsController)
- **Action**: Controller action method name (e.g., CreateECNProjectsAsync)
- **RequestCount**: Number of requests in that bucket

**Traffic patterns to investigate:**
- Sudden spikes in specific controller actions → client demand shift or retry storm
- Zero traffic on normally-active endpoints → potential outage or routing failure
- Uneven distribution across actions → load imbalance or feature-specific issues

#### FIJI DEVs INV - Retry Summary by Component/Operation

Aggregated view showing which components/operations experienced retries and how many were exhausted (failed after all retries).

```kusto
let appName = "Portal WebAPI";
customMetrics
| where name in ("app.retry.attempt.count", "app.retry.exhausted.count")
| extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| where AppName == appName
| extend Component = tostring(dims["component"]), Operation = tostring(dims["operation"])
| extend MetricValue = todouble(column_ifexists("value", real(null)))
| where isnotnull(MetricValue) and isnotempty(Component) and isnotempty(Operation)
| summarize TotalAttempts = sumif(MetricValue, name == "app.retry.attempt.count"), ExhaustedRetries = sumif(MetricValue, name == "app.retry.exhausted.count") by Component, Operation
| extend RecoveryRate = case(
    TotalAttempts > 0, round(100.0 * (TotalAttempts - ExhaustedRetries) / TotalAttempts, 1),
    0.0)
| order by ExhaustedRetries desc, TotalAttempts desc
```

#### FIJI DEVs INV - Correlation Timeline Drill-Through

```kusto
let appName = "Portal WebAPI";
let correlationId = "PUT-CORRELATION-ID-HERE";
union withsource=TableName AppRequests, AppDependencies, AppTraces, AppExceptions
| extend timestamp = TimeGenerated
| extend dims = coalesce(column_ifexists("Properties", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| extend operation_Id = coalesce(tostring(column_ifexists("OperationId", "")), tostring(column_ifexists("operation_Id", "")))
| extend CorrelationId = coalesce(tostring(dims["correlation.id"]), tostring(dims["CorrelationId"]), operation_Id)
| where AppName == appName or isempty(AppName)
| where CorrelationId == correlationId or operation_Id == correlationId
| extend itemType = tostring(
    iff(TableName has "AppRequests", "request",
    iff(TableName has "AppDependencies", "dependency",
    iff(TableName has "AppTraces", "trace",
    iff(TableName has "AppExceptions", "exception", "unknown")))))
| project
    timestamp,
    itemType,
    AppName,
    Name = tostring(column_ifexists("Name", "")),
    Message = tostring(column_ifexists("Message", "")),
    ResultCode = tostring(column_ifexists("ResultCode", "")),
    Success = tostring(column_ifexists("Success", "")),
    Duration = tostring(column_ifexists("DurationMs", "")),
    operation_Id,
    CorrelationId
| order by timestamp asc
```

### appName coverage notes

- appName filter supported:
    - Trace scopes and correlated request/dependency/exception records where scope dimensions are emitted.
    - `requests` (requests table) for endpoint latency and controller action failures.
    - `customMetrics` for `app.operation.*` and `app.retry.*`.
- appName filter not yet supported in `customMetrics` for:
    - `http.server.request.*`
    - `app.dependency.*`
- Worker queue traces currently do not include `appName`; use message-prefix filtering for worker dashboard tiles.

## Correlation Workflow (Incident Handling)

1. Start with the failing request or user-reported timestamp.
2. Capture `X-Correlation-ID` (or use `operation_Id` if correlation header was not provided).
3. Run query **I. Correlation ID incident timeline**.
4. Identify where the first error appears:
   - Request failure (`requests`),
   - Dependency failure (`dependencies`),
   - Application error trace (`traces`),
   - Exception record (`exceptions`).
5. Pivot to the corresponding focused query to identify blast radius and recurrence:
    - `FIJI OPS - Service Health - Request Volume and Failure Rate`
    - `FIJI OPS - Service Health - Endpoint Latency P50/P95/P99`
    - `FIJI OPS - Service Health - Request Traffic Volume by Controller Action`
    - `FIJI OPS - Dependency Health - Failure Rate by Target`
    - `FIJI OPS - Incident - Exception Trend by Type`
    - `FIJI DEVs INV - Top Failing Controller Actions`
    - `FIJI DEVs INV - Slowest Controller Actions by Operation`
    - `FIJI DEVs INV - Retry Summary by Component/Operation`

## Troubleshooting Decision Path

- If failure rate spikes and latency is stable: prioritize dependency failures and auth failures.
- If latency spikes before failures: prioritize slow operations and retries.
- If only one endpoint is affected: prioritize action-level failures and operation-level metrics.
- If queue receives increase but finishes lag: prioritize Worker processing errors and queue backlog investigation.

## Related References

- Root dashboard setup and quick KQL pack:
    [../../../../../README.md](../../../../../README.md)
