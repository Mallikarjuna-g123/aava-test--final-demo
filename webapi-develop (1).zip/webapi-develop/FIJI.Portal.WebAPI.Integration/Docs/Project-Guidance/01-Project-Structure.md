# Project Structure

Back to index: [Project Guidance Index](./README.md)

## Solution Layout

Solution file:
- [FIJI.Portal.Integration.sln](../../FIJI.Portal.Integration.sln)

Projects:
- [FIJI.Portal.WebAPI.Integration](../../FIJI.Portal.WebAPI.Integration.csproj)
- [FIJI.Portal.FileReception.Commons](../../../FIJI.Portal.FileReception.Commons/FIJI.Portal.FileReception.Commons.csproj)
- [FIJI.Portal.FileReception.WinService](../../../FIJI.Portal.FileReception.WinService/FIJI.Portal.FileReception.WinService.csproj)

## WebAPI Project Layout

Root:
- [Program.cs](../../Program.cs): startup pipeline, DI registration, auth, telemetry.
- [appsettings.json](../../appsettings.json) and [appsettings.Development.json](../../appsettings.Development.json): runtime configuration.
- [FIJI.Portal.WebAPI.Integration.csproj](../../FIJI.Portal.WebAPI.Integration.csproj): framework and package dependencies.

Folders:
- [Controllers](../../Controllers): HTTP endpoints.
- [Model](../../Model): business/domain logic and Dataverse orchestration.
- [Model/Generic](../../Model/Generic): reusable generic Dataverse operations.
- [Integration](../../Integration): external integration-specific logic.
- [Observability](../../Observability): correlation middleware and Dataverse proxy instrumentation.
- [Requests](../../Requests): request contracts.
- [Responses](../../Responses): response contracts.
- [Utilities](../../Utilities): constants, route names, query builders, helper utilities.
- [Service](../../Service): service-level helper classes (for example token handling).
- [Docs](../../Docs): generated and maintained documentation.

## Functional Grouping (Practical View)

- Identity and authorization:
  - [Controllers/AuthController.cs](../../Controllers/AuthController.cs)
  - [Service/TokenService.cs](../../Service/TokenService.cs)
- Centralized observability:
  - [Observability/CorrelationAndRequestLoggingMiddleware.cs](../../Observability/CorrelationAndRequestLoggingMiddleware.cs)
  - [Observability/ControllerActionLoggingFilter.cs](../../Observability/ControllerActionLoggingFilter.cs)
  - [Observability/OrganizationServiceLoggingProxy.cs](../../Observability/OrganizationServiceLoggingProxy.cs)
  - [Observability/OutboundHttpLoggingHandler.cs](../../Observability/OutboundHttpLoggingHandler.cs)
  - [Program.cs](../../Program.cs)
- Project and BOM lifecycle:
  - [Controllers/ProjectController.cs](../../Controllers/ProjectController.cs)
  - [Model/Project.cs](../../Model/Project.cs)
  - [Model/BOM.cs](../../Model/BOM.cs)
- Product component lifecycle:
  - [Controllers/ProductComponentController.cs](../../Controllers/ProductComponentController.cs)
  - [Model/ProductComponent.cs](../../Model/ProductComponent.cs)
- File and transfer flows:
  - [Controllers/FileController.cs](../../Controllers/FileController.cs)
  - [Controllers/IAMICTController.cs](../../Controllers/IAMICTController.cs)
  - [../../../FIJI.Portal.FileReception.Commons/Helpers/StorageAccountHelper.cs](../../../FIJI.Portal.FileReception.Commons/Helpers/StorageAccountHelper.cs)
- Dashboard operations:
  - [Controllers/FactoryDashboardController.cs](../../Controllers/FactoryDashboardController.cs)
  - [Model/Tasks.cs](../../Model/Tasks.cs)
  - [Model/Bookings.cs](../../Model/Bookings.cs)

## Request Flow Summary

```mermaid
flowchart TD
    A[Incoming HTTP Request] --> B[Controller]
    B --> C[Request DTO parsing and validation]
    C --> D[Model or Integration service]
    D --> E[Dataverse and Azure dependencies]
    E --> D
    D --> F[Response DTO]
    F --> G[HTTP response]
```
