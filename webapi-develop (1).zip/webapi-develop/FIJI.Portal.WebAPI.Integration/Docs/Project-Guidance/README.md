# FIJI.Portal.WebAPI.Integration Project Guidance

This documentation set explains the middleware project for product owners, developers, and testers.

Project context:
- Hosted on Azure App Service.
- Middleware between front-end portal and Microsoft Dataverse (CRM).
- Core SDKs include Microsoft.Xrm.Sdk and Microsoft.PowerPlatform.Dataverse.Client.

## Contents

1. [Project Structure](./01-Project-Structure.md)
2. [Architectural Conventions](./02-Architectural-Conventions.md)
3. [Technology Stack](./03-Technology-Stack.md)
4. [Code and API Best Practices](./04-Code-and-API-Best-Practices.md)
5. Detailed instruction files:
   - [Dataverse Integration Guidance](./instructions/dataverse-integration.instructions.md)
   - [Controller and Endpoint Guidance](./instructions/api-controller-pattern.instructions.md)
   - [Observability and Logging Guidance](./instructions/observability-and-logging.instructions.md)
   - [Security and Configuration Guidance](./instructions/security-and-config.instructions.md)

Reusable update prompts:
- [Project Guidance Update Prompt](../../../.github/prompts/project-guidance-update.prompt.md)
- [Controller Guidance Update Prompt](../../../.github/prompts/controller-guidance-update.prompt.md)
- [Observability Update Prompt](../../../.github/prompts/observability-update.prompt.md)

## High-Level Architecture

```mermaid
flowchart LR
    FE[Front-end Website] --> API[FIJI.Portal.WebAPI.Integration]
    API --> DV[(Microsoft Dataverse CRM)]
    API --> BLOB[(Azure Blob Storage)]
    API --> SB[(Azure Service Bus)]
    API --> AI[(Azure Application Insights)]

    subgraph App Layers
      CTRL[Controllers]
      MODEL[Model and Integration classes]
      UTIL[Utilities and Query builders]
      OBS[Observability middleware and proxies]
      COMMONS[FIJI.Portal.FileReception.Commons]
    end

    API --> CTRL
    CTRL --> MODEL
    MODEL --> UTIL
    API --> OBS
    OBS --> MODEL
    MODEL --> COMMONS
```

## Intended Audience

- Product Owners:
  - Understand business flow and integration boundaries.
  - Understand impact areas for changes.
- Developers:
  - Follow established controller/model patterns.
  - Extend safely without breaking integration contracts.
- Testers:
  - Identify request validation paths and negative scenarios.
  - Validate endpoint and integration behavior consistently.
