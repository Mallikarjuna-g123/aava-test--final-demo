# Code and API Best Practices

Back to index: [Project Guidance Index](./README.md)

## Purpose

Define practical implementation standards for FIJI middleware APIs to keep them secure, observable, and maintainable.

## API Design Practices

1. Keep controllers focused on API concerns.
- Validate request shape and required values.
- Delegate business logic to model/integration classes.
- Keep status code mapping explicit and consistent.

2. Keep routes centralized.
- Add route constants in [Utilities/RouteConstants.cs](../../Utilities/RouteConstants.cs).
- Avoid duplicated route literals in controllers.

3. Use typed contracts.
- Keep request DTOs in [Requests](../../Requests).
- Keep response DTOs in [Responses](../../Responses).

4. Keep response behavior predictable.
- Use `400` for invalid input/business validation.
- Use `500` for unexpected failures.
- Preserve existing response DTO structure when extending endpoints.

## Observability Practices (Implemented)

1. Central request instrumentation.
- [Observability/CorrelationAndRequestLoggingMiddleware.cs](../../Observability/CorrelationAndRequestLoggingMiddleware.cs) sets and propagates `X-Correlation-ID` and logs request start/end with duration.

2. Central controller action instrumentation.
- [Observability/ControllerActionLoggingFilter.cs](../../Observability/ControllerActionLoggingFilter.cs) is registered globally and logs action start/completion/error with duration and status code for all controllers.

3. Central Dataverse instrumentation.
- [Observability/OrganizationServiceLoggingProxy.cs](../../Observability/OrganizationServiceLoggingProxy.cs) logs Dataverse operations and latency for all `IOrganizationService` calls.

4. Outbound HTTP instrumentation.
- [Observability/OutboundHttpLoggingHandler.cs](../../Observability/OutboundHttpLoggingHandler.cs) is a DelegatingHandler registered via `IHttpClientFactory` that logs all outbound HTTP request/response timing and errors.

5. Authentication event logging.
- JWT bearer events in [Program.cs](../../Program.cs) log authentication failures and challenges as warnings for security visibility.

6. Global exception visibility.
- [Program.cs](../../Program.cs) includes centralized unhandled exception logging and safe 500 JSON response.

7. Startup readiness.
- Application logs a confirmation message after all startup initialization completes.

## Security Practices

- Do not log secrets, tokens, connection strings, or full sensitive payloads.
- Prefer managed identity where feasible for Azure-hosted connectivity.
- Keep CORS restrictions environment-appropriate for production.

## Reliability and Performance Practices

- Prefer async I/O for network operations.
- Avoid fire-and-forget for critical operations unless explicit retry strategy is in place.
- Keep logs structured so production queries are easy in Application Insights.

## PR Review Checklist

- Route constants updated if endpoint path changed.
- DTO changes are backward-compatible where required.
- Logging added through middleware/filter/proxy first, not duplicated across controllers.
- Correlation ID continuity verified from request to response.
- Documentation updated:
  - [Project Guidance Index](./README.md)
  - [Controller and Endpoint Guidance](./instructions/api-controller-pattern.instructions.md)
