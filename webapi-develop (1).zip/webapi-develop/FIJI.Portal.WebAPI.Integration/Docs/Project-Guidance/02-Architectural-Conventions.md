# Architectural Conventions

Back to index: [Project Guidance Index](./README.md)

## Core Architecture Style

The project follows a pragmatic layered style:
- API layer: controllers receive HTTP requests and shape responses.
- Domain/application layer: model classes implement business and Dataverse behavior.
- Shared integration layer: helper classes for storage, Dataverse connection, and messaging.

## Conventions Observed In Code

1. Controller routing and authorization
- Most controllers use `[Route("[controller]")]` and route constants from [Utilities/RouteConstants.cs](../../Utilities/RouteConstants.cs).
- Many business endpoints are protected by `[Authorize]`.

2. Controller responsibility
- Controllers generally:
  - validate payload or required fields,
  - call one or more model methods,
  - map outcomes to HTTP status codes.
- Example: [Controllers/ProjectController.cs](../../Controllers/ProjectController.cs).

3. Business logic placement
- Significant logic is in model classes under [Model](../../Model).
- Example high-complexity domains:
  - [Model/Project.cs](../../Model/Project.cs)
  - [Model/ProductComponent.cs](../../Model/ProductComponent.cs)
  - [Model/ServiceSnapshot.cs](../../Model/ServiceSnapshot.cs)

4. Dataverse access pattern
- Dataverse operations are performed via `IOrganizationService` and SDK types.
- Generic helpers exist in [Model/Generic](../../Model/Generic).

5. Error-handling pattern
- Common pattern is `try/catch` in controllers with `BadRequest` for validation/business failures and `StatusCode(500)` for unexpected failures.
- Response DTOs often contain `Error` property when operation fails.

6. Utility-driven query and constants
- Query construction is centralized in [Utilities/SqlQuery.cs](../../Utilities/SqlQuery.cs).
- Route names are centralized in [Utilities/RouteConstants.cs](../../Utilities/RouteConstants.cs).
- Shared constant values are in [Utilities/Constants.cs](../../Utilities/Constants.cs).

7. Telemetry and startup configuration
- OpenTelemetry with Azure Monitor is configured in [Program.cs](../../Program.cs).
- CORS, JWT auth, Swagger, memory cache, and Dataverse DI are configured at startup.
- Request correlation and request-timing logs are centralized via [Observability/CorrelationAndRequestLoggingMiddleware.cs](../../Observability/CorrelationAndRequestLoggingMiddleware.cs).
- Controller action logging is centralized via [Observability/ControllerActionLoggingFilter.cs](../../Observability/ControllerActionLoggingFilter.cs).
- Dataverse operation logs are centralized via [Observability/OrganizationServiceLoggingProxy.cs](../../Observability/OrganizationServiceLoggingProxy.cs).
- Outbound HTTP call logs are centralized via [Observability/OutboundHttpLoggingHandler.cs](../../Observability/OutboundHttpLoggingHandler.cs).
- JWT authentication failures are logged via bearer events in [Program.cs](../../Program.cs).

8. Exception handling convention
- Unhandled exceptions are captured centrally in startup pipeline and logged with request context.
- Controller-level try/catch blocks remain for business-level status mapping and response contracts.

## Architectural Risks To Watch

- Large model classes increase coupling and change impact.
- Controller-level object construction appears in places where full DI could improve testability.
- Raw body parsing in some endpoints can reduce contract clarity if not documented and tested.

## Recommended Convention Checklist For New Changes

- Keep route names in [Utilities/RouteConstants.cs](../../Utilities/RouteConstants.cs).
- Use typed request/response DTOs in [Requests](../../Requests) and [Responses](../../Responses).
- Keep controllers thin and place business logic in [Model](../../Model).
- Keep endpoint implementation guidance updated in [instructions/api-controller-pattern.instructions.md](./instructions/api-controller-pattern.instructions.md).
- Add operational logging for business-critical paths and integration calls.
- Preserve and propagate `X-Correlation-ID` for diagnostics across client and API boundaries.
