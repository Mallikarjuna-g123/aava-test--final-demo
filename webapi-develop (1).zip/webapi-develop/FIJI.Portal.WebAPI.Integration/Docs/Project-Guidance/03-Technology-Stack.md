# Technology Stack

Back to index: [Project Guidance Index](./README.md)

## Runtime and Hosting

- Runtime: .NET 10 Web API project.
- Hosting: Azure App Service (as described in project usage context).
- Project file: [FIJI.Portal.WebAPI.Integration.csproj](../../FIJI.Portal.WebAPI.Integration.csproj)

## Core Application Framework

- ASP.NET Core Web API.
- Swagger/OpenAPI via Swashbuckle.
- JWT authentication via `Microsoft.AspNetCore.Authentication.JwtBearer`.

## Dataverse / CRM Integration

Primary SDKs:
- `Microsoft.Xrm.Sdk`
- `Microsoft.PowerPlatform.Dataverse.Client`

Connection creation and DI registration occur in:
- [Program.cs](../../Program.cs)

## Azure Platform Dependencies

- Azure Identity: managed identity and credential-based auth.
- Azure Storage Blobs: file and streaming operations.
- Azure Service Bus (through commons helper project) for async notification flow.
- Azure Application Insights via OpenTelemetry Azure Monitor exporter.

## Observability Components (Implemented)

- Request correlation and timing middleware:
  - [Observability/CorrelationAndRequestLoggingMiddleware.cs](../../Observability/CorrelationAndRequestLoggingMiddleware.cs)
- Dataverse operation instrumentation proxy:
  - [Observability/OrganizationServiceLoggingProxy.cs](../../Observability/OrganizationServiceLoggingProxy.cs)
- Central unhandled exception logging pipeline:
  - [Program.cs](../../Program.cs)

## Serialization and Document Processing

- JSON: Newtonsoft.Json and System.Text.Json.
- Open XML for Office document text extraction.
- PdfPig for PDF text extraction in file scanning flow.

## Cross-Project Dependencies

- Web API references commons project:
  - [../../../FIJI.Portal.FileReception.Commons/FIJI.Portal.FileReception.Commons.csproj](../../../FIJI.Portal.FileReception.Commons/FIJI.Portal.FileReception.Commons.csproj)
- Commons project includes reusable storage, messaging, and Dataverse helper components.

## Configuration Surface

Configured via appsettings and environment variables:
- Logging levels.
- Application Insights connection string.
- Dataverse settings (URL, connection string, client credentials).
- JWT secret.
- Storage and service bus settings.

Configuration files:
- [appsettings.json](../../appsettings.json)
- [appsettings.Development.json](../../appsettings.Development.json)

## Quality and Operations Note

Configuration files currently include sensitive keys/secrets in development settings. For public and production-safe operations, prefer secure secret providers (for example Azure Key Vault) and avoid storing plain secrets in source-controlled config files.
