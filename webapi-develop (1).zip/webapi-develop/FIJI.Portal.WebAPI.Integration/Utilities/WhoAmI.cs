﻿using Newtonsoft.Json;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class WhoAmI
    {
        [JsonProperty("@odata.context")]
        public string odatacontext { get; set; }
        public string BusinessUnitId { get; set; }
        public string UserId { get; set; }
        public string OrganizationId { get; set; }
    }
}
