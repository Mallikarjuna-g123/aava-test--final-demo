﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public static class EntityName
    {
        public const string Account = "account";
        public const string Contact = "contact";
        public const string Project = "fiji_project";
        public const string ProductFamily = "fiji_productfamily";
        public const string Servicesnapshot = "fiji_servicesnapshot";
        public const string BOM= "fiji_billofmaterials";
        public const string ComponentType = "fiji_componenttype";
        public const string OAC = "fiji_objectactioncode";
        public const string ProductComponent = "fiji_productcomponent";
        public const string TaskType = "fiji_tasktype";
        public const string FijiConfiguration = "fiji_configuration";
        public const string SystemUser = "systemuser";
        public const string Task = "task";
        public const string RegionLocale = "fiji_regionlocale";
        public const string DeviceCategory = "fiji_devicecategory";
        public const string BookableResource = "bookableresource";
        public const string Bookings = "bookableresourcebooking";
        public const string FijiFactory = "fiji_factory";
        public const string Team = "team";
        public const string FijiTeamContact = "fiji_team_contact";
        public const string BookingStatus = "bookingstatus";
        public const string Country = "fiji_country";
        public const string FijiAssetTagSize = "fiji_assettagsize";
        public const string PCBiosRevision = "fiji_pcbiosrevision";
        public const string KMATProductFamily = "fiji_kmatproductfamily";
        public const string PCPlatformStatus = "fiji_pc_platform_status";
        public const string PlatformAndPlacement = "fiji_platformplacement";
        public const string PlatformRegionLocale = "fiji_productfamily_regionlocale";
        public const string ServiceComplexity = "fiji_servicecomplexity";
        public const string ProductComponentAccount = "fiji_fiji_productcomponent_account";
        public const string ProjectRegionLocale = "fiji_fiji_project_fiji_regionlocale";
        public const string AccountRegionLocale= "fiji_account_fiji_regionlocale";
        public const string Region = "fiji_region";
        public const string SubRegion = "fiji_subregion";
        public const string Calendar = "calendar";
        public const string CalendarRule = "calendarrule";
        public const string TimeZoneDefinition = "timezonedefinition";
        public const string ProductLine = "fiji_productline";
        public const string Delay = "fiji_delay";
        public const string DelayReasons = "fiji_delayreasons";
        public const string DelaySubReasons = "fiji_delaysubreasons";
        public const string ADRReport = "fiji_adrreport";
        public const string ProjectStageTracker = "fiji_projectstagetracker";
        public const string PlatformOperatingSystem = "fiji_plaformoperatingsystem";
        public const string OperatingSystem = "fiji_operatingsystem";
        public const string ComponentTypeOperatingSystem= "fiji_componenttypeoperatingsystem";
        public const string BIOSConfigurationLine = "fiji_biosconfigurationline";
        public const string BIOSConfiguration = "fiji_biosconfiguration";
        public const string PortalManagementInfo = "fiji_portalmanagementinfo";
    }
}
