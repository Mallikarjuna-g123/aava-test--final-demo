using Microsoft.Extensions.Options;
using Microsoft.Playwright;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    /// <summary>
    /// Manages a single long-lived Chromium browser process shared across all
    /// requests. Key production characteristics for PremiumV3 Azure Windows Web App:
    ///
    ///  - One browser process (not one per request) � keeps memory stable.
    ///  - Per-request IBrowserContext gives full tab/cookie/cache isolation without
    ///    the overhead of launching a new browser each time.
    ///  - SemaphoreSlim caps concurrent PDF renders to prevent memory exhaustion
    ///    under traffic spikes (configured via BrowserService:MaxConcurrentPages).
    ///  - Automatic crash recovery � a disconnected browser is detected on the next
    ///    AcquireContextAsync call and transparently relaunched.
    ///  - Registered as both IHostedService (startup/shutdown lifecycle) and
    ///    IBrowserService singleton (injected into controllers).
    /// </summary>
    public sealed class BrowserService : IBrowserService, IHostedService, IAsyncDisposable
    {
        private readonly ILogger<BrowserService> _logger;
        private readonly BrowserServiceOptions _options;

        private IPlaywright? _playwright;
        private IBrowser? _browser;

        private readonly SemaphoreSlim _concurrencySemaphore;
        private readonly SemaphoreSlim _browserLock = new(1, 1);

        public BrowserService(ILogger<BrowserService> logger, IOptions<BrowserServiceOptions> options)
        {
            _logger = logger;
            _options = options.Value;
            _concurrencySemaphore = new SemaphoreSlim(_options.MaxConcurrentPages, _options.MaxConcurrentPages);
        }

        // ?? IHostedService ????????????????????????????????????????????????????

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("BrowserService starting. MaxConcurrentPages={Max}, RenderTimeoutSeconds={Timeout}",
                _options.MaxConcurrentPages, _options.RenderTimeoutSeconds);
            await EnsureBrowserAsync(cancellationToken);
        }

        public async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("BrowserService stopping.");
            await DisposeBrowserAsync();
        }

        // ?? IBrowserService ???????????????????????????????????????????????????

        public async Task<BrowserContextHandle> AcquireContextAsync(CancellationToken cancellationToken = default)
        {
            // Block if too many renders are already in flight.
            await _concurrencySemaphore.WaitAsync(cancellationToken);

            try
            {
                return await CreateContextHandleAsync(cancellationToken);
            }
            catch (Exception ex) when (IsBrowserClosedError(ex))
            {
                // The browser process died between the IsConnected check and the actual
                // context creation (e.g. it was left in a bad state by --single-process).
                // Null out the browser so EnsureBrowserAsync relaunches it, then retry once.
                _logger.LogWarning(ex, "Browser was closed when opening a context. Forcing restart and retrying.");
                _browser = null;

                try
                {
                    return await CreateContextHandleAsync(cancellationToken);
                }
                catch
                {
                    _concurrencySemaphore.Release();
                    throw;
                }
            }
            catch
            {
                _concurrencySemaphore.Release();
                throw;
            }
        }

        private async Task<BrowserContextHandle> CreateContextHandleAsync(CancellationToken cancellationToken)
        {
            var browser = await EnsureBrowserAsync(cancellationToken);
            var context = await browser.NewContextAsync();
            return new BrowserContextHandle(context, _concurrencySemaphore, _logger);
        }

        private static bool IsBrowserClosedError(Exception ex) =>
            ex.Message.Contains("Target page, context or browser has been closed",
                StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("Browser has been closed", StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("Connection closed", StringComparison.OrdinalIgnoreCase);

        // ?? Internals ?????????????????????????????????????????????????????????

        private async Task<IBrowser> EnsureBrowserAsync(CancellationToken cancellationToken)
        {
            // Fast path � browser is alive.
            if (_browser is { IsConnected: true })
                return _browser;

            await _browserLock.WaitAsync(cancellationToken);
            try
            {
                // Double-check after acquiring the lock.
                if (_browser is { IsConnected: true })
                    return _browser;

                if (_browser != null)
                {
                    _logger.LogWarning("Browser disconnected. Restarting...");
                    await DisposeBrowserAsync();
                }

                _playwright = await Playwright.CreateAsync();
                _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
                {
                    Headless = true,
                    Args = new[]
                    {
                        "--no-sandbox",
                        "--disable-setuid-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-gpu"
                    }
                });

                _browser.Disconnected += (_, _) =>
                    _logger.LogWarning("Chromium browser disconnected. It will restart on the next request.");

                _logger.LogInformation("Chromium browser launched.");
                return _browser;
            }
            finally
            {
                _browserLock.Release();
            }
        }

        private async Task DisposeBrowserAsync()
        {
            if (_browser != null)
            {
                try { await _browser.CloseAsync(); } catch { /* already gone */ }
                _browser = null;
            }
            _playwright?.Dispose();
            _playwright = null;
        }

        public async ValueTask DisposeAsync()
        {
            await DisposeBrowserAsync();
            _concurrencySemaphore.Dispose();
            _browserLock.Dispose();
        }
    }
}
