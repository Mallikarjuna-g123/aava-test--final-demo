﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public static class RouteConstants
    {
        public const string UploadADRReport = "UploadADRReport";
        public const string GetDownloadADRReportUrl = "GetDownloadADRReportUrl";
        public const string CreateCustomerFolder = "CreateCustomerFolder";
        public const string Execute = "Execute";
        public const string CustomerRequest = "CustomerRequest";
        public const string CustomerServices = "CustomerServices";
        public const string GetScheduleByUserId = "GetScheduleByUserId";
        public const string GetTasks = "GetTasks";
        public const string UpdateTasks = "UpdateTasks";
        public const string GetBookingsByUserId = "GetBookingsByUserId";
        public const string Export = "Export";
        public const string Upload = "Upload";
        public const string GetCountofRecords = "GetCountofRecords";
        public const string GetDownloadUrl = "GetDownloadUrl";
        public const string Download = "download/{container}";
        public const string UploadIAM = "upload/{container}";
        public const string GetIAMValidExtensions = "GetIAMValidExtensions";
        public const string GenerateUploadUrl = "GenerateUploadUrl";
        public const string SetSHA256 = "SetSHA256";
        public const string Delete = "Delete";
        public const string GetOptionSetValues = "GetOptionSetValues";
        public const string GetData = "GetData";
        public const string GetProductComponents = "GetProductComponents";
        public const string GetCustomerSpecificProductComponents = "GetCustomerSpecificProductComponents";
        public const string GetCSAVToPreSelectBasedOnOCCID = "GetCSAVToPreSelectBasedOnOCCID";
        public const string ConfigureNew = "ConfigureNew";
        public const string Duplicate = "Duplicate";
        public const string GetBiosConfigDetails = "GetBiosConfigDetails";
        public const string Create = "Create";
        public const string AddLocalizationToEcnProject = "AddLocalizationToEcnProject";
        public const string UpdateBomItems = "UpdateBomItems";
        public const string UpdateCSAV = "UpdateCSAV";
        public const string Submit = "Submit";
        public const string GetProjectByRequestID = "GetProjectByRequestID";
        public const string NewInceptionCreation = "NewInceptionCreation";
        public const string ECNInceptionCreation = "ECNInceptionCreation";
        public const string Update = "Update";
        public const string Authorize = "api/v1/auth";
        public const string DeleteRecord = "deleteRecord";
        public const string UpdateRecord = "updateRecord";
        public const string CreateRecord = "createRecord";
        public const string RetrieveRecord = "retrieveRecord";
        public const string RetrieveMultipleRecords = "retrieveMultipleRecords";
        public const string DownloadPortalFile = "portal/webfiles/download/{fileName}";
        public const string DownloadFile = "{containerName}/{Folder}/{FileName}";
        public const string DownloadFileEncodedUrl = "{containerName}/{encodedFileUrl}";
        public const string OpenIdConfiguration = "api/openid-configuration";
        public const string RemoveModel = "RemoveModel";
        public const string ClearComparison = "ClearComparison";
        public const string DuplicateV1 = "DuplicateV1";
        public const string CreateFileContainer = "CreateFileContainer";
        public const string GetHeaderDetails = "GetHeaderDetails";
        public const string Generate = "Generate";
        public const string CreateNewService = "CreateNewService";
        public const string FetchProjectBySkuNumber = "FetchProjectBySkuNumber";
        public const string ListFSPMUsers = "ListFSPMUsers";
        public const string GetFSPMUsingCustomerID = "GetFSPMUsingCustomerID";
        public const string FetchVolumeLicenseManager = "FetchVolumeLicenseManager";
        public const string CheckTenantConsent = "CheckTenantConsent";
    }
}
