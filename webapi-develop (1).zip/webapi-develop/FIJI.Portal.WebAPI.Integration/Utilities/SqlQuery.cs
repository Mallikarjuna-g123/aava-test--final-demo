﻿using FIJI.Portal.WebAPI.Integration.Requests.Customer;
using Newtonsoft.Json.Linq;
using static FIJI.Portal.WebAPI.Integration.Model.BOM;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public static class SqlQuery
    {

        //public static string BomQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n<entity name='fiji_billofmaterials'>\r\n<attribute name='fiji_project' />\r\n<attribute name='fiji_productcomponent' />\r\n<attribute name='fiji_name' />\r\n<attribute name='fiji_objectactioncode' />\r\n<attribute name='fiji_procurementconsultform' />\r\n<attribute name='fiji_billofmaterialsid' />\r\n<order attribute='fiji_project' descending='false' />\r\n<filter type='and'>\r\n<condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n</filter>\r\n<link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='pc'>\r\n<attribute name='fiji_externalid' />\r\n<attribute name='fiji_componenttype' />\r\n<attribute name='fiji_servicecomplexity' />\r\n<filter type='and'>\r\n<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420001' />\r\n<condition attribute='fiji_iscsigenericservice' operator='not-null' />\r\n<condition attribute='fiji_iscsigenericservice' operator='eq' value='1' />\r\n</filter>\r\n<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='ac'>\r\n<attribute name='fiji_servicenumber' />\r\n<filter type='and'>\r\n<condition attribute='fiji_isfactoryservice' operator='eq' value='1' />\r\n<condition attribute='fiji_servicecomplexity' operator='not-null' />\r\n</filter>\r\n</link-entity>\r\n</link-entity>\r\n<link-entity name='fiji_project' from='fiji_projectid' to='fiji_project' visible='false' link-type='outer' alias='pr'>\r\n<attribute name='fiji_productfamily' />\r\n</link-entity>\r\n</entity>\r\n</fetch>";entity>\r\n</link-entity>\r\n<link-entity name='fiji_project' from='fiji_projectid' to='fiji_project' visible='false' link-type='outer' alias='pr'>\r\n<attribute name='fiji_productfamily' />\r\n<link-entity name=\"fiji_productfamily\" from=\"fiji_productfamilyid\" to=\"fiji_productfamily\" link-type=\"inner\" alias=\"ab\">\r\n<attribute name=\"fiji_name\" />\r\n</link-entity>\r\n</link-entity>\r\n</entity>\r\n</fetch>\r\n";
        public static string BomQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n<entity name='fiji_billofmaterials'>\r\n<attribute name='fiji_project' />\r\n<attribute name='fiji_productcomponent' />\r\n<attribute name='fiji_name' />\r\n<attribute name='fiji_objectactioncode' />\r\n<attribute name='fiji_procurementconsultform' />\r\n<attribute name='fiji_billofmaterialsid' />\r\n<order attribute='fiji_project' descending='false' />\r\n<filter type='and'>\r\n<condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n</filter>\r\n<link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='pc'>\r\n<attribute name='fiji_externalid' />\r\n<attribute name='fiji_componenttype' />\r\n<attribute name='fiji_servicecomplexity' />\r\n<attribute name='fiji_name'/>\r\n<filter type='and'>\r\n<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420001' />\r\n<condition attribute='fiji_iscsigenericservice' operator='not-null' />\r\n<condition attribute='fiji_iscsigenericservice' operator='eq' value='1' />\r\n</filter>\r\n<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='ac'>\r\n<attribute name='fiji_servicenumber' />\r\n<attribute name='fiji_name' />\r\n<filter type='and'>\r\n<condition attribute='fiji_isfactoryservice' operator='eq' value='1' />\r\n<condition attribute='fiji_servicecomplexity' operator='not-null' />\r\n</filter>\r\n</link-entity>\r\n<link-entity name=\"fiji_servicecomplexity\" from=\"fiji_servicecomplexityid\" to=\"fiji_servicecomplexity\" link-type=\"inner\" alias=\"aa\">\r\n<attribute name=\"fiji_name\" />\r\n</link-entity>\r\n</link-entity>\r\n<link-entity name='fiji_project' from='fiji_projectid' to='fiji_project' visible='false' link-type='outer' alias='pr'>\r\n<attribute name='fiji_productfamily' />\r\n<link-entity name=\"fiji_productfamily\" from=\"fiji_productfamilyid\" to=\"fiji_productfamily\" link-type=\"inner\" alias=\"ab\">\r\n<attribute name=\"fiji_name\" />\r\n</link-entity>\r\n</link-entity>\r\n</entity>\r\n</fetch>\r\n";

        public static string Osfiletype = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >\r\n    <entity name='fiji_osfiletype' >\r\n        <attribute name='fiji_osfiletypeid' />\r\n        <attribute name='fiji_name' />\r\n        <attribute name='createdon' />\r\n        <attribute name='fiji_minunit' />\r\n        <attribute name='fiji_minsize' />\r\n        <attribute name='fiji_maxunit' />\r\n        <attribute name='fiji_maxsize' />\r\n        <attribute name='fiji_everestid' />\r\n        <order attribute='fiji_name' descending='false' />\r\n <link-entity name='fiji_osvolumefileinfo' from='fiji_osfiletype' to='fiji_osfiletypeid' link-type='inner' alias='ac' >\r\n            <link-entity name='fiji_osvolumetype' from='fiji_osvolumetypeid' to='fiji_osvolumetype' link-type='inner' alias='ad' >\r\n<filter type='and' >\r\n <condition attribute='fiji_osvolumetypeid' operator='eq' value='{0}' />\r\n </filter>\r\n </link-entity>\r\n </link-entity>\r\n </entity>\r\n</fetch>";

        public static string Servicerevision = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <attribute name='fiji_parentservice' />\r\n    <attribute name='fiji_name' />\r\n    <order attribute='fiji_parentservice' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_servicesnapshotid' operator='eq'  uitype='fiji_servicesnapshot' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_parentservice' visible='false' link-type='outer' alias='ps'>\r\n      <attribute name='fiji_externalid' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string Projectplatformproductline = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_project'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_projectid' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_productline' />\r\n    <order attribute='fiji_name' descending='true' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_projectid' operator='eq' uiname='7013143-000' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productfamily' from='fiji_productfamilyid' to='fiji_productfamily' visible='false' link-type='outer' alias='pf'>\r\n      <attribute name='fiji_name' />\r\n    </link-entity>\r\n    <link-entity name='fiji_productline' from='fiji_productlineid' to='fiji_productline' visible='false' link-type='outer' alias='pl'>\r\n      <attribute name='fiji_name' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string ProjectBomServicedetails = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n    <entity name='fiji_billofmaterials'>\r\n      <attribute name='fiji_billofmaterialsid' />\r\n      <attribute name='fiji_name' />\r\n      <attribute name='createdon' />\r\n      <attribute name='fiji_servicerevision' />\r\n      <order attribute='fiji_name' descending='false' />\r\n      <filter type='and'>\r\n        <condition attribute='fiji_project' operator='eq'  uitype='fiji_project' value='{0}' />\r\n      </filter>\r\n    </entity>\r\n  </fetch>";

        public static string GetServiceRevision_ById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n        <attribute name='fiji_name' />\r\n        <attribute name='createdon' />\r\n        <attribute name='fiji_servicesnapshotid' />\r\n        <attribute name='statuscode' />\r\n        <attribute name='fiji_servicedetailinjson' />\r\n    <order attribute='createdon' descending='true' />\r\n    <link-entity name='fiji_billofmaterials' from='fiji_servicerevision' to='fiji_servicesnapshotid' link-type='inner' alias='ak'>\r\n <filter type='and'>\r\n<condition attribute='fiji_objectactioncode' operator='ne' uiname='REMOVE' uitype='fiji_objectactioncode' value='{0}' />\r\n</filter>\r\n      <link-entity name='fiji_project' from='fiji_projectid' to='fiji_project' link-type='inner' alias='al'>\r\n        <filter type='and'>\r\n          <condition attribute='fiji_projectid' operator='eq'  uitype='fiji_project' value= '{1}'/>\r\n \r\n        </filter>\r\n      </link-entity>\r\n      <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='am'>\r\n        <link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='an'>\r\n          <filter type='and'>\r\n            <condition attribute='fiji_servicenumber' operator='eq' value='{2}' />\r\n          </filter>\r\n        </link-entity>\r\n      </link-entity>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string Getcomponenttypebyid = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_componenttype'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_servicenumber' />\r\n    <attribute name='fiji_componenttypeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <filter type='or'>\r\n        {0}\r\n      </filter>\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetOperatingSystems_ByPlatformId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n    <entity name='fiji_operatingsystem'>\r\n      <attribute name='fiji_operatingsystemid' />\r\n      <attribute name='fiji_name' />\r\n      <attribute name='createdon' />\r\n      <attribute name='fiji_displayname' />\r\n      <attribute name='fiji_osimagetype' />\r\n      <attribute name='fiji_oscategory' />\r\n<attribute name='fiji_isvolumelicenserequired' />\r\n      <order attribute='fiji_name' descending='false' />\r\n      <filter type='and'>\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n      </filter>\r\n      <link-entity name='fiji_plaformoperatingsystem' from='fiji_operatingsystem' to='fiji_operatingsystemid' link-type='inner' alias='ae'>\r\n        <filter type='and'>\r\n<condition attribute='fiji_isqualified' operator='eq' value='1' />\r\n          <condition attribute='fiji_platform' operator='like' value='{0}' /> \r\n        </filter>\r\n      </link-entity>\r\n    </entity>\r\n  </fetch>";

        public static string GetOACByName = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_objectactioncode'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_objectactioncodeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_name' operator='eq' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetOSCloing = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n<entity name='fiji_oscloningtool'>\r\n<attribute name='fiji_oscloningtoolid' />\r\n<attribute name='fiji_name' />\r\n<attribute name='createdon' />\r\n<order attribute='fiji_name' descending='false' />\r\n<filter type='and'>\r\n<condition attribute='statecode' operator='eq' value='0' />\r\n</filter>\r\n</entity>\r\n</fetch>";

        public static string GetAY116ComponentTypes = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n        <entity name='fiji_componenttype'>\r\n        <attribute name='fiji_name' />\r\n        <attribute name='createdon' />\r\n        <attribute name='fiji_servicenumber' />\r\n        <attribute name='fiji_servicecomplexity' />\r\n        <attribute name='fiji_isfactoryservice' />\r\n        <attribute name='fiji_componenttypeid' />\r\n        <attribute name='fiji_isay116av' />\r\n        <order attribute='fiji_name' descending='false' />\r\n        <filter type='and'>\r\n            <condition attribute='fiji_isfactoryservice' operator='eq' value='1' />\r\n            <condition attribute='fiji_servicecomplexity' operator='not-null' />\r\n            <condition attribute='fiji_isay116av' operator='eq' value='1' />\r\n        </filter>\r\n        </entity>\r\n    </fetch>";

        public static string GetBomByIPS = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n      <condition attribute='fiji_createdbyipcs' operator='eq' value='1' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetPortalCommentsByProejctId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='adx_portalcomment'>\r\n    <attribute name='activityid' />\r\n    <attribute name='subject' />\r\n    <attribute name='createdon' />\r\n    <attribute name='modifiedon' />\r\n    <attribute name='modifiedby' />\r\n    <attribute name='description' />\r\n    <order attribute='modifiedon' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='regardingobjectid' operator='eq' uitype='fiji_project' value='{0}' />\r\n\t  <condition attribute='description' operator='not-null' />\r\n    <condition attribute='statecode' operator='eq' value='0' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetPortalCommentsByProductComponent = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='adx_portalcomment'>\r\n    <attribute name='activityid' />\r\n    <attribute name='subject' />\r\n    <attribute name='createdon' />\r\n    <attribute name='modifiedon' />\r\n    <attribute name='modifiedby' />\r\n    <attribute name='description' />\r\n    <order attribute='modifiedon' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='regardingobjectid' operator='eq' uitype='fiji_productcomponent' value='{0}' />\r\n\t  <condition attribute='statecode' operator='eq' value='0' />\r\n    <condition attribute='statecode' operator='eq' value='0' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetProductComponentByExternalId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_productcomponent'>\r\n    <attribute name='fiji_productcomponentid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n <condition attribute='fiji_externalid' operator='eq' value='{0}' />   \r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMByProjectIdAndExternalId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <link-entity name='fiji_project' from='fiji_projectid' to='fiji_project' link-type='inner' alias='aa'>\r\n      <filter type='and'>\r\n        <condition attribute='fiji_projectid' operator='eq' uitype='fiji_project' value='{0}' />\r\n      </filter>\r\n    </link-entity>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ab'>\r\n      <filter type='and'>\r\n     <condition attribute='fiji_externalid' operator='eq' value='{1}' />\r\n      </filter>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMByServiceNumber = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_project' operator='eq'  uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ac'>\r\n      <link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='ad'>\r\n        <filter type='and'>\r\n          <condition attribute='fiji_servicenumber' operator='eq' value='{1}' />\r\n        </filter>\r\n      </link-entity>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMByID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_productcomponent' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_billofmaterialsid' operator='eq' uiname='BOM-1023756' uitype='fiji_billofmaterials' value='{0}' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n      <condition attribute='statuscode' operator='eq' value='1' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetFPCByPlatformAndLocalization = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_factoryproductioncapability'>\r\n    <attribute name='fiji_factoryproductioncapabilityid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_localization' />\r\n    <attribute name='fiji_factorypriority' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_productfamily' operator='eq' uitype='fiji_productfamily' value='{0}' />\r\n      <condition attribute='fiji_localization' operator='eq' uitype='fiji_regionlocale' value='{1}' />\r\n      <condition attribute='fiji_factorypriority' operator='eq' value='{2}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetFPCByLocalizationAndProjectId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>\r\n  <entity name='fiji_factoryproductioncapability'>\r\n    <attribute name='fiji_factoryproductioncapabilityid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_localization' operator='eq' uitype='fiji_regionlocale' value='{0}' />\r\n      <condition attribute='fiji_factorypriority' operator='eq' value='1' />\r\n    </filter>\r\n    <link-entity name='fiji_project_fiji_factoryprodcap' from='fiji_factoryproductioncapabilityid' to='fiji_factoryproductioncapabilityid' visible='false' intersect='true'>\r\n      <link-entity name='fiji_project' from='fiji_projectid' to='fiji_projectid' alias='ag'>\r\n        <filter type='and'>\r\n          <condition attribute='fiji_projectid' operator='eq' uiname='7010116-000' uitype='fiji_project' value='{1}' />\r\n        </filter>\r\n      </link-entity>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetObjectActionCodeForNew = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_objectactioncode'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_objectactioncodeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_name' operator='eq' value='NEW' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n      <condition attribute='statuscode' operator='eq' value='1' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetProjectByID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='fiji_project' >\r\n    <attribute name='fiji_projectid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_customerid' />\r\n    <attribute name='fiji_productline' />\r\n    <attribute name='statuscode' />\r\n    <attribute name='fiji_projectcompletedon' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_projectoriginatingregionid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and' >\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n      <condition attribute='fiji_projectid' operator='eq' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMByProjectIdAndComponentTypeID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ad'>\r\n      <filter type='and'>\r\n       <condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n        <condition attribute='fiji_componenttype' operator='eq' value='{1}' />\r\n      </filter>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetServiceRevisionByProjectId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <attribute name='fiji_servicedetailinjson' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_componenttype' operator='eq' uitype='fiji_componenttype' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='ComponentType'>\r\n      <attribute name='fiji_name' />\r\n\t  <attribute name='fiji_componenttypeid' />\r\n      <attribute name='fiji_servicenumber' />\r\n      <filter type='and'>\r\n        <condition attribute='fiji_isfactoryservice' operator='eq' value='1' />\r\n        <condition attribute='fiji_servicecomplexity' operator='not-null' />\r\n      </filter>\r\n    </link-entity>\r\n    <link-entity name='fiji_billofmaterials' from='fiji_servicerevision' to='fiji_servicesnapshotid' link-type='inner' alias='ad'>\r\n      <filter type='and'>\r\n        <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{1}' />\r\n        <condition attribute='fiji_objectactioncode' operator='ne' uitype='fiji_objectactioncode' value='EBADED1A-CB4B-EC11-8C62-0022480A6838' />\r\n      </filter>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetPortalManagementInfoById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_portalmanagementinfo'>\r\n    <attribute name='fiji_portalmanagementinfoid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_suffix' />\r\n    <attribute name='fiji_serialnumber' />\r\n    <attribute name='fiji_prefix' />\r\n    <attribute name='modifiedon' />\r\n    <attribute name='fiji_lowestnumber' />\r\n    <attribute name='fiji_howmanydigits' />\r\n    <attribute name='fiji_hightestnumber' />\r\n    <attribute name='fiji_filename' />\r\n    <attribute name='fiji_contact' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_portalmanagementinfoid' operator='eq' uitype='fiji_portalmanagementinfo' value='{0}' />\r\n      <condition attribute='fiji_useby' operator='eq' value='3' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n    </filter>\r\n    <link-entity name='contact' from='contactid' to='fiji_contact' visible='false' link-type='outer' alias='Contact'>\r\n      <attribute name='fullname' />\r\n      <attribute name='emailaddress1' />\r\n      <attribute name='fiji_contactid' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetPortalManagementInfoByCustomerId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_portalmanagementinfo'>\r\n    <attribute name='fiji_portalmanagementinfoid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_suffix' />\r\n    <attribute name='fiji_serialnumber' />\r\n    <attribute name='fiji_prefix' />\r\n    <attribute name='modifiedon' />\r\n    <attribute name='fiji_lowestnumber' />\r\n    <attribute name='fiji_howmanydigits' />\r\n    <attribute name='fiji_hightestnumber' />\r\n    <attribute name='fiji_filename' />\r\n    <attribute name='fiji_contact' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_customer' operator='eq' uitype='account' value='{0}' />\r\n      <condition attribute='fiji_useby' operator='eq' value='3' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n    </filter>\r\n    <link-entity name='contact' from='contactid' to='fiji_contact' visible='false' link-type='outer' alias='Contact'>\r\n      <attribute name='fullname' />\r\n      <attribute name='emailaddress1' />\r\n      <attribute name='fiji_contactid' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetAccountById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >\r\n  <entity name='account' >\r\n    <attribute name='name' />\r\n    <attribute name='primarycontactid' />\r\n    <attribute name='accountid' />\r\n    <attribute name='fiji_projectmanager' />\r\n    <attribute name='fiji_backupprojectmanager' />\r\n    <attribute name='fiji_customerheadquarters' />\r\n    <order attribute='name' descending='false' />\r\n    <filter type='and' >\r\n      <condition attribute='accountid' operator='eq' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetComponentByGuid = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_componenttype'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_servicenumber' />\r\n    <attribute name='fiji_servicecomplexity' />\r\n    <attribute name='fiji_componenttypeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_componenttypeid' operator='eq' uitype='fiji_componenttype' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetPlatformById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='fiji_productfamily' >\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_srpkmat' />\r\n    <attribute name='fiji_productline' />\r\n    <attribute name='fiji_releasetocdonline' />\r\n    <attribute name='fiji_qualifiedstatus' />\r\n    <attribute name='fiji_platformstatus' />\r\n    <attribute name='fiji_baseplatform' />\r\n    <attribute name='fiji_productfamilyid' />\r\n    <attribute name='fiji_materialnumber' />\r\n    <attribute name='fiji_sadate' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_pidate' />\r\n    <attribute name='fiji_pedate' />\r\n    <attribute name='fiji_padate' />\r\n    <attribute name='fiji_nedate' />\r\n    <attribute name='fiji_gadate' />\r\n    <attribute name='fiji_esdate' />\r\n    <attribute name='fiji_emdate' />\r\n    <attribute name='fiji_eldate' />\r\n    <attribute name='fiji_dodate' />\r\n    <attribute name='fiji_cxdate' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and' >\r\n      <condition attribute='fiji_productfamilyid' operator='eq' uitype='fiji_productfamily' value='{0}' />\r\n      <condition attribute='statuscode' operator='eq' value='1' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetObjectActionCodeByName = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_objectactioncode'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_objectactioncodeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_name' operator='eq' value='{0}' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n      <condition attribute='statuscode' operator='eq' value='1' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMByProjectId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_productcomponent' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_project' operator='eq' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMByProjectIdAndPorductComponent = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='fiji_billofmaterials' >\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and' >\r\n      <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n      <condition attribute='fiji_objectactioncode' operator='ne' uiname='REMOVE' uitype='fiji_objectactioncode' value='ebaded1a-cb4b-ec11-8c62-0022480a6838' />\r\n      <condition attribute='fiji_productcomponent' operator='eq' uitype='fiji_productcomponent' value='{1}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetNotesById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='annotation'>\r\n    <attribute name='subject' />\r\n    <attribute name='notetext' />\r\n    <attribute name='filename' />\r\n    <attribute name='annotationid' />\r\n    <order attribute='subject' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='annotationid' operator='in'>\r\n        {0}\r\n      </condition>\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetAllProjectByID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='fiji_project' >\r\n    <attribute name='fiji_projectid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_customerid' />\r\n    <attribute name='fiji_productline' />\r\n    <attribute name='statuscode' />\r\n    <attribute name='fiji_projectstage' />\r\n    <attribute name='fiji_projectcompletedon' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_projectoriginatingregionid' />\r\n    <attribute name='fiji_productexternalid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and' >\r\n      <condition attribute='fiji_projectid' operator='eq' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_kmatproductfamily' from='fiji_kmatproductfamilyid' to='fiji_kmatproductfamily' visible='false' link-type='outer' alias='PF' >\r\n      <attribute name='fiji_name' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetAllProjectByProductExternalID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='fiji_project' >\r\n    <attribute name='fiji_projectid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_customerid' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_projectstage' />\r\n    <attribute name='fiji_productexternalid' />\r\n    <attribute name='ownerid' />\r\n    <order attribute='createdon' descending='true' />\r\n    <filter type='and' >\r\n      <condition attribute='fiji_productexternalid' operator='eq' value='{0}' />\r\n    </filter>\r\n    <link-entity name='account' from='accountid' to='fiji_customerid' visible='false' link-type='outer' alias='Customer' >\r\n      <attribute name='name' />\r\n    </link-entity>\r\n    <link-entity name='fiji_productfamily' from='fiji_productfamilyid' to='fiji_productfamily' visible='false' link-type='outer' alias='Platform' >\r\n      <attribute name='fiji_name' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string getBombyProjectIDandServiceNumber = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n    <condition attribute='fiji_bomtype' operator='eq' value='102420000' />\r\n      <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n      <condition attribute='fiji_objectactioncode' operator='ne' uiname='REMOVE' uitype='fiji_objectactioncode' value='ebaded1a-cb4b-ec11-8c62-0022480a6838' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ac'>\r\n      <filter type='and'>\r\n        <condition attribute='statecode' operator='eq' value='0' />\r\n        <condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000' />\r\n      </filter>\r\n      <link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='ad'>\r\n        <filter type='and'>\r\n          <condition attribute='fiji_servicenumber' operator='eq' value='{1}' />\r\n        </filter>\r\n      </link-entity>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string getNotesbyBomItemandFilename = "<fetch>\r\n  <entity name='annotation'>\r\n    <attribute name='annotationid' />\r\n    <attribute name='filename' />\r\n    <filter>\r\n      <condition attribute='objectid' operator='eq' value='{0}' uitype='fiji_project' />\r\n      <condition attribute='filename' operator='eq' value='{1}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string getAY108AVBIOSRevision = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n        <entity name='fiji_portalmanagementinfo'>\r\n        <attribute name='fiji_portalmanagementinfoid' />\r\n        <attribute name='fiji_name' />\r\n        <attribute name='fiji_project' />\r\n        <attribute name='fiji_bomitem' />\r\n        <attribute name='fiji_biosversion' />\r\n        <order attribute='fiji_name' descending='false' />\r\n        <filter type='and'>\r\n            <condition attribute='statecode' operator='eq' value='0' />\r\n            <condition attribute='statuscode' operator='eq' value='1' />\r\n            <condition attribute='fiji_useby' operator='eq' value='{0}' />\r\n            <condition attribute='fiji_model' operator='eq' value='{1}' />\r\n            <condition attribute='fiji_biosversion' operator='eq' value='{2}' />\r\n        </filter>\r\n        </entity>\r\n    </fetch>";

        public static string GetTaskTypeFor05dot3 = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_tasktype'>\r\n    <attribute name='fiji_tasktypeid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_name' operator='eq' value='05.3 Project Scope Change' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetFijiConfigByKey = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_configuration'>\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_value' />\r\n    <attribute name='fiji_key' />\r\n    <attribute name='fiji_configurationid' />\r\n    <order attribute='fiji_key' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_key' operator='eq' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetUserByfullname = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='systemuser' >\r\n    <attribute name='systemuserid' />\r\n    <attribute name='domainname' />\r\n    <filter type='and' >\r\n      <condition attribute='fullname' operator='eq' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetContactById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >\r\n  <entity name='contact' >\r\n    <attribute name='fullname' />\r\n    <attribute name='telephone1' />\r\n    <attribute name='contactid' />\r\n    <attribute name='emailaddress1' />\r\n    <attribute name='fiji_scopechange' />\r\n    <order attribute='fullname' descending='false' />\r\n    <filter type='and' >\r\n      <condition attribute='contactid' operator='eq' uitype='contact' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetServiceRevisionByProductComponentId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <order attribute='createdon' descending='true' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_servicedetailinjson' operator='not-null' />\r\n      <condition attribute='fiji_parentservice' operator='eq' uiname='' uitype='fiji_productcomponent' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetBomByProjectIdAndMultipleProductComponentId = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_project' operator='eq' uiname='7003143-000' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n        <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='aa'>\r\n\t\t<filter type='and'>\r\n            <condition attribute='fiji_productcomponentid' operator='in'>\r\n               {1}\r\n            </condition>\r\n        </filter>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetFPCByPlatformAndMultiLocalization = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_factoryproductioncapability'>\r\n    <attribute name='fiji_factoryproductioncapabilityid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_productfamily' />\r\n    <attribute name='fiji_localization' />\r\n    <attribute name='fiji_factorypriority' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_productfamily' operator='eq'  uitype='fiji_productfamily' value='{0}' />\r\n      <condition attribute='fiji_localization' operator='in'>\r\n\t\t\t\t\t\t\t{1}     \r\n      </condition>\r\n      <condition attribute='fiji_factorypriority' operator='eq' value='1' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetLocalizationByMultipleLoc = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_regionlocale'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_regionlocalecode' />\r\n    <attribute name='fiji_regionid' />\r\n    <attribute name='fiji_localizationname' />\r\n    <attribute name='fiji_regionlocaleid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_regionlocaleid' operator='in'>\r\n\t\t\t{0}\r\n      </condition>\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string Retrieve_BOM_Items = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_project' operator='eq' uiname='7006591-000' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ac'>\r\n      <link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='ad'>\r\n        <filter type='and'>\r\n          <condition attribute='fiji_servicenumber' operator='eq' value='{1}' />\r\n        </filter>\r\n      </link-entity>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";
        public static string Retrieve_Notes_VLM = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' top='1'>\r\n  <entity name='annotation'>\r\n    <attribute name='subject' />\r\n    <attribute name='notetext' />\r\n    <attribute name='annotationid' />\r\n    <attribute name='modifiedon' />\r\n    <order attribute='modifiedon' descending='true' />\r\n    <filter type='and'>\r\n      <condition attribute='subject' operator='eq' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_billofmaterials' from='fiji_billofmaterialsid' to='objectid' link-type='inner' alias='ar'>\r\n<attribute name='fiji_billofmaterialsid' />\r\n      <filter type='and'>\r\n        <condition attribute='fiji_project' operator='eq' uiname='7004871-000' uitype='fiji_project' value='{1}' />\r\n      </filter>\r\n      <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='as'>\r\n        <link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='at'>\r\n          <filter type='and'>\r\n            <condition attribute='fiji_servicenumber' operator='eq' value='{2}' />\r\n          </filter>\r\n        </link-entity>\r\n      </link-entity>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";
        public static string Get_row_by_Website_Name = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='adx_website'>\r\n    <attribute name='adx_websiteid' />\r\n    <attribute name='adx_primarydomainname' />\r\n    <attribute name='adx_parentwebsiteid' />\r\n    <order attribute='adx_parentwebsiteid' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='adx_name' operator='eq' value='Partner Portal' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";
        public static string Get_serviceNumber_by_ID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='fiji_componenttype'><attribute name='fiji_name' /><attribute name='createdon' /><attribute name='fiji_servicenumber' /><attribute name='fiji_servicecomplexity' /><attribute name='fiji_isfactoryservice' /><attribute name='fiji_comments' /><attribute name='fiji_componenttypeid' /><order attribute='fiji_name' descending='false' /><filter type='and'><condition attribute='fiji_componenttypeid' operator='eq' uitype='fiji_componenttype' value='{0}' /></filter></entity></fetch>";
        public static string Get_account_and_platform_from_project = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_project'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_projectid' />\r\n    <attribute name='fiji_customerid' />\r\n    <attribute name='fiji_productfamily' />\r\n    <order attribute='fiji_name' descending='true' />\r\n    <filter type='and'>\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n      <condition attribute='fiji_projectid' operator='eq' uiname='7022336-002' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";
        public static string Retrieve_BOM_Items_Record = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n  <attribute name='fiji_objectactioncode' />\r\n<attribute name='fiji_productcomponent' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n     <condition attribute='fiji_bomtype' operator='eq' value='102420000' />\r\n      <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ac'>\r\n<attribute name='fiji_fiji_productcomponentid' />\r\n      <filter type='and'>\r\n<condition attribute='statecode' operator='eq' value='0' />\r\n<condition attribute='fiji_servicetypeglobal' operator='in'>\r\n        <value>102420000</value>\r\n      </condition>\r\n      <condition attribute='fiji_componenttype' operator='eq' value='{1}'/>\r\n      </filter>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";
        public static string LatestRevision_for_the_Product_component = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n     <attribute name='statuscode' />\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <order attribute='createdon' descending='true' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_parentservice' operator='eq' uiname='' uitype='fiji_productcomponent' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";
        public static string Get_service_revision_by_ID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <attribute name='fiji_fileurl' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_servicesnapshotid' operator='eq' uiname='' uitype='fiji_servicesnapshot' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";
        public static string Get_Contact = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='contact'>\r\n    <attribute name='fullname' />\r\n    <attribute name='fullname' />\r\n    <attribute name='telephone1' />\r\n    <attribute name='contactid' />\r\n    <attribute name='fiji_contacttype' />\r\n    <attribute name='fiji_contactrole' />\r\n    <order attribute='fullname' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='contactid' operator='eq' value='{0}' uitype='contact' />\r\n    </filter>\r\n    <link-entity name='adx_webrole_contact' from='contactid' to='contactid' link-type='inner' alias='webrole' intersect='true'>\r\n      <attribute name='adx_webrole_contactid' />\r\n      <attribute name='adx_name' />\r\n      <attribute name='adx_webroleid' />\r\n      <attribute name='contactid' />\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";
        public static string Get_Device_Category = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\">\r\n  <entity name=\"fiji_devicecategory\">\r\n    <attribute name=\"fiji_devicecategoryid\" />\r\n    <attribute name=\"fiji_name\" />\r\n    <attribute name=\"createdon\" />\r\n    <attribute name=\"fiji_iconurl\" />\r\n    <attribute name=\"fiji_displayorder\" />\r\n    <attribute name=\"fiji_contacttype\" />\r\n    <order attribute=\"fiji_displayorder\" descending=\"false\" />\r\n    <filter type=\"and\">\r\n      <condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />\r\n      <condition attribute=\"statuscode\" operator=\"eq\" value=\"1\" />\r\n      <condition attribute=\"fiji_contacttype\" operator=\"eq\" value=\"{0}\" />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetProductFamilyBasedOnSRPKMAT = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_kmatproductfamily'>\r\n    <attribute name='fiji_kmatproductfamilyid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_srpkmat' operator='eq' value='{0} ' />\r\n      <condition attribute='statecode' operator='eq' value='0' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";
        public static string GetPlatformBaseOnProductFamily = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_productfamily'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='fiji_srpkmat' />\r\n    <attribute name='fiji_productline' />\r\n    <attribute name='fiji_materialnumber' />\r\n    <attribute name='fiji_releasetocdonline' />\r\n    <attribute name='fiji_qualifiedstatus' />\r\n    <attribute name='fiji_platformstatus' />\r\n    <attribute name='fiji_iscdapproved' />\r\n    <attribute name='fiji_baseplatform' />\r\n    <attribute name='fiji_productfamilyid' />\r\n    <attribute name='createdon' />\r\n<attribute name='fiji_supportshbma' />\r\n    <order attribute='createdon' descending='false' />\r\n    <filter type='and'>\r\n<condition attribute='statecode' operator='eq' value='0' />\r\n <condition attribute='fiji_baseplatform' operator='eq' value='0' />\r\n      <condition attribute='fiji_productfamily' operator='eq' uitype='fiji_kmatproductfamily' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetWebSiteForPortal = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\" >\r\n  <entity name=\"adx_website\" >\r\n    <attribute name=\"adx_websiteid\" />\r\n    <attribute name=\"adx_name\" />\r\n    <attribute name=\"adx_primarydomainname\" />\r\n    <attribute name=\"createdon\" />\r\n    <order attribute=\"adx_name\" descending=\"false\" />\r\n    <filter type=\"and\" >\r\n      <condition attribute=\"adx_name\" operator=\"eq\" value=\"Partner Portal\" />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetBOMForGetMoreService = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_billofmaterials'>\r\n    <attribute name='fiji_billofmaterialsid' />\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n  <attribute name='fiji_objectactioncode' />\r\n<attribute name='fiji_productcomponent' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n    <condition attribute='fiji_bomtype' operator='eq' value='102420000' />\r\n      <condition attribute='fiji_project' operator='eq' uitype='fiji_project' value='{0}' />\r\n    </filter>\r\n    <link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='ac'>\r\n<attribute name='fiji_fiji_productcomponentid' />\r\n      <filter type='and'>\r\n<condition attribute='statecode' operator='eq' value='0' />\r\n<condition attribute='fiji_servicetypeglobal' operator='in'>\r\n        <value>102420000</value>\r\n      </condition>\r\n         <condition attribute='fiji_componenttype' operator='eq' value='{1}'/>\r\n      </filter>\r\n    </link-entity>\r\n  </entity>\r\n</fetch>";

        public static string GetCTAY117AV = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_componenttype'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_servicenumber' />\r\n    <attribute name='fiji_servicecomplexity' />\r\n    <attribute name='fiji_isfactoryservice' />\r\n    <attribute name='fiji_comments' />\r\n    <attribute name='fiji_componenttypeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_servicenumber' operator='eq' value='AY117AV' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetCTAY116AV = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_componenttype'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_servicenumber' />\r\n    <attribute name='fiji_servicecomplexity' />\r\n    <attribute name='fiji_isfactoryservice' />\r\n    <attribute name='fiji_comments' />\r\n    <attribute name='fiji_componenttypeid' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_servicenumber' operator='eq' value='AY116AV' />\r\n      <condition attribute='fiji_name' operator='eq' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetServiceRevisionByProductComponentID = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n     <attribute name='statuscode' />\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <order attribute='createdon' descending='true' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_parentservice' operator='eq' uiname='' uitype='fiji_productcomponent' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string GetServiceRevisionById = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\r\n  <entity name='fiji_servicesnapshot'>\r\n    <attribute name='fiji_name' />\r\n    <attribute name='createdon' />\r\n    <attribute name='fiji_servicesnapshotid' />\r\n    <attribute name='fiji_fileurl' />\r\n    <order attribute='fiji_name' descending='false' />\r\n    <filter type='and'>\r\n      <condition attribute='fiji_servicesnapshotid' operator='eq' uitype='fiji_servicesnapshot' value='{0}' />\r\n    </filter>\r\n  </entity>\r\n</fetch>";

        public static string FetchXMLBuilderforAggregate(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }
            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            var idx = 0;
            fetchXML = "<fetch version='1.0' mapping='logical' aggregate='true'>";
            fetchXML += "<entity name='" + jObj["entity"] + "'>";
            fetchXML += "<attribute name='" + jObj["primaryKey"] + "' aggregate='" + jObj["aggregate"] + "' alias='count' distinct='true' />";
            if (jObj["filterType"] != null)
            {
                fetchXML += "<filter type='" + jObj["filterType"] + "'>"; //filtertype: and, or
                if (jObj["conditions"] != null)
                {
                    fetchXML += buildFilterConditions(jObj["conditions"]);
                }
                fetchXML += "</filter>";
            }

            if (jObj["linkedEntity"] != null)
            {
                fetchXML += buildLinkEntity(jObj["linkedEntity"], idx);
            }
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }

        public static string buildLinkEntity(JToken linkedEntity, int idx)
        {
            string fetchXML = "";

            foreach (var (item, index) in linkedEntity.Select((item, index) => (item, index)))
            {
                idx += index;
                fetchXML += "<link-entity name='" + item["entity"] + "' from='" + item["from"] + "' to='" + item["to"] + "' link-type='" + (item["linkType"]) + "'>";
                if (item["attribute"] != null)
                {
                    fetchXML += "<attribute name='" + item["attribute"] + "' groupby='true' alias='group" + idx + "' />";
                }
                if (item["filterType"] != null)
                {
                    fetchXML += "<filter type='" + item["filterType"] + "'>";
                    if (item["conditions"] != null)
                    {
                        fetchXML += buildFilterConditions(item["conditions"]);
                    }
                    fetchXML += "</filter>";
                }
                if (item["linkedEntity"] != null)
                {
                    fetchXML += buildLinkEntity(item["linkedEntity"], idx);
                }
                fetchXML += "</link-entity>";
            }
            return fetchXML;
        }

        public static string buildFilterConditions(JToken conditions)
        {
            string fetchXML = "";
            foreach (var item in conditions)
            {
                if (item["filterType"] == null)
                {
                    switch (item["condition"].ToString())
                    {
                        case "like":
                            fetchXML += "<condition attribute='" + item["field"] + "' operator='" + item["condition"] + "' value='%" + item["value"] + "%' />";
                            break;
                        case "in":
                            fetchXML += "<condition attribute='" + item["field"] + "' operator='" + item["condition"] + "'>";
                            foreach (var value in item["value"])
                            {
                                fetchXML += "<value>" + value + "</value>";
                            }
                            fetchXML += "</condition>";
                            break;
                        case "eq":
                        case "ne":
                            fetchXML += "<condition attribute='" + item["field"] + "' operator='" + item["condition"] + "' value='" + item["value"] + "' />";
                            break;
                        case "not-null":
                            fetchXML += "<condition attribute='" + item["field"] + "' operator='" + item["condition"] + "'  />";
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    fetchXML += "<filter type='" + item["filterType"] + "'>"; //filtertype: and, or
                    if (item["conditions"] != null)
                    {
                        fetchXML += buildFilterConditions(item["conditions"]);
                    }
                    fetchXML += "</filter>";
                }
            }
            return fetchXML;
        }
        public static string PCCSAVFetchXmlBuilder(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }

            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' distinct='true'>";
            fetchXML += "<entity name='fiji_productcomponent'>";
            fetchXML += "<attribute name='fiji_name'/>";
            fetchXML += "<attribute name='fiji_externalid'/>";
            fetchXML += "<attribute name='fiji_productcomponentid'/>";
            fetchXML += "<attribute name='fiji_servicetypeglobal'/>";
            fetchXML += "<attribute name='fiji_componenttype'/>";
            fetchXML += "<attribute name='fiji_portaldescription'/>";
            fetchXML += "<attribute name='statecode'/>";
            fetchXML += "<attribute name='statuscode'/>";
            fetchXML += "<link-entity name='fiji_fiji_productcomponent_account' from='fiji_productcomponentid' to='fiji_productcomponentid' intersect='true' link-type='outer' >";
            fetchXML += "<link-entity name='account' from='accountid' to='accountid' alias='customer' link-type='outer' >";
            fetchXML += "<attribute name='accountid' />";
            fetchXML += "</link-entity>";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='compType'>";
            fetchXML += "<attribute name='fiji_servicenumber'/>";
            fetchXML += "<attribute name='fiji_portal_description'/>";
            fetchXML += "</link-entity>";
            fetchXML += "<order attribute='fiji_name' descending='false'/>";
            fetchXML += "<filter type='and'>";
            //fetchXML += "<condition attribute='statecode' operator='eq' value='0' />";
            //fetchXML += "<condition attribute='statuscode' operator='in'>";
            //fetchXML += "<value>219180000</value>";
            //fetchXML += "<value>219180002</value>";
            //fetchXML += "</condition>";
            fetchXML += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000'/>";
            fetchXML += "<filter type='or'>";

            foreach (var externalId in jObj["externalIds"])
                fetchXML += "<condition attribute='fiji_externalid' operator='eq' value='" + externalId + "' />";

            fetchXML += "</filter>";

            //fetchXML += "<filter type='or' >";
            //fetchXML += "<condition attribute='accountid' entityname='customer' operator='null' />";
            //fetchXML += "<condition attribute='accountid' entityname='customer' operator='eq' value='" + jObj["customerId"] + "' />";
            //fetchXML += "</filter>";
            fetchXML += "</filter>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }

        public static string PCFetchXmlBuilder(string arg, string serviceTypeToQuery, List<Guid?>? componentTypeIds = null)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }

            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch mapping='logical' distinct='true'>";
            fetchXML += "<entity name='fiji_productcomponent'>";
            fetchXML += "<attribute name='fiji_productcomponentid'/>";
            fetchXML += "<attribute name='fiji_servicetypeglobal'/>";
            fetchXML += "<attribute name='fiji_externalid'/>";
            fetchXML += "<attribute name='fiji_materialproductline'/>";
            fetchXML += "<attribute name='fiji_name'/>";
            fetchXML += "<attribute name='statuscode'/>";
            fetchXML += "<attribute name='fiji_portaldescription'/>";
            fetchXML += "<order attribute='fiji_name' descending='false'/>";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_servicetypeglobal' operator='in'>";

            if (serviceTypeToQuery == Constants.GenericProductComponents)
            {
                fetchXML += "<value>102420001</value>";
            }
            if (serviceTypeToQuery == Constants.PreDefinedAndPlaceholderProductComponents)
            {
                fetchXML += "<value>622490002</value>";
                fetchXML += "<value>102420002</value>";
            }

            fetchXML += "</condition>";
            fetchXML += "<condition attribute='fiji_hidefromportal' operator='ne' value='1'/>";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0'/>";
            fetchXML += "<condition attribute='statuscode' operator='in'>";
            if (jObj["pcStatuscode"] != null)
            {
                foreach (var item in jObj["pcStatuscode"])
                {
                    fetchXML += "<value>" + item + "</value>";
                }
            }
            fetchXML += "</condition>";
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='compType'>";
            fetchXML += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_getmore_serviceid' link-type='outer' alias='getmore' >";
            fetchXML += "<attribute name='fiji_componenttypeid'/>";
            fetchXML += "<attribute name='fiji_portal_description'/>";
            fetchXML += "<attribute name='statuscode'/>";
            fetchXML += "<attribute name='fiji_is_configurable' />";
            fetchXML += "<attribute name='fiji_enable_reuse' />";
            fetchXML += "<attribute name='fiji_servicenumber' />";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_service_category' from='fiji_service_categoryid' to='fiji_service_category' link-type='inner' alias='svcCategory'>";
            fetchXML += "<attribute name='fiji_portal_display_order'/>";
            fetchXML += "<attribute name='fiji_name'/>";
            fetchXML += "<attribute name='fiji_displayin'/>";
            int? displayInValue = jObj["displayIn"]?.ToString()?.Trim().ToLowerInvariant() switch
            {
                "wizard" => Constants.DisplayInWizard,
                "inceptionnew" => Constants.DisplayInInceptionNew,
                "inceptionecn" => Constants.DisplayInInceptionECN,
                _ => null
            };

            if (displayInValue.HasValue)
            {
                fetchXML += "<filter type='and'>";
                fetchXML += "<condition attribute='fiji_displayin' operator='contain-values'>";
                fetchXML += "<value>" + displayInValue.Value + "</value>";
                fetchXML += "</condition>";
                fetchXML += "</filter>";
            }
            fetchXML += "</link-entity>";
            fetchXML += "<attribute name='fiji_portal_display_order'/>";
            fetchXML += "<attribute name='fiji_componenttypeid'/>";
            fetchXML += "<attribute name='fiji_service_category'/>";
            fetchXML += "<attribute name='fiji_portal_description'/>";
            fetchXML += "<attribute name='fiji_can_be_added_multiple_times_dif_confg'/>";
            fetchXML += "<attribute name='fiji_is_configurable'/>";
            fetchXML += "<attribute name='fiji_enable_reuse'/>";
            fetchXML += "<attribute name='statuscode'/>";
            fetchXML += "<attribute name='fiji_servicenumber'/>";
            fetchXML += "<attribute name='fiji_can_be_used_across_customer'/>";
            fetchXML += "<filter type='and'>";

            if (serviceTypeToQuery == Constants.PreDefinedAndPlaceholderProductComponents && componentTypeIds?.Count > 0)
            {
                fetchXML += "<condition attribute='fiji_componenttypeid' operator='in'>";
                foreach (var componentTypeId in componentTypeIds)
                {
                    fetchXML += "<value>" + componentTypeId + "</value>";
                }
                fetchXML += "</condition>";
            }

            fetchXML += "<condition attribute='fiji_hide_from_portal' operator='ne' value='1'/>";
            fetchXML += "<condition attribute='statuscode' operator='in'>";
            if (jObj["ctStatuscode"] != null)
            {
                foreach (var item in jObj["ctStatuscode"])
                {
                    fetchXML += "<value>" + item + "</value>";
                }
            }
            fetchXML += "</condition>";
            fetchXML += "<condition attribute='fiji_service_category' operator='in'>";
            if (jObj["serviceCategory"] != null)
            {
                foreach (var item in jObj["serviceCategory"])
                {
                    fetchXML += "<value>{" + item + "}</value>";
                }
            }
            fetchXML += "</condition>";
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            if (serviceTypeToQuery == Constants.GenericProductComponents)
            {
                fetchXML += "<link-entity name='fiji_productcomponent_platform_regionfactory' from='fiji_productcomponent' to='fiji_productcomponentid' link-type='inner' alias='ad'>";
                fetchXML += "<filter type='and'>";
                fetchXML += "<condition attribute='fiji_servicestatus' operator='eq' value='102420002'/>";
                fetchXML += "<condition attribute='statecode' operator='eq' value='0'/>";
                fetchXML += "<condition attribute='fiji_platform' operator='eq' uitype='fiji_productfamily' value='" + jObj["platformId"] + "'/>";
                fetchXML += "</filter>";
                fetchXML += "</link-entity>";
            }
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }

        public static string IncompatibleCTFetchXmlBuilder(List<string> list)
        {
            //JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>";
            fetchXML += "<entity name='fiji_componenttype'>";
            fetchXML += "<attribute name='fiji_componenttypeid' />";
            fetchXML += "<order attribute='fiji_name' descending='false' />";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='fiji_componenttypeid' operator='in'>";
            if (list != null && list.Count > 0)
            {
                foreach (var item in list)
                {
                    fetchXML += "<value>" + item + "</value>";
                }
            }
            fetchXML += "</condition>";
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_componenttype_incompatible_service' from='fiji_componenttypeidone' to='fiji_componenttypeid' link-type='outer' intersect='true'>";
            fetchXML += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttypeidtwo' alias='inc' link-type='outer' intersect='true'>";
            fetchXML += "<attribute name='fiji_componenttypeid' />";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0' />";
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }

        public static string DependentCTFetchXmlBuilder(List<string> list)
        {
            string fetchXML = "";
            fetchXML += "<fetch>";
            fetchXML += "<entity name='fiji_componenttype'>";
            fetchXML += "<attribute name='fiji_componenttypeid' />";
            fetchXML += "<link-entity name='fiji_dependency_group' to='fiji_dependency_groupid' from='fiji_dependency_groupid' alias='DG' link-type='inner'>";
            fetchXML += "<attribute name='fiji_dependency_groupid' />";
            fetchXML += "<attribute name='fiji_condition' />";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0' />";
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_fiji_dependency_group_fiji_dependency_g' to='fiji_dependency_groupid' from='fiji_dependency_groupid' alias='NN1' link-type='inner'>";
            fetchXML += "<link-entity name='fiji_dependency_group_item' to='fiji_dependency_group_itemid' from='fiji_dependency_group_itemid' alias='DGI' link-type='inner'>";
            fetchXML += "<attribute name='fiji_dependency_group_itemid' />";
            fetchXML += "<attribute name='fiji_condition' />";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0' />";
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_fiji_dependency_group_item_fiji_compone' to='fiji_dependency_group_itemid' from='fiji_dependency_group_itemid' alias='NN2' link-type='inner'>";
            fetchXML += "<link-entity name='fiji_componenttype' to='fiji_componenttypeid' from='fiji_componenttypeid' alias='CT2' link-type='inner'>";
            fetchXML += "<attribute name='fiji_componenttypeid' />";
            fetchXML += "<order attribute='fiji_name' />";
            fetchXML += "</link-entity>";
            fetchXML += "</link-entity>";
            fetchXML += "</link-entity>";
            fetchXML += "</link-entity>";
            fetchXML += "</link-entity>";
            fetchXML += "<filter type='or'>";
            if (list != null && list.Count > 0)
            {
                foreach (var item in list)
                {
                    fetchXML += "<condition attribute='fiji_componenttypeid' operator='eq' value='" + item + "' />";
                }
            }
            fetchXML += "</filter>";
            fetchXML += "<order attribute='fiji_name' />";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";
            return fetchXML;
        }


        public static string GetSpecificPCFetchXmlBuilder(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }

            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' page='" + jObj["pageNumber"] + "' count='" + jObj["pageSize"] + "'>";
            fetchXML += "<entity name='fiji_productcomponent' >";
            if (!jObj["attributeList"].Any(a => a.ToString() == "fiji_fiji_productcomponentid"))
            {
                fetchXML += "<attribute name='fiji_fiji_productcomponentid' />";
            }

            foreach (var attributeName in jObj["attributeList"])
            {

                fetchXML += "<attribute name='" + attributeName + "' /> ";
            }
            fetchXML += "<order attribute='modifiedon' descending='true' />";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000'/>";
            fetchXML += "<condition attribute='fiji_componenttype' operator='eq' value='" + jObj["componentTypeId"] + "' />";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0'/>";
            fetchXML += "<condition attribute='statuscode' operator='in'><value>1</value><value>219180000</value><value>219180002</value></condition>";
            if (!string.IsNullOrEmpty(jObj["searchString"].ToString()))
            {
                fetchXML += "<filter type='or'>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][0] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][1] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][2] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "</filter>";
            }
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' alias='pcplatformstatus' link-type='inner'>";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='fiji_platformid' operator='eq' value='" + jObj["platformId"] + "' />";
            fetchXML += "<condition attribute='statuscode' operator='ne' value='622490003' />"; //Exclude obsolete records
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_fiji_productcomponent_account' to='fiji_productcomponentid' from='fiji_productcomponentid' alias='pccustomer' link-type='inner'>";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='accountid' operator='eq' value='" + jObj["accountId"] + "' />";
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' alias='pccomponenttype' visible='false' link-type='outer'>";
            fetchXML += "<attribute name='fiji_req_addit_info_multi_model' />";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }

        public static string GetSpecificPCWithExtendedModelsFetchXmlBuilder(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }

            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >";
            fetchXML += "<entity name='fiji_productcomponent' >";
            if (!jObj["attributeList"].Any(a => a.ToString() == "fiji_fiji_productcomponentid"))
            {
                fetchXML += "<attribute name='fiji_fiji_productcomponentid' />";
            }

            foreach (var attributeName in jObj["attributeList"])
            {

                fetchXML += "<attribute name='" + attributeName + "' /> ";
            }
            fetchXML += "<order attribute='modifiedon' descending='true' />";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000'/>";
            fetchXML += "<condition attribute='fiji_componenttype' operator='eq' value='" + jObj["componentTypeId"] + "' />";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0'/>";
            fetchXML += "<condition attribute='statuscode' operator='in'><value>1</value><value>219180000</value><value>219180002</value></condition>";
            if (!string.IsNullOrEmpty(jObj["searchString"].ToString()))
            {
                fetchXML += "<filter type='or'>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][0] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][1] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][2] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "</filter>";
            }
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' alias='pcplatformstatus' link-type='inner'>";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='fiji_platformid' operator='ne' value='" + jObj["platformId"] + "' />";
            fetchXML += "<condition attribute='statuscode' operator='ne' value='622490003' />"; //Exclude obsolete records
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_fiji_productcomponent_account' to='fiji_productcomponentid' from='fiji_productcomponentid' alias='pccustomer' link-type='inner'>";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='accountid' operator='eq' value='" + jObj["accountId"] + "' />";
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' alias='pccomponenttype' visible='false' link-type='outer'>";
            fetchXML += "<attribute name='fiji_req_addit_info_multi_model' />";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }
        public static string GetSpecificPCFetchXmlBuilderforAggregate(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }

            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >";
            fetchXML += "<entity name='fiji_productcomponent' >";
            fetchXML += "<attribute name = 'fiji_productcomponentid' aggregate = 'countcolumn' alias = 'count' distinct = 'true' />";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000'/>";
            fetchXML += "<condition attribute='fiji_componenttype' operator='eq' value='" + jObj["componentTypeId"] + "' />";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0'/>";
            fetchXML += "<condition attribute='statuscode' operator='in'><value>1</value><value>219180000</value><value>219180002</value></condition>";
            if (!string.IsNullOrEmpty(jObj["searchString"].ToString()))
            {
                fetchXML += "<filter type='or'>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][0] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][1] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][2] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "</filter>";
            }
            fetchXML += "</filter>";
            if ((bool)jObj["ShowAllModels"] == false)
            {
                fetchXML += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' alias='pcplatformstatus' link-type='inner'>";
                fetchXML += "<filter>";
                fetchXML += "<condition attribute='fiji_platformid' operator='eq' value='" + jObj["platformId"] + "' />";
                fetchXML += "<condition attribute='statuscode' operator='ne' value='622490003' />"; //Exclude obsolete records
                fetchXML += "</filter>";
                fetchXML += "</link-entity>";
            }
            else
            {
                fetchXML += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' alias='pcplatformstatus' link-type='inner'>";
                fetchXML += "<filter>";
                fetchXML += "<condition attribute='fiji_platformid' operator='ne' value='" + jObj["platformId"] + "' />";
                fetchXML += "<condition attribute='statuscode' operator='ne' value='622490003' />"; //Exclude obsolete records
                fetchXML += "</filter>";
                fetchXML += "</link-entity>";
            }
            fetchXML += "<link-entity name='fiji_fiji_productcomponent_account' to='fiji_productcomponentid' from='fiji_productcomponentid' alias='pccustomer' link-type='inner'>";
            fetchXML += "<attribute name='accountid' groupby='true' alias='group' />";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='accountid' operator='eq' value='" + jObj["accountId"] + "' />";
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";

            return fetchXML;
        }

        public static string GetPCbyPCIDandPCPlatformStatus(List<Guid> pcIds, string platformId)
        {
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>";
            fetchXML += "<entity name='fiji_productcomponent'>";
            fetchXML += "<attribute name='fiji_productcomponentid' />";
            fetchXML += "<attribute name='fiji_name' />";
            fetchXML += "<attribute name='fiji_externalid' />";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_productcomponentid' operator='in'>";
            foreach (var item in pcIds)
            {
                fetchXML += "<value>" + item + "</value>";
            }
            fetchXML += "</condition>";
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' link-type='inner' alias='bb'>";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_platformid' operator='eq' value='" + platformId + "' />";
            fetchXML += "<condition attribute='statuscode' operator='ne' value='622490003' />"; //Exclude obsolete records
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";
            return fetchXML;
        }
        public static string GetPCbyPCIDandPCPlatformStatusforAggregate(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                throw new ArgumentException($"'{nameof(arg)}' cannot be null or empty.", nameof(arg));
            }

            JObject jObj = JObject.Parse(arg);
            string fetchXML = "";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >";
            fetchXML += "<entity name='fiji_productcomponent'>";
            fetchXML += "<attribute name='fiji_productcomponentid' aggregate = 'countcolumn' alias = 'count' distinct = 'true' />";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000'/>";
            fetchXML += "<condition attribute='fiji_componenttype' operator='eq' value='" + jObj["componentTypeId"] + "' />";
            fetchXML += "<condition attribute='statecode' operator='eq' value='0'/>";
            fetchXML += "<condition attribute='statuscode' operator='in'><value>1</value><value>219180000</value><value>219180002</value></condition>";
            if (!string.IsNullOrEmpty(jObj["searchString"].ToString()))
            {
                fetchXML += "<filter type='or'>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][0] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "<condition attribute='" + jObj["searchAttributeName"][1] + "' operator='like' value='%" + jObj["searchString"] + "%'/>";
                fetchXML += "</filter>";
            }
            fetchXML += "</filter>";
            fetchXML += "<link-entity name='fiji_fiji_productcomponent_account' to='fiji_productcomponentid' from='fiji_productcomponentid' alias='pccustomer' link-type='inner'>";
            fetchXML += "<attribute name='accountid' groupby='true' alias='group' />";
            fetchXML += "<filter>";
            fetchXML += "<condition attribute='accountid' operator='eq' value='" + jObj["accountId"] + "' />";
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' link-type='inner' alias='bb'>";
            fetchXML += "<filter type='and'>";
            fetchXML += "<condition attribute='fiji_platformid' operator='eq' value='" + jObj["platformId"] + "' />";
            fetchXML += "<condition attribute='statuscode' operator='ne' value='622490003' />"; //Exclude obsolete records
            fetchXML += "</filter>";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";
            return fetchXML;
        }

        public static string GetSqlQueryForRequestsByCustomerSearch(CustomerRequestPayloadRequest request)
        {
            var query = String.Empty;

            query += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' page='" + request.PageNumber + "' count='" + request.PageSize + "'>";
            query += "<entity name='fiji_project'>";
            query += "<attribute name='fiji_projectid' />";
            query += "<attribute name='fiji_productfamily' />";
            query += "<attribute name='fiji_productexternalid' />";
            query += "<attribute name='fiji_hidefromportal' />";
            query += "<attribute name='fiji_portalcontrolledhidden' />";
            query += "<attribute name='statuscode' />";
            query += "<attribute name='fiji_projectduedate' />";
            query += "<attribute name='fiji_originalprojectduedate' />";
            query += "<attribute name='fiji_configurationname' />";
            query += "<attribute name='fiji_projectcompletedon' />";
            query += "<attribute name='fiji_projectstage' />";
            query += "<attribute name='fiji_occid' />";
            query += "<attribute name='fiji_requestid' />";
            query += "<attribute name='modifiedby' />";
            query += "<attribute name='modifiedon' />";
            query += "<attribute name='createdon' />";
            query += "<attribute name='fiji_customerid' />";
            query += "<attribute name='fiji_projectname' />";
            query += "<attribute name='fiji_modifiedbyportalcontact' />";
            query += "<order attribute='modifiedon' descending='true' />";
            query += "<filter type='and'>";
            query += "<condition attribute='statuscode' operator='not-in'>";
            query += "<value>" + (int)Model.Project.eStatusCode.Canceled + "</value>";
            query += "<value>" + (int)Model.Project.eStatusCode.Rejected + "</value>";
            query += "</condition>";
            query += "<condition attribute='fiji_productfamily' operator='not-null' />";
            query += "<condition attribute='fiji_hidefromportal' operator='ne' value='1' />";

            if (!request.ShowAll)
            {
                query += "<condition attribute='fiji_portalcontrolledhidden' operator='ne' value='1' />";
            }

            if (!string.IsNullOrEmpty(request.SearchText))
            {
                int occidsearchtext = 0;
                query += "<filter type='or'>";
                query += "<condition attribute='fiji_configurationname' operator='like' value='%" + request.SearchText + "%' />";
                query += "<condition attribute='fiji_requestid' operator='like' value='%" + request.SearchText + "%' />";
                query += "<condition attribute='fiji_productexternalid' operator='like' value='%" + request.SearchText + "%' />";
                if (int.TryParse(request.SearchText, out occidsearchtext))
                {
                    query += "<condition attribute='fiji_occid' operator='like' value='" + request.SearchText + "' />";
                }
                query += "</filter>";
            }

            if (!string.IsNullOrEmpty(request.CreatedFrom) && !string.IsNullOrEmpty(request.CreatedTill))
            {
                query += "<condition attribute='createdon' operator='ge' value='" + request.CreatedFrom + "' />";
                query += "<condition attribute='createdon' operator='le' value='" + request.CreatedTill + "' />";
            }
            if (!string.IsNullOrEmpty(request.LastModifiedFrom) && !string.IsNullOrEmpty(request.LastModifiedTill))
            {
                query += "<condition attribute='modifiedon' operator='ge' value='" + request.LastModifiedFrom + "' />";
                query += "<condition attribute='modifiedon' operator='le' value='" + request.LastModifiedTill + "' />";
            }

            // filter for projectStage
            if (request.ProjectStages != null)
            {
                query += "<filter type='or'>";
                foreach (var projectStage in request.ProjectStages)
                {
                    query += "<condition attribute='fiji_projectstage' operator='eq' value='" + projectStage + "' />";
                }
                query += "</filter>";
            }
            // filter for Models
            if (request.Models != null)
            {
                query += "<filter type='or'>";
                foreach (var projectModel in request.Models)
                {
                    query += "<condition attribute='fiji_productfamily' operator='eq' value='" + projectModel + "' />";
                }
                query += "</filter>";
            }

            // filter for status

            if (request.ProjectStages != null && (request.Status == null))
            {
                query += "<condition attribute='statuscode' operator='ne' value='" + (int)Model.Project.eStatusCode.Complete + "' />";
            }
            else if (request.ProjectStages == null && (request.Status != null && request.Status.Count > 0))
            {
                foreach (var projectstatus in request.Status)
                {
                    query += "<condition attribute='statuscode' operator='eq' value='" + projectstatus + "' />";
                }
            }
            query += "</filter>";
            query += "<link-entity name='account' from='accountid' to='fiji_customerid' link-type='inner' alias='customer'>";
            query += "<filter type='and'>";
            query += "<condition attribute='accountid' operator='eq' value='" + request.CustomerId + "' />";
            query += "</filter>";
            query += "</link-entity>";
            query += "<link-entity name='fiji_productfamily' from='fiji_productfamilyid' to='fiji_productfamily' link-type='inner' alias='platform'>";
            query += "<attribute name='fiji_endoflifedate' />";
            query += "<attribute name='fiji_name' />";
            query += "<attribute name='fiji_devicecategoryid' />";
            if (!string.IsNullOrWhiteSpace(request.EndOfLifeFrom) && !string.IsNullOrWhiteSpace(request.EndOfLifeTill))
            {
                query += "<filter type='and'>";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-after' value='" + request?.EndOfLifeFrom + "' />";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-before' value='" + request?.EndOfLifeTill + "' />";
                query += "</filter>";
            }
            query += "<link-entity name='fiji_devicecategory' from='fiji_devicecategoryid' to='fiji_devicecategoryid' link-type='inner' alias='devicecategoryid' >";
            query += "<attribute name='fiji_iconurl' />";
            query += "</link-entity>";
            query += "</link-entity>";
            if (request?.ComponenttypeIDs != null)
            {
                query += "<link-entity name='fiji_billofmaterials' from='fiji_project' to='fiji_projectid' link-type='inner' alias='BOM'>";
                query += "<filter type='and'>";
                query += "<condition attribute='fiji_productactioncode' operator='ne' value ='" + (int)eProductActionCode.Remove + "' />";
                query += "<condition attribute='fiji_bomtype' operator='eq' value='" + (int)eBomtype.Project + "' />";
                query += "<condition attribute='fiji_productrevision' operator ='null' />";
                query += "</filter>";
                query += "<link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='productcomponent'>";
                query += "<attribute name='fiji_portaldescription' />";
                query += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='componenttype'>";
                query += "<filter type='or'>";
                foreach (var componenttype in request.ComponenttypeIDs)
                {
                    query += "<condition attribute='fiji_componenttypeid' operator='eq' value='" + componenttype + "' />";
                }
                query += "</filter>";
                query += "</link-entity>";
                query += "</link-entity>";
                query += "</link-entity>";
            }
            //get project manager email address
            query += "<link-entity name='systemuser' from='systemuserid' to='ownerid' link-type='outer' alias='projectmanager'>";
            query += "<attribute name='internalemailaddress' />";
            query += "</link-entity>";
            query += "</entity>";
            query += "</fetch>";

            return query;
        }

        public static string GetSqlQueryForRequestsByCustomerSearchForAggregate(CustomerRequestPayloadRequest request)
        {
            var query = String.Empty;

            query += "<fetch version='1.0' output-format='xml-platform' mapping='logical' aggregate='true'>";
            query += "<entity name='fiji_project'>";
            query += "<attribute name='fiji_projectid' aggregate='countcolumn' distinct='true' alias='TotalCount'/>";
            query += "<filter type='and'>";
            query += "<condition attribute='statuscode' operator='not-in'>";
            query += "<value>" + (int)Model.Project.eStatusCode.Canceled + "</value>";
            query += "<value>" + (int)Model.Project.eStatusCode.Rejected + "</value>";
            query += "</condition>";
            query += "<condition attribute='fiji_productfamily' operator='not-null' />";
            query += "<condition attribute='fiji_hidefromportal' operator='ne' value='1' />";
            if (!request.ShowAll)
            {
                query += "<condition attribute='fiji_portalcontrolledhidden' operator='ne' value='1' />";
            }
            query += "<condition attribute='fiji_customerid' operator='eq' value='" + request.CustomerId + "' />";
            if (!string.IsNullOrEmpty(request.SearchText))
            {
                int occidsearchtext = 0;
                query += "<filter type='or'>";
                query += "<condition attribute='fiji_configurationname' operator='like' value='%" + request.SearchText + "%' />";
                query += "<condition attribute='fiji_requestid' operator='like' value='%" + request.SearchText + "%' />";
                query += "<condition attribute='fiji_productexternalid' operator='like' value='%" + request.SearchText + "%' />";
                if (int.TryParse(request.SearchText, out occidsearchtext))
                {
                    query += "<condition attribute='fiji_occid' operator='like' value='" + request.SearchText + "' />";
                }
                query += "</filter>";
            }

            if (!string.IsNullOrEmpty(request.CreatedFrom) && !string.IsNullOrEmpty(request.CreatedTill))
            {
                query += "<condition attribute='createdon' operator='ge' value='" + request.CreatedFrom + "' />";
                query += "<condition attribute='createdon' operator='le' value='" + request.CreatedTill + "' />";

            }
            if (!string.IsNullOrEmpty(request.LastModifiedFrom) && !string.IsNullOrEmpty(request.LastModifiedTill))
            {
                query += "<condition attribute='modifiedon' operator='ge' value='" + request.LastModifiedFrom + "' />";
                query += "<condition attribute='modifiedon' operator='le' value='" + request.LastModifiedTill + "' />";
            }

            // filter for projectStage
            if (request.ProjectStages != null)
            {
                query += "<filter type='or'>";
                foreach (var projectStage in request.ProjectStages)
                {
                    query += "<condition attribute='fiji_projectstage' operator='eq' value='" + projectStage + "' />";
                }
                query += "</filter>";
            }
            // filter for Models
            if (request.Models != null)
            {
                query += "<filter type='or'>";
                foreach (var projectModel in request.Models)
                {
                    query += "<condition attribute='fiji_productfamily' operator='eq' value='" + projectModel + "' />";
                }
                query += "</filter>";
            }

            // filter for status

            if (request.ProjectStages != null && (request.Status == null))
            {
                query += "<condition attribute='statuscode' operator='ne' value='" + (int)Model.Project.eStatusCode.Complete + "' />";
            }
            else if (request.ProjectStages == null && (request.Status != null && request.Status.Count > 0))
            {
                foreach (var projectstatus in request.Status)
                {
                    query += "<condition attribute='statuscode' operator='eq' value='" + projectstatus + "' />";
                }
            }
            query += "</filter>";
            query += "<link-entity name='account' from='accountid' to='fiji_customerid' link-type='inner' alias='customer'>";
            query += "<filter type='and'>";
            query += "<condition attribute='accountid' operator='eq' value='" + request.CustomerId + "' />";
            query += "</filter>";
            query += "</link-entity>";
            query += "<link-entity name='fiji_productfamily' from='fiji_productfamilyid' to='fiji_productfamily' link-type='inner' alias='platform'>";
            if (!string.IsNullOrWhiteSpace(request.EndOfLifeFrom) && !string.IsNullOrWhiteSpace(request.EndOfLifeTill))
            {
                query += "<filter type='and'>";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-after' value='" + request?.EndOfLifeFrom + "' />";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-before' value='" + request?.EndOfLifeTill + "' />";
                query += "</filter>";
            }
            query += "<link-entity name='fiji_devicecategory' from='fiji_devicecategoryid' to='fiji_devicecategoryid' link-type='inner' alias='devicecategoryid' />";
            query += "</link-entity>";
            if (request?.ComponenttypeIDs != null)
            {
                query += "<link-entity name='fiji_billofmaterials' from='fiji_project' to='fiji_projectid' link-type='inner' alias='BOM'>";
                query += "<filter type='and'>";
                query += "<condition attribute='fiji_productactioncode' operator='ne' value ='" + (int)eProductActionCode.Remove + "' />";
                query += "<condition attribute='fiji_bomtype' operator='eq' value='" + (int)eBomtype.Project + "' />";
                query += "<condition attribute='fiji_productrevision' operator ='null' />";
                query += "</filter>";
                query += "<link-entity name='fiji_productcomponent' from='fiji_productcomponentid' to='fiji_productcomponent' link-type='inner' alias='productcomponent'>";
                query += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='componenttype'>";
                query += "<filter type='or'>";
                foreach (var componenttype in request.ComponenttypeIDs)
                {
                    query += "<condition attribute='fiji_componenttypeid' operator='eq' value='" + componenttype + "' />";
                }
                query += "</filter>";
                query += "</link-entity>";
                query += "</link-entity>";
                query += "</link-entity>";
            }
            query += "</entity>";
            query += "</fetch>";

            return query;
        }

        public static string GetSqlQueryForServicesByCustomerSearch(CustomerServicesRequest request)
        {
            var query = String.Empty;

            query += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' page='" + request.PageNumber + "' count='" + request.PageSize + "'>";
            query += "<entity name='fiji_productcomponent'>";
            query += "<attribute name='fiji_productcomponentid' />";
            query += "<attribute name='fiji_fiji_productcomponentid' />";
            query += "<attribute name='fiji_name' />";
            query += "<attribute name='createdon' />";
            query += "<attribute name='fiji_externalid' />";
            query += "<attribute name='statecode' />";
            query += "<attribute name='modifiedon' />";
            query += "<attribute name='fiji_servicetypeglobal' />";
            query += "<attribute name='fiji_hidefromportal' />";
            query += "<attribute name='fiji_portalcontrolledhidden' />";
            query += "<attribute name='fiji_portaldescription' />";
            query += "<order attribute='modifiedon' descending='true' />";
            query += "<filter type='and'>";
            query += "<condition attribute='statecode' operator='eq' value='0' />";
            query += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000' />";
            query += "<condition attribute='fiji_hidefromportal' operator='ne' value='1' />";
            if (request?.ShowAll != true)
            {
                query += "<condition attribute='fiji_portalcontrolledhidden' operator='ne' value='1' />";
            }
            if (!string.IsNullOrWhiteSpace(request?.CreatedFrom) && !string.IsNullOrWhiteSpace(request?.CreatedTill))
            {
                query += "<condition attribute='createdon' operator='ge' value='" + request.CreatedFrom + "' />";
                query += "<condition attribute='createdon' operator='le' value='" + request.CreatedTill + "' />";
            }
            if (!string.IsNullOrWhiteSpace(request?.LastModifiedFrom) && !string.IsNullOrWhiteSpace(request?.LastModifiedTill))
            {
                query += "<condition attribute='modifiedon' operator='ge' value='" + request.LastModifiedFrom + "' />";
                query += "<condition attribute='modifiedon' operator='le' value='" + request.LastModifiedTill + "' />";
            }
            if (!string.IsNullOrWhiteSpace(request?.SearchText))
            {
                query += "<filter type='or'>";
                query += "<condition attribute='fiji_fiji_productcomponentid' operator='like' value='" + request.SearchText + "' />";
                query += "<condition attribute='fiji_externalid' operator='like' value='" + request.SearchText + "' />";
                query += "<condition attribute='fiji_portaldescription' operator='like' value='" + request.SearchText + "' />";
                query += "<condition entityname='componentype' attribute='fiji_portal_description' operator='like' value='" + request.SearchText + "' />";
                query += "</filter>";
            }
            query += "</filter>";
            query += "<link-entity name='fiji_fiji_productcomponent_account' from='fiji_productcomponentid' to='fiji_productcomponentid' visible='false' intersect='true'>";
            query += "<link-entity name='account' from='accountid' to='accountid' alias='customer'>";
            query += "<filter type='and'>";
            query += "<condition attribute='accountid' operator='eq' value='" + request.CustomerId + "' />";
            query += "</filter>";
            query += "</link-entity>";
            query += "</link-entity>";
            query += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='componentype'>";
            query += "<attribute name='statuscode' />";
            query += "<attribute name='statecode' />";
            query += "<attribute name='fiji_service_category' />";
            query += "<attribute name='fiji_req_addit_info_multi_model' />";
            query += "<attribute name='fiji_portal_description' />";
            query += "<attribute name='fiji_is_configurable' />";
            query += "<attribute name='fiji_enable_reuse' />";
            query += "<attribute name='fiji_can_be_used_across_customer' />";
            query += "<attribute name='fiji_componenttypeid' />";
            query += "<attribute name='fiji_servicenumber' />";
            query += "<attribute name='fiji_ismultimodel' />";
            query += "<filter type='and'>";
            query += "<filter type='or'>";
            query += "<condition attribute='fiji_enable_reuse' operator='eq' value='1' />";
            query += "<condition attribute='fiji_is_configurable' operator='eq' value='1' />";
            query += "</filter>";
            query += "<condition attribute='statuscode' operator='in'>";
            query += "<value>" + (int)Model.ComponentType.eStatusCode.InUse + "</value>";
            query += "<value>" + (int)Model.ComponentType.eStatusCode.Legacy + "</value>";
            query += "</condition>";
            query += "<condition attribute='statecode' operator='eq' value='" + (int)Model.ComponentType.eStateCode.Active + "' />";
            query += "<condition attribute='fiji_can_be_used_across_customer' operator='ne' value='1' />";
            if (request?.Category != null)
            {
                query += "<filter type='or'>";
                foreach (var serviceCategory in request.Category)
                {
                    query += "<condition attribute='fiji_service_category' operator='eq' value='" + serviceCategory + "' />";
                }
                query += "</filter>";
            }
            if (request?.ComponenttypeIDs != null)
            {
                query += "<filter type='or'>";
                foreach (var componenttype in request.ComponenttypeIDs)
                {
                    query += "<condition attribute='fiji_componenttypeid' operator='eq' value='" + componenttype + "' />";
                }
                query += "</filter>";
            }
            query += "</filter>";
            query += "</link-entity>";
            query += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_getmoresource' link-type='outer' alias='getmoreCT'>";
            query += "<attribute name='statuscode' />";
            query += "<attribute name='fiji_service_category' />";
            query += "<attribute name='fiji_componenttypeid' />";
            query += "<attribute name='fiji_req_addit_info_multi_model' />";
            query += "<attribute name='fiji_portal_description' />";
            query += "<attribute name='fiji_ismultimodel' />";
            query += "</link-entity>";

            if (!string.IsNullOrWhiteSpace(request?.EndOfLifeFrom) && !string.IsNullOrWhiteSpace(request?.EndOfLifeTill))
            {
                query += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' link-type='inner' alias='pcPlatformStatus'>";
                query += "<link-entity name='fiji_productfamily' from='fiji_productfamilyid' to='fiji_platformid' link-type='inner' alias='platform'>";
                query += "<attribute name='fiji_productfamilyid' />";
                query += "<attribute name='fiji_endoflifedate' />";
                query += "<filter type='and'>";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-after' value='" + request?.EndOfLifeFrom + "' />";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-before' value='" + request?.EndOfLifeTill + "' />";
                query += "</filter>";
                query += "</link-entity>";
                query += "</link-entity>";
            }

            if (request?.Models != null && request.Models.Count > 0)
            {
                query += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' link-type='inner' alias='pcPlatformStatusModelFilter'>";
                query += "<filter type='and'>";
                query += "<condition attribute='statuscode' operator='ne' value='622490003' />"; // Exclude obsolete records 
                query += "<filter type='or'>";
                foreach (var modelId in request.Models)
                {
                    query += "<condition attribute='fiji_platformid' operator='eq' value='" + modelId + "' />";
                }
                query += "</filter>";
                query += "</filter>";
                query += "</link-entity>";
            }
            if (request?.LatestServiceStatusCode != null)
            {
                query += "<link-entity name='fiji_servicesnapshot' from='fiji_parentservice' to='fiji_productcomponentid' link-type='inner' alias='sr'>";
                query += "<filter type='or'>";
                foreach (var StatusCode in request.LatestServiceStatusCode)
                {
                    query += "<condition attribute='statuscode' operator='eq' value='" + StatusCode + "' />";
                }
                query += "</filter>";
                query += "</link-entity>";
            }
            query += "</entity>";
            query += "</fetch>";

            return query;
        }

        public static string GetSqlQueryForServicesByCustomerSearchForAggregate(CustomerServicesRequest request)
        {
            var query = String.Empty;

            query += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true'>";
            query += "<entity name='fiji_productcomponent'>";
            query += "<attribute name='fiji_productcomponentid' aggregate='countcolumn' distinct='true' alias='TotalCount'/>";
            query += "<filter type='and'>";
            query += "<condition attribute='statecode' operator='eq' value='0' />";
            query += "<condition attribute='fiji_servicetypeglobal' operator='eq' value='102420000' />";
            query += "<condition attribute='fiji_hidefromportal' operator='ne' value='1' />";
            if (request?.ShowAll != true)
            {
                query += "<condition attribute='fiji_portalcontrolledhidden' operator='ne' value='1' />";
            }
            if (!string.IsNullOrWhiteSpace(request?.CreatedFrom) && !string.IsNullOrWhiteSpace(request?.CreatedTill))
            {
                query += "<condition attribute='createdon' operator='ge' value='" + request.CreatedFrom + "' />";
                query += "<condition attribute='createdon' operator='le' value='" + request.CreatedTill + "' />";
            }
            if (!string.IsNullOrWhiteSpace(request?.LastModifiedFrom) && !string.IsNullOrWhiteSpace(request?.LastModifiedTill))
            {
                query += "<condition attribute='modifiedon' operator='ge' value='" + request.LastModifiedFrom + "' />";
                query += "<condition attribute='modifiedon' operator='le' value='" + request.LastModifiedTill + "' />";
            }
            if (!string.IsNullOrWhiteSpace(request?.SearchText))
            {
                query += "<filter type='or'>";
                query += "<condition attribute='fiji_fiji_productcomponentid' operator='like' value='" + request.SearchText + "' />";
                query += "<condition attribute='fiji_externalid' operator='like' value='" + request.SearchText + "' />";
                query += "<condition attribute='fiji_portaldescription' operator='like' value='" + request.SearchText + "' />";
                query += "<condition entityname='componentype' attribute='fiji_portal_description' operator='like' value='" + request.SearchText + "' />";
                query += "</filter>";
            }
            query += "</filter>";
            query += "<link-entity name='fiji_fiji_productcomponent_account' from='fiji_productcomponentid' to='fiji_productcomponentid' visible='false' intersect='true'>";
            query += "<link-entity name='account' from='accountid' to='accountid' alias='customer'>";
            query += "<filter type='and'>";
            query += "<condition attribute='accountid' operator='eq' value='" + request?.CustomerId + "' />";
            query += "</filter>";
            query += "</link-entity>";
            query += "</link-entity>";
            query += "<link-entity name='fiji_componenttype' from='fiji_componenttypeid' to='fiji_componenttype' link-type='inner' alias='componentype'>";
            query += "<filter type='and'>";
            query += "<filter type='or'>";
            query += "<condition attribute='fiji_enable_reuse' operator='eq' value='1' />";
            query += "<condition attribute='fiji_is_configurable' operator='eq' value='1' />";
            query += "</filter>";
            query += "<condition attribute='statuscode' operator='in'>";
            query += "<value>" + (int)Model.ComponentType.eStatusCode.InUse + "</value>";
            query += "<value>" + (int)Model.ComponentType.eStatusCode.Legacy + "</value>";
            query += "</condition>";
            query += "<condition attribute='statecode' operator='eq' value='" + (int)Model.ComponentType.eStateCode.Active + "' />";
            query += "<condition attribute='fiji_can_be_used_across_customer' operator='ne' value='1' />";
            if (request?.Category != null)
            {
                query += "<filter type='or'>";
                foreach (var serviceCategory in request.Category)
                {
                    query += "<condition attribute='fiji_service_category' operator='eq' value='" + serviceCategory + "' />";
                }
                query += "</filter>";
            }
            if (request?.ComponenttypeIDs != null)
            {
                query += "<filter type='or'>";
                foreach (var componenttype in request.ComponenttypeIDs)
                {
                    query += "<condition attribute='fiji_componenttypeid' operator='eq' value='" + componenttype + "' />";
                }
                query += "</filter>";
            }
            query += "</filter>";
            query += "</link-entity>";

            if (!string.IsNullOrWhiteSpace(request?.EndOfLifeFrom) && !string.IsNullOrWhiteSpace(request?.EndOfLifeTill))
            {
                query += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' link-type='inner' alias='pcPlatformStatus'>";
                query += "<link-entity name='fiji_productfamily' from='fiji_productfamilyid' to='fiji_platformid' link-type='inner' alias='platform'>";
                query += "<filter type='and'>";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-after' value='" + request.EndOfLifeFrom + "' />";
                query += "<condition attribute='fiji_endoflifedate' operator='on-or-before' value='" + request.EndOfLifeTill + "' />";
                query += "</filter>";
                query += "</link-entity>";
                query += "</link-entity>";
            }

            if (request?.Models != null && request.Models.Count > 0)
            {
                query += "<link-entity name='fiji_pc_platform_status' from='fiji_productcomponentid' to='fiji_productcomponentid' link-type='inner' alias='pcPlatformStatusModelFilter'>";
                query += "<filter type='and'>";
                query += "<condition attribute='statuscode' operator='ne' value='622490003' />"; // Exclude obsolete records 
                query += "<filter type='or'>";
                foreach (var modelId in request.Models)
                {
                    query += "<condition attribute='fiji_platformid' operator='eq' value='" + modelId + "' />";
                }
                query += "</filter>";
                query += "</filter>";
                query += "</link-entity>";
            }
            if (request?.LatestServiceStatusCode != null)
            {
                query += "<link-entity name='fiji_servicesnapshot' from='fiji_parentservice' to='fiji_productcomponentid' link-type='inner' alias='sr'>";
                query += "<filter type='or'>";
                foreach (var StatusCode in request.LatestServiceStatusCode)
                {
                    query += "<condition attribute='statuscode' operator='eq' value='" + StatusCode + "' />";
                }
                query += "</filter>";
                query += "</link-entity>";
            }
            query += "</entity>";
            query += "</fetch>";

            return query;
        }

        public static string GetSqlQueryForAvailableLocalizations(Guid? PlatformID)
        {
            string fetchXml = $@"
                                <fetch distinct='true'>
                                    <entity name='fiji_productfamily_regionlocale'>
                                    <attribute name='fiji_productfamilyid' />
                                    <filter>
                                        <condition attribute='fiji_productfamilyid' operator='eq' value='{PlatformID}' />
                                        <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='fiji_regionlocale' from='fiji_regionlocaleid' to='fiji_regionlocaleid' link-type='outer'>
                                        <attribute name='fiji_regionlocaleid' />
                                        <attribute name='fiji_localizationname' />
                                        <attribute name='fiji_regionlocalecode' />
                                    </link-entity>
                                    </entity>
                                </fetch>";
            return fetchXml;
        }

        public static string FetchProjectBySkuNumber(string selectedSkuId, string customerId)
        {
            string currentDate = DateTime.UtcNow.ToString("o");
            string fetchXML = "?fetchXml=";
            fetchXML += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>";
            fetchXML += "<entity name='fiji_project'>";
            fetchXML += "<attribute name='fiji_name'/>";
            fetchXML += "<attribute name='createdon'/>";
            fetchXML += "<attribute name='fiji_everestid'/>";
            fetchXML += "<attribute name='fiji_projectid'/>";
            fetchXML += "<attribute name='fiji_requestid'/>";
            fetchXML += "<attribute name='fiji_customerid'/>";
            fetchXML += "<attribute name='fiji_productexternalid'/>";
            fetchXML += "<attribute name='fiji_productfamily'/>";
            fetchXML += "<attribute name='fiji_projectduedate'/>";
            fetchXML += "<attribute name='fiji_projectdaysou'/>";
            fetchXML += "<attribute name='fiji_productfamily'/>";
            fetchXML += "<attribute name='statuscode'/>";
            fetchXML += "<attribute name='fiji_projectstage'/>";
            fetchXML += "<order attribute='createdon' descending='true'/>";
            fetchXML += "<filter type='and'>";
            fetchXML += $"<condition attribute='fiji_productexternalid' operator='eq' value='{selectedSkuId}' />";
            fetchXML += $"<condition attribute='fiji_customerid' operator='eq' value='{customerId}' />";
            fetchXML += $"<condition attribute='modifiedon' operator='le' value='{currentDate}' />";
            fetchXML += "</filter>";
            fetchXML +=
              "<link-entity name='systemuser' from='systemuserid' to='owninguser' link-type='outer' alias='pm'>";
            fetchXML += "<attribute name='internalemailaddress' />";
            fetchXML += "</link-entity>";
            fetchXML += "</entity>";
            fetchXML += "</fetch>";
            return fetchXML;
        }

    }
}
