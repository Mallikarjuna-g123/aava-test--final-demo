﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class AttributeNames
    {
        public class Account
        {
            public const string AccountId = "accountid";
            public const string Name = "name";
            public const string CustomerHeadQuarterId = "fiji_customerheadquartercountryid";
            public const string AccountNumber = "accountnumber";
        }

        public class SystemUser
        {
            public const string SystemUserId = "systemuserid";
            public const string IsDisabled = "isdisabled";
            public const string CountryId = "fiji_countryid";
            public const string InternalEmailAddress = "internalemailaddress";
            public const string FullName = "fullname";
        }

        public class Country
        {
            public const string CountryId = "fiji_countryid";
            public const string SubRegionid = "fiji_subregionid";
            public const string RegionId = "fiji_regionid";
        }

        public class ObjectActionCode
        {
            public const string ObjectActionCodeId = "fiji_objectactioncodeid";
            public const string ActionName = "fiji_name";
        }

        public class Project
        {
            public const string PortalInitiated = "fiji_portalinitiated";
            public const string StatusCode = "statuscode";
            public const string ProjectId = "fiji_projectid";
            public const string Name = "fiji_name";
            public const string CustomerId = "fiji_customerid";
            public const string ProjectOriginatingRegionId = "fiji_projectoriginatingregionid";
            public const string ProductFamilyName = "fiji_productfamily";
            public const string KMATProductFamily = "fiji_kmatproductfamily";
            public const string ProductLine = "fiji_productline";
            public const string IsNeworECN = "fiji_isneworecn";
            public const string ProjectType = "fiji_projecttype";
            public const string ProductType = "fiji_producttype";
            public const string ProjectSourceCode = "fiji_projectsourcecode";
            public const string CreatedFrom = "fiji_createdfromcode";
            public const string OCCId = "fiji_occid";
            public const string ProjectStage = "fiji_projectstage";
            public const string PortalContact = "fiji_portalcontact";
            public const string ModifiedByPortalContact = "fiji_modifiedbyportalcontact";
            public const string OwnerId = "ownerid";
            public const string ProjectOriginatingSubRegion = "fiji_projectoriginatingsubregion";
            public const string RequestId = "fiji_requestid";
            public const string ConfigurationName = "fiji_configurationname";
            public const string ProjectName = "fiji_projectname";
            public const string CustomerRequestDate = "fiji_customerrequestdate";
            public const string CustomerPOCPreference = "fiji_customerpocpreference";
            public const string AdditionalEmail = "fiji_additionalemail";
            public const string ProjectComments = "fiji_projectcomments";
            public const string Opinel = "fiji_opinel";
            public const string ComponentModificationAcceptancePreference = "fiji_componentmodificationacceptancepreference";
            public const string AcceptedTermConditions = "fiji_accepted_term_cond";
            public const string DeterminedLocalization = "fiji_determine_locs";
            public const string ParentProjectId = "fiji_parentprojectid";
            public const string ProjectPriority = "fiji_projectpriority";
            public const string HideFromPortal = "fiji_hidefromportal";
            public const string StateCode = "statecode";
            public const string ProjectLevel = "fiji_projectlevel";
            public const string ProjectProductActionComments = "fiji_projectproductactioncomments";
            public const string ProjectProductAction = "fiji_projectproductaction";
            public const string OwningUser = "owninguser";
            public const string ComponentType = "fiji_componenttype";
            public const string ProductExternalId = "fiji_productexternalid";
            public const string CopyDuplicateSourceProjectId = "fiji_copyduplicatesourceprojectid";
            public const string ProjectScopeChangeJson = "fiji_projectscopechangejson";
            public const string CreatedOn = "createdon";
            public const string PCRCode = "fiji_pcrcode";
        }

        public class BOM
        {
            public const string ProductActionCode = "fiji_productactioncode";
            public const string Quantity = "fiji_quantity";
            public const string Comments = "fiji_comments";
            public const string SkipBOMAutoParse = "fiji_skip_bom_auto_parse";
            public const string ProductComponent = "fiji_productcomponent";
            public const string Project = "fiji_project";
            public const string BOMId = "fiji_billofmaterialsid";
            public const string ServiceRevision = "fiji_servicerevision";
            public const string StateCode = "statecode";
            public const string BomType = "fiji_bomtype";
            public const string ProductRevision = "fiji_productrevision";
            public const string ObjectActionCode = "fiji_objectactioncode";
            public const string Name = "fiji_name";
            public const string BOMComponentDescription = "fiji_bomcomponentdescription";
            public const string Createdbyipcs = "fiji_createdbyipcs";
            public const string StatusCode = "statuscode";
            public const string ServiceRevisionName = "fiji_servicerevisionname";
        }

        public class ProductComponent
        {
            public const string ProductComponentId = "fiji_productcomponentid";
            public const string ExternalId = "fiji_externalid";
            public const string ParentProductComponentId = "fiji_fiji_productcomponentid";
            public const string Name = "fiji_name";
            public const string ServiceTypeGlobal = "fiji_servicetypeglobal";
            public const string MaterialProductLine = "fiji_materialproductline";
            public const string ServiceComplexity = "fiji_servicecomplexity";
            public const string HideFromPortal = "fiji_hidefromportal";
            public const string PortalContact = "fiji_portalcontact";
            public const string ComponentType = "fiji_componenttype";
            public const string StatusCode = "statuscode";
            public const string StateCode = "statecode";
            public const string GetMoreSource = "fiji_getmoresource";
            public const string AutomationFlag = "fiji_automationflag";
            public const string CreatedBy = "createdby";
            public const string ModifiedBy = "modifiedby";
            public const string ModifiedOn = "modifiedon";
            public const string ModifiedByPortalContact = "fiji_modifiedbyportalcontact";
            public const string HasBeenSustaining = "fiji_has_been_in_sustaining";
            public const string EverestId = "fiji_everestid";
            public const string ExcludeFromBOMValidation = "fiji_excludefrombomvalidation";
            public const string LastServiceRevisionCompletedVersion = "fiji_latest_service_revision_modifiedon";
            public const string Comments = "fiji_comments";
            public const string CreatedOn = "createdon";
            public const string DataImportSource = "fiji_dataimportsource";
            public const string CompletedServiceRevisionVersion = "fiji_completedservicerevisionversion";
            public const string Owner = "ownerid";
            public const string OverriddenCreatedon = "overriddencreatedon";
            public const string PortalDescription = "fiji_portaldescription";
            public const string DuplicatedFromPC = "fiji_duplicatedfrompc";
        }

        public class ComponentType
        {
            public const string ComponentTypeId = "fiji_componenttypeid";
            public const string EnableReuse = "fiji_enable_reuse";
            public const string PortalDescription = "fiji_portal_description";
            public const string StatusCode = "statuscode";
            public const string ServiceNumber = "fiji_servicenumber";
            public const string AdditionalInfoMultiModel = "fiji_req_addit_info_multi_model";
            public const string IsConfigurable = "fiji_is_configurable";
            public const string ServiceCategory = "fiji_service_category";
            public const string CanBeUsedAcrossCustomer = "fiji_can_be_used_across_customer";
            public const string IsFactoryService = "fiji_isfactoryservice";
            public const string MultipleDifferentConfig = "fiji_can_be_added_multiple_times_dif_confg";
            public const string ServiceComplexity = "fiji_servicecomplexity";
            public const string ServiceType = "fiji_servicetype";
            public const string ServiceCategoryName = "fiji_service_categoryname";
            public const string StateCode = "statecode";
            public const string GetMoreServiceId = "fiji_getmore_serviceid";
            public const string IsMultiModel = "fiji_ismultimodel";
        }

        public class Servicesnapshot
        {
            public const string ServicesnapshotId = "fiji_servicesnapshotid";
            public const string ModifiedByPortalContact = "fiji_modifiedbyportalcontact";
            public const string ServiceRevisionVersion = "fiji_servicerevisionversion";
            public const string ModifiedOn = "modifiedon";
            public const string StatusCode = "statuscode";
            public const string ServiceDetailInJson = "fiji_servicedetailinjson";
            public const string CreatedOn = "createdon";
            public const string ParentService = "fiji_parentservice";
            public const string CustomerId = "fiji_customer";
            public const string TriggerEmailNotification = "fiji_trigger_email_notification";
            public const string ComponentType = "fiji_componenttype";
            public const string Name = "fiji_name";
            public const string ModifiedBy = "modifiedby";
            public const string ChangeComments = "fiji_changecomments";
            public const string ChangeMadeByUser = "fiji_changemadebyuser";
            public const string ObjectAction = "fiji_objectaction";
            public const string CreatedBy = "createdby";
            public const string IsAutomated = "fiji_isautomated";
            public const string FileId = "fiji_azurefileid";
            public const string EverestId = "fiji_everestid";
            public const string DataSource = "fiji_datasource";
            public const string CompareJSON = "fiji_comparejson";
            public const string FileURL = "fiji_fileurl";
            public const string HideFromPortal = "fiji_hidefromportal";
            public const string Externalid = "fiji_externalid";
        }

        public class FijiAssetTagSize
        {
            public const string FijiAssetTagSizeId = "fiji_assettagsizeid";
            public const string ProductComponent = "fiji_productcomponent";
            public const string Name = "fiji_name";
            public const string StateCode = "statecode";
        }

        public class FijiConfiguration
        {
            public const string Value = "fiji_value";
            public const string Key = "fiji_key";
        }

        public class PCBiosRevision
        {
            public const string Name = "fiji_name";
            public const string ProductComponentId = "fiji_productcomponentid";
            public const string ProductFamilyId = "fiji_productfamilyid";
        }

        public class PCPlatformStatus
        {
            public const string Name = "fiji_name";
            public const string ProductComponentId = "fiji_productcomponentid";
            public const string StatusCode = "statuscode";
            public const string ProjectId = "fiji_projectid";
            public const string PlatformId = "fiji_platformid";
            public const string PCPlatformStatusId = "fiji_pc_platform_statusid";
            public const string Createdon = "createdon";
            public const string CreatedBy = "createdby";
            public const string Modifiedon = "modifiedon";
            public const string Modifiedby = "modifiedby";
            public const string PlatformName = "fiji_platformidname";
        }

        public class SubRegion
        {
            public const string SubRegionId = "fiji_subregionid";
        }

        public class Region
        {
            public const string RegionId = "fiji_regionid";
        }

        public class ProductFamily
        {
            public const string ProductFamilyId = "fiji_productfamilyid";
            public const string ProductFamilyName = "fiji_productfamily";
            public const string Name = "fiji_name";
            public const string DeviceCategory = "fiji_devicecategoryid";
        }

        public class KMATProductFamily
        {
            public const string ProductLine = "fiji_productline";
            public const string KMATProductFamilyId = "fiji_kmatproductfamilyid";

        }

        public class Bookings
        {
            public const string BookableResourceId = "bookableresourcebookingid";
            public const string StartTime = "starttime";
            public const string EndTime = "endtime";
            public const string Duration = "duration";
            public const string Attended = "fiji_attended";
            public const string Comments = "fiji_comments";
            public const string Resource = "resource";
            public const string ModifiedOn = "modifiedon";
            public const string CreatedOn = "createdon";
            public const string BookingStatus = "bookingstatus";
            public const string ProjectId = "fiji_fiji_project";
        }

        public class BookableResource
        {
            public const string BookableResourceId = "bookableresourceid";
            public const string Factory = "fiji_factory";
            public const string Name = "name";
            public const string ResourceType = "resourcetype";
            public const string StatusCode = "statuscode";
            public const string FactoryId = "fiji_factory";
            public const string CalendarId = "calendarid";
        }

        public class FijiFactory
        {

            public const string FactoryId = "fiji_factoryid";
            public const string FactoryTeam = "fiji_factoryteam";
            public const string StatusCode = "statuscode";
            public const string Name = "fiji_name";
            public const string IsResilientFactory = "fiji_isresilientfactory";
        }

        public class Team
        {
            public const string TeamId = "teamid";
        }

        public class FijiTeamContact
        {
            public const string TeamId = "teamid";
            public const string ContactId = "contactid";
            public const string TeamContactId = "fiji_team_contactid";
        }

        public class Contact
        {
            public const string ContactId = "contactid";
        }

        public class BookingStatus
        {
            public const string BookingStatusId = "bookingstatusid";
            public const string Name = "name";
        }

        public class PlatformAndPlacement
        {
            public const string PlatformAndPlacementId = "fiji_platformplacementid";
            public const string ServicesnapshotId = "fiji_servicesnapshotid";
            public const string Platform = "fiji_platform";
            public const string Name = "fiji_name";
            public const string RequiredCustomAssetTag = "fiji_requiredcustomassettag";
            public const string Placement = "fiji_placement";
            public const string Orientation = "fiji_orientation";
            public const string CustomAssetTag = "fiji_customassettag";
            public const string CreatedOn = "createdon";
            public const string CreatedBy = "createdby";
            public const string ModifiedOn = "modifiedon";
            public const string ModifiedBy = "modifiedby";
            public const string OwnerId = "ownerid";
            public const string EverestId = "fiji_everestid";

        }

        public class ProductComponentAccount
        {
            public const string AccountId = "accountid";
            public const string ProductComponentId = "fiji_productcomponentid";
        }

        public class ProjectRegionLocale
        {
            public const string ProjectId = "fiji_projectid";
            public const string RegionLocaleId = "fiji_regionlocaleid";
        }

        public class RegionLocale
        {
            public const string LocalizationName = "fiji_localizationname";
            public const string RegionLocaleId = "fiji_regionlocaleid";
            public const string RegionLocaleCode = "fiji_regionlocalecode";
            public const string StateCode = "statecode";
        }

        public class AccountRegionLocale
        {
            public const string AccountId = "accountid";
            public const string RegionLocaleId = "fiji_regionlocaleid";
            public const string Name = "name";
            public const string CustomerHeadQuarterId = "fiji_customerheadquartercountryid";
        }

        public class PlatformRegionLocale
        {
            public const string RegionLocaleId = "fiji_regionlocaleid";
            public const string ProductFamilyRegionLocaleId = "fiji_productfamily_regionlocaleid";
            public const string ProductFamilyId = "fiji_productfamilyid";
            public const string StateCode = "statecode";
        }

        public class Task
        {
            public const string StateCode = "statecode";
            public const string ActualStart = "actualstart";
            public const string ActualStartUtc = "fiji_actualstartutc";
            public const string ActivityId = "activityid";
            public const string Description = "description";
            public const string PSTTicketNumber = "fiji_pstticketnumber";
            public const string PSTTicketUrl = "fiji_pstticketurl";
            public const string HPDelayDays = "fiji_hpdelaydays";
            public const string TaskType = "fiji_tasktype";
            public const string RegardingObjectId = "regardingobjectid";
            public const string CustomerId = "fiji_customer";
            public const string TaskAssignedDate = "fiji_taskassigneddate";
            public const string TaskDueDateAdjusted = "fiji_taskduedateadjusted";
            public const string StatusCode = "statuscode";
            public const string TaskId = "fiji_taskid";
            public const string TaskOUDays = "fiji_taskoudays";
            public const string KVMKeyboard = "fiji_kvmkeyboard";
            public const string CreatedOn = "createdon";
            public const string ActualEnd = "actualend";
            public const string Factory = "fiji_factory";
            public const string TaskTatDays = "fiji_tasktatdays";
            public const string ModifiedOn = "modifiedon";
            public const string CustomerName = "fiji_customername";
            public const string RegardingObjectIdName = "regardingobjectidname";
            public const string OwningTeam = "owningteam";
            public const string ModifiedByPortalContact = "fiji_modifiedbyportalcontact";
            public const string FactoryTatDays = "fiji_factorytatdays";
        }

        public class Calendar
        {
            public const string CalendarId = "calendarid";
            public const string Name = "name";
        }

        public class CalendarRule
        {
            public const string CalendarId = "calendarid";
            public const string StartTime = "starttime";
            public const string EffectiveIntervalEnd = "effectiveintervalend";
            public const string Description = "description";
            public const string Pattern = "pattern";
            public const string TimeZoneCode = "timezonecode";
            public const string EndTime = "endtime";
            public const string InnerCalendarId = "innercalendarid";
            public const string Duration = "duration";
            public const string SubCode = "subcode";
            public const string Offset = "offset";
        }

        public class TaskType
        {
            public const string TaskTypeId = "fiji_tasktypeid";
            public const string POCType = "fiji_poctype";
            public const string ValidationType = "fiji_validationtype";
            public const string POCTypeName = "fiji_poctypename";
        }

        public class Delay
        {
            public const string ModifiedOn = "modifiedon";
            public const string TaskId = "fiji_taskid";
            public const string DelayReasonsId = "fiji_delayreasonsid";
        }

        public class DelayReasons
        {
            public const string DelayReasonsId = "fiji_delayreasonsid";
            public const string Name = "fiji_name";
            public const string DelaySubReasonsId = "fiji_delaysubreasonsid";
        }

        public class DelaySubReasons
        {
            public const string DelaySubReasonsId = "fiji_delaysubreasonsid";
            public const string Name = "fiji_name";
        }
        public class ADRReport
        {
            public const string Id = "fiji_adrreportid";
            public const string FileName = "fiji_name";
            public const string FileURL = "fiji_fileurl";
            public const string CustomerId = "fiji_customer";
            public const string ReportFrequency = "fiji_reportfrequency";
        }
        public class ProjectStageTracker
        {
            public const string ProjectStage = "fiji_projectstage";
            public const string StageCompletedOn = "fiji_stagecompleteddate";
            public const string ProjectStageTrackerId = "fiji_projectstagetrackerid";
            public const string ProjectId = "fiji_projectid";
        }

        public class TimeZoneDefinition
        {
            public const string StandardName = "standardname";
            public const string TimeZoneCode = "timezonecode";
        }

        public class PlatformOperatingSystem
        {
            public const string PlatformOperatingSystemId = "fiji_plaformoperatingsystemid";
            public const string Name = "fiji_name";
            public const string CreatedOn = "createdon";
            public const string IsQualified = "fiji_isqualified";
            public const string StateCode = "statecode";
            public const string PlatformId = "fiji_platform";
            public const string OperatingSystem = "fiji_operatingsystem";
        }

        public class OperatingSystem
        {
            public const string StateCode = "statecode";
            public const string Name = "fiji_name";
            public const string OperatingSystemId = "fiji_operatingsystemid";
            public const string DisplayName = "fiji_displayname";
        }

        public class ComponentTypeOperatingSystem
        {
            public const string StateCode = "statecode";
            public const string OperatingSystem = "fiji_operatingsystem";
            public const string ComponentType = "fiji_componenttype";
        }

        public class BIOSConfigurationLine
        {
            public const string Name = "fiji_name";
            public const string BIOSConfigurationLineId = "fiji_biosconfigurationlineid";
            public const string ConfigurationId = "fiji_configurationid";
            public const string DataType = "fiji_datatype";
            public const string Value = "fiji_value";
            public const string StatusCode = "statuscode";
            public const string IsReadOnly = "fiji_isreadonly";
            public const string IsAutomated = "fiji_isautomated";
        }

        public class BIOSConfiguration
        {
            public const string BIOSConfigurationId = "fiji_biosconfigurationid";
            public const string PlatformId = "fiji_platformid";
            public const string StatusCode = "statuscode";
        }

        public class PortalManagementInfo
        {
            public const string FileName = "fiji_filename";
            public const string PortalManagementInfoId = "fiji_portalmanagementinfoid";
        }
    }
}