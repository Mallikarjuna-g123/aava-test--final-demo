using Microsoft.Playwright;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    /// <summary>
    /// A lightweight handle to an isolated browser context acquired from IBrowserService.
    /// Provides a new page for rendering and releases the concurrency slot on disposal.
    /// </summary>
    public sealed class BrowserContextHandle : IAsyncDisposable
    {
        private readonly IBrowserContext _context;
        private readonly SemaphoreSlim _semaphore;
        private readonly ILogger _logger;
        private bool _disposed;

        internal BrowserContextHandle(IBrowserContext context, SemaphoreSlim semaphore, ILogger logger)
        {
            _context = context;
            _semaphore = semaphore;
            _logger = logger;
        }

        public Task<IPage> NewPageAsync() => _context.NewPageAsync();

        public async ValueTask DisposeAsync()
        {
            if (_disposed) return;
            _disposed = true;
            try
            {
                await _context.CloseAsync();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error closing browser context.");
            }
            finally
            {
                _semaphore.Release();
            }
        }
    }

    /// <summary>
    /// Provides access to a long-lived, shared Chromium browser instance.
    /// Use AcquireContextAsync to get an isolated browser context per request
    /// and dispose it when done.
    /// </summary>
    public interface IBrowserService
    {
        /// <summary>
        /// Returns a new isolated browser context handle. The caller must dispose it
        /// after use to release the concurrency slot and close the context.
        /// </summary>
        Task<BrowserContextHandle> AcquireContextAsync(CancellationToken cancellationToken = default);
    }
}
