﻿using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Requests;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Text.Json;
using static FIJI.Portal.WebAPI.Integration.Model.Project;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class ProjectScopeChangeHelper : Base<ProjectScopeChangeHelper>
    {

        // Constructor to initialize the IOrganizationService
        public ProjectScopeChangeHelper(IOrganizationService dataverseClient, ILogger<ProjectScopeChangeHelper>? logger = null) : base(dataverseClient, "projectscopechangehelper", logger)
        { }
        
        public void UpdateProjectScopeChangeByProjectId(ProjectScopeChangeRequest projectScopeChangereponse, string projectId)
        {
            TraceOperation(nameof(UpdateProjectScopeChangeByProjectId), () =>
            {
                var project = this.DataverseClient.Retrieve(EntityName.Project, new Guid(projectId), new ColumnSet(AttributeNames.Project.ProjectStage));
                OptionSetValue? optionSetValue = project.Attributes[AttributeNames.Project.ProjectStage] as OptionSetValue;

                if (optionSetValue != null)
                {
                    int projectStage = optionSetValue.Value;

                    if ((int)eProjectstage.Initialization == projectStage
                        || (int)eProjectstage.Feasibility == projectStage
                        || (int)eProjectstage.Setup == projectStage)
                    {
                        var options = new JsonSerializerOptions { WriteIndented = true };
                        string json = System.Text.Json.JsonSerializer.Serialize(projectScopeChangereponse, options);

                        Entity fiji_project = new Entity(EntityName.Project, new Guid(projectId));
                        fiji_project[AttributeNames.Project.ProjectScopeChangeJson] = json;

                        this.DataverseClient.Execute(new UpdateRequest { Target = fiji_project });
                    }
                }
            }, ("projectId", projectId), ("hasRequest", projectScopeChangereponse != null));
        }

        public dynamic? GetProductExternalIdByBOMID(string BOMID)
        {
            return TraceOperation<dynamic?>(nameof(GetProductExternalIdByBOMID), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.BOM);
                query.ColumnSet = new ColumnSet(AttributeNames.BOM.ProductComponent, AttributeNames.BOM.Name);
                query.AddLink(EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId);
                query.LinkEntities[0].EntityAlias = "ct";
                query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductComponent.ExternalId, AttributeNames.ProductComponent.PortalDescription);

                string externalId = string.Empty, bomName = string.Empty, description = string.Empty;

                // Add filtering conditions
                query.Criteria.AddCondition(AttributeNames.BOM.BOMId, ConditionOperator.Equal, BOMID);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    //string? bomId = entity.Id.ToString();

                    if (entity.Contains(AttributeNames.BOM.Name))
                        bomName = entity.GetAttributeValue<string>(AttributeNames.BOM.Name) ?? string.Empty;

                    if (entity.Contains("ct.fiji_portaldescription"))
                        description = entity.GetAttributeValue<AliasedValue>("ct.fiji_portaldescription")?.Value?.ToString() ?? string.Empty;

                    if (entity.Contains("ct.fiji_externalid"))
                        externalId = entity.GetAttributeValue<AliasedValue>("ct.fiji_externalid")?.Value?.ToString() ?? string.Empty;

                    return new
                    {
                        externalId,
                        bomName,
                        description
                    };
                }
                return null;
            }, ("bomId", BOMID));
        }

        public Guid? GetProjectIDByBOMID(Guid billofmaterialsID)
        {
            return TraceOperation<Guid?>(nameof(GetProjectIDByBOMID), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.BOM)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.BOM.Project)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.BOM.BOMId, ConditionOperator.Equal, billofmaterialsID);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    return entity.GetAttributeValue<EntityReference>(AttributeNames.BOM.Project)?.Id;
                }
                return null;
            }, ("bomId", billofmaterialsID));
        }
    }
}
    

