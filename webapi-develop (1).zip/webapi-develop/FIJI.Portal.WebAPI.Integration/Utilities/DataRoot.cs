﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class DataRoot
    {
        public int statcode { get; set; }
        public string status { get; set; }
        public Data data { get; set; }
        public class Data
        {
            public string name { get; set; }
        }
    }
}
