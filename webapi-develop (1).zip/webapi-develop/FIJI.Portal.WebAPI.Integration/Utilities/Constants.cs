﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public static class Constants
    {

        /// <summary>
        /// UserAgentHeaderValue
        /// </summary>
        public const string UserAgentHeaderValue = "FIJIPortalWebApi/1.0";

        /// <summary>
        /// Configuration key for malicious keywords pattern list
        /// </summary>
        public const string MaliciousKeywords = "MaliciousKeywords";

        /// <summary>
        /// Cache key for storing malicious keywords in memory
        /// </summary>
        public const string CachedMaliciousKeywordsKey = "CachedMaliciousKeywords";

        /// <summary>
        /// Fiji configuration key attribute name
        /// </summary>
        public const string FijiKeyAttribute = "fiji_key";

        /// <summary>
        /// Fiji configuration value attribute name
        /// </summary>
        public const string FijiValueAttribute = "fiji_value";

        public static string Fiji_Objectactioncode_remove = "ebaded1a-cb4b-ec11-8c62-0022480a6838";

        public static string Fiji_CrmUrl = "CrmUrl";
        public static string Fiji_CrmConnectionString = "CRMConnectionString";

        public const string ImmutableEtag = "\"immutable\"";
        public const string CacheControl = "public, max-age=604800";

        /// <summary>
        /// The ipcs line item
        /// </summary>
        public const string ipcsLineItem = "IPCSLineItem";

        /// <summary>
        /// The text XML
        /// </summary>
        public const string textXml = "text/xml";

        /// <summary>
        /// The failure
        /// </summary>
        public const string failure = "Failure";

        /// <summary>
        /// The occ identifier null message
        /// </summary>
        public const string occIdNullMessage = "OCC Id is null";

        /// <summary>
        /// The connection string
        /// </summary>
        public const string connectionString = "connectionString";

        /// <summary>
        /// The queue name
        /// </summary>
        public const string queueName = "queueName";

        /// <summary>
        /// The success
        /// </summary>
        public const string success = "Success";

        /// <summary>
        /// The validation failure
        /// </summary>
        public const string validationFailure = "Validation Failure";

        /// <summary>
        /// The length exception
        /// </summary>
        public const string lengthException = "The message is too large to fit in the batch.";

        /// <summary>
        /// The web service URL
        /// </summary>
        public const string webServiceUrl = "webServiceUrl";

        /// <summary>
        /// The OCI endpoint url
        /// </summary>
        public const string OCIEndPoint = "OCIEndPoint";

        /// <summary>
        /// The Authentication token url
        /// </summary>
        public const string AuthTokenUrl = "AuthTokenUrl";

        /// <summary>
        /// The OCI Client id
        /// </summary>
        public const string OCIClientId = "OCIClientId";

        /// <summary>
        /// The OCI Client Secret
        /// </summary>
        public const string OCIClientSecret = "OCIClientSecret";

        /// <summary>
        /// The OCI App Name
        /// </summary>
        public const string OCIAppName = "One Config (OCI)";

        /// <summary>
        /// The OCC Application
        /// </summary>
        public const string OCCAppName = "OCC Application";

        /// <summary>
        /// The HP Internal Application
        /// </summary>
        public const string HPInternalApplication = "HP-Internal-Application";

        /// <summary>
        /// The Config-Id key
        /// </summary>
        public const string ConfigID = "Config-Id";

        /// <summary>
        /// The One condition string check
        /// </summary>
        public const string OneConditionCheck = "1";

        /// <summary>
        /// The Three condition string check
        /// </summary>
        public const string ThreeConditionCheck = "3";

        /// <summary>
        /// The Four condition string check
        /// </summary>
        public const string FourConditionCheck = "4";

        /// <summary>
        /// The Five condition string check
        /// </summary>
        public const string FiveConditionCheck = "5";

        /// <summary>
        /// The starting point identifier
        /// </summary>
        public const string startingPointId = "ipc:startingPointId";

        /// <summary>
        /// The identifier
        /// </summary>
        public const string id = "ID";

        /// <summary>
        /// The part description
        /// </summary>
        public const string partDescription = "Part Description";

        /// <summary>
        /// The quantity
        /// </summary>
        public const string quantity = "Quantity";

        /// <summary>
        /// The localized
        /// </summary>
        public const string localized = "Localized";

        /// <summary>
        /// The product line
        /// </summary>
        public const string productLine = "Product Line";

        /// <summary>
        /// The component type
        /// </summary>
        public const string componentType = "Component Type";

        /// <summary>
        /// The price
        /// </summary>
        public const string price = "Price";

        /// <summary>
        /// The service number
        /// </summary>
        public const string serviceNumber = "Service Number";

        /// <summary>
        /// The product family
        /// </summary>
        public const string productFamily = "Product Family";

        /// <summary>
        /// The material
        /// </summary>
        public const string material = "ipc:material";

        /// <summary>
        /// The component type name
        /// </summary>
        public const string componentTypeName = "ComponentTypeName";

        /// <summary>
        /// The component type description
        /// </summary>
        public const string componentTypeDescription = "ComponentTypeDescription";

        /// <summary>
        /// The messages
        /// </summary>
        public const string messages = "ipc:messages";

        /// <summary>
        /// The configuration
        /// </summary>
        public const string configuration = "ipc:configuration";

        /// <summary>
        /// The complete
        /// </summary>
        public const string complete = "complete";

        /// <summary>
        /// The conflict
        /// </summary>
        public const string conflict = "conflict";

        /// <summary>
        /// The selected
        /// </summary>
        public const string selected = "selected";

        /// <summary>
        /// The list price
        /// </summary>
        public const string listPrice = "listPrice";

        /// <summary>
        /// The cstic short text
        /// </summary>
        public const string csticShortText = "csticShortText";

        /// <summary>
        /// The cstic
        /// </summary>
        public const string cstic = "ipc:cstic";

        /// <summary>
        /// The hp system legacy locn
        /// </summary>
        public const string hpSystemLegacyLocn = "HP_SYSTEM_LEGACY_LOCN";

        /// <summary>
        /// The header
        /// </summary>
        public const string header = "ipc:header";

        /// <summary>
        /// The future shipment date response
        /// </summary>
        public const string futureShipmentDateResponse = "futureShipmentDateResponse";

        /// <summary>
        /// The yyyy m MDD
        /// </summary>
        public const string yyyyMMdd = "yyyyMMdd";

        /// <summary>
        /// The ddMMMyyyy
        /// </summary>
        public const string ddMMMyyyy = "ddMMMyyyy";

        /// <summary>
        /// The m mddyyyy
        /// </summary>
        public const string MMddyyyy = "MM-dd-yyyy";

        /// <summary>
        /// The hh:mm tt
        /// </summary>
        public const string HoursMinutes = "hh:mm tt";

        /// <summary>
        /// The product
        /// </summary>
        public const string product = "ipc:product";

        /// <summary>
        /// The generic component place holder
        /// </summary>
        public const string genericComponentPlaceHolder = "Generic Component Place Holder";

        /// <summary>
        /// The ipc price
        /// </summary>
        public const string ipcPrice = "ipc:price";

        /// <summary>
        /// The ipc desc
        /// </summary>
        public const string ipcDesc = "ipc:desc";

        /// <summary>
        /// The product line
        /// </summary>
        public const string _productLine = "productLine";

        /// <summary>
        /// The ipc qty
        /// </summary>
        public const string ipcQty = "ipc:qty";

        /// <summary>
        /// The ipc
        /// </summary>
        public const string ipc = "ipc";

        /// <summary>
        /// The ipcs namespace
        /// </summary>
        public const string ipcsNamespace = "http://hp.com/ipcs/response/";

        /// <summary>
        /// The ipcs single node
        /// </summary>
        public const string ipcsSingleNode = "ipc:configurations/ipc:configuration/ipc:header[@id='Program']";

        /// <summary>
        /// The cstic values
        /// </summary>
        public const string csticValues = "csticValues";

        /// <summary>
        /// The ipc desc start tag
        /// </summary>
        public const string ipcDescStartTag = "<ipc:desc>";

        /// <summary>
        /// The ipc desc close tag
        /// </summary>
        public const string ipcDescCloseTag = "</ipc:desc>";

        /// <summary>
        /// StorageAccount
        /// </summary>
        public const string StorageAccount = "StorageAccount";

        /// <summary>
        /// StorageAccountKey
        /// </summary>
        public const string StorageAccountKey = "StorageAccountKey";

        /// <summary>
        /// GenericProductComponents
        /// </summary>
        public const string GenericProductComponents = "GenericProductComponents";

        /// <summary>
        /// PreDefinedAndPlaceholderProductComponents
        /// </summary>
        public const string PreDefinedAndPlaceholderProductComponents = "PreDefinedAndPlaceholderProductComponents";

        /// <summary>
        /// FIJIConfigurationPOCTaskKey
        /// </summary>
        public const string PocTaskKey = "POC Tasks";

        /// <summary>
        /// FIJIConfigurationVirtualValidationTaskKey
        /// </summary>
        public const string VirtualValidationTaskKey = "Virtual Validation Tasks";

        /// <summary>
        /// Portal URL
        /// </summary>
        public const string PortalBaseUrl = "Portal URL";

        /// <summary>
        /// PSTHostURL
        /// </summary>
        public const string PSTHostURL = "PSTHostURL";

        /// <summary>
        /// AY103AV_API_BaseURL
        /// </summary>
        public const string AY103AV_API_BaseURL = "AY103AV_API_BaseURL";

        /// <summary>
        /// AY103AV_API_Code
        /// </summary>
        public const string AY103AV_API_Code = "AY103AV_API_Code";

        /// <summary>
        /// Part Number AY103AV
        /// </summary>
        public const string PartNumber_AY103AV = "AY103AV";

        /// <summary>
        /// Part Number AY777AV
        /// </summary>
        public const string PartNumber_AY777AV = "AY777AV";

        /// <summary>
        /// Customer_Files_HostUrl
        /// </summary>
        public const string Customer_Files_HostUrl = "Customer_Files_HostUrl";

        /// <summary>
        /// FIJIConfigurationVirtualValidationTitle
        /// </summary>
        public const string VirtualValidationTitle = "FijiData_11.1_Tasks_";

        /// <summary>
        /// FIJIConfigurationPOCTaskTitle
        /// </summary>
        public const string POCTaskTitle = "FijiData_POC_Tasks_";

        /// <summary>
        /// Content Type
        /// </summary>
        public const string ContentTypeExcel = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        /// <summary>
        /// Access-Control-Expose-Headers
        /// </summary>
        public const string AccessControlHeaders = "Access-Control-Expose-Headers";

        /// <summary>
        /// Content-Disposition
        /// </summary>
        public const string ContentDisposition = "Content-Disposition";

        /// <summary>
        /// JsonApplication
        /// </summary>
        public const string JsonApplication = "application/json";

        /// <summary>
        /// ContentType
        /// </summary>
        public const string ContentType = "Content-Type";

        /// <summary>
        /// LessThanSymbol
        /// </summary>
        public const string LessThanSymbol = "<";

        /// <summary>
        /// Count
        /// </summary>
        public const string Count = "count";

        /// <summary>
        /// Success
        /// </summary>
        public const string Success = "Success";

        /// <summary>
        /// ApplicationOctetStream
        /// </summary>
        public const string ApplicationOctetStream = "application/octet-stream";

        /// <summary>
        /// NewService
        /// </summary>
        public const string NewService = "newService";

        /// <summary>
        /// RemoveService
        /// </summary>
        public const string RemoveService = "removeService";

        /// <summary>
        /// UpdateService
        /// </summary>
        public const string UpdateService = "updateService";

        /// <summary>
        /// Result
        /// </summary>
        ///
        public const string Result = "result";

        /// <summary>
        /// AY108AV
        /// </summary>
        ///
        public const string AY108AV = "AY108AV";

        /// <summary>
        /// AY111AV
        /// </summary>
        ///
        public const string AY111AV = "AY111AV";

        /// <summary>
        /// EMEA Region
        /// </summary>
        public const string EMEA = "EMEA";

        /// <summary>
        /// UK
        /// </summary>
        public const string UK = "UK";

        /// <summary>
        /// US
        /// </summary>
        public const string US = "US";

        /// <summary>
        /// Automated
        /// </summary>
        public const string Automated = "Automated";

        /// <summary>
        /// Submitted
        /// </summary>
        public const string Submitted = "Submitted";

        /// <summary>
        /// Manual
        /// </summary>
        public const string Manual = "Manual";

        /// <summary>
        /// Hypen
        /// </summary>
        public const string Hypen = " - ";

        /// <summary>
        /// PC
        /// </summary>
        public const string PC = "PC-";

        /// <summary>
        /// Version1
        /// </summary>
        public const string Version1 = "1.0";

        /// <summary>
        /// Version.0
        /// </summary>
        public const string Version0 = ".0";

        /// <summary>
        /// KVMKeyboard
        /// </summary>
        public const string KVMKeyboard = "Fiji_kvmkeyboard";

        /// <summary>
        /// POCType
        /// </summary>
        public const string POCType = "Fiji_poctype";

        /// <summary>
        /// Tasks
        /// </summary>
        public const string Tasks = "Tasks";

        /// <summary>
        /// Link
        /// </summary>
        public const string Link = "Link";

        /// <summary>
        /// Complete BOM
        /// </summary>
        public const string CompleteBOM = "Complete BOM";

        /// <summary>
        /// PSTTicketNumber
        /// </summary>
        public const string PSTTicketNumber = "Fiji_pstticketnumber";

        /// <summary>
        /// OwnerId
        /// </summary>
        public const string OwnerId = "Ownerid";

        /// <summary>
        /// String
        /// </summary>
        public const string String = "String";

        /// <summary>
        /// Int32
        /// </summary>
        public const string Int32 = "Int32";

        /// <summary>
        /// DateTime
        /// </summary>
        public const string DateTime = "DateTime";

        /// <summary>
        /// Bearer
        /// </summary>
        public const string Bearer = "Bearer";

        /// <summary>
        /// OAuth2
        /// </summary>
        public const string OAuth2 = "oauth2";

        /// <summary>
        /// JWTSecret
        /// </summary>
        public const string JWTSecret = "JWT_Secret";

        /// <summary>
        /// ApplicationInsightsConnectionString
        /// </summary>
        public const string ApplicationInsightsConnectionString = "APPLICATIONINSIGHTS_CONNECTION_STRING";

        /// <summary>
        /// EnableVirusCheck
        /// </summary>
        public const string EnableVirusCheck = "enableVirusCheck";

        /// <summary>
        /// CRMUrl
        /// </summary>
        public const string CRMUrl = "crm_url";

        /// <summary>
        /// CRMConnectionString
        /// </summary>
        public const string CRMConnectionString = "crm_connection_string";

        /// <summary>
        /// ClientId
        /// </summary>
        public const string ClientId = "clientId";

        /// <summary>
        /// Secret
        /// </summary>
        public const string Secret = "secret";

        /// <summary>
        /// Authorization
        /// </summary>
        public const string Authorization = "Authorization";

        /// <summary>
        /// Copy
        /// </summary>
        public const string Copy = "-Copy";

        /// <summary>
        /// Frequent
        /// </summary>
        public const string Frequent = "FREQ";

        /// <summary>
        /// BY DAY
        /// </summary>
        public const string BYDAY = "BYDAY";

        /// <summary>
        /// COUNT
        /// </summary>
        public const string COUNT = "COUNT";

        /// <summary>
        /// Never
        /// </summary>
        public const string Never = "Never";

        /// <summary>
        /// Committed
        /// </summary>
        public const string Committed = "Committed";

        /// <summary>
        /// Completed
        /// </summary>
        public const string Completed = "Completed";

        /// <summary>
        /// Daily
        /// </summary>
        ///
        public const string Daily = "daily";

        /// <summary>
        /// Monthly
        /// </summary>
        ///
        public const string Monthly = "monthly";

        /// <summary>
        /// Portal WebAPI
        /// </summary>
        public const string PortalWebApi = "Portal WebAPI";

        /// <summary>
        /// RequestLimits__MaxRequestBodySizeBytes
        /// </summary>
        public const string RequestLimitsMaxRequestBodySizeBytes = "RequestLimits__MaxRequestBodySizeBytes";

        /// <summary>
        /// Project Id Search Mode
        /// </summary>
        public const string ProjectIdSearchMode = "ProjectId";

        /// <summary>
        /// Global Search Mode
        /// </summary>
        public const string GlobalSearchMode = "Global";

        /// <summary>
        /// Max Project Id Search Count
        /// </summary>
        public const int MaxProjectIdSearchCount = 50;

        /// <summary> 
        /// The ADR Check Tenant Consent endpoint url 
        /// </summary> 
        public const string ADRCheckTenantConsentEndpoint = "ADRCheckTenantConsentEndpoint";

        /// <summary> 
        /// The ADR Authentication token url 
        /// </summary> 
        public const string ADRTokenUrl = "ADRTokenUrl";

        /// <summary> 
        /// The ADR Client id 
        /// </summary> 
        public const string ADRClientId = "ADRClientId";

        /// <summary> 
        /// The ADR Client Secret 
        /// </summary> 
        public const string ADRClientSecret = "ADRClientSecret";

        /// <summary> 
        /// The ADR consent scope 
        /// </summary> 
        public const string ADRConsentScope = "ADR.Read";

        /// <summary> 
        /// Fixed SoldToCustomerID/ReceivedFromCustomerID per HP ADR integration contract 
        /// </summary> 
        public const string ADRSoldToCustomerId = "0000064397";

        public const string ADRTokenURL = "ADRTokenURL";

        public const string ADRConsentURL = "ADRConsentURL";

        /// <summary> 
        /// fiji_display_in option set values on fiji_service_category 
        /// </summary> 
        public const int DisplayInWizard = 622490000;
        public const int DisplayInInceptionNew = 622490001;
        public const int DisplayInInceptionECN = 622490002;

        /// <summary>
        /// Error Messages
        /// </summary>
        ///
        public static class ErrorMessages
        {
            public const string DuplicateKey = "Cannot insert duplicate key.";
            public const string InvalidPayload = "Payload is not valid!";
            public const string EmptyPayload = "Empty request payload!";
            public const string EmptyParameters = "Parameters (table and optionSet) must have a value";
            public const string EmptyParams = "No params!";
            public const string NoRecord = "No record found!";
            public const string EmptyCustomerId = "CustomerId is required";
            public const string RemoveServiceList = "Remove service list contain bom record which is also present in update service record.";
            public const string EmptyBOMId = "BOM ID  cannot be empty  in update Service list";
            public const string EmptyProductComponentId = "Product Component ID  cannot be empty in update Service list";
            public const string Unsuccessful = "Unsuccessful";
            public const string InvalidRequestId = "invalid/non-existent requestId";
            public const string EmptyRequestId = "RequestId cannot be empty or null.";
            public const string InvalidProjectId = "Invalid Project ID";
            public const string NullTransaction = "Transaction cannot be null!";
            public const string NoPlatformId = "Platform Id is a Mandatory Field";
            public const string NoRegion = "Region not found for ownerID. Region must be configured for OwnerID.";
            public const string NoRegionforFSPM = "Region not found for FSPMID. Region must be configured for FSPMID.";
            public const string NoLocalization = "No Localization's for this project";
            public const string NoTaskTypeDefined = "Task Type not defined!";
            public const string UnableToTagEndPoint = "Unable to determine tag for endpoint.";
            public const string NoCustomerInSourceProject = "Customer in source project is null";
            public const string NoNewECNInSourceProject = "NewOrECN in source project is null";
            public const string NoProjectTypeInSourceProject = "ProjectType in source project is null";
            public const string NoProductTypeInSourceProject = "ProductType in source project is null";
            public const string NoProjectFoundForSKU = "No valid project available for SKU(s) {0}";
            public const string SKUAlreadyInProgressPleaseWait = "The SKU(s) {0} is being used in another process. Please wait and try again!";
            public const string NoProductComponentId = "ProductComponent Id is a Mandatory Field";
            public const string AvailableBomItems = "Linked to a project. The model cannot be removed.";
            public const string NoServiceRevisionId = "ServiceRevision Id is a Mandatory Field";
            public const string NoServiceRevisionsFound = "No service revisions found with CompareJSON to clear.";
            public const string NoPortalUserId = "PortalUser Id is a Mandatory Field";
            public const string NoDescription = "Description is a Mandatory Field";
            public const string InvalidProductComponentId = "Invalid ProductComponentId";
            public const string DuplicatePortalDescription = "A service exists with this description, Please enter a unique value.";
            public const string ProjectIdSearchLimitExceeded = "You can search for a maximum of 50 Project IDs at a time. Please remove some IDs and try again.";
        }

        public static class ResponseMessages
        {
            public const string Ok = "OK";
            public const string BOMSuccessfullyCreated = "BOMs are Successfully Created";
            public const string BOMProductActionCode = "BOMs Product action code updated successfully.";
            public const string BomUpdatedSuccessfully = "BOMs are Updated Successfully";
            public const string ProjectandBOMCreated = "Project and BOM are Successfully Created";
            public const string TaskUpdatedSuccessfully = "Task updated successfully!";
            public const string CompareJSOnUpdated = "CompareJSON cleared successfully.";
        }

        public static class ActionCode
        {
            public const string NoChange = "No Change";
            public const string New = "NEW";
            public const string Reuse = "REUSE";
        }

        public static class WorkFlows
        {
            public const string CreateDuplicateProject = "fiji_CreateDuplicateProject";
        }

        public static class TaskColumnNames
        {
            public const string StartDate = "startdate";
            public const string EndDate = "enddate";
            public const string Type = "type";
            public const string StartTime = "starttime";
            public const string EndTime = "endtime";
            public const string Repeat = "repeat";
            public const string Days = "days";
        }

        public static string GetURLAzure = "GetURLAzure";
        public static string GetHomeURL = "GetHomeURL";
        public static string AzureAccessScope = "AzureAccessScope";

        public static class QuestionaireDetails
        {
            public const string AY103AV = "AY103AV";
            public const string AY307AV = "AY307AV";
            public const string AY802AV = "AY802AV";
            public const string IsBCUSetting = "IsBCUSetting";
            public const string AdditionalRequirements = "AdditionalRequirements";
            public const string ValueList = "ValueList";
            public const string ID = "Id";
            public const string Zero = "0";
            public const string ImageCloningTool = "ImageCloningTool";
            public const string SourceICT = "SourceICT";
            public const string Other = "Other";
            public const string Applications = "applications";
            public const string additionalRequirements = "additionalRequirements";
            public const string Files = "files";
            public const string HPPreferredAction = "HPPreferredAction";
            public const string OSSettingsFile = "OSSettingsFile";
            public const string OSChangeRequirements = "OSChangeRequirements";
            public const string IsModifyHPSmartSupport = "isModifyHPSmartSupport";
            public const string IsTermsAndConditionAccepted = "isTermsAndConditionAccepted";
            public const string IsHPSureRecovery = "isHPSureRecovery";
            public const string CustomizeSysPrepOOBE = "customizeSysPrepOOBE";
            public const string IsModifyRegistrySettings = "isModifyRegistrySettings";
            public const string IsInstallTrialVersion = "isInstallTrialVersion";
            public const string InstallSpecificVersion = "yes_want_install_specificVersion";
            public const string InstallTrialVersion = "installTrialVersion";
            public const string CustomizeWinStrtMenu = "customizeWinStrtMenu";
            public const string CustomizeWinDesktopFile = "customizeWinDesktopFile";
            public const string IsInstallRSAT = "isInstallRSAT";
            public const string Partitions = "partitions";
            public const string PartitionType = "partitionType";
            public const string RecoveryPartition = "Recovery Partition";
            public const string Image = "image";
            public const string ICTSource = "ictSource";
            public const string ImageX = "Image X / DISM (Microsoft WIM or SWM format - HP preferred)";
            public const string IsBCD = "isBCD";
            public const string Yes = "yes";
            public const string PPKG = "ppkg";
            public const string MyRequirements = "myRequirements";
        }

        public class SecurityRole
        {
            public const string FIJIFSPM = "FIJI FSPM";
        }

        public class Team
        {
            public const string FSPM = "Fiji FSPM Team";
        }
    }
}