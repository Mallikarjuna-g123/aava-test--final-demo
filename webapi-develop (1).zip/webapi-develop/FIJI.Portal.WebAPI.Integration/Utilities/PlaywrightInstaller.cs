namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class PlaywrightInstaller : IHostedService
    {
        // Resolved once at process startup so every component (installer + controller)
        // reads the same value even before StartAsync runs.
        public static readonly string BrowsersPath = ResolveBrowsersPath();

        private readonly ILogger<PlaywrightInstaller> _logger;

        static PlaywrightInstaller()
        {
            // Set the env var at the earliest possible moment — static constructor
            // runs before any instance is created, so Playwright's driver will always
            // find the correct path regardless of call order.
            Environment.SetEnvironmentVariable("PLAYWRIGHT_BROWSERS_PATH", BrowsersPath);
        }

        public PlaywrightInstaller(ILogger<PlaywrightInstaller> logger)
        {
            _logger = logger;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Playwright browsers path resolved to: {Path}", BrowsersPath);

            // Derive the expected Chromium executable path directly from the browsers
            // path without spawning a Playwright driver process. The folder structure
            // that Playwright uses is:  <BrowsersPath>\chromium-<revision>\chrome-win\chrome.exe
            // We scan for any chromium-* subfolder so the check is revision-agnostic.
            var chromiumExecutable = FindChromiumExecutable(BrowsersPath);

            if (chromiumExecutable != null)
            {
                _logger.LogInformation("Chromium already installed at {Path}. Skipping installation.", chromiumExecutable);
                return Task.CompletedTask;
            }

            _logger.LogInformation("Chromium not found under {Path}. Installing...", BrowsersPath);

            // PLAYWRIGHT_BROWSERS_PATH is already set in the static constructor so
            // the install command will write into the correct persistent directory.
            var exitCode = Microsoft.Playwright.Program.Main(new[] { "install", "chromium" });

            if (exitCode != 0)
                _logger.LogError("Playwright Chromium installation failed with exit code {ExitCode}.", exitCode);
            else
                _logger.LogInformation("Playwright Chromium installed successfully under {Path}.", BrowsersPath);

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

        /// <summary>
        /// Resolves the persistent browsers storage path.
        /// Azure Windows Web App  ? D:\home\playwright-browsers  (persistent across restarts)
        /// Local / other          ? app base directory\playwright-browsers
        /// Detection uses WEBSITE_INSTANCE_ID which Azure App Service always sets,
        /// making it a more reliable signal than checking whether D:\home exists.
        /// </summary>
        private static string ResolveBrowsersPath()
        {
            var isAzureAppService = !string.IsNullOrEmpty(
                Environment.GetEnvironmentVariable("WEBSITE_INSTANCE_ID"));

            if (isAzureAppService)
                return @"D:\home\playwright-browsers";

            return Path.Combine(AppContext.BaseDirectory, "playwright-browsers");
        }

        /// <summary>
        /// Scans browsersRoot for a Chromium executable installed by Playwright
        /// (chromium-revision\chrome-win\chrome.exe) without requiring a live
        /// Playwright driver process. Returns the full path if found, otherwise null.
        /// </summary>
        private static string? FindChromiumExecutable(string browsersRoot)
        {
            if (!Directory.Exists(browsersRoot))
                return null;

            foreach (var dir in Directory.EnumerateDirectories(browsersRoot, "chromium-*"))
            {
                var candidate = Path.Combine(dir, "chrome-win", "chrome.exe");
                if (File.Exists(candidate))
                    return candidate;
            }

            return null;
        }
    }
}
