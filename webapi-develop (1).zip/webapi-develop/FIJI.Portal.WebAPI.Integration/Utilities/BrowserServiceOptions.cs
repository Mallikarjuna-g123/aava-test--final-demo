namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public sealed class BrowserServiceOptions
    {
        public const string SectionName = "BrowserService";

        /// <summary>
        /// Maximum number of PDF renders allowed to run concurrently.
        /// Tune this based on the PremiumV3 SKU RAM:
        ///   P1v3 (8 GB)  ? 4�6
        ///   P2v3 (16 GB) ? 8�12
        ///   P3v3 (32 GB) ? 16�20
        /// Defaults to 5 if not configured.
        /// </summary>
        public int MaxConcurrentPages { get; set; } = 5;

        /// <summary>
        /// Timeout in seconds for a single PDF render operation.
        /// Requests exceeding this are cancelled with HTTP 408.
        /// Defaults to 60 seconds.
        /// </summary>
        public int RenderTimeoutSeconds { get; set; } = 60;
    }
}
