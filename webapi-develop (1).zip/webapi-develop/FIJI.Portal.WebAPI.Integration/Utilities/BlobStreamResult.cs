﻿using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Mvc;
using System.IO.Pipelines;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class BlobStreamResult : ActionResult
    {
        int _statusCode;
        string _blobName;
        BlobDownloadStreamingResult _blobResult;

        public BlobStreamResult(string blobName, int statusCode, BlobDownloadStreamingResult blobResult)
        {
            _statusCode = statusCode;
            _blobResult = blobResult;
            _blobName = blobName;
        }

        public override async Task ExecuteResultAsync(ActionContext context)
        {
            try
            {
                if (_blobName.Contains("/"))
                    _blobName = _blobName.Substring(_blobName.LastIndexOf("/") + 1);

                var response = context.HttpContext.Response;
                response.StatusCode = _statusCode;
                response.Headers.ContentType = _blobResult.Details.ContentType;
                response.Headers.ContentLength = _blobResult.Details.ContentLength;
                response.Headers.ContentDisposition = $"attachment; filename={_blobName}";

                if (_statusCode == StatusCodes.Status206PartialContent)
                {
                    response.Headers.ContentRange = _blobResult.Details.ContentRange;
                }

                // Be sure to cancel flowing the stream if the request is aborted
                CancellationToken ct = context.HttpContext.RequestAborted;
                await _blobResult.Content.CopyToAsync(response.BodyWriter, ct);
            }
            finally
            {
                // Clean up the blob stream when done. A TaskCanceledException (or
                // for some other reason) may occur in the above block.
                _blobResult.Dispose();
            }
        }
    }
}
