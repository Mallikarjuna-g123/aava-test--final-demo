﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class UpdateProjectname
    {
        public string acesstoken { get; set; }
        public string accountid { get; set; }
        public string platformid { get; set; }
        public string projectid { get; set; }
        public string serviceurl { get; set; }
      
    }
}
