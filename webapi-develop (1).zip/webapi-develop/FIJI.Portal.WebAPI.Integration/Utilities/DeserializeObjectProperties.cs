﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Reflection.Metadata.Ecma335;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class ClasDeserializeObjectPropertiess
    {
        public string Jsonobjectreturn(string Inputvalue, string outputvalue)

        { 
            string outputresponse = string.Empty;
            JObject obj = (JObject)JsonConvert.DeserializeObject(Inputvalue);
            //outputresponse= obj[outputvalue].ToString();
            JObject objdata = (JObject)JsonConvert.DeserializeObject(obj["data"].ToString());
            outputresponse = objdata[outputvalue].ToString();
            return outputresponse;
        }
    }
}
