﻿using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Reflection;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public static class Utils
    {
        private static readonly ILogger _logger = NullLogger.Instance;

        private static void TraceOperation(string operationName, Action action, params (string Key, object? Value)[] context)
        {
            OperationTraceHelper.TraceOperation(_logger, nameof(Utils), "utils", operationName, action, context);
        }

        private static T TraceOperation<T>(string operationName, Func<T> action, params (string Key, object? Value)[] context)
        {
            return OperationTraceHelper.TraceOperation(_logger, nameof(Utils), "utils", operationName, action, context);
        }

        [OutputCache]
        public static List<KeyValuePair<string, int>> TimeZoneList(IOrganizationService DataverseClient)
        {
            return TraceOperation(nameof(TimeZoneList), () =>
            {
                var query = new QueryExpression(EntityName.TimeZoneDefinition);
                query.ColumnSet = new ColumnSet(AttributeNames.TimeZoneDefinition.StandardName, AttributeNames.TimeZoneDefinition.TimeZoneCode);
                var response = DataverseClient.RetrieveMultiple(query);

                var result = response.Entities.Select(item => new KeyValuePair<string, int>(
                             item.GetAttributeValue<string>("standardname"), item.GetAttributeValue<int>("timezonecode")))
                             .Where(kvp => kvp.Key != null).ToList();

                return result;
            }, ("hasDataverseClient", DataverseClient != null));
        }

        public static string GetConvertedDateTime(int sourceId, int targetId, DateTime? dateTime, List<KeyValuePair<string, int>> timeZoneList)
        {
            return TraceOperation(nameof(GetConvertedDateTime), () =>
            {
                if (!dateTime.HasValue) return string.Empty;

                DateTime? originalDateTime = dateTime;
                originalDateTime = DateTime.SpecifyKind((DateTime)originalDateTime, DateTimeKind.Unspecified);
                var sourceTimeZoneId = timeZoneList.FirstOrDefault(kvp => kvp.Value == sourceId);
                var targetTimeZoneId = timeZoneList.FirstOrDefault(kvp => kvp.Value == targetId);
                if (!string.IsNullOrEmpty(sourceTimeZoneId.Key) && !string.IsNullOrEmpty(targetTimeZoneId.Key))
                {
                    TimeZoneInfo sourceTimeZone = TimeZoneInfo.FindSystemTimeZoneById(sourceTimeZoneId.Key);
                    DateTime utcDateTime = TimeZoneInfo.ConvertTimeToUtc((DateTime)originalDateTime, sourceTimeZone);
                    TimeZoneInfo targetTimeZone = TimeZoneInfo.FindSystemTimeZoneById(targetTimeZoneId.Key);
                    DateTime convertedDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, targetTimeZone);
                    return convertedDateTime.ToString();
                }
                return string.Empty;
            }, ("sourceId", sourceId), ("targetId", targetId), ("hasDateTime", dateTime.HasValue), ("timeZoneCount", timeZoneList?.Count));
        }

        public static string GetConvertedTimeUtcToTarget(int targetId, DateTime? dateTime, List<KeyValuePair<string, int>> timeZoneList)
        {
            return TraceOperation(nameof(GetConvertedTimeUtcToTarget), () =>
            {
                if (!dateTime.HasValue) return string.Empty;

                DateTime? originalDateTime = dateTime;
                originalDateTime = DateTime.SpecifyKind((DateTime)originalDateTime, DateTimeKind.Utc);
                var targetTimeZoneId = timeZoneList.FirstOrDefault(kvp => kvp.Value == targetId);
                if (!string.IsNullOrEmpty(targetTimeZoneId.Key))
                {
                    TimeZoneInfo targetTimeZone = TimeZoneInfo.FindSystemTimeZoneById(targetTimeZoneId.Key);
                    DateTime convertedDateTime = TimeZoneInfo.ConvertTimeFromUtc((DateTime)originalDateTime, targetTimeZone);
                    return convertedDateTime.ToString();
                }
                return string.Empty;
            }, ("targetId", targetId), ("hasDateTime", dateTime.HasValue), ("timeZoneCount", timeZoneList?.Count));
        }

        public static string GetConvertedTimeSourceToUTC(int sourceId, DateTime? dateTime, List<KeyValuePair<string, int>> timeZoneList)
        {
            return TraceOperation(nameof(GetConvertedTimeSourceToUTC), () =>
            {
                if (!dateTime.HasValue) return string.Empty;

                DateTime? originalDateTime = dateTime;
                originalDateTime = DateTime.SpecifyKind((DateTime)originalDateTime, DateTimeKind.Unspecified);
                var targetTimeZoneId = timeZoneList.FirstOrDefault(kvp => kvp.Value == sourceId);
                if (!string.IsNullOrEmpty(targetTimeZoneId.Key))
                {
                    TimeZoneInfo targetTimeZone = TimeZoneInfo.FindSystemTimeZoneById(targetTimeZoneId.Key);
                    DateTime convertedDateTime = TimeZoneInfo.ConvertTimeToUtc((DateTime)originalDateTime, targetTimeZone);
                    return convertedDateTime.ToString();
                }
                return string.Empty;
            }, ("sourceId", sourceId), ("hasDateTime", dateTime.HasValue), ("timeZoneCount", timeZoneList?.Count));
        }

        public static byte[]? JVWSecret { get; set; }
        public static bool EnableVirusCheck { get; set; }

        private static readonly string webAPIAppAuthorityUrl = "https://login.microsoftonline.com/hp.com";

        public static List<Entity> RetrieveAllRecords(IOrganizationService service, QueryExpression query)
        {
            return TraceOperation(nameof(RetrieveAllRecords), () =>
            {
                var pageNumber = 1;
                var pagingCookie = string.Empty;
                var result = new List<Entity>();
                EntityCollection resp;
                do
                {
                    if (pageNumber != 1)
                    {
                        query.PageInfo.PageNumber = pageNumber;
                        query.PageInfo.PagingCookie = pagingCookie;
                    }
                    resp = service.RetrieveMultiple(query);
                    if (resp.MoreRecords)
                    {
                        pageNumber++;
                        pagingCookie = resp.PagingCookie;
                    }
                    //Add the result from RetrieveMultiple to the List to be returned.
                    result.AddRange(resp.Entities);
                }
                while (resp.MoreRecords);

                return result;
            }, ("entityName", query?.EntityName));
        }

        public static string PluralEntityName(string entityName)
        {
            return TraceOperation(nameof(PluralEntityName), () =>
            {
                if (!string.IsNullOrWhiteSpace(entityName))
                {
                    if (entityName.ToLower().EndsWith("y"))
                    {
                        entityName = entityName.Substring(0, entityName.Length - 1);
                        return entityName + "ies";
                    }
                    if (entityName.ToLower().EndsWith("s"))
                    {
                        return entityName + "es";
                    }
                    else
                        return entityName + "s";
                }
                return entityName;
            }, ("entityName", entityName));
        }

        public static string GetIdFromUrl(string url)
        {
            return TraceOperation(nameof(GetIdFromUrl), () =>
            {
                int startIdx = url.Length - 37;
                return url.Substring(startIdx, 36);
            }, ("hasUrl", !string.IsNullOrWhiteSpace(url)), ("urlLength", url?.Length));
        }

        public static T? GetValue<T>(Entity obj, string attrName, bool formattedValue = false) where T : class
        {
            return TraceOperation(nameof(GetValue), () =>
            {
                if (obj != null && obj.Contains(attrName))
                {
                    if (formattedValue)
                        return (T)(object)obj.FormattedValues[attrName];

                    return (T)obj[attrName];
                }

                return default(T);
            }, ("attributeName", attrName), ("formattedValue", formattedValue), ("hasObject", obj != null));
        }

        public static Guid ConvertInGuid(this string guid)
        {
            return TraceOperation(nameof(ConvertInGuid), () =>
            {
                bool isGuidValid = Guid.TryParse(guid, out Guid result);
                if (isGuidValid)
                {
                    return new Guid(guid);
                }
                else
                {
                    throw new FormatException($"The provided string '{guid}' is not a valid GUID!");
                }
            }, ("hasGuid", !string.IsNullOrWhiteSpace(guid)));
        }

        // Check GUId is valid or not
        public static bool IsGuidValid(this string guid)
        {
            return TraceOperation(nameof(IsGuidValid), () =>
            {
                bool isGuidValid = Guid.TryParse(guid, out Guid result);
                if (isGuidValid)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }, ("hasGuid", !string.IsNullOrWhiteSpace(guid)));
        }

        // This check whether field in request payload is valid GUId or not
        public static bool ValidateGUIDINPayload(this string guid, string methodname)
        {
            return TraceOperation(nameof(ValidateGUIDINPayload), () =>
            {
                bool isGuidValid = Guid.TryParse(guid, out Guid result);
                if (isGuidValid)
                {
                    return true;
                }
                else
                {
                    throw new FormatException($"The provided " + methodname + " is not a valid GUID!");
                }
            }, ("methodName", methodname), ("hasGuid", !string.IsNullOrWhiteSpace(guid)));
        }

        /// <summary>
        /// Validate provided string is a GUID
        /// return Entity reference format
        /// </summary>
        /// <param name="fijiKey"></param>
        /// <param name="fijiGuid"></param>
        /// <returns></returns>
        /// <exception cref="FormatException"></exception>
        public static EntityReference GetEntityReference(string key, string guid)
        {
            return TraceOperation(nameof(GetEntityReference), () =>
            {
                try
                {
                    bool isGuidValid = Guid.TryParse(guid, out Guid result);
                    if (isGuidValid)
                    {
                        return new EntityReference(key, new Guid(guid));
                    }
                    else
                    {
                        throw new FormatException($"The provided string '{guid}' is not a valid GUID!");
                    }
                }
                catch (Exception getEntityReferenceException)
                {
                    throw new FormatException(getEntityReferenceException.Message);
                }
            }, ("entityName", key), ("hasGuid", !string.IsNullOrWhiteSpace(guid)));
        }

        public static DateTime? ConvertDateMinValue(DateTime? dateTime)
        {
            return TraceOperation(nameof(ConvertDateMinValue), () =>
            {
                if (dateTime == DateTime.MinValue)
                {
                    return null;
                }
                return dateTime;
            }, ("hasDateTime", dateTime.HasValue));
        }

        public static Dictionary<string, object> ConvertToDictionary(object obj)
        {
            return TraceOperation(nameof(ConvertToDictionary), () =>
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                foreach (PropertyInfo property in obj.GetType().GetProperties())
                {
                    dict[property.Name] = property.GetValue(obj);
                }
                return dict;
            }, ("typeName", obj?.GetType().Name));
        }

        // Method which get the Total count in query expression
        public static EntityCollection RetrieveCompleteRecords(QueryExpression query, IOrganizationService _service, int count = 5000)
        {
            return TraceOperation(nameof(RetrieveCompleteRecords), () =>
            {
                query.PageInfo = new PagingInfo
                {
                    Count = count,
                    PageNumber = 1,
                    ReturnTotalRecordCount = true
                };

                EntityCollection entityCollection = _service.RetrieveMultiple(query);
                EntityCollection ecFinal = new EntityCollection();
                ecFinal.Entities.AddRange(entityCollection.Entities);
                do
                {
                    query.PageInfo.PageNumber += 1;
                    query.PageInfo.PagingCookie = entityCollection.PagingCookie;
                    entityCollection = _service.RetrieveMultiple(query);
                    ecFinal.Entities.AddRange(entityCollection.Entities);
                }
                while (entityCollection.MoreRecords);
                return ecFinal;
            }, ("entityName", query?.EntityName), ("count", count));
        }

        /// <summary>
        /// Helper method to safely retrieve values from dictionary with case-insensitive key matching.
        /// Tries exact match first, then falls back to case-insensitive match.
        /// </summary>
        public static object GetDictionaryValue(Dictionary<string, dynamic> dict, string key)
        {
            if (dict == null || string.IsNullOrEmpty(key))
                return null;

            // Try exact match first
            if (dict.TryGetValue(key, out var value))
                return value;

            // Try case-insensitive match
            var caseInsensitiveKey = dict.Keys.FirstOrDefault(k => string.Equals(k, key, StringComparison.OrdinalIgnoreCase));
            if (caseInsensitiveKey != null && dict.TryGetValue(caseInsensitiveKey, out value))
                return value;

            return null;
        }

        /// <summary> 
        /// Creates a Web API transaction log entry for ADR integrations. 
        /// </summary> 

        public static void WebApiTransactionLog(IOrganizationService dataverseClient, string apiName, string request, string response, string logs)
        {
            try
            {
                Entity entity = new Entity("fiji_webapilog");
                entity["fiji_apirequest"] = request ?? string.Empty;
                entity["fiji_apiresponse"] = response ?? string.Empty;
                entity["fiji_logs"] = logs ?? string.Empty;
                entity["fiji_logs"] = $"API: {apiName}{Environment.NewLine}" + $"{entity["fiji_logs"]}";
                entity["fiji_apitypes"] = new OptionSetValue(622490003);
                dataverseClient.Create(entity);
            }
            catch (Exception ex)

            {
                _logger.LogError(ex, "Failed to create Web API transaction log for {ApiName}", apiName);
            }

        }
    }
}
