﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public static class EntityExtensions
    {
        public static void Remove(this Entity entity, string attributeName)
        {
            if (entity.Contains(attributeName))
                entity.Attributes.Remove(attributeName);
        }

        public static T? GetValue<T>(this Entity entity, string attrName, bool formattedValue = false) where T : class
        {
            if (entity != null && entity.Contains(attrName))
            {
                if (formattedValue)
                    return (T)(object)entity.FormattedValues[attrName];

                return (T)entity[attrName];
            }

            return default(T);
        }
    }
}
