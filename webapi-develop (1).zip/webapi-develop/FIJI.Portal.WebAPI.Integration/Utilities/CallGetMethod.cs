﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class CallGetMethod
    {
        public string GetCallwebapi(string url)
        {
            string responsetext = string.Empty;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.UserAgent.ParseAdd(Constants.UserAgentHeaderValue);
                var responsetask = client.GetAsync(url);
                responsetask.Wait();
                responsetext = responsetask.Result.Content.ReadAsStringAsync().Result;
                return responsetext;
            }
        }
    }
}
