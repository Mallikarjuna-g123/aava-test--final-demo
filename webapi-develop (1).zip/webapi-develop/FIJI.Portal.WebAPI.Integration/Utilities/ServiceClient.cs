﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    internal class ServiceClient1
    {
        private string? crmConnectionString;

        public ServiceClient1(string? crmConnectionString)
        {
            this.crmConnectionString = crmConnectionString;
        }
    }
}