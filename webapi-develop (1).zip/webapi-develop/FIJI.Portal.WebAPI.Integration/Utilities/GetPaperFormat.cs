﻿namespace FIJI.Portal.WebAPI.Integration.Utilities
{
    public class ResolvePaperFormat
    {
        private static readonly HashSet<string> _validFormats = new(StringComparer.OrdinalIgnoreCase)
        {
            "A0", "A1", "A2", "A3", "A4", "A5", "A6",
            "Letter", "Legal", "Tabloid", "Ledger"
        };

        public static string FromString(string? format)
        {
            if (format != null && _validFormats.Contains(format))
                return format;
            return "A4";
        }
    }
}
