﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;


namespace FIJI.Portal.WebAPI.Integration.Service
{
    public static class TokenService
    {
        public static object GenerateToken()
        {
            var tokenConfig = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                      new Claim("fiji", "0"),
                }),
                Expires = DateTime.UtcNow.AddMinutes(6),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Utils.JVWSecret), SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenConfig);
            var tokenString = tokenHandler.WriteToken(token);

            return new
            {
                token = tokenString
            };

        }

    }
}
