﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ServiceComplexity : Base<ServiceComplexity>
    {
        public ServiceComplexity(IOrganizationService dataverseClient) : base(dataverseClient, "servicecomplexity") { }
    }
}
