﻿using Azure.Core;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ADRReport : Base<ADRReport>
    {

        private readonly string _sourceContainerName = "deviceregistrationreport-ssh";
        private readonly string _destinationContainerName = "adrreports";

        public ADRReport(IOrganizationService dataverseClient, ILogger<ADRReport>? logger = null) : base(dataverseClient, "adrreport", logger)
        { }

        public enum eReportFrequency
        {
            Daily = 622490000,
            Monthly = 622490001
        }

        private string GetConnectionString()
        {
            return TraceOperation(nameof(GetConnectionString), () =>
            {
                string connectionString = Environment.GetEnvironmentVariable("AzureStorageForADRReport_ConnectionString");
                return connectionString;
            });
        }

        public Guid? GetAccountIdByAccountNumber(string accountNumber)
        {
            return TraceOperation(nameof(GetAccountIdByAccountNumber), () =>
            {
                QueryExpression query = new(EntityName.Account)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Account.AccountId, AttributeNames.Account.AccountNumber)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.Account.AccountNumber, ConditionOperator.Equal, accountNumber);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    return (Guid?)entity.GetAttributeValue<Guid>(AttributeNames.Account.AccountId);
                }

                return (Guid?)null;
            }, ("accountNumber", accountNumber));
        }

        public string? ExtractCustomerId(string blobName)
        {
            return TraceOperation(nameof(ExtractCustomerId), () =>
            {
                string[] parts = blobName.Split('_');
                return parts.Length > 1 ? parts[1] : null;
            }, ("blobName", blobName));
        }

        public void CreateNewADRReportRecord(string fileName, string fileURL, string CustomerId)
        {
            TraceOperation(nameof(CreateNewADRReportRecord), () =>
            {
                var frequency = GetReportFrequency(fileName);
                var accountId = GetAccountIdByAccountNumber(CustomerId);
                string actualFileName = fileName.Contains("/") ? fileName.Substring(fileName.LastIndexOf("/") + 1) : fileName;

                Entity adrReport = new(EntityName.ADRReport);
                adrReport[AttributeNames.ADRReport.Id] = Guid.NewGuid();
                adrReport[AttributeNames.ADRReport.FileName] = actualFileName;
                adrReport[AttributeNames.ADRReport.FileURL] = fileURL;
                adrReport[AttributeNames.ADRReport.CustomerId] = Utils.GetEntityReference(EntityName.Account, accountId.Value.ToString());

                if (frequency != null)
                {
                    adrReport[AttributeNames.ADRReport.ReportFrequency] = new OptionSetValue((int)frequency);
                }

                Execute(new CreateRequest { Target = adrReport });
            }, ("fileName", fileName), ("customerId", CustomerId));
        }

        private int? GetReportFrequency(string fileName)
        {
            return TraceOperation(nameof(GetReportFrequency), () =>
            {
                int? frequency = null;

                if (!string.IsNullOrEmpty(fileName))
                {
                    // Extract only the actual filename, ignoring customerId folder structure
                    string actualFileName = fileName.Contains("/") ? fileName.Substring(fileName.LastIndexOf("/") + 1) : fileName;

                    string[] parts = actualFileName.Split('_');  // Split by underscore
                    string frequencyName = parts[0];

                    if (frequencyName.StartsWith(Constants.Daily, StringComparison.OrdinalIgnoreCase))
                        frequency = (int)eReportFrequency.Daily;
                    else if (frequencyName.StartsWith(Constants.Monthly, StringComparison.OrdinalIgnoreCase))
                        frequency = (int)eReportFrequency.Monthly;
                }

                return frequency;
            }, ("fileName", fileName));
        }


        public async Task<string> MoveADRReport(BlobServiceClient blobServiceClient, string fileName, string customerId)
        {
            return await TraceOperationAsync(nameof(MoveADRReport), async () =>
            {
                BlobContainerClient destinationContainer = blobServiceClient.GetBlobContainerClient($"{_destinationContainerName}");
                if (!destinationContainer.Exists())
                {
                    // Ensure the destination container exists
                    await destinationContainer.CreateIfNotExistsAsync();
                }

                BlobClient sourceBlob = blobServiceClient.GetBlobContainerClient($"{_sourceContainerName}").GetBlobClient(fileName);
                BlobClient destinationBlob = destinationContainer.GetBlobClient($"{customerId}/{fileName}");

                if (await sourceBlob.ExistsAsync())
                {
                    // Copy the blob
                    await destinationBlob.StartCopyFromUriAsync(sourceBlob.Uri);

                    // Wait for copy to complete
                    BlobProperties properties;
                    do
                    {
                        await System.Threading.Tasks.Task.Delay(500);
                        properties = await destinationBlob.GetPropertiesAsync();
                    } while (properties.CopyStatus == CopyStatus.Pending);

                    if (properties.CopyStatus == CopyStatus.Success)
                    {
                        // Delete the original file
                        await sourceBlob.DeleteAsync();
                        Console.WriteLine($"File '{fileName}' moved to '{_destinationContainerName}/{customerId}'.");

                        // Generate file URL with SAS Token
                        string fileURL = destinationBlob.Uri.ToString();

                        // Create a new ADR Report record
                        ADRReport adrReportInstance = new ADRReport(this.DataverseClient, this.Logger);
                        adrReportInstance.CreateNewADRReportRecord(fileName, fileURL, customerId);

                        return fileURL;
                    }
                }
                return await Task.FromResult<string>(null);
            }, ("fileName", fileName), ("customerId", customerId));
        }

        private static string GenerateSasUri(BlobClient blobClient)
        {
            // Ensure the account has permissions to generate SAS
            BlobSasBuilder sasBuilder = new BlobSasBuilder()
            {
                BlobContainerName = blobClient.BlobContainerName,
                BlobName = blobClient.Name,
                Resource = "b", // 'b' means Blob
                StartsOn = DateTimeOffset.UtcNow,
                ExpiresOn = DateTimeOffset.UtcNow.AddDays(1) // Expiry time for the URL
            };

            // Provide read access
            sasBuilder.SetPermissions(BlobSasPermissions.Read);

            // Generate SAS token
            Uri sasUri = blobClient.GenerateSasUri(sasBuilder);
            return sasUri.ToString();
        }

        public async Task<List<string>> ProcessADRReportsAsync(string customerId, string fileURl, string fileName)
        {
            return await TraceOperationAsync(nameof(ProcessADRReportsAsync), async () =>
            {
                string storageAccountName = Environment.GetEnvironmentVariable("AzureADRReportStorageAccount");
                StorageAccountHelper storageHelper = new StorageAccountHelper(storageAccountName, null);

                BlobServiceClient blobServiceClient = storageHelper.GetBlobServiceClient(new Uri(fileURl));
                BlobContainerClient sourceContainer = blobServiceClient.GetBlobContainerClient(_sourceContainerName);

                List<string> movedFileUrls = new List<string>();

                string fileUrl = await MoveADRReport(blobServiceClient, fileName, customerId);

                if (!string.IsNullOrEmpty(fileUrl))
                {
                    movedFileUrls.Add(fileUrl);
                    Console.WriteLine($"File moved. Access URL: {fileUrl}");
                }
                return movedFileUrls;
            }, ("customerId", customerId), ("fileName", fileName));
        }

        public string? ExtractFolderName(string blobURL)
        {
            return TraceOperation(nameof(ExtractFolderName), () =>
            {
                Uri uri = new Uri(blobURL);
                string[] segments = uri.AbsolutePath.Trim('/').Split('/');

                return segments.Length > 0 ? segments[0] : null;
            }, ("blobUrl", blobURL));
        }

        internal string CreateCustomerFolder(string customerAccountNumber)
        {
            return TraceOperation(nameof(CreateCustomerFolder), () =>
            {
                string message = String.Empty;
                string storageAccountName = Environment.GetEnvironmentVariable("AzureADRReportStorageAccount");
                StorageAccountHelper storageHelper = new StorageAccountHelper(storageAccountName, null);
                BlobContainerClient adrContainerClient = storageHelper.InitializeADRContainer(_sourceContainerName);
                BlobClient folderBlobClient = adrContainerClient.GetBlobClient($"{customerAccountNumber}/");

                if (!folderBlobClient.Exists())
                {
                    BlobClient folderToCreate = adrContainerClient.GetBlobClient($"{customerAccountNumber}/_.txt");
                    folderToCreate.Upload(Stream.Null);
                    if (folderToCreate.Exists())
                    {
                        //remove dummy file
                        folderToCreate.Delete();
                    }
                    message = $"Folder '{customerAccountNumber}' created successfully.";
                }
                else
                {
                    message = $"Folder '{customerAccountNumber}' already exists.";
                }
                return message;
            }, ("customerAccountNumber", customerAccountNumber));
        }
    }
}

