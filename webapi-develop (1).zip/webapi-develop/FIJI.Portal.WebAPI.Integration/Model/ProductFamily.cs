﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ProductFamily : Base<ProductFamily>
    {
        public string? Name { get; set; }
        public Guid? Id { get; set; }
        public DeviceCategory DeviceCategory { get; set; }
        public List<PlatformRegionLocale> PlatformRegionLocale { get; set; }
        public ProductFamily() : base("productfamily") { }

        public ProductFamily(IOrganizationService dataverseClient, ILogger<ProductFamily>? logger = null) : base(dataverseClient, "productfamily") { }
        

        public Guid GetProductFamily(Guid modelId)
        {
            return TraceOperation(nameof(GetProductFamily), () =>
            {

                QueryExpression query = new QueryExpression(EntityName.ProductFamily);
                query.ColumnSet = new ColumnSet(AttributeNames.ProductFamily.ProductFamilyName);
                query.Criteria.AddCondition(AttributeNames.ProductFamily.ProductFamilyId, ConditionOperator.Equal, modelId);
                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.ProductFamily.ProductFamilyName))
                        return entity.GetAttributeValue<EntityReference>(AttributeNames.ProductFamily.ProductFamilyName).Id;
                }
                return Guid.Empty;
            }, ("modelId", modelId));
        }

        public Guid GetKmatProductFamily(Guid productFamilyId)
        {
            return TraceOperation(nameof(GetKmatProductFamily), () =>
            {

                QueryExpression query = new QueryExpression(EntityName.KMATProductFamily);
                query.ColumnSet = new ColumnSet(AttributeNames.KMATProductFamily.ProductLine);
                query.Criteria.AddCondition(AttributeNames.KMATProductFamily.KMATProductFamilyId, ConditionOperator.Equal, productFamilyId);
                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.KMATProductFamily.ProductLine))
                        return entity.GetAttributeValue<EntityReference>(AttributeNames.KMATProductFamily.ProductLine).Id;
                }
                return Guid.Empty;
            }, ("productFamilyId", productFamilyId));
        }
    }
}
