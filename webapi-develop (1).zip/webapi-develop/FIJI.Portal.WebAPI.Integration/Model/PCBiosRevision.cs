﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class PCBiosRevision : Base<PCBiosRevision>
    {

        public PCBiosRevision(IOrganizationService dataverseClient, ILogger<PCBiosRevision>? logger = null) : base(dataverseClient, "pcbiosrevision")
        { }

        public void CreatePCBiosRevisionOnNewProductComponent(Requests.ProductComponentRequest productComponentRequest, Guid? productcomponentID)
        {
            TraceOperation(nameof(CreatePCBiosRevisionOnNewProductComponent), () =>
            {
                if (!string.IsNullOrEmpty(productComponentRequest.BiosRevision))
                {
                    Entity fiji_pc_bios_revision = new Entity(EntityName.PCBiosRevision);
                    fiji_pc_bios_revision.Id = Guid.NewGuid();
                    fiji_pc_bios_revision[AttributeNames.PCBiosRevision.Name] = productComponentRequest.BiosRevision;
                    if (productcomponentID != null)
                        fiji_pc_bios_revision[AttributeNames.PCBiosRevision.ProductComponentId] = Utils.GetEntityReference(EntityName.ProductComponent, productcomponentID.Value.ToString());

                    if (productComponentRequest.ModelId != null)
                        fiji_pc_bios_revision[AttributeNames.PCBiosRevision.ProductFamilyId] = Utils.GetEntityReference(EntityName.ProductFamily, productComponentRequest.ModelId);

                    this.Execute(new CreateRequest { Target = fiji_pc_bios_revision });
                }
            }, ("productComponentId", productcomponentID), ("hasBiosRevision", !string.IsNullOrEmpty(productComponentRequest?.BiosRevision)));

        }
    }
}