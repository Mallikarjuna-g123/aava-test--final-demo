﻿using Newtonsoft.Json;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class OCIPortalError
    {
        [JsonProperty("isConflict")]
        public bool IsConflict { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; } = string.Empty;

        [JsonProperty("subtitle")]
        public string Subtitle { get; set; } = string.Empty;

        [JsonProperty("conflicts")]
        public List<OCIConflictItem> Conflicts { get; set; } = new List<OCIConflictItem>();
    }
}