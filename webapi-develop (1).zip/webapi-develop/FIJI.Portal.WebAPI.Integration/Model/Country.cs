﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Country : Base<Country>
    {
        public Country(IOrganizationService dataverseClient, ILogger<Country>? logger = null) : base(dataverseClient, "country", logger)
        { }

        /// <summary>
        /// Get Region Id
        /// </summary>
        /// <param name="ownerId"></param>
        /// <returns></returns>
        public Guid? GetRegionIdBy(string managerType, string managerId)
        {
            return TraceOperation<Guid?>(nameof(GetRegionIdBy), () =>
            {
                // Create a QueryExpression for the "fiji_country" entity
                QueryExpression query = new QueryExpression(EntityName.Country);
                query.ColumnSet = new ColumnSet(AttributeNames.Country.CountryId);

                // Add filtering condition for systemuser ID
                query.Criteria.AddCondition(managerType, ConditionOperator.Equal, managerId);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.Country.CountryId))
                        return (Guid?)entity.Id;
                }
                return (Guid?)null;
            }, ("managerType", managerType), ("managerId", managerId));

        }
    }
}
