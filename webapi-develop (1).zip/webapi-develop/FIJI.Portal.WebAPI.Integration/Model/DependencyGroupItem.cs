﻿namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class DependencyGroupItem
    {
        public string? itemCondition { get; set; }
        public List<string>? dependentCIds { get; set;}
    }
}
