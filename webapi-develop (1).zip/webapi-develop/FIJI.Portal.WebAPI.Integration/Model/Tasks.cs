using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Data;
using System.Net;
using System.ServiceModel;
using System.Text;
using static FIJI.Portal.WebAPI.Integration.Model.BOM;
using Hyperlink = DocumentFormat.OpenXml.Spreadsheet.Hyperlink;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Tasks : Base<Tasks>
    {
        private readonly FijiConfiguration? _fijiConfig;
        private readonly ILogger<Tasks> _logger = NullLogger<Tasks>.Instance;
        public List<Hyperlink>? hyperlinkList;
        public WorksheetPart? worksheetPart;
        public Uri? portalBaseUri;
        public Uri? pstTicketUri;
        public int totalRecordCount = 0;
        public const int ProjectIdSearchLevel = -1;

        public enum eTrigger
        {
            Header,
            Row
        }

        public enum sortingOrder
        {
            Descending = 0,
            Ascending = 1
        }

        private Dictionary<string, string> scheduleTypeMappings = new Dictionary<string, string>
          {
              { "1", "Working" },
              { "0", "Non Working" },
              { "6", "Time Off" },
        };

        public enum TaskTypeAlias
        {
            FAI,
            CPOC,
            RPOC,
            PPOC
        }

        public enum TaskStatus
        {
            Open = 0,
            Completed = 1,
            Canceled = 2
        }

        public enum ServiceType
        {
            CSAV = 102420000,
            GenericService = 102420001,
            TechnicalAV = 622490001,
            PreDefinedAV = 622490002
        }

        public enum Statuscode
        {
            Completed = 5
        }

        public enum Fiji_validationtype
        {
            Virtual = 622490000,
            POC = 622490001
        }

        public enum SearchLevel
        {
            Task,
            POCType,
            Project,
            User
        }

        public static List<string> SplitProjectIdInput(string? search)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return new List<string>();
            }
            return search.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
        }

        public static List<string> ParseProjectIdSearch(string? search)
        {
            return SplitProjectIdInput(search).Distinct().ToList();
        }

        public static readonly Dictionary<string, string> ColumnHeaders = new Dictionary<string, string>
        {
            {"Regardingobjectidname", "Project ID"},
            {"Fiji_productfamily", "Platform"},
            {"Fiji_productexternalid", "External ID"},
            {"ServiceList", "Service List"},
            {"Link", "Link to Complete BOM"},
            {"Fiji_customername", "Customer"},
            {"Fiji_projectoriginatingregionid", "Lead Region"},
            {"Fiji_taskassigneddate", "Factory Start"},
            {"Fiji_taskduedateadjusted", "Factory Due"},
            {"Actualend", "Factory Release"},
            {"Fiji_tasktatdays", "Task TAT"},
            {"FactoryTat", "Factory TAT"},
            {"Statuscode", "Task Status"},
            {"Fiji_taskoudays", "O/U"},
            {"Fiji_hpdelaydays", "HP Delay"},
            {"DelayReason", "Delay Reason"},
            {"DelaySubreason", "Delay Sub Reason"},
            {"Fiji_poctype", "POC Type" },
            {"Fiji_kvmkeyboard", "KVM Keyboard" },
            {"Fiji_pstticketnumber", "PST Ticket"},
            {"Description", "Comments"},
            {"Ownerid", "FSPM"},
        };

        public static readonly Dictionary<string, string> TaskType = new Dictionary<string, string>
        {
            { "11.20 Factory FAI", "FAI" },
            { "11.30 Factory Customer Physical POC", "CPOC" },
            { "11.50 Factory Customer Remote POC", "RPOC" },
            { "11.60 Factory Customer Picture POC", "PPOC" },
        };

        public Tasks(): base("tasks")
        { }

        public Tasks(IOrganizationService dataverseClient, ILogger<Tasks>? logger = null) : base(dataverseClient, "tasks", logger)
        {
            _fijiConfig = new FijiConfiguration(dataverseClient);
            _logger = logger ?? NullLogger<Tasks>.Instance;
        }

        public QueryExpression TaskConditionalQuery(TaskRequest request, int taskType, int searchLevel = 0, int pageNumber = 0, string pagingCookie = null, int fetchCount = 0)
        {
            QueryExpression query = new QueryExpression(EntityName.Task);
            query.Distinct = true;
            query.Criteria.AddCondition(AttributeNames.Task.StateCode, ConditionOperator.Equal, request.StateCode);
            if (!String.IsNullOrEmpty(request?.Filters?.Factory))
            {
                query.Criteria.AddCondition(AttributeNames.Task.Factory, ConditionOperator.Equal, request.Filters.Factory);
            }
            if (!String.IsNullOrEmpty(request?.Filters?.Statuscode))
            {
                query.Criteria.AddCondition(AttributeNames.Task.StatusCode, ConditionOperator.Equal, request.Filters.Statuscode);
            }
            if (request?.Filters?.StartDateRange != null && request?.Filters?.EndDateRange != null)
            {
                query.Criteria.AddCondition(AttributeNames.Task.TaskAssignedDate, ConditionOperator.GreaterEqual, request.Filters.StartDateRange);
                query.Criteria.AddCondition(AttributeNames.Task.TaskAssignedDate, ConditionOperator.LessEqual, request.Filters.EndDateRange);
            }

            #region search

            if (!string.IsNullOrWhiteSpace(request?.Filters?.Search) && searchLevel == (int)SearchLevel.Task)
            {
                var query_Or = new FilterExpression(LogicalOperator.Or);
                query.Criteria.AddFilter(query_Or);
                query_Or.AddCondition(AttributeNames.Task.CustomerName, ConditionOperator.Like, $"%{request.Filters.Search}%");
                if (request.Filters.Search.Length < 7)
                    query_Or.AddCondition(AttributeNames.Task.PSTTicketNumber, ConditionOperator.Like, $"%{request.Filters.Search}%");
            }

            #endregion search

            var tt = query.AddLink(EntityName.TaskType, AttributeNames.Task.TaskType, AttributeNames.TaskType.TaskTypeId);
            tt.EntityAlias = "tt";
            tt.LinkCriteria.AddCondition(AttributeNames.TaskType.ValidationType, ConditionOperator.Equal, taskType);

            #region search

            if (!string.IsNullOrEmpty(request?.Filters?.Search) && searchLevel == (int)SearchLevel.POCType)
            {
                var tt_Or = new FilterExpression(LogicalOperator.Or);
                tt.LinkCriteria = tt_Or;
                tt_Or.AddCondition(AttributeNames.TaskType.POCTypeName, ConditionOperator.Like, $"%{request.Filters.Search}%");
            }

            #endregion search

            var bk = query.AddLink(EntityName.Team, AttributeNames.Task.OwningTeam, AttributeNames.Team.TeamId);
            bk.EntityAlias = "bk";

            var bk_fiji_team_contact = bk.AddLink(EntityName.FijiTeamContact, AttributeNames.Team.TeamId, AttributeNames.FijiTeamContact.TeamId);

            var bl = bk_fiji_team_contact.AddLink(EntityName.Contact, AttributeNames.FijiTeamContact.ContactId, AttributeNames.Contact.ContactId);
            bl.EntityAlias = "bl";

            bl.LinkCriteria.AddCondition(AttributeNames.Contact.ContactId, ConditionOperator.Equal, request.Contact);
            bool isProjectIdSearch = searchLevel == ProjectIdSearchLevel;
            JoinOperator pr_JoinOperator = (searchLevel > 1 || isProjectIdSearch) ? JoinOperator.Inner : JoinOperator.LeftOuter;
            var pr = query.AddLink(EntityName.Project, AttributeNames.Task.RegardingObjectId, AttributeNames.Project.ProjectId, pr_JoinOperator);
            pr.EntityAlias = "pr";

            #region search

            if (!string.IsNullOrEmpty(request?.Filters?.Search) && searchLevel == (int)SearchLevel.Project)
            {
                var pr_Or = new FilterExpression(LogicalOperator.Or);
                pr.LinkCriteria = pr_Or;
                pr_Or.AddCondition(AttributeNames.Project.Name, ConditionOperator.Like, $"%{request.Filters.Search}%");
                pr_Or.AddCondition(AttributeNames.Project.ProductExternalId, ConditionOperator.Like, $"%{request.Filters.Search}%");
            }

            if (isProjectIdSearch)
            {
                var projectIds = ParseProjectIdSearch(request?.Filters?.Search);
                var condition = new ConditionExpression(AttributeNames.Project.Name, ConditionOperator.In);
                foreach (var projectId in projectIds)
                {
                    condition.Values.Add(projectId);
                }
                pr.LinkCriteria.AddCondition(condition);
            }

            #endregion search

            JoinOperator ad_JoinOperator = searchLevel == (int)SearchLevel.User ? JoinOperator.Inner : JoinOperator.LeftOuter;
            var ad = pr.AddLink(EntityName.SystemUser, AttributeNames.Project.OwningUser, AttributeNames.SystemUser.SystemUserId, ad_JoinOperator);
            ad.EntityAlias = "ad";

            #region search

            if (!string.IsNullOrEmpty(request?.Filters?.Search) && searchLevel == (int)SearchLevel.User)
            {
                var ad_Or = new FilterExpression(LogicalOperator.Or);
                ad.LinkCriteria.AddFilter(ad_Or);
                ad_Or.AddCondition(AttributeNames.SystemUser.FullName, ConditionOperator.Like, $"%{request.Filters.Search}%");
                ad_Or.AddCondition(AttributeNames.SystemUser.InternalEmailAddress, ConditionOperator.Like, $"%{request.Filters.Search}%");
            }

            #endregion search

            if (fetchCount != 0)
            {
                query.PageInfo = new PagingInfo
                {
                    Count = fetchCount,
                    PageNumber = pageNumber,
                    PagingCookie = pagingCookie
                };
                query.ColumnSet = new ColumnSet(false)
                {
                    AttributeExpressions = {
                        {
                            new XrmAttributeExpression(
                               attributeName: AttributeNames.Task.ActivityId,
                               alias: "Count",
                               aggregateType: XrmAggregateType.Count)
                        },
                    {
                            new XrmAttributeExpression(
                               attributeName: AttributeNames.Task.ActivityId,
                               alias: "TaskId",
                               aggregateType: XrmAggregateType.None){
                                HasGroupBy = true
                            }
                                }
                    }
                };
                query.Orders.Add(new OrderExpression(AttributeNames.Task.ActivityId, OrderType.Ascending, "TaskId"));
            }
            else
            {
                if (request?.Page?.PageSize != null && request?.Page?.PageNumber != null)
                    query.PageInfo = new PagingInfo
                    {
                        Count = (int)request.Page.PageSize,
                        PageNumber = (int)request.Page.PageNumber,
                        PagingCookie = pagingCookie
                    };
                query.ColumnSet.AddColumns(
                    AttributeNames.Task.StateCode,
                    AttributeNames.Task.RegardingObjectId,
                    AttributeNames.Task.ActivityId,
                    AttributeNames.Task.CustomerId,
                    AttributeNames.Task.Description,
                    AttributeNames.Task.TaskAssignedDate,
                    AttributeNames.Task.TaskDueDateAdjusted,
                    AttributeNames.Task.StatusCode,
                    AttributeNames.Task.TaskId,
                    AttributeNames.Task.PSTTicketNumber,
                    AttributeNames.Task.PSTTicketUrl,
                    AttributeNames.Task.TaskOUDays,
                    AttributeNames.Task.KVMKeyboard,
                    AttributeNames.Task.CreatedOn,
                    AttributeNames.Task.ActualEnd,
                    AttributeNames.Task.Factory,
                    AttributeNames.Task.HPDelayDays,
                    AttributeNames.Task.TaskTatDays,
                    AttributeNames.Task.ModifiedOn,
                    AttributeNames.Task.FactoryTatDays);
                tt.Columns.AddColumns(AttributeNames.TaskType.POCType);
                pr.Columns.AddColumns(
                AttributeNames.Project.IsNeworECN,
                AttributeNames.Project.ComponentType,
                AttributeNames.Project.ProductExternalId,
                AttributeNames.Project.ProjectOriginatingRegionId,
                AttributeNames.Project.OwnerId,
                AttributeNames.Project.ProductType,
                AttributeNames.Project.ProductFamilyName,
                AttributeNames.Project.ProjectType,
                AttributeNames.Project.ProjectStage
                );
                ad.Columns.AddColumn(AttributeNames.SystemUser.InternalEmailAddress);
                var fac = query.AddLink(EntityName.FijiFactory, AttributeNames.Task.Factory, AttributeNames.FijiFactory.FactoryId, JoinOperator.LeftOuter);
                fac.EntityAlias = "fac";
                fac.Columns.AddColumns(AttributeNames.FijiFactory.IsResilientFactory);

                #region sort

                if (!String.IsNullOrEmpty(request?.Sort?.ColumnName))
                {
                    var order = request?.Sort?.SortOrder == (int)OrderType.Ascending ? OrderType.Ascending : OrderType.Descending;
                    switch (request.Sort.ColumnName)
                    {
                        case AttributeNames.Task.RegardingObjectIdName:
                        case AttributeNames.Task.CustomerName:
                        case AttributeNames.Task.TaskAssignedDate:
                        case AttributeNames.Task.TaskDueDateAdjusted:
                        case AttributeNames.Task.ActualEnd:
                        case AttributeNames.Task.TaskTatDays:
                        case AttributeNames.Task.StatusCode:
                        case AttributeNames.Task.TaskOUDays:
                        case AttributeNames.Task.PSTTicketNumber:
                        case AttributeNames.Task.Description:
                        case AttributeNames.Task.HPDelayDays:
                        case AttributeNames.Task.KVMKeyboard:
                            query.AddOrder(request.Sort.ColumnName, order);
                            break;

                        case AttributeNames.Project.ProductFamilyName:
                        case AttributeNames.Project.ProductExternalId:
                        case AttributeNames.Project.ProjectOriginatingRegionId:
                        case AttributeNames.Project.OwnerId:
                            pr.Orders.Add(new OrderExpression(request.Sort.ColumnName, order));
                            break;

                        case AttributeNames.TaskType.POCType:
                            tt.Orders.Add(new OrderExpression(request.Sort.ColumnName, order)); break;

                        default:
                            break;
                    }
                }
                else
                {
                    if (request.StateCode == (int)TaskStatus.Open)
                    {
                        query.AddOrder(AttributeNames.Task.CreatedOn, OrderType.Ascending);
                    }
                    else if (request.StateCode == (int)TaskStatus.Completed)
                    {
                        query.AddOrder(AttributeNames.Task.ActualEnd, OrderType.Descending);
                    }
                    else if (request.StateCode == (int)TaskStatus.Canceled)
                    {
                        query.AddOrder(AttributeNames.Task.ModifiedOn, OrderType.Descending);
                    }
                }

                #endregion sort
            }

            return query;
        }

        public async Task<EntityCollection> GetDelayDetails(Guid[] taskIdList)
        {
            return await TraceOperationAsync(nameof(GetDelayDetails), async () =>
            {
                var query = new QueryExpression(EntityName.Delay);
                query.AddOrder(AttributeNames.Delay.ModifiedOn, OrderType.Descending);

                var al = query.AddLink(EntityName.Task, AttributeNames.Delay.TaskId, AttributeNames.Task.ActivityId);
                al.EntityAlias = "al";

                al.Columns.AddColumn(AttributeNames.Task.ActivityId);

                ConditionExpression condition = new ConditionExpression(AttributeNames.Task.ActivityId, ConditionOperator.In);
                foreach (Guid taskId in taskIdList)
                    condition.Values.Add(taskId);

                al.LinkCriteria.AddCondition(condition);

                var dr = query.AddLink(EntityName.DelayReasons, AttributeNames.Delay.DelayReasonsId, AttributeNames.DelayReasons.DelayReasonsId);
                dr.EntityAlias = "dr";

                dr.Columns.AddColumn(AttributeNames.DelayReasons.Name);

                var dsr = query.AddLink(EntityName.DelaySubReasons, AttributeNames.DelayReasons.DelaySubReasonsId, AttributeNames.DelaySubReasons.DelaySubReasonsId);
                dsr.EntityAlias = "dsr";

                dsr.Columns.AddColumn(AttributeNames.DelaySubReasons.Name);
                return DataverseClient.RetrieveMultiple(query);
            }, ("taskIdCount", taskIdList?.Length));
        }

        public async Task<EntityCollection> GetServices(Guid[] taskIdList)
        {
            return await TraceOperationAsync(nameof(GetServices), async () =>
             {
                 var query = new QueryExpression(EntityName.Task);
                 query.Distinct = true;
                 query.ColumnSet.AddColumn(AttributeNames.Task.ActivityId);

                 ConditionExpression condition = new ConditionExpression(AttributeNames.Task.ActivityId, ConditionOperator.In);
                 foreach (Guid taskId in taskIdList)
                     condition.Values.Add(taskId);

                 query.Criteria.AddCondition(condition);

                 var project = query.AddLink(EntityName.Project, AttributeNames.Task.RegardingObjectId, AttributeNames.Project.ProjectId);
                 project.EntityAlias = "project";

                 project.Columns.AddColumn(AttributeNames.Project.ProjectId);

                 var bom = project.AddLink(EntityName.BOM, AttributeNames.Project.ProjectId, AttributeNames.BOM.Project);
                 bom.EntityAlias = "bom";
                 bom.LinkCriteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project);
                 bom.LinkCriteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);
                 bom.LinkCriteria.AddCondition(AttributeNames.BOM.ProductActionCode, ConditionOperator.NotEqual, (int)eProductActionCode.Remove);

                 var pc = bom.AddLink(EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId);
                 pc.EntityAlias = "pc";

                 pc.Columns.AddColumns(AttributeNames.ProductComponent.ExternalId, AttributeNames.ProductComponent.ServiceTypeGlobal);

                 ConditionExpression serviceTypeCondition = new ConditionExpression(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.In);
                 serviceTypeCondition.Values.Add((int)ServiceType.CSAV);
                 serviceTypeCondition.Values.Add((int)ServiceType.TechnicalAV);
                 serviceTypeCondition.Values.Add((int)ServiceType.PreDefinedAV);
                 serviceTypeCondition.Values.Add((int)ServiceType.GenericService);
                 pc.LinkCriteria.AddCondition(serviceTypeCondition);

                 var ct = pc.AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.LeftOuter);
                 ct.EntityAlias = "ct";

                 ct.Columns.AddColumn(AttributeNames.ComponentType.ServiceNumber);
                 return DataverseClient.RetrieveMultiple(query);
             }, ("taskIdCount", taskIdList?.Length));
        }

        public QueryExpression TaskQueryById(TaskRequest request)
        {
            QueryExpression query = new QueryExpression(EntityName.Task);
            query.Distinct = true;
            query.Criteria.AddCondition(AttributeNames.Task.ActivityId, ConditionOperator.In, request.TaskIds.ToArray());

            var tt = query.AddLink(EntityName.TaskType, AttributeNames.Task.TaskType, AttributeNames.TaskType.TaskTypeId);
            tt.EntityAlias = "tt";
            var pr = query.AddLink(EntityName.Project, AttributeNames.Task.RegardingObjectId, AttributeNames.Project.ProjectId, JoinOperator.LeftOuter);
            pr.EntityAlias = "pr";
            var ad = pr.AddLink(EntityName.SystemUser, AttributeNames.Project.OwningUser, AttributeNames.SystemUser.SystemUserId, JoinOperator.LeftOuter);
            ad.EntityAlias = "ad";

            query.ColumnSet.AddColumns(
                AttributeNames.Task.StateCode,
                AttributeNames.Task.RegardingObjectId,
                AttributeNames.Task.ActivityId,
                AttributeNames.Task.CustomerId,
                AttributeNames.Task.Description,
                AttributeNames.Task.TaskAssignedDate,
                AttributeNames.Task.TaskDueDateAdjusted,
                AttributeNames.Task.StatusCode,
                AttributeNames.Task.TaskId,
                AttributeNames.Task.PSTTicketNumber,
                AttributeNames.Task.PSTTicketUrl,
                AttributeNames.Task.TaskOUDays,
                AttributeNames.Task.KVMKeyboard,
                AttributeNames.Task.CreatedOn,
                AttributeNames.Task.ActualEnd,
                AttributeNames.Task.Factory,
                AttributeNames.Task.HPDelayDays,
                AttributeNames.Task.TaskTatDays,
                AttributeNames.Task.ModifiedOn
                );
            tt.Columns.AddColumns(AttributeNames.TaskType.POCType);
            pr.Columns.AddColumns(
            AttributeNames.Project.IsNeworECN,
            AttributeNames.Project.ComponentType,
            AttributeNames.Project.ProductExternalId,
            AttributeNames.Project.ProjectOriginatingRegionId,
            AttributeNames.Project.OwnerId,
            AttributeNames.Project.ProductType,
            AttributeNames.Project.ProductFamilyName,
            AttributeNames.Project.ProjectType,
            AttributeNames.Project.ProjectStage
            );
            ad.Columns.AddColumn(AttributeNames.SystemUser.InternalEmailAddress);

            if (request.StateCode == (int)TaskStatus.Open)
            {
                query.AddOrder(AttributeNames.Task.CreatedOn, OrderType.Ascending);
            }
            else if (request.StateCode == (int)TaskStatus.Completed)
            {
                query.AddOrder(AttributeNames.Task.ActualEnd, OrderType.Descending);
            }
            return query;
        }

        public string GetTaskTypeAlias(string? taskType)
        {
            return TraceOperation(nameof(GetTaskTypeAlias), () =>
                taskType != null && TaskType.TryGetValue(taskType, out var alias) ? alias : "",
                ("taskType", taskType));
        }

        //Retrieve tasks based on filters
        public async Task<EntityCollection> GetTasksListPerPage(TaskRequest request, int taskTypes, int searchLevel = 0)
        {
            return await TraceOperationAsync(nameof(GetTasksListPerPage), async () =>
            {
                var query = TaskConditionalQuery(request, taskTypes, searchLevel);
                return DataverseClient.RetrieveMultiple(query);
            }, ("taskTypes", taskTypes), ("searchLevel", searchLevel), ("stateCode", request?.StateCode));
        }

        //Get tasks by Ids
        public async Task<EntityCollection> GetTasksListbyTaskId(TaskRequest request)
        {
            return await TraceOperationAsync(nameof(GetTasksListbyTaskId), async () =>
            {
                var query = TaskQueryById(request);
                return DataverseClient.RetrieveMultiple(query);
            }, ("taskIdCount", request?.TaskIds?.Count));
        }

        public async Task<List<TasksResponse>> OrderTasksList(EntityCollection taskList, string taskType, int timeZoneId)
        {
            return await TraceOperationAsync(nameof(OrderTasksList), async () =>
            {
                try
                {
                    List<TasksResponse> tasksResponse = new List<TasksResponse>();

                    if (taskList?.Entities.Count > 0)
                    {
                        Guid[] taskIdList = taskList?.Entities?.Select(task => task.Id)?.Distinct().ToArray();
                        //threads to get service list and delay list
                        var delayCollectionTask = GetDelayDetails(taskIdList);
                        var serviceCollectionTask = GetServices(taskIdList);
                        await Task.WhenAll(delayCollectionTask, serviceCollectionTask);

                        var delayCollection = delayCollectionTask.Result;
                        var serviceCollection = serviceCollectionTask.Result;
                        List<KeyValuePair<string, int>> timeZoneList = Utils.TimeZoneList(DataverseClient);
                        foreach (Entity item in taskList.Entities)
                        {
                            var newTask = new TasksResponse();
                            newTask.Id = item.Id;
                            newTask.Regardingobjectid = item.GetAttributeValue<EntityReference>("regardingobjectid")?.Id;
                            newTask.Regardingobjectidname = item.GetAttributeValue<EntityReference>("regardingobjectid")?.Name ?? null;
                            newTask.Fiji_productfamily = Utils.GetValue<string>(item, "pr.fiji_productfamily", true);
                            newTask.Fiji_productexternalid = Utils.GetValue<AliasedValue>(item, "pr.fiji_productexternalid")?.Value.ToString();
                            newTask.Fiji_customername = Utils.GetValue<string>(item, "fiji_customer", true);
                            newTask.Fiji_projectoriginatingregionid = Utils.GetValue<string>(item, "pr.fiji_projectoriginatingregionid", true);

                            string taskAssignedDate = Utils.GetConvertedTimeUtcToTarget(timeZoneId, Utils.ConvertDateMinValue(item.GetAttributeValue<DateTime>("fiji_taskassigneddate")), timeZoneList);
                            if (!string.IsNullOrEmpty(taskAssignedDate))
                                newTask.Fiji_taskassigneddate = DateTime.Parse(taskAssignedDate).ToString("MMM dd yyyy hh:mm:ss tt");

                            string taskDueDateAdjusted = Utils.GetConvertedTimeUtcToTarget(timeZoneId, Utils.ConvertDateMinValue(item.GetAttributeValue<DateTime>("fiji_taskduedateadjusted")), timeZoneList);
                            if (!string.IsNullOrEmpty(taskDueDateAdjusted))
                                newTask.Fiji_taskduedateadjusted = DateTime.Parse(taskDueDateAdjusted).ToString("MMM dd yyyy hh:mm:ss tt");

                            string actualEnd = Utils.GetConvertedTimeUtcToTarget(timeZoneId, Utils.ConvertDateMinValue(item.GetAttributeValue<DateTime>("actualend")), timeZoneList);
                            if (!string.IsNullOrEmpty(actualEnd))
                                newTask.Actualend = DateTime.Parse(actualEnd).ToString("MMM dd yyyy hh:mm:ss tt");

                            newTask.Fiji_tasktatdays = item.GetAttributeValue<int>("fiji_tasktatdays");
                            newTask.Statuscode = Utils.GetValue<string>(item, "statuscode", true);
                            newTask.Fiji_taskoudays = item.GetAttributeValue<int>("fiji_taskoudays");
                            newTask.Fiji_pstticketnumber = item.GetAttributeValue<string>("fiji_pstticketnumber");
                            newTask.Fiji_pstticketurl = Utils.GetValue<string>(item, "fiji_pstticketurl");
                            newTask.Description = Utils.GetValue<string>(item, "description");
                            newTask.Ownerid = Utils.GetValue<string>(item, "pr.ownerid", true);
                            newTask.Internalemailaddress = Utils.GetValue<AliasedValue>(item, "ad.internalemailaddress")?.Value.ToString();
                            newTask.Fiji_hpdelaydays = item.GetAttributeValue<int?>("fiji_hpdelaydays");
                            newTask.FactoryTat = item.GetAttributeValue<int?>("fiji_factorytatdays");
                            bool isResilientFactory = item.GetAttributeValue<AliasedValue>("fac.fiji_isresilientfactory")?.Value is bool b && b;
                            string factoryName = Utils.GetValue<string>(item, "fiji_factory", true);
                            newTask.FactoryName = isResilientFactory && !string.IsNullOrEmpty(factoryName) ? $"{factoryName} (Resilient)" : factoryName;
                            if (taskType == Constants.PocTaskKey)
                            {
                                newTask.Fiji_poctype = Utils.GetValue<string>(item, "tt.fiji_poctype", true);
                                newTask.Fiji_kvmkeyboard = Utils.GetValue<string>(item, "fiji_kvmkeyboard");
                            }

                            if (delayCollection?.Entities.Count > 0)
                            {
                                var delayEntity = delayCollection.Entities.FirstOrDefault(x => (Guid)x.GetAttributeValue<AliasedValue>("al.activityid").Value == item.Id);
                                if (delayEntity != null)
                                {
                                    newTask.DelayReason = delayEntity.GetAttributeValue<AliasedValue>("dr.fiji_name")?.Value.ToString();
                                    newTask.DelaySubreason = delayEntity.GetAttributeValue<AliasedValue>("dsr.fiji_name")?.Value.ToString();
                                }
                            }
                            var serviceList = serviceCollection?.Entities.Where(x => x.Id == item.Id).Select(
                                x =>
                                {
                                    var pcExternalId = x.GetAttributeValue<AliasedValue>("pc.fiji_externalid")?.Value?.ToString();
                                    var ctServiceNumber = x.GetAttributeValue<AliasedValue>("ct.fiji_servicenumber")?.Value?.ToString();
                                    var serviceTypeGlobal = (x.GetAttributeValue<AliasedValue>("pc.fiji_servicetypeglobal")?.Value as OptionSetValue)?.Value;

                                    return new
                                    {
                                        ServiceNumber = ctServiceNumber,
                                        ExternalId = pcExternalId,
                                        ServiceTypeGlobal = serviceTypeGlobal
                                    };
                                })
                                .Where(x => !string.IsNullOrEmpty(x.ServiceNumber))
                                .OrderBy(x => x.ServiceNumber)
                                .ThenBy(x => x.ExternalId)
                                .Select(x =>
                                {
                                    if (x.ServiceTypeGlobal == (int)ServiceType.GenericService)
                                    {
                                        return x.ServiceNumber;
                                    }
                                    return !string.IsNullOrEmpty(x.ExternalId) ? $"{x.ServiceNumber}_{x.ExternalId}" : x.ServiceNumber;
                                })
                                .ToList();
                            newTask.ServiceList = String.Join(",", serviceList);

                            tasksResponse.Add(newTask);
                        }
                    }
                    return tasksResponse;
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("taskCount", taskList?.Entities?.Count), ("taskType", taskType), ("timeZoneId", timeZoneId));
        }

        public async Task<List<Entity>> ReturnTotalRecordCount(TaskRequest request, int taskTypes, int searchLevel = 0)
        {
            return await TraceOperationAsync(nameof(ReturnTotalRecordCount), async () =>
            {
                try
                {
                    int recordCount = 0;
                    int pageNumber = 1;
                    int fetchCount = 5000;
                    string pagingCookie = null;
                    EntityCollection results = new();
                    while (true)
                    {
                        var query = TaskConditionalQuery(request, taskTypes, searchLevel, pageNumber, pagingCookie, fetchCount);
                        EntityCollection resultPerPage = DataverseClient.RetrieveMultiple(query);
                        results.Entities.AddRange(resultPerPage.Entities);
                        if (results.MoreRecords)
                        {
                            pageNumber++;
                            pagingCookie = results.PagingCookie;
                        }
                        else
                        {
                            break;
                        }
                    }
                    return results.Entities.ToList();
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("taskTypes", taskTypes), ("searchLevel", searchLevel), ("stateCode", request?.StateCode));
        }

        public async Task<FactoryDashboardResponse> GetFactoryDasboardTasks(TaskRequest request)
        {
            return await TraceOperationAsync(nameof(GetFactoryDasboardTasks), async () =>
            {
                try
                {
                    var factoryDashboardResponse = new FactoryDashboardResponse();
                    EntityCollection taskList = new();
                    EntityCollection recordCountColl = new();
                    if (String.IsNullOrEmpty(request?.TaskType))
                    {
                        throw new Exception(Constants.ErrorMessages.NoTaskTypeDefined);
                    }
                    var taskTypeValue = request?.TaskType == Constants.VirtualValidationTaskKey ? (int)Fiji_validationtype.Virtual : (int)Fiji_validationtype.POC;
                    bool isProjectIdSearch = string.Equals(request?.Filters?.SearchMode, Constants.ProjectIdSearchMode, StringComparison.OrdinalIgnoreCase);
                    List<string> requestedProjectIds = isProjectIdSearch ? ParseProjectIdSearch(request?.Filters?.Search) : new List<string>();

                    if (isProjectIdSearch)
                    {
                        taskList = await GetTasksListPerPage(request, taskTypeValue, ProjectIdSearchLevel);
                        recordCountColl.Entities.AddRange(ReturnTotalRecordCount(request, taskTypeValue, ProjectIdSearchLevel).Result);
                    }
                    else if (!String.IsNullOrWhiteSpace(request?.Filters?.Search))
                    {
                        var taskRuns = new List<Task>();
                        foreach (int level in SearchLevel.GetValues(typeof(SearchLevel)))
                        {
                            taskRuns.Add(Task.Run(() =>
                            {
                                taskList.Entities.AddRange(GetTasksListPerPage(request, taskTypeValue, level).Result.Entities);
                                recordCountColl.Entities.AddRange(ReturnTotalRecordCount(request, taskTypeValue, level).Result);
                            }));
                        }
                        await Task.WhenAll(taskRuns);
                    }
                    else
                    {
                        taskList = await GetTasksListPerPage(request, taskTypeValue);
                        recordCountColl.Entities.AddRange(ReturnTotalRecordCount(request, taskTypeValue).Result);
                    }
                    EntityCollection distinctColl = new();
                    distinctColl.Entities.AddRange(taskList.Entities.GroupBy(x => x.Id).Select(x => x.First()).ToList());
                    totalRecordCount += recordCountColl.Entities.GroupBy(x => x.GetAttributeValue<AliasedValue>("TaskId").Value).Select(x => x.First()).ToList().Count();
                    List<TasksResponse> tasksResponse = await OrderTasksList(distinctColl, request?.TaskType, Convert.ToInt32(request.TimeZone));
                    factoryDashboardResponse.factoryDashboardTasks = tasksResponse;
                    factoryDashboardResponse.totalRecordCount = totalRecordCount;

                    if (isProjectIdSearch)
                    {
                        var matchedProjectIds = new HashSet<string>(tasksResponse.Select(x => x.Regardingobjectidname).Where(x => !string.IsNullOrEmpty(x)), StringComparer.OrdinalIgnoreCase);
                        factoryDashboardResponse.UnmatchedProjectIds = requestedProjectIds.Where(id => !matchedProjectIds.Contains(id)).ToList();
                    }

                    return factoryDashboardResponse;
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("taskType", request?.TaskType), ("stateCode", request?.StateCode), ("hasSearch", !string.IsNullOrWhiteSpace(request?.Filters?.Search)));
        }

        public UpdateTasksResponse UpdateFactoryDasboardTasks(UpdateTasksRequest payload)
        {
            return TraceOperation(nameof(UpdateFactoryDasboardTasks), () =>
            {
                try
                {
                    if (payload?.eTrigger == null || payload?.UpdateTasks.Count <= 0)
                        throw new Exception(Constants.ErrorMessages.EmptyPayload);

                    UpdateTasksResponse response = new UpdateTasksResponse();
                    List<Update> taskList = payload.UpdateTasks;
                    EntityCollection taskColl = new EntityCollection() { EntityName = EntityName.Task };

                    #region Executing the CheckForGatedTasks Workflow for task in Completed Status
                    if (taskList.Any(x => x.Statuscode != null))
                    {
                        foreach (var item in taskList)
                        {
                            Entity task = new Entity(EntityName.Task);
                            task.Id = item.Id;
                            if (item?.Statuscode is int status && status == (int)Statuscode.Completed)
                            {
                                SetTaskStartDateByTaskId(task.Id, payload?.ModifiedByPortalContact);
                                var executeWorkflowRequest = new ExecuteWorkflowRequest()
                                {
                                    WorkflowId = Guid.Parse("44929d5b-1e5f-45b8-8481-2293be9034b4"),
                                    EntityId = task.Id
                                };

                                var executeWorkflowResponse = (ExecuteWorkflowResponse)this.DataverseClient.Execute(executeWorkflowRequest);
                            }
                        }
                        response.Message = Constants.ResponseMessages.TaskUpdatedSuccessfully;
                        return response;
                    }

                    #endregion Executing the CheckForGatedTasks Workflow for task in Completed Status

                    EntityCollection taskCollectionWithComments = new EntityCollection();
                    if (payload.eTrigger == (int)eTrigger.Header)
                    {
                        if (taskList.Any(x => !String.IsNullOrEmpty(x.Description)))
                        {
                            Guid[] taskIds = taskList.Select(x => x.Id).ToArray();
                            var query = new QueryExpression(EntityName.Task);
                            query.ColumnSet.AddColumns(AttributeNames.Task.ActivityId, AttributeNames.Task.Description);
                            query.Criteria.FilterOperator = LogicalOperator.Or;
                            ConditionExpression condition = new ConditionExpression(AttributeNames.Task.ActivityId, ConditionOperator.In);
                            foreach (Guid taskId in taskIds)
                                condition.Values.Add(taskId);
                            query.Criteria.AddCondition(condition);
                            taskCollectionWithComments = DataverseClient.RetrieveMultiple(query);
                        }
                    }

                    var existingComment = taskCollectionWithComments?.Entities.GroupBy(x => x.Id) ?? null;

                    Dictionary<Guid, int> currentStatusByTaskId = new();
                    if (!payload.CommentOnlyUpdate)
                    {
                        Guid[] taskIds = taskList.Select(x => x.Id).ToArray();
                        var statusQuery = new QueryExpression(EntityName.Task);
                        statusQuery.ColumnSet.AddColumns(AttributeNames.Task.ActivityId, AttributeNames.Task.StatusCode);
                        ConditionExpression statusCondition = new ConditionExpression(AttributeNames.Task.ActivityId, ConditionOperator.In);
                        foreach (Guid taskId in taskIds)
                        {
                            statusCondition.Values.Add(taskId);
                        }
                        statusQuery.Criteria.AddCondition(statusCondition);
                        var currentStatusColl = DataverseClient.RetrieveMultiple(statusQuery);
                        currentStatusByTaskId = currentStatusColl.Entities.Where(x => x.GetAttributeValue<OptionSetValue>(AttributeNames.Task.StatusCode) != null)
                            .ToDictionary(x => x.Id, x => x.GetAttributeValue<OptionSetValue>(AttributeNames.Task.StatusCode).Value);
                    }

                    foreach (var item in taskList)
                    {
                        Entity task = new Entity(EntityName.Task);
                        task.Id = item.Id;
                        if (!payload.CommentOnlyUpdate)
                        {
                            task[AttributeNames.Task.PSTTicketNumber] = item?.Fiji_pstticketnumber?.ToString();
                            task[AttributeNames.Task.PSTTicketUrl] = item?.Fiji_pstticketurl;
                            bool taskAlreadyCompleted = currentStatusByTaskId.TryGetValue(item.Id, out var currentStatus) && currentStatus == (int)Statuscode.Completed;
                            if (!taskAlreadyCompleted)
                            {
                                task[AttributeNames.Task.HPDelayDays] = item?.Fiji_hpdelaydays;
                            }
                        }
                        if (!string.IsNullOrEmpty(payload.ModifiedByPortalContact))
                            task[AttributeNames.Task.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, payload.ModifiedByPortalContact);

                        var decodedStr = WebUtility.HtmlDecode(item?.Description);
                        var finalComment = String.Empty;
                        if (payload.eTrigger == (int)eTrigger.Header)
                        {
                            var cmtGrouping = existingComment?.FirstOrDefault(x => x.Key == item.Id);
                            string currentComment = cmtGrouping?.FirstOrDefault()?.GetAttributeValue<string>(AttributeNames.Task.Description) ?? "";
                            finalComment = decodedStr + "\n" + currentComment;
                        }
                        else
                        {
                            finalComment = decodedStr;
                        }
                        task[AttributeNames.Task.Description] = finalComment.TrimEnd();
                        taskColl.Entities.Add(task);
                    }
                    UpdateMultipleRequest updateMultipleRequest = new()
                    {
                        Targets = taskColl,
                    };
                    var responseForUpdatedTasks = this.Execute(updateMultipleRequest) as UpdateMultipleResponse;

                    response.Message = Constants.ResponseMessages.TaskUpdatedSuccessfully;
                    return response;
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new Exception(((ExecuteTransactionFault)(ex.Detail)).ActivityId + Constants.Hypen + ex.Detail.Message);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }, ("updateCount", payload?.UpdateTasks?.Count), ("trigger", payload?.eTrigger), ("commentOnlyUpdate", payload?.CommentOnlyUpdate));
        }

        public async Task<List<TasksResponse>> GetFactoryDasboardTasksForExport(TaskRequest request)
        {
            return await TraceOperationAsync(nameof(GetFactoryDasboardTasksForExport), async () =>
            {
                try
                {
                    var factoryDashboardResponse = new FactoryDashboardResponse();
                    if (String.IsNullOrEmpty(request.TaskType) || request?.TaskIds?.Count <= 0)
                        throw new Exception(Constants.ErrorMessages.InvalidPayload);

                    EntityCollection taskTypeCollection = null;
                    EntityCollection taskList = null;
                    if (!String.IsNullOrEmpty(request?.TaskType) && request?.Contact != null && request?.StateCode != null)
                    {
                        var taskTypeValue = request?.TaskType == Constants.VirtualValidationTaskKey ? (int)Fiji_validationtype.Virtual : (int)Fiji_validationtype.POC;
                        taskList = await GetTasksListPerPage(request, taskTypeValue);
                    }
                    else
                    {
                        taskList = await GetTasksListbyTaskId(request);
                    }
                    List<TasksResponse> response = await OrderTasksList(taskList, request?.TaskType, Convert.ToInt32(request.TimeZone));

                    return response;
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("taskType", request?.TaskType), ("taskIdCount", request?.TaskIds?.Count));
        }

        public async Task<byte[]> ExportTasks(TaskRequest request)
        {
            return await TraceOperationAsync(nameof(ExportTasks), async () =>
            {
                var taskResponse = await GetFactoryDasboardTasksForExport(request);
                var urlCollection = await _fijiConfig.GetFijiConfigKeyValue(new List<string>() { Constants.PortalBaseUrl, Constants.PSTHostURL });
                portalBaseUri = new Uri($"{urlCollection.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == Constants.PortalBaseUrl)?.GetAttributeValue<string>("fiji_value")}factory-dashboard/");
                pstTicketUri = new Uri(urlCollection.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == Constants.PSTHostURL)?.GetAttributeValue<string>("fiji_value"));
                var stream = new MemoryStream();
                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook))
                {
                    // Add a WorkbookPart to the document.
                    WorkbookPart workbookPart = spreadsheetDocument.AddWorkbookPart();
                    workbookPart.Workbook = new Workbook();

                    // Add a WorksheetPart to the WorkbookPart.
                    worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                    worksheetPart.Worksheet = new Worksheet(new SheetData());

                    hyperlinkList = new List<Hyperlink>();
                    // Add Sheets to the Workbook.
                    Sheets sheets = workbookPart.Workbook.AppendChild(new Sheets());

                    // Append a new worksheet and associate it with the workbook.
                    Sheet sheet = new Sheet()
                    {
                        Id = workbookPart.GetIdOfPart(worksheetPart),
                        SheetId = 1,
                        Name = Constants.Tasks
                    };
                    sheets.Append(sheet);

                    // Get the sheetData cell table.
                    SheetData sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();

                    // Add a row to the cell table.
                    Row header = new Row();
                    foreach (var col in ColumnHeaders)
                    {
                        if (request.TaskType == Constants.VirtualValidationTaskKey && (col.Key == Constants.KVMKeyboard || col.Key == Constants.POCType))
                        {
                            continue;
                        }
                        Cell cell = new Cell();
                        cell.DataType = CellValues.String;
                        cell.CellValue = new CellValue(col.Value);
                        header.AppendChild(cell);
                    }
                    sheetData.Append(header);
                    var columnKey = ColumnHeaders.Keys.ToList();
                    var rowIndex = 1;

                    // Add cells to the row.
                    foreach (var item in taskResponse)
                    {
                        var colIndex = 0;
                        rowIndex++;
                        Row newRow = new Row();
                        Dictionary<string, object> dict = Utils.ConvertToDictionary(item);
                        foreach (var col in columnKey)
                        {
                            if (request.TaskType == Constants.VirtualValidationTaskKey && (col == Constants.KVMKeyboard || col == Constants.POCType))
                            {
                                continue;
                            }
                            colIndex++;
                            StringBuilder sb = new StringBuilder();
                            var columnNum = GetExcelColumnName(colIndex);
                            var cellReference = $"{columnNum}{rowIndex}";
                            Cell cell = new Cell();
                            if (col == Constants.Link)
                            {
                                var link = (item?.Regardingobjectid != null) ? $"{portalBaseUri}?bom-item=true&projectGuid={item.Regardingobjectid.ToString()}" : "";
                                AddHyperLink(link, cellReference);
                                cell.DataType = CellValues.String;
                                cell.CellValue = new CellValue(Constants.CompleteBOM);
                            }
                            else
                            {
                                sb.Clear();
                                sb.Append(dict[col]?.ToString());
                                if (col == Constants.PSTTicketNumber)
                                {
                                    //get PST link
                                    var pstUrl = (!String.IsNullOrEmpty(item.Fiji_pstticketnumber)) ? $"{pstTicketUri}{item.Fiji_pstticketnumber}" : "";
                                    AddHyperLink(pstUrl, cellReference);
                                    dict[col] = !String.IsNullOrWhiteSpace(sb.ToString()) ? int.Parse(sb?.ToString()) : String.Empty;
                                }
                                else if (col == Constants.OwnerId)
                                {
                                    var emailLink = (!String.IsNullOrEmpty(item.Internalemailaddress)) ? $"mailto:{item.Internalemailaddress}" : "";
                                    AddHyperLink(emailLink, cellReference);
                                }
                                cell.DataType = GetCellDataType(dict[col]?.GetType()?.Name);
                                cell.CellValue = new CellValue(sb?.ToString() ?? String.Empty);
                            }

                            newRow.AppendChild(cell);
                        }
                        sheetData.AppendChild(newRow);
                    }
                    if (hyperlinkList.Count > 0)
                    {
                        Hyperlinks hyperlinks = new Hyperlinks();
                        foreach (var link in hyperlinkList)
                        {
                            hyperlinks.Append(link);
                        }
                        worksheetPart.Worksheet.InsertAfter(hyperlinks, worksheetPart.Worksheet.GetFirstChild<SheetData>());
                    }
                    // Save the changes to the worksheet.
                    worksheetPart.Worksheet.Save();
                }
                return stream.ToArray();
            }, ("taskType", request?.TaskType), ("taskIdCount", request?.TaskIds?.Count));
        }

        public CellValues GetCellDataType(string dataType = Constants.String)
        {
            return TraceOperation(nameof(GetCellDataType), () =>
            {
                switch (dataType)
                {
                    case Constants.Int32: // Integer
                        return CellValues.Number;
                    case Constants.DateTime: // Date
                        return CellValues.Date;
                    default: // Text
                        return CellValues.String;
                }
            }, ("dataType", dataType));
        }

        public void AddHyperLink(string hyperLink, string cellRef)
        {
            TraceOperation(nameof(AddHyperLink), () =>
            {
                if (!String.IsNullOrEmpty(hyperLink))
                {
                    Uri uri = new Uri(hyperLink);
                    string hyperlinkId = "rId" + (worksheetPart.HyperlinkRelationships.Count() + 1).ToString();
                    Hyperlink hyperlink = new Hyperlink { Reference = cellRef, Id = hyperlinkId };
                    hyperlinkList.Add(hyperlink);
                    worksheetPart.AddHyperlinkRelationship(uri, true, hyperlinkId);
                }
            }, ("hasLink", !String.IsNullOrEmpty(hyperLink)), ("cellRef", cellRef));
        }

        public string GetExcelColumnName(int columnNumber)
        {
            return TraceOperation(nameof(GetExcelColumnName), () =>
            {
                int dividend = columnNumber;
                string columnName = String.Empty;
                int modulo;

                while (dividend > 0)
                {
                    modulo = (dividend - 1) % 26;
                    columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                    dividend = (int)((dividend - modulo) / 26);
                }

                return columnName;
            }, ("columnNumber", columnNumber));
        }

        public ScheduleResponse GetFactoryScheduleByUserId(ScheduleRequest request)
        {
            return TraceOperation(nameof(GetFactoryScheduleByUserId), () =>
            {
                List<KeyValuePair<string, int>> timeZoneList = Utils.TimeZoneList(DataverseClient);

                List<ScheduleRecords> scheduleRecordsList = new List<ScheduleRecords>();
                var query = new QueryExpression(EntityName.BookableResource);
                var order = request?.sort?.SortOrder == (int)OrderType.Ascending ? OrderType.Ascending : OrderType.Descending;

                if (string.IsNullOrEmpty(request?.sort?.ColumnName))
                    request.sort.ColumnName = AttributeNames.BookableResource.Name;

                if (request.sort.ColumnName == AttributeNames.BookableResource.Name || request.sort.ColumnName == AttributeNames.BookableResource.ResourceType)
                    query.AddOrder(request.sort.ColumnName, order);

                query.ColumnSet.AddColumns(AttributeNames.BookableResource.Name, AttributeNames.BookableResource.ResourceType, AttributeNames.BookableResource.StatusCode);
                query.Criteria.AddCondition(AttributeNames.BookableResource.StatusCode, ConditionOperator.Equal, 1);

                var query_fiji_factory = query.AddLink(EntityName.FijiFactory, AttributeNames.BookableResource.FactoryId, AttributeNames.FijiFactory.FactoryId);
                query_fiji_factory.EntityAlias = "fiji_factory";
                query_fiji_factory.Columns.AddColumn(AttributeNames.FijiFactory.FactoryId);
                if (request.sort.ColumnName == AttributeNames.FijiFactory.FactoryId)
                {
                    query_fiji_factory.Orders.Add(new OrderExpression(request.sort.ColumnName, order));
                }
                if (!string.IsNullOrEmpty(request?.filter?.factory))
                    query_fiji_factory.LinkCriteria.AddCondition(AttributeNames.FijiFactory.FactoryId, ConditionOperator.Equal, request.filter.factory);
                query_fiji_factory.LinkCriteria.AddCondition(AttributeNames.FijiFactory.StatusCode, ConditionOperator.Equal, 1);
                var query_fiji_factory_team = query_fiji_factory.AddLink(EntityName.Team, AttributeNames.FijiFactory.FactoryTeam, AttributeNames.Team.TeamId);
                query_fiji_factory_team.EntityAlias = "team";
                query_fiji_factory_team.Columns.AddColumn(AttributeNames.Team.TeamId);
                var ct = query_fiji_factory_team.AddLink(EntityName.FijiTeamContact, AttributeNames.Team.TeamId, AttributeNames.FijiTeamContact.TeamId);
                ct.EntityAlias = "ct";
                ct.Columns.AddColumn(AttributeNames.FijiTeamContact.TeamContactId);
                var ct_contact = ct.AddLink(EntityName.Contact, AttributeNames.FijiTeamContact.ContactId, AttributeNames.Contact.ContactId);
                ct_contact.EntityAlias = "contact";
                ct_contact.LinkCriteria.AddCondition(AttributeNames.Contact.ContactId, ConditionOperator.Equal, request?.contact);
                var cal = query.AddLink(EntityName.Calendar, AttributeNames.BookableResource.CalendarId, AttributeNames.Calendar.CalendarId);
                cal.EntityAlias = "cal";
                cal.Columns.AddColumn(AttributeNames.Calendar.Name);
                var calrule = cal.AddLink(EntityName.CalendarRule, AttributeNames.Calendar.CalendarId, AttributeNames.CalendarRule.CalendarId);
                calrule.EntityAlias = "calrule";
                calrule.Columns.AddColumns(AttributeNames.CalendarRule.StartTime, AttributeNames.CalendarRule.EndTime, AttributeNames.CalendarRule.EffectiveIntervalEnd, AttributeNames.CalendarRule.Description, AttributeNames.CalendarRule.Pattern, AttributeNames.CalendarRule.TimeZoneCode);
                if (request?.sort.ColumnName == AttributeNames.CalendarRule.StartTime || request?.sort.ColumnName == AttributeNames.CalendarRule.EndTime || request?.sort.ColumnName == AttributeNames.CalendarRule.Pattern)
                {
                    calrule.Orders.Add(new OrderExpression(request.sort.ColumnName, order));
                }

                var calrule_Or = new FilterExpression(LogicalOperator.Or);
                calrule.LinkCriteria = calrule_Or;
                calrule_Or.AddCondition(AttributeNames.CalendarRule.EffectiveIntervalEnd, ConditionOperator.OnOrAfter, DateTime.Now.AddHours(-27));

                var inc = calrule.AddLink(EntityName.Calendar, AttributeNames.CalendarRule.InnerCalendarId, AttributeNames.Calendar.CalendarId);
                inc.EntityAlias = "inc";
                var incr = inc.AddLink(EntityName.CalendarRule, AttributeNames.Calendar.CalendarId, AttributeNames.CalendarRule.CalendarId);
                incr.EntityAlias = "incr";
                incr.Columns.AddColumns(AttributeNames.CalendarRule.CalendarId, AttributeNames.CalendarRule.Duration, AttributeNames.CalendarRule.TimeZoneCode, AttributeNames.CalendarRule.SubCode, AttributeNames.CalendarRule.Offset);

                query.PageInfo = new PagingInfo
                {
                    Count = (int)request.page.PageSize,
                    PageNumber = (int)request.page.PageNumber,
                    PagingCookie = null,
                    ReturnTotalRecordCount = true
                };

                var response = DataverseClient.RetrieveMultiple(query);

                foreach (var entity in response.Entities)
                {
                    ScheduleRecords scheduleRecords = new ScheduleRecords();

                    scheduleRecords.TestBench = entity.GetAttributeValue<string>("name") ?? string.Empty;

                    AliasedValue typeValue = entity.GetAttributeValue<AliasedValue>("incr.subcode");
                    if (typeValue != null)
                    {
                        scheduleRecords.type = scheduleTypeMappings.TryGetValue(entity.GetAttributeValue<AliasedValue>("incr.subcode").Value.ToString(), out var mappedType) ? mappedType : string.Empty;
                    }

                    AliasedValue timeZoneCodeValue = entity.GetAttributeValue<AliasedValue>("calrule.timezonecode");
                    if (timeZoneCodeValue != null)
                    {
                        scheduleRecords.TimeZoneCode = entity.GetAttributeValue<AliasedValue>("calrule.timezonecode").Value.ToString();
                    }

                    AliasedValue factoryValue = entity.GetAttributeValue<AliasedValue>("fiji_factory.fiji_factoryid");
                    if (factoryValue != null)
                    {
                        scheduleRecords.Factory = ((Guid)entity.GetAttributeValue<AliasedValue>("fiji_factory.fiji_factoryid").Value).ToString();
                    }

                    AliasedValue startDate = entity.GetAttributeValue<AliasedValue>("calrule.starttime");
                    if (startDate != null)
                    {
                        scheduleRecords.startDate = Convert.ToDateTime(Utils.GetConvertedDateTime(Convert.ToInt32(scheduleRecords.TimeZoneCode), Convert.ToInt32(request.timeZone), Convert.ToDateTime(entity.GetAttributeValue<AliasedValue>("calrule.starttime").Value), timeZoneList)).ToString("yyyy-MM-dd");
                    }

                    AliasedValue endDate = entity.GetAttributeValue<AliasedValue>("calrule.effectiveintervalend");
                    if (endDate != null)
                    {
                        scheduleRecords.endDate = Convert.ToDateTime(Utils.GetConvertedDateTime(Convert.ToInt32(scheduleRecords.TimeZoneCode), Convert.ToInt32(request.timeZone), Convert.ToDateTime(entity.GetAttributeValue<AliasedValue>("calrule.effectiveintervalend").Value), timeZoneList)).AddDays(-1).ToString("yyyy-MM-dd");
                        if (scheduleRecords.endDate.Contains("9999"))
                            scheduleRecords.endDate = string.Empty;
                    }

                    AliasedValue offsetValue = entity.GetAttributeValue<AliasedValue>("incr.offset");
                    int offset = (int)entity.GetAttributeValue<AliasedValue>("incr.offset").Value;

                    scheduleRecords.startTime = Convert.ToDateTime(Utils.GetConvertedDateTime(Convert.ToInt32(scheduleRecords.TimeZoneCode), Convert.ToInt32(request.timeZone), Convert.ToDateTime(scheduleRecords.startDate).AddMinutes(offset), timeZoneList)).ToString(Constants.HoursMinutes);

                    AliasedValue durationValue = entity.GetAttributeValue<AliasedValue>("incr.duration");
                    int duration = (int)entity.GetAttributeValue<AliasedValue>("incr.duration").Value;

                    scheduleRecords.endTime = Convert.ToDateTime(Utils.GetConvertedDateTime(Convert.ToInt32(scheduleRecords.TimeZoneCode), Convert.ToInt32(request.timeZone), Convert.ToDateTime(scheduleRecords.startDate).AddMinutes(offset).AddMinutes(duration), timeZoneList)).ToString(Constants.HoursMinutes);

                    scheduleRecords.StartDateTime = $"{scheduleRecords.startDate} {scheduleRecords.startTime}";
                    scheduleRecords.EndDateTime = $"{scheduleRecords.endDate} {scheduleRecords.endTime}";

                    AliasedValue patternValue = entity.GetAttributeValue<AliasedValue>("calrule.pattern");
                    if (patternValue != null)
                    {
                        string pattern = (string)entity.GetAttributeValue<AliasedValue>("calrule.pattern").Value ?? string.Empty;
                        var patternList = new Dictionary<string, string>();
                        var pairs = pattern.Split(';');
                        foreach (var pair in pairs)
                        {
                            var keyValue = pair.Split('=');
                            if (keyValue.Length == 2)
                            {
                                if (keyValue[0].Equals(Constants.Frequent, StringComparison.OrdinalIgnoreCase))
                                {
                                    scheduleRecords.repeat = keyValue[1];
                                }
                                else if (keyValue[0].Equals(Constants.BYDAY, StringComparison.OrdinalIgnoreCase))
                                {
                                    scheduleRecords.days = keyValue[1];
                                }
                                if (keyValue[0].Equals(Constants.COUNT, StringComparison.OrdinalIgnoreCase))
                                {
                                    if (keyValue[1] == "1")
                                    {
                                        scheduleRecords.repeat = Constants.Never;
                                        scheduleRecords.endDate = string.Empty;
                                    }
                                    break;
                                }
                            }
                        }
                    }

                    scheduleRecordsList.Add(scheduleRecords);
                }
                if (string.IsNullOrEmpty(request.sort.ColumnName) || request.sort.ColumnName == "name")
                {
                    if (order == OrderType.Ascending)
                        scheduleRecordsList = scheduleRecordsList.OrderBy(x => x.TestBench).ThenBy(x => x.startDate).ThenBy(x => DateTime.TryParseExact(x.startTime, Constants.HoursMinutes, null,
                                System.Globalization.DateTimeStyles.None, out var parsedTime) ? parsedTime.TimeOfDay : TimeSpan.MinValue).ToList();
                    else if (order == OrderType.Descending)
                        scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => x.TestBench).ThenBy(x => x.startDate).ThenBy(x => DateTime.TryParseExact(x.startTime, Constants.HoursMinutes, null,
                                System.Globalization.DateTimeStyles.None, out var parsedTime) ? parsedTime.TimeOfDay : TimeSpan.MinValue).ToList();
                }
                else
                {
                    if (order == OrderType.Ascending)
                    {
                        if (request.sort.ColumnName == Constants.TaskColumnNames.StartDate)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => x.startDate).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.EndDate)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => x.endDate).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.Type)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => x.type).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.StartTime)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => DateTime.TryParseExact(x.startTime, Constants.HoursMinutes, null,
                                System.Globalization.DateTimeStyles.None, out var parsedTime) ? parsedTime.TimeOfDay : TimeSpan.MinValue).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.EndTime)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => DateTime.TryParseExact(x.endTime, Constants.HoursMinutes, null,
                               System.Globalization.DateTimeStyles.None, out var parsedTime) ? parsedTime.TimeOfDay : TimeSpan.MinValue).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.Repeat)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => x.repeat).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.Days)
                            scheduleRecordsList = scheduleRecordsList.OrderBy(x => x.days).ToList();
                    }
                    else if (order == OrderType.Descending)
                    {
                        if (request.sort.ColumnName == Constants.TaskColumnNames.StartDate)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => x.startDate).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.EndDate)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => x.endDate).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.Type)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => x.type).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.StartTime)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => DateTime.TryParseExact(x.startTime, Constants.HoursMinutes, null,
                                  System.Globalization.DateTimeStyles.None, out var parsedTime) ? parsedTime.TimeOfDay : TimeSpan.MinValue).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.EndTime)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => DateTime.TryParseExact(x.endTime, Constants.HoursMinutes, null,
                                 System.Globalization.DateTimeStyles.None, out var parsedTime) ? parsedTime.TimeOfDay : TimeSpan.MinValue).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.Repeat)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => x.repeat).ToList();
                        else if (request.sort.ColumnName == Constants.TaskColumnNames.Days)
                            scheduleRecordsList = scheduleRecordsList.OrderByDescending(x => x.days).ToList();
                    }
                }
                ScheduleResponse scheduleResponse = new();
                scheduleResponse.Data = scheduleRecordsList;
                scheduleResponse.TotalRecords = response.TotalRecordCount;
                return scheduleResponse;
            }, ("contact", request?.contact), ("factory", request?.filter?.factory), ("sortColumn", request?.sort?.ColumnName), ("sortOrder", request?.sort?.SortOrder));
        }

        protected void SetTaskStartDateByTaskId(Guid taskId, string? modifiedByPortalContact)
        {
            TraceOperation(nameof(SetTaskStartDateByTaskId), () =>
            {
                DateTime currentDateTime = DateTime.UtcNow;
                Entity task = new Entity(EntityName.Task, taskId);
                task[AttributeNames.Task.ActualStart] = currentDateTime;
                task[AttributeNames.Task.ActualStartUtc] = currentDateTime;
                if (!string.IsNullOrEmpty(modifiedByPortalContact))
                    task[AttributeNames.Task.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, modifiedByPortalContact);

                Execute(new UpdateRequest { Target = task });
            });
        }
    }
}