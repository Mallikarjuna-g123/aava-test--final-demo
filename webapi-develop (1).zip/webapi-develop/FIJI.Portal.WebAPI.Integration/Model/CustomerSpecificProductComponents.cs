﻿using Microsoft.Xrm.Sdk;
using System.Text.Json.Serialization;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class CustomerSpecificProductComponents : Base<CustomerSpecificProductComponents>
    {
        private IOrganizationService service;
        public CustomerSpecificProductComponents(): base("customerspecificproductcomponents") { }
        public CustomerSpecificProductComponents(IOrganizationService dataverseClient) : base(dataverseClient, "customerspecificproductcomponents")
        {
            this.service = dataverseClient;
        }

        // Lower camel case for Json Properties
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("externalId")]
        public string? ExternalId { get; set; }

        [JsonPropertyName("modifiedon")]
        public string? Modifiedon { get; set; }

        [JsonPropertyName("requiredInfoMultiModel")]
        public bool? RequiredInfoMultiModel { get; set; }

        [JsonPropertyName("portalDescription")]
        public string PortalDescription { get; set; }

        [JsonPropertyName("pcId")]
        public string? ProductComponentId { get; set; }
    }
}
