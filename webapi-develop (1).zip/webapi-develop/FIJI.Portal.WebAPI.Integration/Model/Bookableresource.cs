﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Bookableresource:Base<Bookableresource>
    {
        public Bookableresource(IOrganizationService dataverseClient) : base(dataverseClient, "bookableresource")
        {

        }
    }
}
