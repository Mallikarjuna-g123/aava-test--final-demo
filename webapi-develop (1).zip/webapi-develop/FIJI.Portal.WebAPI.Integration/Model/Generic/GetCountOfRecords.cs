﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace FIJI.Portal.WebAPI.Integration.Model.Generic
{
    public class GetCountOfRecords : Base<GetCountOfRecords>
    {
        
        public GetCountOfRecords(IOrganizationService dataverseClient, ILogger<GetCountOfRecords>? logger = null) : base(dataverseClient, "generic.getcountofrecords")
        { }

        public async Task<string> CallDynamicsRetrieveCount(string fetchxmlquery)
        {
            return await TraceOperationAsync(nameof(CallDynamicsRetrieveCount), async () =>
            {
                Dictionary<string, string> lresponsedataset = new Dictionary<string, string>();
                try
                {

                    FetchExpression fetchExpression = new FetchExpression(fetchxmlquery);

                    var retrieveObj = DataverseClient.RetrieveMultiple(fetchExpression);

                    foreach (var item in retrieveObj.Entities)
                    {
                        if (item.Contains("count"))
                        {
                            lresponsedataset.Add("count", ((AliasedValue)item["count"]).Value.ToString());
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return await Task.FromResult(System.Text.Json.JsonSerializer.Serialize(lresponsedataset));
            }, ("hasFetchXml", !string.IsNullOrWhiteSpace(fetchxmlquery)));
        }

    }
}
