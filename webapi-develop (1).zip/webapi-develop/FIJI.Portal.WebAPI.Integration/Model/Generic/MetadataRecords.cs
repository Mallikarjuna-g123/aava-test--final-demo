﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace FIJI.Portal.WebAPI.Integration.Model.Generic
{
    public class MetadataRecords : Base<MetadataRecords>
    {
        
        public MetadataRecords(IOrganizationService dataverseClient, ILogger<MetadataRecords>? logger = null) : base(dataverseClient, "generic.metadatarecords")
        { }

        public async Task<Dictionary<int, string>> GetOptionSetValues(string table, string optionSet)
        {
            return await TraceOperationAsync(nameof(GetOptionSetValues), async () =>
            {
                var response = new Dictionary<int, string>();
                try
                {
                    RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest();
                    attributeRequest.EntityLogicalName = table;
                    attributeRequest.LogicalName = optionSet;

                    var attributeResponse = (RetrieveAttributeResponse)DataverseClient.Execute(attributeRequest);
                    var picklist = (PicklistAttributeMetadata)attributeResponse.AttributeMetadata;

                    if (picklist?.OptionSet?.Options?.Count > 0)
                        foreach (var item in picklist.OptionSet.Options)
                            response.Add(item.Value.Value, item.Label?.LocalizedLabels?.FirstOrDefault(x => x.LanguageCode == 1033)?.Label);

                    return await Task.FromResult(response);
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("table", table), ("optionSet", optionSet));
        }
    }
}
