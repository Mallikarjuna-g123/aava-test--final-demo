﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace FIJI.Portal.WebAPI.Integration.Model.Generic
{
    public class DissociateRecords : Base<DissociateRecords>
    {
        
        public DissociateRecords(IOrganizationService dataverseClient, ILogger<DissociateRecords>? logger = null) : base(dataverseClient, "dissociaterecords")
        { }

        public void Execute(Requests.AssociateDissociateRecordsRequest request)
        {
            TraceOperation(nameof(Execute), () =>
            {
                EntityReference target = new EntityReference(request.Target.LogicalName, request.Target.Id);
                foreach (var item in request.RelatedEntities)
                {
                    EntityReference relatedEntity = new EntityReference(item.LogicalName, item.Id);
                    DisassociateRequest dissociateRequest = new DisassociateRequest()
                    {
                        Target = target,
                        Relationship = new Relationship(request.RelationName),
                        RelatedEntities = new EntityReferenceCollection { relatedEntity }
                    };
                    if (request.Target.LogicalName.Equals(item.LogicalName))
                        dissociateRequest.Relationship.PrimaryEntityRole = EntityRole.Referencing;

                    this.Execute(dissociateRequest);
                }
            }, ("relationName", request?.RelationName), ("targetLogicalName", request?.Target?.LogicalName), ("relatedCount", request?.RelatedEntities?.Count));
        }
    }
}
