﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace FIJI.Portal.WebAPI.Integration.Model.Generic
{
    public class RetrieveMultiple : Base<RetrieveMultiple>
    {

        public RetrieveMultiple(IOrganizationService dataverseClient, ILogger<RetrieveMultiple>? logger = null) : base(dataverseClient, "generic.retrievemultiple")
        { }

        public async Task<EntityCollection> CallDynamicsRetrieveData(string fetchxmlquery)
        {
            return await TraceOperationAsync(nameof(CallDynamicsRetrieveData), async () =>
            {
                Dictionary<string, string> lresponsedataset = new Dictionary<string, string>();
                try
                {

                    FetchExpression fetchExpression = new FetchExpression(fetchxmlquery);
                    var retrieveObj = DataverseClient.RetrieveMultiple(fetchExpression);
                    if (retrieveObj != null && retrieveObj.Entities.Count > 0)
                    {
                        return await Task.FromResult(retrieveObj);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return await Task.FromResult((EntityCollection)null);
            }, ("hasFetchXml", !string.IsNullOrWhiteSpace(fetchxmlquery)));
        }
    }
}
