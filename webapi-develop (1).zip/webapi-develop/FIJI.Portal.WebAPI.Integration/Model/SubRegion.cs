﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class SubRegion : Base<SubRegion>
    {
        public SubRegion(IOrganizationService dataverseClient, ILogger<SubRegion>? logger = null) : base(dataverseClient, "subregion") { }
        
        public Guid? GetSubRegionBy(Guid managerId)
        {
            return TraceOperation<Guid?>(nameof(GetSubRegionBy), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.SubRegion);
                query.ColumnSet = new ColumnSet(AttributeNames.SubRegion.SubRegionId);
                query.TopCount = 1;

                LinkEntity countryLink = new LinkEntity(EntityName.SubRegion, EntityName.Country, AttributeNames.SubRegion.SubRegionId, AttributeNames.Country.SubRegionid, JoinOperator.Inner);
                LinkEntity userLink = new LinkEntity(EntityName.Country, EntityName.SystemUser, AttributeNames.Country.CountryId, AttributeNames.SystemUser.CountryId, JoinOperator.Inner);

                FilterExpression filter = new FilterExpression();
                filter.FilterOperator = LogicalOperator.And;
                filter.AddCondition(AttributeNames.SystemUser.SystemUserId, ConditionOperator.Equal, managerId);

                userLink.LinkCriteria = filter;
                countryLink.LinkEntities.Add(userLink);
                query.LinkEntities.Add(countryLink);

                EntityCollection results = DataverseClient.RetrieveMultiple(query);

                if (results != null && results.Entities.Count > 0)
                {
                    var entity = results.Entities[0];
                    if (entity.Contains(AttributeNames.SubRegion.SubRegionId))
                        return (Guid?)entity.Id;
                }
                return (Guid?)null;
            }, ("managerId", managerId));
        }
    }
}
