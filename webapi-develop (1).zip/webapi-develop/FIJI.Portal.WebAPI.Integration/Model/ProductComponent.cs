using DocumentFormat.OpenXml.Vml.Office;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Model.Generic;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Serialization;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ProductComponent : Base<ProductComponent>
    {
        private PCPlatformStatus? _pcPlatformStatusService;
        private ServiceSnapshot? _serviceSnapshotService;
        private PlatformAndPlacement? _platformAndPlacementService;
        private readonly BOM? _bomService;
        private PCBiosRevision? _PCBiosRevision;
        private readonly FijiConfiguration? _fijiConfig;
        private readonly RetrieveMultiple? retrieveMultipleBaseInfra;
        private Account? _customer;
        private ADRReport? _adrReport;
        private readonly IMemoryCache? _memoryCache;
        private ComponentType? _componentTypeService;

        public ProductComponent(): base("productcomponent")
        { }

        public ProductComponent(IOrganizationService dataverseClient, IMemoryCache cache, ILogger<ProductComponent>? logger = null, ILoggerFactory? loggerFactory = null) : base(dataverseClient, "productcomponent")
        {
            loggerFactory ??= NullLoggerFactory.Instance;
            this._pcPlatformStatusService = new PCPlatformStatus(dataverseClient, loggerFactory.CreateLogger<PCPlatformStatus>());
            this._serviceSnapshotService = new ServiceSnapshot(dataverseClient, cache, loggerFactory.CreateLogger<ServiceSnapshot>(), loggerFactory);
            this._platformAndPlacementService = new PlatformAndPlacement(dataverseClient, loggerFactory.CreateLogger<PlatformAndPlacement>());
            this._bomService = new BOM(dataverseClient, cache, loggerFactory.CreateLogger<BOM>(), loggerFactory);
            this._PCBiosRevision = new PCBiosRevision(dataverseClient, loggerFactory.CreateLogger<PCBiosRevision>());
            _fijiConfig = new FijiConfiguration(dataverseClient, loggerFactory.CreateLogger<FijiConfiguration>());
            this.retrieveMultipleBaseInfra = new RetrieveMultiple(dataverseClient, loggerFactory.CreateLogger<RetrieveMultiple>());
            this._customer = new Account(dataverseClient, loggerFactory.CreateLogger<Account>());
            this._adrReport = new ADRReport(dataverseClient);
            this._memoryCache = cache;
            this._componentTypeService = new ComponentType(dataverseClient, loggerFactory.CreateLogger<ComponentType>());
        }

        // Lower camel case for Json Properties
        [JsonPropertyName("id")]
        public Guid? Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("serviceTypeGlobal")]
        public int? ServiceTypeGlobal { get; set; }

        [JsonPropertyName("externalId")]
        public string? ExternalId { get; set; }

        [JsonPropertyName("materialProductLine")]
        public string? MaterialProductLine { get; set; }

        [JsonPropertyName("componentType")]
        public ComponentType? ComponentType { get; set; }

        [JsonPropertyName("ServiceSnapshot")]
        public List<ServiceSnapshot>? ServiceSnapshot { get; set; }

        [JsonPropertyName("serviceType")]
        public int? ServiceType { get; set; }

        public List<Account>? CustomerList { get; set; }

        public string? ProductComponentId { get; set; }

        // upper camel case for C# properties
        public string? ModelId { get; set; }

        public int? StatusCode { get; set; }
        public int? StateCode { get; set; }
        public string? BiosRevision { get; set; }
        public string? ServiceComplexity { get; set; }

        public bool? HideFromPortal { get; set; }

        public string? PortalContact { get; set; }

        //addtional fields required for Description which will come from payload

        public string? PartNumber { get; set; }

        public string? CustomerName { get; set; }

        public string? ModelName { get; set; }

        public Guid? ServiceSnapShotId { get; set; }

        public Guid BOMId { get; set; }

        public int? AutomationFlag { get; set; }

        public ComponentType? GetMoreSource { get; set; }

        public string? PortalDescription { get; set; }

        public enum eStatusCode
        {
            Inactive = 2,
            Legacy = 622490001,
            New = 1,
            None = 219180003,
            Obsolete = 622490002,
            ObsoleteRemove = 219180001,
            Setup = 219180000,
            Sustaining = 219180002
        }

        public enum eStateCode
        {
            Active = 0,
            Inactive = 1
        }

        public enum eServiceTypeGlobal
        {
            CustomerSpecific = 102420000,
            GenericService = 102420001,
            Hardware = 102420003,
            PhantomAV = 622490000,
            PlaceholderAV = 102420002,
            PreDefinedAV = 622490002,
            TechnicalAV = 622490001
        }

        public enum eAutomationFlag
        {
            Automated = 1,
            Manual = 2
        }

        //Create new Product component
        public Responses.ProductComponentResponse CreateProductComponent(Requests.ProductComponentRequest productComponentRequest)
        {
            return TraceOperation("CreateProductComponent", () =>
            {
                Guid? NewServiceSnapShotId = null;
                Guid? BOMID = null;
                Guid? PcplatformStatusID = null;
                string pcNumber = string.Empty;
                string ServiceRevisionVersion = string.Empty;
                int? AutomationFlagInherited = null;
                Responses.ProductComponentResponse productComponentResponse = new Responses.ProductComponentResponse();

                if (!string.IsNullOrWhiteSpace(productComponentRequest.ServiceDescription) && !IsPortalDescriptionUnique(productComponentRequest.ServiceDescription, Guid.TryParse(productComponentRequest.CustomerId, out var custId) ? new[] { custId } : null, productComponentRequest.CanBeUsedAcrossCustomers))
                {
                    productComponentResponse.Error = Constants.ErrorMessages.DuplicatePortalDescription;
                    return productComponentResponse;
                }
                this.BeginTransaction();
                this._PCBiosRevision.SetTransaction(this.Transaction);
                this._pcPlatformStatusService.SetTransaction(this.Transaction);
                this._serviceSnapshotService.SetTransaction(this.Transaction);
                this._platformAndPlacementService.SetTransaction(this.Transaction);
                this._bomService.SetTransaction(this.Transaction);

                this.StatusCode = (int)eStatusCode.New;// 1 for new
                this.StateCode = (int)eStateCode.Active; // 0 for Active
                this.BiosRevision = productComponentRequest.BiosRevision;
                this.ServiceTypeGlobal = (int)eServiceTypeGlobal.CustomerSpecific;// customer specific
                this.HideFromPortal = false;

                if (productComponentRequest.PortalUserId != "" && productComponentRequest.PortalUserId != null)
                    this.PortalContact = productComponentRequest.PortalUserId;

                this.ServiceComplexity = GetServiceComplexitybyComponentID(new Guid(productComponentRequest.ComponentTypeId));
                var projectScopeChangeHelper = new ProjectScopeChangeHelper(DataverseClient);

                var AutomationValue = GetServiceTypeByComponent(productComponentRequest?.SourceComponentTypeid.Value.ToString());
                if (AutomationValue.Equals((int)eAutomationFlag.Automated))
                    AutomationFlag = (int)eAutomationFlag.Automated;
                if (AutomationValue.Equals((int)eAutomationFlag.Manual))
                    AutomationFlag = (int)eAutomationFlag.Manual;
                AutomationFlagInherited = AutomationFlag;

                if (!string.IsNullOrEmpty(productComponentRequest.AutomationFlagName)
                          && productComponentRequest.AutomationFlagName.Trim().Equals(Constants.Automated, StringComparison.OrdinalIgnoreCase))
                {
                    AutomationFlag = (int)eAutomationFlag.Automated;
                }

                if (!string.IsNullOrEmpty(productComponentRequest.AutomationFlagName)
                                     && productComponentRequest.AutomationFlagName.Trim().Equals(Constants.Manual, StringComparison.OrdinalIgnoreCase))
                {
                    AutomationFlag = (int)eAutomationFlag.Manual;
                }

                Entity fijiProductComponent = new Entity(EntityName.ProductComponent);
                fijiProductComponent.Id = Guid.NewGuid();
                this.Id = fijiProductComponent.Id;
                fijiProductComponent[AttributeNames.ProductComponent.StatusCode] = new OptionSetValue(this.StatusCode.Value);
                fijiProductComponent[AttributeNames.ProductComponent.StateCode] = new OptionSetValue(this.StateCode.Value);
                if (productComponentRequest.SourceComponentTypeid != null)
                    fijiProductComponent[AttributeNames.ProductComponent.GetMoreSource] = Utils.GetEntityReference(EntityName.ComponentType, productComponentRequest.SourceComponentTypeid.Value.ToString());

                fijiProductComponent[AttributeNames.ProductComponent.ServiceTypeGlobal] = new OptionSetValue(this.ServiceTypeGlobal.Value); // optionset
                fijiProductComponent[AttributeNames.ProductComponent.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, productComponentRequest.ComponentTypeId);
                fijiProductComponent[AttributeNames.ProductComponent.ServiceComplexity] = Utils.GetEntityReference(EntityName.ServiceComplexity, this.ServiceComplexity);// lookup
                fijiProductComponent[AttributeNames.ProductComponent.HideFromPortal] = false;

                if (productComponentRequest.PortalUserId != "" && productComponentRequest.PortalUserId != null)
                    fijiProductComponent[AttributeNames.ProductComponent.PortalContact] = Utils.GetEntityReference(EntityName.Contact, this.PortalContact);

                if (AutomationFlag != null && (Convert.ToInt32(productComponentRequest.StatusCodeServiceRevision) == (int)Model.ServiceSnapshot.eStatusCode.Submitted))
                    fijiProductComponent[AttributeNames.ProductComponent.AutomationFlag] = new OptionSetValue((int)AutomationFlag);
                else if (AutomationFlagInherited != null)
                    fijiProductComponent[AttributeNames.ProductComponent.AutomationFlag] = new OptionSetValue((int)AutomationFlagInherited);

                this.Execute(new CreateRequest { Target = fijiProductComponent });

                this._PCBiosRevision.CreatePCBiosRevisionOnNewProductComponent(productComponentRequest, this.Id);

                AssociateCustomerWithProductComponent(productComponentRequest);

                PCPlatformStatus.eStatusCode statusPCPlatformStatus = PCPlatformStatus.eStatusCode.Draft;

                if (Convert.ToInt32(productComponentRequest.StatusCodeServiceRevision) == (int)Model.ServiceSnapshot.eStatusCode.Submitted)
                    statusPCPlatformStatus = PCPlatformStatus.eStatusCode.Requested; //Requested


                this._pcPlatformStatusService.CreatePCPlatformStatusOnNewProductComponent(productComponentRequest, this.Name, this.Id, (int)statusPCPlatformStatus, out PcplatformStatusID);

                this._serviceSnapshotService.CreateServiceRevisionOnNewProductComponent(productComponentRequest, (Guid)this.Id, null, out NewServiceSnapShotId, out ServiceRevisionVersion, AutomationFlag);

                this._platformAndPlacementService.CreatePlatformandPlacementOnNewProductComponent(productComponentRequest, NewServiceSnapShotId);

                this._bomService.CreateorUpdateBOMOnNewProductComponent(productComponentRequest, this.Id, NewServiceSnapShotId, out BOMID);

                CommitTransaction();

                BeginTransaction();

                this._pcPlatformStatusService.SetTransaction(this.Transaction);
                UpdateProductComponentDescription(productComponentRequest, out pcNumber);
                this._pcPlatformStatusService.UpdatePCPlatformStatusDescription(this.Name, PcplatformStatusID, productComponentRequest.ModelName);
                CommitTransaction();

                //Project Scope Change Automation
                var projectScopeChangereponse = new ProjectScopeChangeRequest();
                if (string.IsNullOrEmpty(productComponentRequest.BomId))
                {
                    var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(BOMID.ToString());
                    if (result != null)
                    {
                        projectScopeChangereponse.Sections ??= new Sections();

                        projectScopeChangereponse.Sections.Add ??= new List<BomItem>();
                        // Add the new BomItem
                        projectScopeChangereponse.Sections.Add.Add(new BomItem
                        {
                            BomId = result.bomName,
                            ExternalId = result.externalId,
                            PortalDescription = result.description
                        });
                    }
                }
                if (!string.IsNullOrEmpty(productComponentRequest.BomId))
                {
                    var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(BOMID.ToString());
                    if (result != null)
                    {
                        projectScopeChangereponse.Sections ??= new Sections();

                        projectScopeChangereponse.Sections.Customize ??= new List<BomItem>();
                        // Customize the new BomItem
                        projectScopeChangereponse.Sections.Customize.Add(new BomItem
                        {
                            BomId = result.bomName,
                            ExternalId = result.externalId,
                            PortalDescription = result.description
                        });
                    }
                }
                projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, productComponentRequest.ProjectId);

                if (this.Id != Guid.Empty)
                    productComponentResponse.ProductComponent = this.GetBy(this.Id.Value); // add newly generated product component to Product Response
                if (NewServiceSnapShotId != null)
                    productComponentResponse.ServiceRevision = _serviceSnapshotService.GetBy(NewServiceSnapShotId.Value);
                if (BOMID != null)
                    productComponentResponse.BomId = BOMID.Value.ToString();
                if (productComponentRequest.SourceComponentTypeid != null)
                    productComponentResponse.SourceComponentTypeid = productComponentRequest.SourceComponentTypeid;

                //Transform API for AY103AV Service for the Existing API 
                QuestionnaireDetails details = JsonConvert.DeserializeObject<QuestionnaireDetails>(productComponentRequest?.QuestionnaireDetails);
                if (details?.ScreenNumber == Constants.PartNumber_AY103AV)
                {
                    var response = _serviceSnapshotService.TransformAPIAY103AVService(details, NewServiceSnapShotId, Guid.Parse(PortalContact));
                }
                else if (details?.ScreenNumber == Constants.PartNumber_AY777AV)
                {
                    string customerAccountNumber = string.Empty;
                    _customer.GetCustomerNameorNumberByAccId(new Guid(productComponentRequest?.CustomerId), out customerAccountNumber);
                    _adrReport.CreateCustomerFolder(customerAccountNumber);
                }

                return productComponentResponse; // this is a new product component id
            },
            ("ProductComponentRequest", productComponentRequest));
        }

        public void UpdateProductComponentDescription(Requests.ProductComponentRequest productComponentRequest, out string pcNumber)
        {
            var result = TraceOperation(nameof(UpdateProductComponentDescription), () =>
            {
                Guid? updrecID = this.Id;

                string autogenproductcomponentid = "";
                autogenproductcomponentid = GetAutoGenProductComponentID(updrecID.Value);

                Entity fijiProductComponent = new Entity(EntityName.ProductComponent, updrecID.Value);

                StringBuilder strDescription = new StringBuilder();
                if (!string.IsNullOrWhiteSpace(productComponentRequest.ServiceDescription))
                {
                    strDescription.Append(productComponentRequest.ServiceDescription.Trim());
                }
                else
                {
                    strDescription.Append(productComponentRequest.PartNumber);
                    strDescription.Append(Constants.Hypen);
                    if (Convert.ToBoolean(productComponentRequest.CanBeUsedAcrossCustomers) == false)
                    {
                        strDescription.Append(productComponentRequest.CustomerName);
                    }
                    if (!string.IsNullOrWhiteSpace(productComponentRequest.ModelName))
                    {
                        strDescription.Append(Constants.Hypen);
                        strDescription.Append(productComponentRequest.ModelName);
                    }
                    if (!string.IsNullOrEmpty(productComponentRequest.BiosRevision))
                    {
                        strDescription.Append(Constants.Hypen);
                        strDescription.Append(productComponentRequest.BiosRevision);
                    }
                }
                if (!string.IsNullOrEmpty(autogenproductcomponentid))
                {
                    string[] productdescid = autogenproductcomponentid.Split(Constants.PC);
                    if (productdescid.Length == 2)
                    {
                        strDescription.Append(Constants.Hypen);
                        strDescription.Append(productdescid[1]);
                    }
                }

                fijiProductComponent[AttributeNames.ProductComponent.Name] = strDescription.ToString();
                fijiProductComponent[AttributeNames.ProductComponent.PortalDescription] = strDescription.ToString();

                this.Name = strDescription.ToString();
                this.Execute(new UpdateRequest { Target = fijiProductComponent });
                return autogenproductcomponentid;

            }, ("productComponentId", this.Id));
            pcNumber = result;
        }

        // canBeUsedAcrossCustomers  be used accross customer N:N mapping
        public void AssociateCustomerWithProductComponent(Requests.ProductComponentRequest productComponentRequest)
        {
            TraceOperation(nameof(AssociateCustomerWithProductComponent), () =>
            {
                if ((productComponentRequest.CanBeUsedAcrossCustomers) == null || productComponentRequest.CanBeUsedAcrossCustomers == false)
                {
                    EntityReference account = new EntityReference(EntityName.Account, new Guid(productComponentRequest.CustomerId));
                    EntityReference fijiProductComponent = new EntityReference(EntityName.ProductComponent, (Guid)this.Id);

                    AssociateRequest associateRequest = new AssociateRequest()
                    {
                        Target = fijiProductComponent,
                        Relationship = new Relationship(EntityName.ProductComponentAccount),
                        RelatedEntities = new EntityReferenceCollection { account }
                    };

                    this.Execute(associateRequest);
                }
            }, ("productComponentId", this.Id), ("customerId", productComponentRequest?.CustomerId));
        }

        //Update Product component on service revision update
        public void UpdatePCOnServiceRevisionUpdate(Guid? ComponentTypeId, Guid? ProductComponentId)
        {
            TraceOperation(nameof(UpdatePCOnServiceRevisionUpdate), () =>
            {
                if (ComponentTypeId != null && ProductComponentId != null)
                {
                    Entity fijiProductComponent = new Entity(EntityName.ProductComponent, ProductComponentId.Value);
                    fijiProductComponent[AttributeNames.ProductComponent.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, ComponentTypeId.Value.ToString());
                    this.Execute(new UpdateRequest { Target = fijiProductComponent });
                }
            }, ("componentTypeId", ComponentTypeId), ("productComponentId", ProductComponentId));
        }

        // Web api to create duplicate response
        public Responses.ProductComponent.ProductComponent_DuplicateResponse Duplicate(Requests.ProductComponent.ProductComponent_Duplicate_Request reqPayload)
        {
            BeginTransaction();
            _pcPlatformStatusService.SetTransaction(this.Transaction);
            _serviceSnapshotService.SetTransaction(this.Transaction);
            _platformAndPlacementService.SetTransaction(this.Transaction);
            Guid? fiji_componenttypeid = null;
            // Get the latest service revision based on product component id
            ServiceSnapshot? LatestServiceRevision = _serviceSnapshotService.GetLatestServiceRevisionByProductcomponent(reqPayload.ProductComponentId.ToString(), null);



            Responses.ProductComponent.ProductComponent_DuplicateResponse response = new Responses.ProductComponent.ProductComponent_DuplicateResponse();
            var copyFijiProductComponent = this.DataverseClient.Retrieve(EntityName.ProductComponent, reqPayload.ProductComponentId, new ColumnSet(true));
            // Get the componentype based on questionnaire Screen
            if (LatestServiceRevision != null)
            {
                var LasestServiceRevisionDtl = this.DataverseClient.Retrieve(EntityName.Servicesnapshot, LatestServiceRevision.Id.Value, new ColumnSet(AttributeNames.Servicesnapshot.ServiceDetailInJson));
                string joncontent = LasestServiceRevisionDtl.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson);
                if (!string.IsNullOrEmpty(joncontent))
                {
                    JObject jObject = JObject.Parse(joncontent);
                    string questionnaireScreen = GetQuestionnaireNumberFromJSON(jObject);
                    if (!string.IsNullOrWhiteSpace(questionnaireScreen))
                    {
                        fiji_componenttypeid = GetComponentTypeByServiceNumber(questionnaireScreen).Value;
                    }
                }
                else
                {
                    if (copyFijiProductComponent.Contains(AttributeNames.ProductComponent.GetMoreSource) && copyFijiProductComponent.Attributes[AttributeNames.ProductComponent.GetMoreSource] != null)
                        fiji_componenttypeid = copyFijiProductComponent.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.GetMoreSource).Id;
                    else if (copyFijiProductComponent.Contains(AttributeNames.ProductComponent.ComponentType) && copyFijiProductComponent.Attributes[AttributeNames.ProductComponent.ComponentType] != null)
                        fiji_componenttypeid = copyFijiProductComponent.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType).Id;
                }

            }
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.CreatedBy);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.ModifiedBy);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.ModifiedOn);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.ExternalId);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.ProductComponentId);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.GetMoreSource);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.ParentProductComponentId);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.HasBeenSustaining);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.EverestId);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.DataImportSource);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.CreatedOn);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.CompletedServiceRevisionVersion);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.Owner);
            copyFijiProductComponent.Remove(AttributeNames.ProductComponent.OverriddenCreatedon);
            copyFijiProductComponent.Id = Guid.NewGuid();
            copyFijiProductComponent[AttributeNames.ProductComponent.PortalContact] = Utils.GetEntityReference(EntityName.Contact, reqPayload.PortalUserId.ToString());
            copyFijiProductComponent[AttributeNames.ProductComponent.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, reqPayload.PortalUserId.ToString());
            if (fiji_componenttypeid != null)
                copyFijiProductComponent[AttributeNames.ProductComponent.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, fiji_componenttypeid.Value.ToString());
            string copyfijiname = copyFijiProductComponent.GetAttributeValue<string>(AttributeNames.ProductComponent.Name).ToString();
            string description = copyfijiname + Constants.Copy;
            copyFijiProductComponent[AttributeNames.ProductComponent.Name] = description;
            //Get list of asscoited customer from copy product component
            List<Guid>? lsCustomer = GetCustomerAssociatedWithProductComponent(reqPayload.ProductComponentId);   // moved up 
            if (!IsPortalDescriptionUnique(description, lsCustomer, canBeUsedAcrossCustomers: lsCustomer == null || lsCustomer.Count == 0))
            {
                response.Error = Constants.ErrorMessages.DuplicatePortalDescription;
                return response;
            }
            this.Execute(new CreateRequest { Target = copyFijiProductComponent });

            if (lsCustomer != null && lsCustomer.Count > 0)
            {
                foreach (var customer in lsCustomer)
                {
                    AssociateProductComponentWithCustomer(copyFijiProductComponent.Id, customer);
                }
            }

            // Get the platform from PC Platfrom Status by product component
            List<Guid>? lspcplatformstatusid = GetPCPlatformStatusByProductComponent(reqPayload.ProductComponentId);
            if (lspcplatformstatusid != null && lspcplatformstatusid.Count > 0)
            {
                foreach (var pcplatformstatusid in lspcplatformstatusid)
                {
                    _pcPlatformStatusService.DuplicatePCPlatformStatus(pcplatformstatusid, copyFijiProductComponent.Id, description);
                }
            }

            //
            Guid? NewServicesnapshotID = null;
            _serviceSnapshotService.CreateServiceRevisionOnDuplicateProductComponent(reqPayload, copyFijiProductComponent.Id, out NewServicesnapshotID);

            if (LatestServiceRevision != null)
            {
                List<Guid>? lsPlacementandPlatformRec = _platformAndPlacementService.GetPlatformandPlacementByServiceRevision(LatestServiceRevision.Id, out _);

                if (lsPlacementandPlatformRec != null)
                {
                    foreach (var fiji_platfromID in lsPlacementandPlatformRec)
                    {
                        _platformAndPlacementService.CreatePlatformandPlacementForDuplicateProductComponent(NewServicesnapshotID, fiji_platfromID);
                    }
                }
            }

            CommitTransaction();
            response.NewProductComponentId = copyFijiProductComponent.Id;
            return response;
        }

        /// <summary>
        /// Get questionnaire number from the possible properties
        /// </summary>
        /// <param name="jObject">Service Revision JSON</param>
        /// <returns>Questionnaire Number</returns>
        private static string GetQuestionnaireNumberFromJSON(JObject jObject)
        {
            string? questionnaireScreen = jObject["questionnaireScreen"]?.ToString();
            if (!string.IsNullOrWhiteSpace(questionnaireScreen))
                return questionnaireScreen;

            JObject? details = jObject["Details"] as JObject;
            string? screenNumberFromDetails = details != null
                ? GetTokenValueCaseInsensitive(details, "screenNumber")
                : null;

            if (!string.IsNullOrWhiteSpace(screenNumberFromDetails))
                return screenNumberFromDetails;

            string? service = GetTokenValueCaseInsensitive(jObject, "Service");
            if (!string.IsNullOrWhiteSpace(service))
                return service;

            string? screenNumber = GetTokenValueCaseInsensitive(jObject, "screenNumber");
            if (!string.IsNullOrWhiteSpace(screenNumber))
                return screenNumber;

            return string.Empty;

            string? GetTokenValueCaseInsensitive(JObject obj, string key)
            {
                var token = obj.Properties()
                               .FirstOrDefault(p => string.Equals(p.Name, key, StringComparison.OrdinalIgnoreCase));

                return token?.Value?.ToString();
            }
        }

        // Associate product component with customer
        protected void AssociateProductComponentWithCustomer(Guid productComponentId, Guid customerId)
        {
            TraceOperation(nameof(AssociateProductComponentWithCustomer), () =>
            {
                EntityReference account = new EntityReference(EntityName.Account, customerId);
                EntityReference fijiProductComponent = new EntityReference(EntityName.ProductComponent, productComponentId);

                AssociateRequest associateRequest = new AssociateRequest()
                {
                    Target = fijiProductComponent,
                    Relationship = new Relationship(EntityName.ProductComponentAccount),
                    RelatedEntities = new EntityReferenceCollection { account }
                };

                this.Execute(associateRequest);
            }, ("productComponentId", productComponentId), ("customerId", customerId));
        }

        #region Fetch data from CRM using Query expression

        // Get the PC platform status associated with Product components
        protected List<Guid>? GetPCPlatformStatusByProductComponent(Guid fiji_productcomponent)
        {
            return TraceOperation(nameof(GetPCPlatformStatusByProductComponent), () =>
            {
                List<Guid> lsPcPlatformStatus = new List<Guid>();

                QueryExpression query = new QueryExpression(EntityName.PCPlatformStatus)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.PCPlatformStatus.PlatformId)
                };

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.PCPlatformStatus.ProductComponentId, ConditionOperator.Equal, fiji_productcomponent);
                query.Criteria.AddFilter(filter);
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        if (tempentity.Contains(AttributeNames.PCPlatformStatus.PCPlatformStatusId))
                            lsPcPlatformStatus.Add(tempentity.GetAttributeValue<Guid?>(AttributeNames.PCPlatformStatus.PCPlatformStatusId).Value);
                    }

                    return lsPcPlatformStatus;
                }
                return null;
            }, ("productComponentId", fiji_productcomponent));
        }

        // Get the customer associated with Product components
        protected List<Guid>? GetCustomerAssociatedWithProductComponent(Guid fiji_productcomponent)
        {
            return TraceOperation(nameof(GetCustomerAssociatedWithProductComponent), () =>
            {
                List<Guid> lsCustomer = new List<Guid>();

                QueryExpression query = new QueryExpression(EntityName.ProductComponentAccount)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponentAccount.AccountId)
                };

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.ProductComponentAccount.ProductComponentId, ConditionOperator.Equal, fiji_productcomponent);
                query.Criteria.AddFilter(filter);
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        if (tempentity.Contains(AttributeNames.ProductComponentAccount.AccountId))
                            lsCustomer.Add(tempentity.GetAttributeValue<Guid>(AttributeNames.ProductComponentAccount.AccountId));
                    }

                    return lsCustomer;
                }
                return null;
            }, ("productComponentId", fiji_productcomponent));
        }

        // Get the fiji_fiji_productcomponentid
        protected string GetAutoGenProductComponentID(Guid recID)
        {
            return TraceOperation(nameof(GetAutoGenProductComponentID), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ParentProductComponentId)
                };

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.Equal, recID);
                query.Criteria.AddFilter(filter);
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.ProductComponent.ParentProductComponentId))
                        return entity.GetAttributeValue<string>(AttributeNames.ProductComponent.ParentProductComponentId);
                }

                return string.Empty;
            }, ("productComponentId", recID));
        }

        //Get servicecomplexity based on componenttypeid
        public string GetServiceComplexitybyComponentID(Guid recID)
        {
            return TraceOperation(nameof(GetServiceComplexitybyComponentID), () =>
            {
                // Create a QueryExpression for the "account" entity
                QueryExpression query = new QueryExpression(EntityName.ComponentType);
                query.ColumnSet = new ColumnSet(AttributeNames.ComponentType.ServiceComplexity);

                // Add filtering conditions
                query.Criteria.AddCondition(AttributeNames.ComponentType.ComponentTypeId, ConditionOperator.Equal, recID);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.ComponentType.ServiceComplexity))
                        return entity.GetAttributeValue<EntityReference>(AttributeNames.ComponentType.ServiceComplexity)?.Id.ToString();
                }
                return string.Empty;
            }, ("componentTypeId", recID));
        }

        internal ProductComponent? GetBy(Guid id)
        {
            return TraceOperation(nameof(GetBy), () =>
            {
                return ConvertEntityToModel(this.DataverseClient.Retrieve(EntityName.ProductComponent, id, new ColumnSet(AttributeNames.ProductComponent.ExternalId, AttributeNames.ProductComponent.Name, AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ParentProductComponentId)));
            }, ("productComponentId", id));
        }

        internal Entity? GetBy(string? externalId)
        {
            return TraceOperation(nameof(GetBy), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ProductComponent);
                query.PageInfo = new PagingInfo() { Count = 1, PageNumber = 1 };
                query.ColumnSet.AddColumns(AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ComponentType);
                query.Criteria.AddCondition(AttributeNames.ProductComponent.ExternalId, ConditionOperator.Equal, externalId);
                return this.DataverseClient.RetrieveMultiple(query).Entities.FirstOrDefault();
            }, ("externalId", externalId));
        }

        private Model.ProductComponent ConvertEntityToModel(Entity entity)
        {
            var pc = new ProductComponent()
            {
                Id = entity.Id,
                ExternalId = entity.GetValue<string>(AttributeNames.ProductComponent.ExternalId),
                Name = entity.GetValue<string>(AttributeNames.ProductComponent.Name),
                ServiceTypeGlobal = entity.GetValue<OptionSetValue>(AttributeNames.ProductComponent.ServiceTypeGlobal)?.Value,
                ProductComponentId = entity.GetValue<string>(AttributeNames.ProductComponent.ParentProductComponentId)
            };

            return pc;
        }

        // Get the fiji_fiji_productcomponentid
        protected Guid? GetComponentTypeByServiceNumber(string servicenumber)
        {
            return TraceOperation(nameof(GetComponentTypeByServiceNumber), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ComponentType)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.ComponentType.ComponentTypeId)
                };

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.ComponentType.ServiceNumber, ConditionOperator.Equal, servicenumber);
                filter.AddCondition(AttributeNames.ComponentType.StateCode, ConditionOperator.Equal, (int)eStateCode.Active);
                query.Criteria.AddFilter(filter);
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.ComponentType.ComponentTypeId))
                        return (Guid?)entity.GetAttributeValue<Guid>(AttributeNames.ComponentType.ComponentTypeId);
                }

                return (Guid?)null;
            }, ("serviceNumber", servicenumber));
        }

        // Get the fiji_servicetype
        public int? GetServiceTypeByComponent(string recID)
        {
            return TraceOperation(nameof(GetServiceTypeByComponent), () =>
            {
                // Create a QueryExpression for the "serviceType" flag
                QueryExpression query = new QueryExpression(EntityName.ComponentType)
                {
                    ColumnSet = new ColumnSet(AttributeNames.ComponentType.ServiceType)
                };

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.ComponentType.ComponentTypeId, ConditionOperator.Equal, recID);
                query.Criteria.AddFilter(filter);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.ComponentType.ServiceType))
                        return (int?)entity.GetAttributeValue<OptionSetValue>(AttributeNames.ComponentType.ServiceType)?.Value;
                }

                return (int?)null;
            }, ("componentTypeId", recID));
        }
        #endregion

        // get the Bios Configuration Details
        public async Task<HttpResponseMessage> GetBiosConfigDetails(Requests.ProductComponent.ProductComponent_GetBiosConfigDetails_Request request)
        {
            return await TraceOperationAsync(nameof(GetBiosConfigDetails), async () =>
            {
                if (request?.PlatformId == null)
                {
                    throw new Exception(Constants.ErrorMessages.NoPlatformId);
                }

                var urlCollection = await _fijiConfig.GetFijiConfigKeyValue(new List<string>() {
                                                                            Constants.AY103AV_API_BaseURL,
                                                                            Constants.AzureAccessScope
            });

                Uri TransformApiBaseUri = new Uri($"{urlCollection.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == Constants.AY103AV_API_BaseURL)?.GetAttributeValue<string>("fiji_value")}");
                string azureAccessScopeUrl = urlCollection.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == "AzureAccessScope")?.GetAttributeValue<string>("fiji_value") ?? null;

                using (HttpClient client = new())
                {
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Constants.UserAgentHeaderValue);
                    if (!string.IsNullOrEmpty(azureAccessScopeUrl))
                    {
                        string token = await Authentication.GetToken(azureAccessScopeUrl, new Azure.Identity.DefaultAzureCredential(), _memoryCache);
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    }
                    var url = $"{TransformApiBaseUri}get-configuration-detail?platformid={request.PlatformId}";
                    HttpResponseMessage response = await client.GetAsync(url);
                    return response;
                }
            }, ("platformId", request?.PlatformId));
        }

        public EntityCollection GetOverlayBy(Guid overlayPCId)
        {
            return TraceOperation(nameof(GetOverlayBy), () =>
            {
                EntityCollection entityCollection = new EntityCollection();
                QueryExpression queryOverlay = new QueryExpression(EntityName.ProductComponent)
                {
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ComponentType)
                };
                queryOverlay.Criteria.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.Equal, overlayPCId);
                queryOverlay.Criteria.AddCondition(AttributeNames.ProductComponent.StatusCode, ConditionOperator.Equal, (int)eStatusCode.Sustaining);
                var ct = queryOverlay.AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.Inner);
                ct.EntityAlias = "ct";
                ct.Columns.AddColumn(AttributeNames.ComponentType.ServiceNumber);
                EntityCollection resultPc = this.DataverseClient.RetrieveMultiple(queryOverlay);
                if (resultPc != null && resultPc.Entities.Count > 0)
                {
                    entityCollection.Entities.Add(resultPc.Entities[0]);
                    var ctTypeId = resultPc.Entities[0].GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType).Id;
                    //get generic service
                    QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                    {
                        ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ComponentType)
                    };
                    query.Criteria.AddCondition(AttributeNames.ProductComponent.ComponentType, ConditionOperator.Equal, ctTypeId);
                    query.Criteria.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, (int)eServiceTypeGlobal.GenericService);
                    query.Criteria.AddCondition(AttributeNames.ProductComponent.StatusCode, ConditionOperator.Equal, (int)eStatusCode.Sustaining);
                    var ct1 = query.AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.Inner);
                    ct1.EntityAlias = "ct";
                    ct1.Columns.AddColumn(AttributeNames.ComponentType.ServiceNumber);
                    EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                    if (result != null && result.Entities.Count > 0)
                    {
                        entityCollection.Entities.Add(result.Entities[0]);
                    }
                }
                return entityCollection;
            }, ("overlayProductComponentId", overlayPCId));
        }

        internal Entity? GetBy(Guid? productComponentId, string externalId)
        {
            return TraceOperation(nameof(GetBy), () =>
            {
                if (productComponentId == null)
                    return this.GetBy(externalId);
                else
                    return this.DataverseClient.Retrieve(EntityName.ProductComponent, productComponentId.Value, new ColumnSet(AttributeNames.ProductComponent.ServiceTypeGlobal));
            }, ("productComponentId", productComponentId), ("externalId", externalId));
        }

        public async Task<List<CustomerSpecificProductComponents>> GetCustomerSpecificProductComponents(string param)
        {
            return await TraceOperationAsync(nameof(GetCustomerSpecificProductComponents), async () =>
            {
                List<Model.CustomerSpecificProductComponents> returnValue = new();
                EntityCollection csAvCollection = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.GetSpecificPCFetchXmlBuilder(param));
                if (csAvCollection != null && csAvCollection.Entities.Count > 0)
                {
                    foreach (var item in csAvCollection.Entities)
                    {
                        returnValue.Add(new Model.CustomerSpecificProductComponents
                        {
                            Id = item.Id,
                            Name = Utils.GetValue<string>(item, "fiji_name"),
                            ExternalId = Utils.GetValue<string>(item, "fiji_externalid"),
                            PortalDescription = Utils.GetValue<string>(item, "fiji_portaldescription") ?? null,
                            Modifiedon = Utils.GetValue<string>(item, "modifiedon", true),
                            RequiredInfoMultiModel = (bool?)Utils.GetValue<AliasedValue>(item, "pccomponenttype.fiji_req_addit_info_multi_model")?.Value,
                            ProductComponentId = Utils.GetValue<string>(item, "fiji_fiji_productcomponentid")
                        });

                    }
                }
                return returnValue;
            }, ("payloadLength", param?.Length));
        }

        public async Task<List<CustomerSpecificProductComponents>> GetCustomerSpecificProductComponentsWithExtendedModels(string param)
        {
            return await TraceOperationAsync(nameof(GetCustomerSpecificProductComponentsWithExtendedModels), async () =>
            {
                var filteredcsAvIds = new List<Guid>();
                var allRecords = new List<CustomerSpecificProductComponents>();
                JObject jObj = JObject.Parse(param);

                // Retrieve the data as before
                EntityCollection csAvCollection = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.GetSpecificPCWithExtendedModelsFetchXmlBuilder(param));
                if (csAvCollection != null && csAvCollection.Entities.Count > 0)
                {
                    var pcIds = csAvCollection?.Entities?.Select(service => service.Id)?.Distinct().ToList();

                    // Filter out extended model PCs
                    EntityCollection filteredcsAvCollection = await retrieveMultipleBaseInfra.CallDynamicsRetrieveData(SqlQuery.GetPCbyPCIDandPCPlatformStatus(pcIds, jObj["platformId"].ToString()));
                    filteredcsAvIds = filteredcsAvCollection?.Entities?.Select(service => service.Id)?.Distinct().ToList();

                    foreach (var item in csAvCollection.Entities)
                    {
                        if (filteredcsAvIds != null && filteredcsAvIds.Contains(item.Id))
                        {
                            continue;
                        }
                        else
                        {
                            allRecords.Add(new Model.CustomerSpecificProductComponents
                            {
                                Id = item.Id,
                                Name = Utils.GetValue<string>(item, "fiji_name"),
                                ExternalId = Utils.GetValue<string>(item, "fiji_externalid"),
                                Modifiedon = Utils.GetValue<string>(item, "modifiedon", true),
                                RequiredInfoMultiModel = (bool?)Utils.GetValue<AliasedValue>(item, "pccomponenttype.fiji_req_addit_info_multi_model")?.Value,
                                PortalDescription = Utils.GetValue<string>(item, "fiji_portaldescription") ?? null,
                                ProductComponentId = Utils.GetValue<string>(item, "fiji_fiji_productcomponentid")
                            });
                        }
                    }
                }
                return allRecords;
            }, ("payloadLength", param?.Length));
        }

        public ComponentType? GetMoreSourceByProductComponentId(string productComponentId)
        {
            return TraceOperation(nameof(GetMoreSourceByProductComponentId), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.GetMoreSource)
                };

                query.AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.GetMoreSource, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.Inner);
                query.LinkEntities[0].EntityAlias = "getMoreSource";
                query.LinkEntities[0].Columns.AddColumns(AttributeNames.ComponentType.ComponentTypeId, AttributeNames.ComponentType.ServiceNumber, AttributeNames.ComponentType.IsMultiModel);

                // Add filtering conditions
                query.Criteria.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.Equal, productComponentId);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    ComponentType getMoreSource = new()
                    {
                        Id = entity.GetAttributeValue<EntityReference>("fiji_getmoresource")?.Id,
                        ServiceNumber = entity.GetAttributeValue<AliasedValue>("getMoreSource.fiji_servicenumber")?.Value?.ToString(),
                        IsMultiModel = ((bool?)entity.GetAttributeValue<AliasedValue?>("getMoreSource.fiji_ismultimodel")?.Value) ?? null,
                    };
                    return getMoreSource;
                }
                return null;
            }, ("productComponentId", productComponentId));
        }

        public UpdateRemoveAssociatedModelResponse RemoveAssociatedModel(ProductComponent_RemoveAssociatedModel removeAssociatedModel)
        {
            if (removeAssociatedModel?.PlatformId == null)
            {
                throw new Exception(Constants.ErrorMessages.NoPlatformId);
            }
            if (removeAssociatedModel?.ProductComponentId == null)
            {
                throw new Exception(Constants.ErrorMessages.NoProductComponentId);
            }

            UpdateRemoveAssociatedModelResponse response = new UpdateRemoveAssociatedModelResponse();

            this.BeginTransaction();
            //this._bomService.SetTransaction(this.Transaction);
            this._pcPlatformStatusService.SetTransaction(this.Transaction);

            //this._bomService.GetBomItemsByProductComponentId(removeAssociatedModel.ProductComponentId);
            this._pcPlatformStatusService.DeletePcPlatformStatus(removeAssociatedModel.ProductComponentId, removeAssociatedModel.PlatformId);
            this.CommitTransaction();

            this.BeginTransaction();
            this._serviceSnapshotService.SetTransaction(this.Transaction);
            this._platformAndPlacementService.SetTransaction(this.Transaction);

            dynamic serviceRevisionResult = this._serviceSnapshotService.CreateNewServiceRevisionForRemoveAssiociatedModel(removeAssociatedModel.ProductComponentId, removeAssociatedModel.PlatformId);
            Guid? oldServiceRevisionId = serviceRevisionResult.OldServiceRevisionId;
            Guid? newServiceRevisionId = serviceRevisionResult.NewServiceRevisionId;

            this._platformAndPlacementService.ReassociatePlatformPlacements(oldServiceRevisionId, newServiceRevisionId, removeAssociatedModel.PlatformId);
            this.CommitTransaction();

            response.Message = Constants.success;
            return response;
        }

        public async Task<UpdateClearComparisonModelResponse> ClearComparison(ProductComponent_ClearComparisonModel clearComparisonModel)
        {
            if (clearComparisonModel?.ProductComponentId == null)
            {
                throw new Exception(Constants.ErrorMessages.NoProductComponentId);
            }

            UpdateClearComparisonModelResponse response = new UpdateClearComparisonModelResponse();
            this.BeginTransaction();
            this._serviceSnapshotService.SetTransaction(this.Transaction);

            try
            {
                UpdateClearComparisonModelResponse result = this._serviceSnapshotService.GetAllServiceRevisionToClearCompareJSONByProductcomponent(clearComparisonModel.ProductComponentId);
                this.CommitTransaction();
                return await System.Threading.Tasks.Task.FromResult(result);
            }
            catch
            {
                throw;
            }
        }
        public ProductComponent_DuplicateV1Response DuplicateV1(ProductComponent_DuplicateV1_Request reqPayload)
        {
            return TraceOperation(nameof(DuplicateV1), () =>
            {
                if (string.IsNullOrWhiteSpace(reqPayload?.ProductComponentId))
                {
                    throw new Exception(Constants.ErrorMessages.NoProductComponentId);
                }
                if (string.IsNullOrWhiteSpace(reqPayload?.PortalUserId))
                {
                    throw new Exception(Constants.ErrorMessages.NoPortalUserId);
                }
                if (string.IsNullOrWhiteSpace(reqPayload?.Description))
                {
                    throw new Exception(Constants.ErrorMessages.NoDescription);
                }
                BeginTransaction();
                _pcPlatformStatusService.SetTransaction(this.Transaction);
                _serviceSnapshotService.SetTransaction(this.Transaction);
                _platformAndPlacementService.SetTransaction(this.Transaction);
                Guid? fiji_componenttypeid = null;
                Guid productComponentId;

                if (!Guid.TryParse(reqPayload.ProductComponentId, out productComponentId))
                {
                    throw new ArgumentException(Constants.ErrorMessages.InvalidProductComponentId);
                }
                // Get the latest service revision based on product component id
                ServiceSnapshot? LatestServiceRevision = _serviceSnapshotService.GetLatestServiceRevisionByProductcomponent(reqPayload.ProductComponentId, null);

                // Get the componentype based on questionnaire Screen
                if (LatestServiceRevision != null)
                {
                    var LasestServiceRevisionDtl = this.DataverseClient.Retrieve(EntityName.Servicesnapshot, LatestServiceRevision.Id.Value, new ColumnSet(AttributeNames.Servicesnapshot.ServiceDetailInJson));
                    string joncontent = LasestServiceRevisionDtl.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson);
                    if (!string.IsNullOrEmpty(joncontent))
                    {
                        JObject jObject = JObject.Parse(joncontent);
                        string questionnaireScreen = GetQuestionnaireNumberFromJSON(jObject);
                        if (!string.IsNullOrWhiteSpace(questionnaireScreen))
                        {
                            fiji_componenttypeid = GetComponentTypeByServiceNumber(questionnaireScreen).Value;
                        }
                    }
                    else
                    {
                        var retrievedProductComponent = this.DataverseClient.Retrieve(EntityName.ProductComponent, productComponentId, new ColumnSet(true));

                        if (retrievedProductComponent.Contains(AttributeNames.ProductComponent.GetMoreSource) && retrievedProductComponent.Attributes[AttributeNames.ProductComponent.GetMoreSource] != null)
                            fiji_componenttypeid = retrievedProductComponent.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.GetMoreSource).Id;
                        else if (retrievedProductComponent.Contains(AttributeNames.ProductComponent.ComponentType) && retrievedProductComponent.Attributes[AttributeNames.ProductComponent.ComponentType] != null)
                            fiji_componenttypeid = retrievedProductComponent.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType).Id;
                    }

                }
                string? componentType_ServiceNumber = fiji_componenttypeid.HasValue ? _componentTypeService.GetServiceNumberFromComponentId(fiji_componenttypeid.Value) : null;

                ProductComponent_DuplicateV1Response response = new ProductComponent_DuplicateV1Response();

                Entity copyFijiProductComponent = new Entity(EntityName.ProductComponent);
                var existingProductComponent = GetRequiredProductComponentFields(productComponentId);

                if (existingProductComponent != null)
                {
                    // Copy retrieved attributes
                    foreach (var attribute in existingProductComponent.Attributes)
                    {
                        copyFijiProductComponent[attribute.Key] = attribute.Value;
                    }
                }

                copyFijiProductComponent.Remove(AttributeNames.ProductComponent.ProductComponentId);
                copyFijiProductComponent.Id = Guid.NewGuid();
                copyFijiProductComponent[AttributeNames.ProductComponent.PortalContact] = Utils.GetEntityReference(EntityName.Contact, reqPayload.PortalUserId.ToString());
                copyFijiProductComponent[AttributeNames.ProductComponent.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, reqPayload.PortalUserId.ToString());
                if (fiji_componenttypeid != null)
                    copyFijiProductComponent[AttributeNames.ProductComponent.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, fiji_componenttypeid.Value.ToString());
                copyFijiProductComponent[AttributeNames.ProductComponent.Name] = reqPayload.Description;
                copyFijiProductComponent[AttributeNames.ProductComponent.PortalDescription] = reqPayload.Description;
                copyFijiProductComponent[AttributeNames.ProductComponent.HideFromPortal] = false;
                copyFijiProductComponent[AttributeNames.ProductComponent.DuplicatedFromPC] = productComponentId.ToString();
                Guid NewProductComponentId = copyFijiProductComponent.Id;
                //Get list of asscoited customer from copy product component
                List<Guid>? lsCustomer = GetCustomerAssociatedWithProductComponent(productComponentId);
                if (!IsPortalDescriptionUnique(reqPayload.Description, lsCustomer, canBeUsedAcrossCustomers: lsCustomer == null || lsCustomer.Count == 0))
                {
                    response.Error = Constants.ErrorMessages.DuplicatePortalDescription;
                    return response;
                }
                this.Execute(new CreateRequest { Target = copyFijiProductComponent });

                CommitTransaction();

                BeginTransaction();
                _pcPlatformStatusService.SetTransaction(this.Transaction);
                _serviceSnapshotService.SetTransaction(this.Transaction);
                _platformAndPlacementService.SetTransaction(this.Transaction);

                //Update Description and Portal Description of Product Component
                UpdatePortalDescriptionInProductComponent(reqPayload.Description, NewProductComponentId);

                if (lsCustomer != null && lsCustomer.Count > 0)
                {
                    foreach (var customer in lsCustomer)
                    {
                        AssociateProductComponentWithCustomer(copyFijiProductComponent.Id, customer);
                    }
                }

                // Check Associate Models
                bool isMultiModel = GetIsMultiModelByComponentTypeId(fiji_componenttypeid) ?? false;

                // Get the platform from PC Platfrom Status by product component
                List<Guid>? lspcplatformstatusid = GetPCPlatformStatusByProductComponent(productComponentId);

                if (isMultiModel)
                {
                    if (lspcplatformstatusid != null && lspcplatformstatusid.Count > 0)
                    {
                        foreach (var pcplatformstatusid in lspcplatformstatusid)
                        {
                            _pcPlatformStatusService.DuplicatePCPlatformStatus(pcplatformstatusid, copyFijiProductComponent.Id, reqPayload?.Description);
                        }
                    }
                }
                else
                {
                    if (lspcplatformstatusid != null && lspcplatformstatusid.Count > 0)
                    {
                        foreach (var pcplatformstatusid in lspcplatformstatusid)
                        {
                            _pcPlatformStatusService.DuplicatePCPlatformStatusandPlatformID(pcplatformstatusid, copyFijiProductComponent.Id, reqPayload?.PlatformId, reqPayload?.Description);
                        }
                    }
                }


                Guid? NewServicesnapshotID = null;
                string serviceDetailJson = string.Empty;
                string compareJSON = _serviceSnapshotService.CreateServiceRevisionOnDuplicateV1ProductComponent(productComponentId, reqPayload.PortalUserId, copyFijiProductComponent.Id, componentType_ServiceNumber, reqPayload.PlatformId, fiji_componenttypeid.Value, out NewServicesnapshotID, out serviceDetailJson);

                //var automationflag = GetAutomationFlag(componentType_ServiceNumber, fiji_componenttypeid, NewServicesnapshotID, serviceDetailJson);
                //UpdateAutomationFlagOnPC(copyFijiProductComponent.Id, automationflag);

                List<Guid>? lsPlacementandPlatformRec = _platformAndPlacementService.GetPlatformandPlacementByServiceRevision(LatestServiceRevision.Id, out _);

                if (isMultiModel && LatestServiceRevision != null)
                {
                    if (lsPlacementandPlatformRec != null)
                    {
                        foreach (var fiji_placementandplatfromID in lsPlacementandPlatformRec)
                        {
                            _platformAndPlacementService.CreatePlatformandPlacementForDuplicateProductComponent(NewServicesnapshotID, fiji_placementandplatfromID);
                        }
                    }
                }
                else
                {
                    if (lsPlacementandPlatformRec != null)
                    {
                        foreach (var fiji_placementandplatfromID in lsPlacementandPlatformRec)
                        {
                            _platformAndPlacementService.CreatePlatformandPlacementForDuplicateProductComponentWithPlatformId(NewServicesnapshotID, fiji_placementandplatfromID, reqPayload?.PlatformId);
                        }
                    }
                }

                CommitTransaction();
                BeginTransaction();
                var automationflag = GetAutomationFlag(componentType_ServiceNumber, fiji_componenttypeid, NewServicesnapshotID, serviceDetailJson);
                UpdateAutomationFlagOnPC(copyFijiProductComponent.Id, automationflag);
                CommitTransaction();
                response.NewProductComponentId = copyFijiProductComponent.Id.ToString();
                response.NewPCId = GetAutoGenProductComponentID(copyFijiProductComponent.Id);
                response.ChangedBIOS = compareJSON;
                return response;
            }, ("productComponentId", reqPayload?.ProductComponentId), ("portalUserId", reqPayload?.PortalUserId));
        }

        protected bool? GetIsMultiModelByComponentTypeId(Guid? componentTypeID)
        {
            return TraceOperation(nameof(GetIsMultiModelByComponentTypeId), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ComponentType)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.ComponentType.IsMultiModel)
                };

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.ComponentType.ComponentTypeId, ConditionOperator.Equal, componentTypeID);
                // filter.AddCondition(AttributeNames.ComponentType.StateCode, ConditionOperator.Equal, (int)eStateCode.Active);
                query.Criteria.AddFilter(filter);
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.ComponentType.IsMultiModel))
                        return (bool?)entity.GetAttributeValue<bool>(AttributeNames.ComponentType.IsMultiModel);
                }
                return (bool?)null;
            }, ("componentTypeId", componentTypeID));
        }

        public Entity GetRequiredProductComponentFields(Guid productComponentId)
        {
            return TraceOperation(nameof(GetRequiredProductComponentFields), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                {
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ServiceTypeGlobal,
                    AttributeNames.ProductComponent.AutomationFlag,
                    AttributeNames.ProductComponent.PortalDescription,
                    AttributeNames.ProductComponent.Name)
                };

                query.Criteria.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.Equal, productComponentId);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var productComponent = result.Entities[0];

                    return productComponent;
                }
                return null;
            }, ("productComponentId", productComponentId));
        }

        public void UpdatePortalDescriptionInProductComponent(string Description, Guid ProductComponentId)
        {
            TraceOperation<string?>(nameof(UpdatePortalDescriptionInProductComponent), () =>
            {
                string autogenproductcomponentid = "";
                autogenproductcomponentid = GetAutoGenProductComponentID(ProductComponentId);
                Entity fijiProductComponent = new Entity(EntityName.ProductComponent, ProductComponentId);
                StringBuilder strDescription = new StringBuilder();
                List<Guid>? lsCustomer = GetCustomerAssociatedWithProductComponent(ProductComponentId);
                if (!IsPortalDescriptionUnique(Description, lsCustomer, canBeUsedAcrossCustomers: lsCustomer == null || lsCustomer.Count == 0, ProductComponentId))
                {
                    return Constants.ErrorMessages.DuplicatePortalDescription;
                }
                if (!string.IsNullOrWhiteSpace(Description))
                {
                    strDescription.Append(Description);
                }
                if (!string.IsNullOrEmpty(autogenproductcomponentid))
                {
                    string[] productdescid = autogenproductcomponentid.Split(Constants.PC);
                    if (productdescid.Length == 2)
                    {
                        string value = productdescid[1];
                        string desc = strDescription.ToString();
                        if (desc.Contains(Constants.Copy)) // "-Copy" exists
                        {
                            int index = desc.IndexOf(Constants.Copy);
                            strDescription.Insert(index, "-" + value);
                        }
                        else
                        {
                            strDescription.Append("-");
                            strDescription.Append(value);
                            strDescription.Append(Constants.Copy);
                        }
                    }
                }
                fijiProductComponent[AttributeNames.ProductComponent.Name] = strDescription.ToString();
                fijiProductComponent[AttributeNames.ProductComponent.PortalDescription] = strDescription.ToString();
                this.Execute(new UpdateRequest { Target = fijiProductComponent });
                return null;
            }, ("productComponentId", ProductComponentId), ("description", Description));
        }

        public ProductComponent_HeaderDetails_Response GetHeaderDetails(ProductComponent_HeaderDetails_Request reqPayload)
        {
            try
            {
                ProductComponent_HeaderDetails_Response response = new ProductComponent_HeaderDetails_Response
                {
                    RequestIds = new List<string>(),
                    ModelsList = new List<string>()
                };

                if (reqPayload?.ProductComponentId == null)
                    return response;

                Guid productComponentId = reqPayload.ProductComponentId.Value;

                var productComponent = GetProductComponentDetails(productComponentId);

                if (productComponent != null)
                {
                    response.PartNumber = productComponent.GetAttributeValue<string>(AttributeNames.ProductComponent.ExternalId);

                    response.PortalDescription = productComponent.GetAttributeValue<string>(AttributeNames.ProductComponent.PortalDescription);

                    // Customer Name
                    if (reqPayload.CustomerId.HasValue)
                    {
                        response.CustomerName = _customer.GetCustomerNames(new List<Guid> { reqPayload.CustomerId.Value });
                    }
                    else
                    {
                        List<Guid>? lsCustomer = GetCustomerAssociatedWithProductComponent(productComponentId);

                        if (lsCustomer != null && lsCustomer.Count > 0)
                        {
                            response.CustomerName = _customer.GetCustomerNames(lsCustomer);
                        }
                    }
                }

                // Get the list of platformNames from PC Platfrom Status by product component
                response.ModelsList = _pcPlatformStatusService.GetAssociatedPlatformNamesByProductComponent(productComponentId);

                // Get the list of requestId's by Customer Id and ServiceRevision
                response.RequestIds = _bomService.GetRequestIdByCustomerIdAndServiceRevision(reqPayload);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error while fetching header details for Product Component Id : {reqPayload?.ProductComponentId}", ex);
            }
        }



        private Entity GetProductComponentDetails(Guid? productComponentId)
        {
            return TraceOperation(nameof(GetProductComponentDetails), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                {
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ExternalId,
                AttributeNames.ProductComponent.PortalDescription)
                };

                query.Criteria.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.Equal, productComponentId);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var productComponent = result.Entities[0];

                    return productComponent;
                }
                return null;
            }, ("productComponentId", productComponentId));
        }

        private eAutomationFlag GetAutomationFlag(string serviceNumber, Guid? componentId, Guid? NewServicesnapshotID, string jsoncontent)
        {
            return TraceOperation(nameof(GetAutomationFlag), () =>
            {
                eAutomationFlag automationFlag;
                JObject? jObject = null;
                if (!string.IsNullOrWhiteSpace(jsoncontent))
                {
                    jObject = JObject.Parse(jsoncontent);
                }

                if (string.Equals(serviceNumber, Constants.QuestionaireDetails.AY103AV, StringComparison.OrdinalIgnoreCase))
                {
                    automationFlag = eAutomationFlag.Automated;
                    // Rule  1 
                    bool isBCUSetting = jObject?[Constants.QuestionaireDetails.IsBCUSetting]?.Value<bool>() == true;

                    bool hasAdditionalInformation = !string.IsNullOrWhiteSpace(jObject?[Constants.QuestionaireDetails.AdditionalRequirements]?.ToString());

                    bool hasNonAutomatedBiosSetting = false;

                    var valueListToken = jObject?[Constants.QuestionaireDetails.ValueList];

                    if (valueListToken != null && valueListToken.Type == JTokenType.Array)
                    {
                        var idList = valueListToken.Select(v => v[Constants.QuestionaireDetails.ID]?.ToString()).Where(id => !string.IsNullOrWhiteSpace(id)).ToList();

                        if (idList.Any())
                        {
                            List<Guid> guidList = idList.Where(id => Guid.TryParse(id, out _)).Select(Guid.Parse).ToList();

                            var biosValueItems = GetBiosConfigurationLineAutomationValues(guidList);

                            if (biosValueItems != null && biosValueItems.Any())
                            {
                                hasNonAutomatedBiosSetting = biosValueItems.Any(x => x.Value == Constants.QuestionaireDetails.Zero);
                            }
                        }
                    }

                    if (isBCUSetting || hasAdditionalInformation || hasNonAutomatedBiosSetting)
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }
                }

                else if (string.Equals(serviceNumber, Constants.QuestionaireDetails.AY307AV, StringComparison.OrdinalIgnoreCase))
                {
                    automationFlag = eAutomationFlag.Automated;
                    //Rule 1 
                    bool isOtherSourceICT = jObject?[Constants.QuestionaireDetails.ImageCloningTool]?[Constants.QuestionaireDetails.SourceICT]?.ToString().Equals(Constants.QuestionaireDetails.Other, StringComparison.OrdinalIgnoreCase) == true;

                    bool hasApplicationsSelected = false;

                    var applicationsToken = jObject?[Constants.QuestionaireDetails.Applications];

                    if (applicationsToken != null && applicationsToken.Type == JTokenType.Array)
                    {
                        hasApplicationsSelected = applicationsToken.Any();
                    }

                    bool hasInvalidFileExtension = HasInvalidImageFileExtension(jsoncontent);

                    if ((hasInvalidFileExtension) || hasApplicationsSelected)
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }

                    //Rule 3 
                    bool hasAdditionalInformationText = !string.IsNullOrWhiteSpace(jObject?[Constants.QuestionaireDetails.additionalRequirements]?.ToString());

                    bool hasAdditionalInformationFile = jObject?[Constants.QuestionaireDetails.Files] is JArray filesArray && filesArray.Any();

                    if (hasAdditionalInformationFile || hasAdditionalInformationText)
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }

                    //Rule 2 
                    bool hasDriverSettings = !string.IsNullOrWhiteSpace(jObject?[Constants.QuestionaireDetails.HPPreferredAction]?.ToString());
                    bool hasOSSettingsFile = jObject?[Constants.QuestionaireDetails.OSSettingsFile] is JArray osSettingsFiles && osSettingsFiles.Any();
                    bool hasOSChangeRequirements = !string.IsNullOrWhiteSpace(jObject?[Constants.QuestionaireDetails.OSChangeRequirements]?.ToString());
                    bool isModifyHPSmartSupport = jObject?[Constants.QuestionaireDetails.IsModifyHPSmartSupport]?.Value<bool>() == true;
                    bool isTermsAndConditionAccepted = jObject?[Constants.QuestionaireDetails.IsTermsAndConditionAccepted]?.Value<bool>() == true;
                    bool isHPSureRecovery = jObject?[Constants.QuestionaireDetails.IsHPSureRecovery]?.Value<bool>() == true;

                    if (hasDriverSettings || hasOSSettingsFile || hasOSChangeRequirements ||
                            (isModifyHPSmartSupport && isTermsAndConditionAccepted) || isHPSureRecovery)
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }
                }

                else if (string.Equals(serviceNumber, Constants.QuestionaireDetails.AY802AV, StringComparison.OrdinalIgnoreCase))
                {
                    automationFlag = eAutomationFlag.Automated;
                    // Rule 1 
                    bool customizeSysPrepOOBE = string.Equals(jObject?[Constants.QuestionaireDetails.CustomizeSysPrepOOBE]?.ToString(), "true", StringComparison.OrdinalIgnoreCase);

                    //Rule 2 
                    bool hasRegistrySettings = string.Equals(jObject?[Constants.QuestionaireDetails.IsModifyRegistrySettings]?.ToString(), "true", StringComparison.OrdinalIgnoreCase);

                    // Rule 3 
                    bool isInstallSpecificVersion = jObject?[Constants.QuestionaireDetails.IsInstallTrialVersion]?.ToString().Equals(Constants.QuestionaireDetails.InstallSpecificVersion, StringComparison.OrdinalIgnoreCase) == true;
                    bool hasInstallTrialVersionFile = !string.IsNullOrWhiteSpace(jObject?[Constants.QuestionaireDetails.InstallTrialVersion]?.ToString());

                    //Rule 4 
                    bool customizeWinDesktopFile = false;
                    var token = jObject?[Constants.QuestionaireDetails.CustomizeWinDesktopFile];

                    if (token != null)
                    {
                        if (token.Type == JTokenType.Boolean)
                        {
                            customizeWinDesktopFile = token.Value<bool>();
                        }
                        else if (token.Type == JTokenType.String)
                        {
                            customizeWinDesktopFile = !string.IsNullOrWhiteSpace(token.ToString());
                        }
                    }

                    //Rule 5  
                    bool customizeWinStrtMenu = false;
                    var startMenuToken = jObject?[Constants.QuestionaireDetails.CustomizeWinStrtMenu];

                    if (startMenuToken != null)
                    {
                        if (startMenuToken.Type == JTokenType.Boolean)
                        {
                            customizeWinStrtMenu = startMenuToken.Value<bool>();
                        }
                        else if (startMenuToken.Type == JTokenType.String)
                        {
                            customizeWinStrtMenu = !string.IsNullOrWhiteSpace(startMenuToken.ToString());
                        }
                    }

                    if (customizeSysPrepOOBE || hasRegistrySettings || (isInstallSpecificVersion && !hasInstallTrialVersionFile) ||
                         customizeWinDesktopFile || customizeWinStrtMenu)
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }

                    //Rule 6 
                    bool isInstallRSAT = string.Equals(jObject?[Constants.QuestionaireDetails.IsInstallRSAT]?.ToString(), "true", StringComparison.OrdinalIgnoreCase);

                    //Rule 7 
                    bool hasRecoveryPartition = jObject?[Constants.QuestionaireDetails.Partitions] is JArray partitions && partitions.Any(x =>
                            x[Constants.QuestionaireDetails.PartitionType]?.ToString().Equals(Constants.QuestionaireDetails.RecoveryPartition, StringComparison.OrdinalIgnoreCase) == true);

                    //Rule 8 
                    bool hasImageSelected = jObject?[Constants.QuestionaireDetails.Image] is JArray images && images.Any();
                    bool hasApplicationSelected = jObject?[Constants.QuestionaireDetails.Applications] is JArray applications && applications.Any();
                    bool isImageXDISM = jObject?[Constants.QuestionaireDetails.ICTSource] is JArray ictSources && ictSources.Any(x =>
                                            x?.ToString().Equals(Constants.QuestionaireDetails.ImageX, StringComparison.OrdinalIgnoreCase) == true);
                    bool isBCD = jObject?[Constants.QuestionaireDetails.IsBCD]?.ToString().Equals(Constants.QuestionaireDetails.Yes, StringComparison.OrdinalIgnoreCase) == true;

                    if (isInstallRSAT || hasRecoveryPartition || hasImageSelected || hasApplicationSelected || (isImageXDISM && isBCD))
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }

                    //Rule 9 
                    bool hasPPKGSelected = jObject?[Constants.QuestionaireDetails.PPKG] is JArray ppkgArray && ppkgArray.Any();

                    //Rule 10 
                    bool hasAdditionalRequirements = jObject?[Constants.QuestionaireDetails.MyRequirements] is JArray myRequirementsArray && myRequirementsArray.Any();

                    //Rule 11 
                    bool hasAdditionalInformationText = !string.IsNullOrWhiteSpace(jObject?[Constants.QuestionaireDetails.additionalRequirements]?.ToString());
                    bool hasAdditionalInformationFiles = jObject?[Constants.QuestionaireDetails.Files] is JArray files && files.Any();

                    if (hasPPKGSelected || hasAdditionalRequirements || hasAdditionalInformationText || hasAdditionalInformationFiles)
                    {
                        automationFlag = eAutomationFlag.Manual;
                    }
                }
                else
                {
                    var AutomationValue = componentId.HasValue ? GetServiceTypeByComponent(componentId.Value.ToString()) : null;
                    automationFlag = AutomationValue.HasValue ? (eAutomationFlag)AutomationValue.Value : eAutomationFlag.Manual;
                }

                return automationFlag;
            }, ("serviceNumber", serviceNumber), ("componentId", componentId), ("NewServicesnapshotID", NewServicesnapshotID));
        }

        //Update Automation Flag on Product Component
        public void UpdateAutomationFlagOnPC(Guid? productComponentId, eAutomationFlag automationFlag)
        {
            TraceOperation(nameof(UpdateAutomationFlagOnPC), () =>
            {
                if (productComponentId != null)
                {
                    Entity fijiProductComponent = new Entity(EntityName.ProductComponent, productComponentId.Value);
                    fijiProductComponent[AttributeNames.ProductComponent.AutomationFlag] = new OptionSetValue((int)automationFlag);
                    this.Execute(new UpdateRequest { Target = fijiProductComponent });
                }
            }, ("productComponentId", productComponentId), ("automationFlag", automationFlag));
        }

        private List<ValueItem> GetBiosConfigurationLineAutomationValues(List<Guid> biosConfigLineIds)
        {
            return TraceOperation(nameof(GetBiosConfigurationLineAutomationValues), () =>
            {

                if (biosConfigLineIds == null || biosConfigLineIds.Count == 0)
                    return new List<ValueItem>();

                var distinctIds = biosConfigLineIds.Distinct().ToList();

                QueryExpression query = new QueryExpression(EntityName.BIOSConfigurationLine)
                {
                    ColumnSet = new ColumnSet(BIOSConfigurationLine.BIOSConfigurationLineId, BIOSConfigurationLine.IsAutomated),
                    NoLock = true
                };

                query.Criteria.AddCondition(BIOSConfigurationLine.BIOSConfigurationLineId, ConditionOperator.In, distinctIds.Cast<object>().ToArray());

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                if (result?.Entities == null || result.Entities.Count == 0)
                    return new List<ValueItem>();

                return result.Entities.Where(e => e.Id != Guid.Empty)
                                        .Select(e => new ValueItem
                                        {
                                            Id = e.Id,
                                            Value = e.GetAttributeValue<bool?>(Convert.ToString(BIOSConfigurationLine.IsAutomated)) == true ? "1" : "0"
                                        }).ToList();
            }, ("biosConfigLineIds Count", biosConfigLineIds.Count));
        }

        private bool HasInvalidImageFileExtension(string serviceDetailInJson)
        {
            return TraceOperation(nameof(HasInvalidImageFileExtension), () =>
            {
                JObject jObject = JObject.Parse(serviceDetailInJson);

                List<Guid> imageIdList = new List<Guid>();

                var imageToken = jObject?["image"];

                if (imageToken != null && imageToken.Type == JTokenType.Array)
                {
                    imageIdList = imageToken
                        .Select(x => x["imageId"]?.ToString())
                        .Where(x => Guid.TryParse(x, out _))
                        .Select(Guid.Parse)
                        .Distinct()
                        .ToList();
                }

                if (!imageIdList.Any())
                {
                    return false;
                }

                QueryExpression query = new QueryExpression(EntityName.PortalManagementInfo)
                {
                    ColumnSet = new ColumnSet(PortalManagementInfo.PortalManagementInfoId, PortalManagementInfo.FileName),
                    NoLock = true
                };

                query.Criteria.AddCondition(PortalManagementInfo.PortalManagementInfoId, ConditionOperator.In, imageIdList.Cast<object>().ToArray());

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                List<string> fileNames = result.Entities.Select(x => x.GetAttributeValue<string>(PortalManagementInfo.FileName))
                                                                    .Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
                var imageExtensions = new[] { ".wim", ".swm", ".gho", ".ghs", ".zip", ".ffu" }
                                  .Concat(Enumerable.Range(1, 999).Select(i => $".{i:D3}"))
                                  .ToHashSet(StringComparer.OrdinalIgnoreCase);

                bool hasInvalidExtension = result.Entities.Any(entity =>
                {
                    string fileName = entity.GetAttributeValue<string>(PortalManagementInfo.FileName);

                    if (string.IsNullOrWhiteSpace(fileName))
                    {
                        return false;
                    }

                    string extension = Path.GetExtension(fileName);

                    return !imageExtensions.Contains(extension);
                });

                return hasInvalidExtension;
            }, ("HasServiceDetailInJson", !string.IsNullOrWhiteSpace(serviceDetailInJson)));
        }

        protected bool IsPortalDescriptionUnique(string rawDescription, IEnumerable<Guid>? customerIds, bool canBeUsedAcrossCustomers, Guid? excludeProductComponentId = null)
        {
            return TraceOperation(nameof(IsPortalDescriptionUnique), () =>
            {
                if (string.IsNullOrWhiteSpace(rawDescription)) return true;
                var query = new QueryExpression(EntityName.ProductComponent) { ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ProductComponentId) };
                var filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.ProductComponent.PortalDescription, ConditionOperator.Equal, rawDescription.Trim());
                filter.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, (int)eServiceTypeGlobal.CustomerSpecific);
                filter.AddCondition(AttributeNames.ProductComponent.StateCode, ConditionOperator.Equal, (int)eStateCode.Active);
                if (excludeProductComponentId.HasValue)
                    filter.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.NotEqual, excludeProductComponentId.Value);
                query.Criteria.AddFilter(filter);
                var matches = this.DataverseClient.RetrieveMultiple(query);
                if (matches?.Entities.Count is null or 0) return true;
                var newCustomers = customerIds?.ToList() ?? new List<Guid>();
                foreach (var match in matches.Entities)
                {
                    var matchCustomers = GetCustomerAssociatedWithProductComponent(match.Id);
                    if (matchCustomers == null || matchCustomers.Count == 0) return false;
                    if (canBeUsedAcrossCustomers) return false;
                    if (newCustomers.Any(c => matchCustomers.Contains(c))) return false;
                }
                return true;
            }, ("rawDescription", rawDescription));
        }

        public ProductComponentResponse CreateNewService(ProductComponentRequest productComponentRequest)
        {
            return TraceOperation(nameof(CreateNewService), () =>
            {
                ProductComponentResponse productComponentResponse = new ProductComponentResponse();
                if (!string.IsNullOrWhiteSpace(productComponentRequest.ServiceDescription) && !IsPortalDescriptionUnique(productComponentRequest.ServiceDescription, Guid.TryParse(productComponentRequest.CustomerId, out var custId) ? new[] { custId } : null, productComponentRequest.CanBeUsedAcrossCustomers))
                {
                    productComponentResponse.Error = Constants.ErrorMessages.DuplicatePortalDescription;
                    return productComponentResponse;
                }
                this.BeginTransaction();
                this._PCBiosRevision.SetTransaction(this.Transaction);
                this._pcPlatformStatusService.SetTransaction(this.Transaction);
                this._serviceSnapshotService.SetTransaction(this.Transaction);
                this._platformAndPlacementService.SetTransaction(this.Transaction);
                this.StatusCode = (int)eStatusCode.New;
                this.StateCode = (int)eStateCode.Active;
                this.ServiceTypeGlobal = (int)eServiceTypeGlobal.CustomerSpecific;
                this.HideFromPortal = false;
                if (!string.IsNullOrEmpty(productComponentRequest.PortalUserId))
                {
                    this.PortalContact = productComponentRequest.PortalUserId;
                }
                Entity fijiProductComponent = new Entity(EntityName.ProductComponent);
                fijiProductComponent.Id = Guid.NewGuid();
                this.Id = fijiProductComponent.Id;
                fijiProductComponent[AttributeNames.ProductComponent.StatusCode] = new OptionSetValue(this.StatusCode.Value);
                fijiProductComponent[AttributeNames.ProductComponent.StateCode] = new OptionSetValue(this.StateCode.Value);
                fijiProductComponent[AttributeNames.ProductComponent.ServiceTypeGlobal] = new OptionSetValue(this.ServiceTypeGlobal.Value);
                fijiProductComponent[AttributeNames.ProductComponent.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, productComponentRequest.ComponentTypeId);
                fijiProductComponent[AttributeNames.ProductComponent.HideFromPortal] = false;
                if (!string.IsNullOrEmpty(productComponentRequest.PortalUserId))
                {
                    fijiProductComponent[AttributeNames.ProductComponent.PortalContact] = Utils.GetEntityReference(EntityName.Contact, this.PortalContact);
                }
                this.Execute(new CreateRequest { Target = fijiProductComponent });
                this._PCBiosRevision.CreatePCBiosRevisionOnNewProductComponent(productComponentRequest, this.Id);
                AssociateCustomerWithProductComponent(productComponentRequest);
                Guid? pcPlatformStatusId;
                this._pcPlatformStatusService.CreatePCPlatformStatusOnNewProductComponent(productComponentRequest, this.Name, this.Id, (int)PCPlatformStatus.eStatusCode.Draft, out pcPlatformStatusId);
                Guid? newServiceSnapShotId;
                string serviceRevisionVersion;
                this._serviceSnapshotService.CreateServiceRevisionForNewService(this.Id.Value, productComponentRequest.ComponentTypeId, productComponentRequest.PortalUserId, out newServiceSnapShotId, out serviceRevisionVersion);
                Guid? newPlacementId;
                this._platformAndPlacementService.CreatePlatformAndPlacementForNewService(productComponentRequest.ModelId, productComponentRequest.ModelName, newServiceSnapShotId, out newPlacementId);
                CommitTransaction();
                BeginTransaction();
                this._pcPlatformStatusService.SetTransaction(this.Transaction);
                string pcNumber;
                UpdateProductComponentDescription(productComponentRequest, out pcNumber);   // ServiceDescription + PC ID branch 
                this._pcPlatformStatusService.UpdatePCPlatformStatusDescription(this.Name, pcPlatformStatusId, productComponentRequest.ModelName);
                CommitTransaction();
                if (this.Id != Guid.Empty)
                {
                    productComponentResponse.ProductComponent = this.GetBy(this.Id.Value);
                }
                if (newServiceSnapShotId != null)
                {
                    productComponentResponse.ServiceRevision = _serviceSnapshotService.GetBy(newServiceSnapShotId.Value);
                }
                return productComponentResponse;
            }, ("ProductComponentRequest", productComponentRequest));
        }
    }
}
