﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class PlatformRegionLocale : Base<PlatformRegionLocale>
    {
        public string? Name { get; set; }
        public Guid? Id { get; set; }
        public RegionLocale? Localization { get; set; }

        public PlatformRegionLocale(): base("platformregionlocale") { }
        public PlatformRegionLocale(IOrganizationService dataverseClient) : base(dataverseClient, "platformregionlocale")
        {

        }
    }
}
