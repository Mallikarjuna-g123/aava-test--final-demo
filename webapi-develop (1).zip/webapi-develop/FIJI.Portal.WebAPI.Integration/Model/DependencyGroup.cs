﻿namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class DependencyGroup
    {
        public string? ctId { get; set; }
        public string? groupCondition { get; set; }
        public List<DependencyGroupItem>? dependentItems { get; set; }
    }
}
