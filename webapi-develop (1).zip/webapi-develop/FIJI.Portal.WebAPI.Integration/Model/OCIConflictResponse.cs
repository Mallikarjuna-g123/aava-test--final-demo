﻿using Newtonsoft.Json;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class OCIConflictResponse
    {
        [JsonProperty("status")]
        public string Status { get; set; } = string.Empty;

        [JsonProperty("conflicts")]
        public List<OCIConflictItem> Conflicts { get; set; } = new List<OCIConflictItem>();

        [JsonProperty("originalMessage")]
        public string? OriginalMessage { get; set; }
    }

    public class OCIConflictItem
    {
        [JsonProperty("partNo")]
        public string PartNo { get; set; } = string.Empty;

        [JsonProperty("chaDes")]
        public string ChaDes { get; set; } = string.Empty;
    }
}