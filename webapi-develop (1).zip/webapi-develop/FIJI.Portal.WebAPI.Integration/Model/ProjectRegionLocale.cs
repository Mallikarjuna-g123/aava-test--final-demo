﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ProjectRegionLocale : Base<ProjectRegionLocale>
    {
        public ProjectRegionLocale(IOrganizationService dataverseClient) : base(dataverseClient, "projectregionlocale") { }
    }
}
