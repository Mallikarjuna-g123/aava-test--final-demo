﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class FijiFactory : Base<FijiFactory>
    {
        public FijiFactory(IOrganizationService dataverseClient) : base(dataverseClient, "fijifactory")
        {

        }
    
    }
}
