﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class RegionLocale : Base<RegionLocale>
    {
        public string? Name { get; set; }
        public Guid? Id { get; set; }
        public string? LocalizationName { get; set; }
        public string? LocalizationCode { get; set; }
        public RegionLocale(): base("regionlocale") { }
        public RegionLocale(IOrganizationService dataverseClient) : base(dataverseClient, "regionlocale")
        {

        }
    }
}
