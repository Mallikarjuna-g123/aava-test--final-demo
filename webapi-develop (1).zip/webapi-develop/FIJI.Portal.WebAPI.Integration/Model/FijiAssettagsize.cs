﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class FijiAssettagsize : Base<FijiAssettagsize>
    {
        public FijiAssettagsize() : base("fijiassettagsize")        {}

        public FijiAssettagsize(IOrganizationService dataverseClient, ILogger<FijiAssettagsize>? logger = null) : base(dataverseClient, "fijiassettagsize")
        { }

        public Guid GetByLabelSize(string labelSize)
        {
            return TraceOperation(nameof(GetByLabelSize), () =>
            {
                Guid pcId = new Guid();
                QueryExpression query = new QueryExpression(EntityName.FijiAssetTagSize)
                {
                    ColumnSet = new ColumnSet(FijiAssetTagSize.FijiAssetTagSizeId, FijiAssetTagSize.ProductComponent, FijiAssetTagSize.Name),
                    PageInfo = new PagingInfo() { Count = 1, PageNumber = 1 }
                };
                query.Criteria.AddCondition(FijiAssetTagSize.Name, ConditionOperator.Equal, labelSize);
                query.Criteria.AddCondition(FijiAssetTagSize.StateCode, ConditionOperator.Equal, 0); // Active (0) records only
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    pcId = result.Entities[0].GetAttributeValue<EntityReference>(FijiAssetTagSize.ProductComponent).Id;
                }
                return pcId;
            }, ("labelSize", labelSize));
        }
    }
}
