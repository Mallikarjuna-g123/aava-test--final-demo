﻿using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Bookings : Base<Bookings>
    {
        private readonly Bookings? _bookingService;

        public Bookings() : base("bookings") { }

        public Bookings(IOrganizationService dataverseClient, ILogger<Bookings>? logger = null) : base(dataverseClient, "bookings", logger)
        { }

        public FactoryDashboardBookings TaskConditionalQuery(BookingRequest request)
        {
            return TraceOperation(nameof(TaskConditionalQuery), () =>
            {
                FactoryDashboardBookings response = new();
                List<KeyValuePair<string, int>> timeZoneList = Utils.TimeZoneList(DataverseClient);
                var startDate = "";
                var endDate = "";
                if (request?.Filter?.StartDate != null && request?.Filter?.EndDate != null)
                {
                    startDate = Utils.GetConvertedTimeSourceToUTC(request.TimeZone, request.Filter.StartDate, timeZoneList);
                    endDate = Utils.GetConvertedTimeSourceToUTC(request.TimeZone, request.Filter.EndDate, timeZoneList);
                }
            
                QueryExpression query = new()
                {
                    EntityName = EntityName.Bookings,
                    ColumnSet = new ColumnSet(AttributeNames.Bookings.BookableResourceId, AttributeNames.Bookings.StartTime, AttributeNames.Bookings.EndTime, AttributeNames.Bookings.Duration,
                    AttributeNames.Bookings.Attended, AttributeNames.Bookings.Comments, AttributeNames.Bookings.Resource, AttributeNames.Bookings.ModifiedOn, AttributeNames.Bookings.CreatedOn),
                    PageInfo = new PagingInfo()
                    {
                        Count = request?.Page?.PageSize ?? 20,
                        PageNumber = request?.Page?.PageNumber ?? 1,
                        ReturnTotalRecordCount = true
                    }
                };
                var order = request?.Sort?.SortOrder == (int)OrderType.Ascending ? OrderType.Ascending : OrderType.Descending;
                if (request?.Sort?.ColumnName == AttributeNames.Bookings.StartTime || request?.Sort?.ColumnName == AttributeNames.Bookings.BookableResourceId || request?.Sort?.ColumnName == AttributeNames.Bookings.EndTime
                  || request?.Sort?.ColumnName == AttributeNames.Bookings.Duration || request?.Sort?.ColumnName == AttributeNames.Bookings.Comments
                  || request?.Sort?.ColumnName == AttributeNames.Bookings.Attended || request?.Sort?.ColumnName == AttributeNames.Bookings.Resource || request?.Sort?.ColumnName == AttributeNames.Bookings.CreatedOn)
                {
                    query.AddOrder(request.Sort.ColumnName, order);
                }
                query.Distinct = true;
                //based on Booking Status
                if (request?.Tab == Constants.Committed)
                {
                    query.Criteria.AddCondition(AttributeNames.Bookings.StartTime, ConditionOperator.GreaterEqual, DateTime.Now);
                    query.Criteria.AddCondition(AttributeNames.Bookings.StartTime, ConditionOperator.LessEqual, DateTime.Now.AddMonths(3));
                }

                if (request?.Tab == Constants.Completed)
                {
                    query.Criteria.AddCondition(AttributeNames.Bookings.ModifiedOn, ConditionOperator.GreaterEqual, DateTime.Now.AddDays(-7));
                    query.Criteria.AddCondition(AttributeNames.Bookings.ModifiedOn, ConditionOperator.LessEqual, DateTime.Now);
                }

                var filter = request?.Filter;

                if (filter?.Attended != null)
                {
                    query.Criteria.AddCondition(AttributeNames.Bookings.Attended, ConditionOperator.Equal, filter.Attended);
                }

                if (filter?.StartDate != null && filter.EndDate != null)
                {
                    query.Criteria.AddCondition(AttributeNames.Bookings.StartTime, ConditionOperator.GreaterEqual, Convert.ToDateTime(startDate));
                    query.Criteria.AddCondition(AttributeNames.Bookings.StartTime, ConditionOperator.LessEqual, Convert.ToDateTime(endDate));
                }

                // link entities
                query.LinkEntities.Add(new LinkEntity(EntityName.Bookings, EntityName.BookableResource, AttributeNames.Bookings.Resource, AttributeNames.BookableResource.BookableResourceId, JoinOperator.Inner));
                query.LinkEntities[0].Columns.AddColumn(AttributeNames.BookableResource.BookableResourceId);// here the colums will come from bookable resource
                query.LinkEntities[0].EntityAlias = "bookableResource";
                query.LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.BookableResource, EntityName.FijiFactory, AttributeNames.BookableResource.Factory, AttributeNames.FijiFactory.FactoryId, JoinOperator.Inner));
                query.LinkEntities[0].LinkEntities[0].Columns.AddColumns(AttributeNames.FijiFactory.FactoryId, AttributeNames.FijiFactory.FactoryTeam);
                if (!string.IsNullOrEmpty(request?.Filter?.Factory))
                    query.LinkEntities[0].LinkEntities[0].LinkCriteria.AddCondition(AttributeNames.FijiFactory.FactoryId, ConditionOperator.Equal, request?.Filter?.Factory);

                query.LinkEntities[0].LinkEntities[0].EntityAlias = "factory";
                query.LinkEntities[0].LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.FijiFactory, EntityName.Team, AttributeNames.FijiFactory.FactoryTeam, AttributeNames.Team.TeamId, JoinOperator.Inner));
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].Columns.AddColumn(AttributeNames.Team.TeamId);
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].EntityAlias = "team";
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.Team, EntityName.FijiTeamContact, AttributeNames.Team.TeamId, AttributeNames.FijiTeamContact.TeamId, JoinOperator.Inner));
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].Columns.AddColumns(AttributeNames.FijiTeamContact.TeamId, AttributeNames.FijiTeamContact.ContactId);
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].EntityAlias = "fiji_team_contact";
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.FijiTeamContact, EntityName.Contact, AttributeNames.FijiTeamContact.ContactId, AttributeNames.Contact.ContactId, JoinOperator.Inner));
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].Columns.AddColumns(AttributeNames.Contact.ContactId);
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].EntityAlias = "contact";

                query.LinkEntities.Add(new LinkEntity(EntityName.Bookings, EntityName.BookingStatus, AttributeNames.Bookings.BookingStatus, AttributeNames.BookingStatus.BookingStatusId, JoinOperator.Inner));
                query.LinkEntities[1].Columns.AddColumns(AttributeNames.BookingStatus.BookingStatusId, AttributeNames.BookingStatus.Name);
                query.LinkEntities[1].EntityAlias = "bookingStatus";

                query.LinkEntities.Add(new LinkEntity(EntityName.Bookings, EntityName.Project, AttributeNames.Bookings.ProjectId, AttributeNames.Project.ProjectId, JoinOperator.LeftOuter));
                query.LinkEntities[2].Columns.AddColumns(AttributeNames.Project.ProjectId, AttributeNames.Project.Name, AttributeNames.Project.CustomerId, AttributeNames.Project.ProjectOriginatingRegionId);
                if (request?.Sort?.ColumnName == AttributeNames.Project.Name || request?.Sort?.ColumnName == AttributeNames.Project.CustomerId)
                {
                    query.LinkEntities[2].Orders.Add(new OrderExpression(request.Sort.ColumnName, order));
                }
                query.LinkEntities[2].EntityAlias = "project";

                //condition
                FilterExpression filtercontactid = new FilterExpression(LogicalOperator.And);
                filtercontactid.AddCondition(AttributeNames.Contact.ContactId, ConditionOperator.Equal, request?.Contact);
                query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkCriteria.AddFilter(filtercontactid);

                FilterExpression filterBookingStatus = new FilterExpression(LogicalOperator.And);
                filterBookingStatus.AddCondition(AttributeNames.BookingStatus.Name, ConditionOperator.Equal, request?.Tab);
                query.LinkEntities[1].LinkCriteria.AddFilter(filterBookingStatus);

                //based on Booking Status
                if (request?.Tab == Constants.Committed)
                {
                    OrderExpression modifiedOrder = new()
                    {
                        EntityName = EntityName.Bookings,
                        AttributeName = AttributeNames.Bookings.StartTime,
                        OrderType = OrderType.Ascending
                    };
                    query.Orders.Add(modifiedOrder);
                }

                if (request?.Tab == Constants.Completed)
                {
                    OrderExpression modifiedOrder = new()
                    {
                        EntityName = EntityName.Bookings,
                        AttributeName = AttributeNames.Bookings.ModifiedOn,
                        OrderType = OrderType.Descending
                    };
                    query.Orders.Add(modifiedOrder);
                }

                // result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                EntityCollection competeEntityresult = Utils.RetrieveCompleteRecords(query, this.DataverseClient);
                int Totalrecordscounts = 0;
                if (competeEntityresult != null)
                    Totalrecordscounts = competeEntityresult.Entities.Count;
                List<BookingResponse> bookingResponse = new();
            
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        BookingResponse newBooking = new()
                        {
                            Id = ((Guid?)tempentity.GetAttributeValue<Guid?>("bookableresourcebookingid")) ?? null,
                            ProjectId = ((string?)tempentity.GetAttributeValue<AliasedValue?>("project.fiji_name")?.Value).ToString() ?? null,
                            Fiji_customername = ((EntityReference?)tempentity.GetAttributeValue<AliasedValue?>("project.fiji_customerid")?.Value).Name ?? null,

                            CreatedOn = Utils.GetConvertedTimeUtcToTarget(request.TimeZone, Utils.ConvertDateMinValue(tempentity.GetAttributeValue<DateTime>("createdon")), timeZoneList),
                            Duration = ((int?)tempentity.GetAttributeValue<int?>("duration")) ?? null,
                            Start = Utils.GetConvertedTimeUtcToTarget(request.TimeZone, Utils.ConvertDateMinValue(tempentity.GetAttributeValue<DateTime>("starttime")), timeZoneList),
                            End = Utils.GetConvertedTimeUtcToTarget(request.TimeZone, Utils.ConvertDateMinValue(tempentity.GetAttributeValue<DateTime>("endtime")), timeZoneList),
                            Attended = tempentity.GetAttributeValue<bool>("fiji_attended"),
                            Comments = ((string?)tempentity.GetAttributeValue<string?>("fiji_comments")?.ToString()) ?? null,
                            TestBench = ((string?)tempentity.GetAttributeValue<EntityReference?>("resource")?.Name).ToString() ?? null

                        };

                        if (tempentity.Contains("project.fiji_projectoriginatingregionid"))
                            newBooking.Fiji_kvmkeyboard = this.GetKVMKeyBoard(Utils.GetValue<AliasedValue>(tempentity, "project.fiji_projectoriginatingregionid")?.Value as EntityReference);

                        bookingResponse.Add(newBooking);
                    }
                }
                response.Bookings = bookingResponse;
                response.TotalCount = Totalrecordscounts;
                return response;
            }, ("tab", request?.Tab), ("hasFilter", request?.Filter != null), ("pageNumber", request?.Page?.PageNumber), ("pageSize", request?.Page?.PageSize));
        }

        private string GetKVMKeyBoard(EntityReference? value)
        {
            if (value?.Name == Constants.EMEA)
                return Constants.UK;

            return Constants.US;
        }

        public FactoryDashboardBookings GetFactoryDasboardBookings(BookingRequest request)
        {
            return TraceOperation(nameof(GetFactoryDasboardBookings), () =>
            {
                FactoryDashboardBookings response = new FactoryDashboardBookings();
                response = TaskConditionalQuery(request);
                return response;
            }, ("tab", request?.Tab));
        }
    }
}