﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class DeviceCategory : Base<DeviceCategory>
    {
        public string? Name { get; set; }
        public Guid? Id { get; set; }

        public string? Iconurl { get; set; }
        public DeviceCategory() : base("devicecategory") { }
        public DeviceCategory(IOrganizationService dataverseClient) : base(dataverseClient, "devicecategory")
        {

        }
    }
}
