﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class FijiConfiguration : Base<FijiConfiguration>
    {
        public FijiConfiguration() : base("fijiconfiguration") { }


        public FijiConfiguration(IOrganizationService dataverseClient, ILogger<FijiConfiguration>? logger = null) : base(dataverseClient, "fijiconfiguration")
        { }


        public async Task<EntityCollection> GetFijiConfigKeyValue(List<string> key)
        {
            return await TraceOperationAsync(nameof(GetFijiConfigKeyValue), async () =>
            {
                var query = new QueryExpression(EntityName.FijiConfiguration)
                {
                    ColumnSet = new ColumnSet(AttributeNames.FijiConfiguration.Value, AttributeNames.FijiConfiguration.Key)
                };
                query.Criteria.AddCondition(AttributeNames.FijiConfiguration.Key, ConditionOperator.In, key.ToArray());
                return await Task.FromResult(DataverseClient.RetrieveMultiple(query));
            }, ("keyCount", key?.Count));
        }
    }
}
