﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Team: Base<Team>
    {
        public Team(IOrganizationService dataverseClient) : base(dataverseClient, "teams")
        {

        }
    }
}
