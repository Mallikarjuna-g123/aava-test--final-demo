﻿using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
using static FIJI.Portal.WebAPI.Integration.Model.ProductComponent;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class BOM : Base<BOM>
    {

        private readonly ActionCode? _actionCode;
        private ServiceSnapshot _serviceSnapshotService;
        private ComponentType? _componentType;
        private readonly IMemoryCache? memoryCache;

        public Guid? Id { get; set; }
        public Guid? ProductComponentId { get; set; }
        public int Type { get; set; }
        public string? ComponentTypeServiceNumber { get; set; }
        public bool CameFromOCI { get; set; }
        public int Quantity { get; set; }   

        public string? Comments { get; set; }

        public Guid ProjectId { get; set; }
        public ProductComponent? ProductComponent { get; set; }
        public ServiceSnapshot? ServiceRevision { get; set; }

        public BOM() : base("bom", NullLogger<BOM>.Instance) { }
        
        public BOM(IOrganizationService dataverseClient, IMemoryCache cache, ILogger<BOM>? logger = null, ILoggerFactory? loggerFactory = null) : base(dataverseClient, "bom", logger)
        {
            _actionCode = new ActionCode(dataverseClient);
            memoryCache = cache;
            loggerFactory ??= NullLoggerFactory.Instance;
            _serviceSnapshotService = new ServiceSnapshot(dataverseClient, cache, loggerFactory.CreateLogger<ServiceSnapshot>(), loggerFactory);
            _componentType = new ComponentType(dataverseClient, loggerFactory.CreateLogger<ComponentType>());
        }

        public enum eStateCode
        {
            Active = 0,
            Inactive = 1
        }

        public enum eProductActionCode
        {
            ADD = 622490001,
            NoChange = 622490000,
            Remove = 622490002
        }

        public enum eSkipBOMAutoParse
        {
            Yes = 1,
            No = 2
        }

        public enum eBomtype
        {
            BOM5 = 102420002,
            Product = 102420001,
            Project = 102420000
        }

        public enum BillOfMaterialType
        {
            Generic_Service = 102420001,
            Pre_Defined_AV = 622490002,
            CS_AV = 102420000,
            Placeholder_AV = 102420002,
            Fiji_Draft = 219170000
        }

        public enum eStatusCode
        {
            Active = 1,
            Inactive = 2
        }

        public enum eProjectStatusCode
        {
            Active = 1,
            Canceled = 219180001,
            Complete = 2,
            Feasibility = 622490004,
            FeasibilityComplete = 219180002,
            Initialization = 622490003,
            NPI = 622490006,
            OnHold = 219180000,
            OrderCatalogue = 622490007,
            Rejected = 622490008,
            Reopened = 219180003,
            Setup = 622490005,
            Submitted = 622490001,
            Unsubmitted = 622490000
        }

        public Dictionary<string, Responses.BillofMaterial.CreateDeleteBOMResponse> CreateDeleteBomItems(CreateUpdateBomItemRquest value)
        {
            return TraceOperation(nameof(CreateDeleteBomItems), () =>
            {

                Dictionary<string, Responses.BillofMaterial.CreateDeleteBOMResponse> dictionaryData = new();
                var projectScopeChangereponse = new ProjectScopeChangeRequest();
                int removeServiceCount = 0;
                var projectScopeChangeHelper = new ProjectScopeChangeHelper(DataverseClient);
                try
                {
                    string BOMID = string.Empty;
                    //get by fiji_portalinitiated by project id -- update portal initiated to avoid extra creation of BOM
                    var isPortalInitiated = false;
                    var project = this.DataverseClient.Retrieve(EntityName.Project, new Guid(value.ProjectId), new ColumnSet(AttributeNames.Project.PortalInitiated, AttributeNames.Project.ProjectStage));
                    if (project != null && project.Attributes[AttributeNames.Project.PortalInitiated] != null)
                    {
                        isPortalInitiated = project.GetAttributeValue<bool>(AttributeNames.Project.PortalInitiated);
                    }

                    Entity updateProject = new Entity(EntityName.Project, new Guid(value.ProjectId));

                    if (!isPortalInitiated)
                    {
                        updateProject[AttributeNames.Project.PortalInitiated] = true;
                    }

                    if (!string.IsNullOrEmpty(value.ModifiedByPortalContact))
                    {
                        updateProject[AttributeNames.Project.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, value.ModifiedByPortalContact);
                    }
                    Execute(new UpdateRequest { Target = updateProject });

                    this.BeginTransaction(this.Transaction);

                    if (value.NewService != null && value.NewService.Count > 0)
                    {
                        CreateBomItems(value, dictionaryData);
                    }
                    if (value.RemoveService != null && value.RemoveService.Count > 0)
                    {
                        removeServiceCount = value.RemoveService.Count;
                        DeleteBomService(value.RemoveService, value.ProjectId, dictionaryData);
                        for (int i = 0; i < value.RemoveService.Count; i++)
                        {

                            var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(value.RemoveService[i].BomId);
                            if (result != null)
                            {
                                projectScopeChangereponse.Sections ??= new Sections();

                                projectScopeChangereponse.Sections.Remove ??= new List<BomItem>();
                                // Remove the new BomItem
                                projectScopeChangereponse.Sections.Remove.Add(new BomItem
                                {
                                    BomId = result.bomName,
                                    ExternalId = result.externalId,
                                    PortalDescription = result.description
                                });
                            }
                        }
                    }

                    if (value.UpdateServices != null && value.UpdateServices.Count > 0)
                    {
                        UpdateBomService(value.UpdateServices, value.ProjectId, dictionaryData);
                        for (int i = 0; i < value.UpdateServices.Count; i++)
                        {
                            var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(value.UpdateServices[i].BomId.ToString());
                            if (result != null)
                            {
                                projectScopeChangereponse.Sections ??= new Sections();

                                projectScopeChangereponse.Sections.Customize ??= new List<BomItem>();
                                // Customize the new BomItem
                                projectScopeChangereponse.Sections.Customize.Add(new BomItem
                                {
                                    BomId = result.bomName,
                                    ExternalId = result.externalId,
                                    PortalDescription = result.description
                                });
                            }
                        }
                    }

                    var responses = CommitTransaction();
                    List<string> BOMGuids = new List<string>();
                    if (dictionaryData.GetValueOrDefault(Constants.NewService) != null)
                        dictionaryData.GetValueOrDefault(Constants.NewService).ServiceIds = new List<Responses.BillofMaterial.ServiceDtls>();

                    // While adding the check to the service to the response
                    if (value.NewService != null)
                    {
                        if (value.NewService.Count > 0)
                        {
                            for (int i = 0; i < value.NewService.Count; i++)
                            {
                                Responses.BillofMaterial.ServiceDtls srvcDtl = new Responses.BillofMaterial.ServiceDtls();
                                BOMID = ((CreateResponse)responses.Responses[i]).id.ToString();
                                srvcDtl.ID = BOMID;
                                if (value.NewService[i] != null)
                                    srvcDtl.ProductComponentId = value.NewService[i].ProductComponentId.ToString();
                                if (dictionaryData.GetValueOrDefault(Constants.NewService) != null)
                                    dictionaryData.GetValueOrDefault(Constants.NewService).ServiceIds.Add(srvcDtl);
                                var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(BOMID);
                                if (result != null)
                                {
                                    projectScopeChangereponse.Sections ??= new Sections();

                                    projectScopeChangereponse.Sections.Add ??= new List<BomItem>();
                                    // Add the new BomItem
                                    projectScopeChangereponse.Sections.Add.Add(new BomItem
                                    {
                                        BomId = result.bomName,
                                        ExternalId = result.externalId,
                                        PortalDescription = result.description
                                    });
                                }
                            }
                        }
                    }
                    projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, value.ProjectId);
                }
                catch (FaultException<OrganizationServiceFault> fe)
                {
                    bool IsExceptionRemoveService = false;
                    bool IsExceptionUpdateService = false;
                    string errormsg = fe.Message;
                    if (fe.Message == "")
                        errormsg = fe.Detail.TraceText.ToString();

                    if (value.RemoveService != null)
                    {
                        foreach (var removeService in value.RemoveService)
                        {
                            if (fe.Message.Contains(removeService.BomId.ToString()))
                            {
                                IsExceptionRemoveService = true;
                                break;
                            }
                        }
                    }

                    if (value.UpdateServices != null)
                    {
                        foreach (var UpdateService in value.UpdateServices)
                        {
                            if (fe.Message.Contains(UpdateService.BomId.ToString()))
                            {
                                IsExceptionUpdateService = true;
                                break;
                            }
                        }
                    }

                    if (dictionaryData.ContainsKey(Constants.NewService))
                    {
                        dictionaryData.GetValueOrDefault(Constants.NewService).ProjectId = null;
                        dictionaryData.GetValueOrDefault(Constants.NewService).Message = null;
                    }
                    if (dictionaryData.ContainsKey(Constants.RemoveService))
                    {
                        dictionaryData.GetValueOrDefault(Constants.RemoveService).ProjectId = null;
                        dictionaryData.GetValueOrDefault(Constants.RemoveService).Message = null;
                        dictionaryData.GetValueOrDefault(Constants.RemoveService).ServiceIds = null;
                    }
                    if (dictionaryData.ContainsKey(Constants.UpdateService))
                    {
                        dictionaryData.GetValueOrDefault(Constants.UpdateService).ProjectId = null;
                        dictionaryData.GetValueOrDefault(Constants.UpdateService).Message = null;
                        dictionaryData.GetValueOrDefault(Constants.UpdateService).ServiceIds = null;
                    }

                    if (IsExceptionRemoveService)
                    {
                        dictionaryData.GetValueOrDefault(Constants.RemoveService).Error = errormsg;
                    }
                    else if (IsExceptionUpdateService)
                    {
                        dictionaryData.GetValueOrDefault(Constants.UpdateService).Error = errormsg;
                    }
                    else
                    {
                        if (dictionaryData.ContainsKey(Constants.NewService))
                        {
                            dictionaryData.GetValueOrDefault(Constants.NewService).Error = errormsg;
                        }
                        if (dictionaryData.ContainsKey(Constants.RemoveService))
                        {
                            dictionaryData.GetValueOrDefault(Constants.RemoveService).Error = errormsg;
                        }
                        if (dictionaryData.ContainsKey(Constants.UpdateService))
                        {
                            dictionaryData.GetValueOrDefault(Constants.UpdateService).Error = errormsg;
                        }
                    }
                }
                return dictionaryData;
            }, ("projectId", value.ProjectId));
        }

        private void CreateBomItems(CreateUpdateBomItemRquest value, Dictionary<string, Responses.BillofMaterial.CreateDeleteBOMResponse> dictionaryData)
        {
            Responses.BillofMaterial.CreateDeleteBOMResponse response = new Responses.BillofMaterial.CreateDeleteBOMResponse();
            try
            {
                foreach (var item in value.NewService)
                {
                    this.BOMInitialize(Utils.ConvertInGuid(value.ProjectId), item);
                    this.CreateBOM();
                }
                response.ProjectId = value.ProjectId;
                response.Message = Constants.ResponseMessages.BOMSuccessfullyCreated;
                dictionaryData.Add(Constants.NewService, response);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void DeleteBomService(List<RemoveBOMService> bomServices, string ProjectId, Dictionary<string, Responses.BillofMaterial.CreateDeleteBOMResponse> dictionaryData)
        {
            TraceOperation(nameof(DeleteBomService), () =>
            {
                Responses.BillofMaterial.CreateDeleteBOMResponse fijiResponse = new Responses.BillofMaterial.CreateDeleteBOMResponse();
                fijiResponse.ServiceIds = new List<Responses.BillofMaterial.ServiceDtls>();

                try
                {
                    foreach (var bomService in bomServices)
                    {
                        Entity fiji_billofmaterials = new Entity(EntityName.BOM, new Guid(bomService.BomId));
                        fiji_billofmaterials[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductActionCode.Remove);
                        fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                        dynamic? result = GetProductComponentAndComponentTypeByBOMID(new Guid(bomService.BomId));
                        Execute(new UpdateRequest { Target = fiji_billofmaterials });

                        Responses.BillofMaterial.ServiceDtls srvcDtl = new Responses.BillofMaterial.ServiceDtls();
                        srvcDtl.ID = bomService.BomId;

                        if (result != null)
                            srvcDtl.ProductComponentId = result.productComponentId.ToString();

                        fijiResponse.ServiceIds.Add(srvcDtl);

                        //Check whether there is generic service to be marked as removed 
                        //if (result?.componentTypeId != null)
                        //{
                        //    int? quantity = 0;
                        //    Guid? bomItemGenericSevice = GetBomItemAssociateWithGenericServiceBy(new Guid(ProjectId), result?.componentTypeId, out quantity);

                        //    if (quantity.GetValueOrDefault(0) < 2)
                        //    {
                        //        if (bomItemGenericSevice != null)
                        //        {
                        //            Entity bomTypeEntity = new Entity(EntityName.BOM, bomItemGenericSevice.Value);
                        //            bomTypeEntity[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductActionCode.Remove);
                        //            bomTypeEntity[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                        //            Execute(new UpdateRequest { Target = bomTypeEntity });
                        //        }
                        //    }
                        //    else
                        //    {
                        //        //Subtract quantity and update BOM Item;
                        //        Entity bomTypeEntity = new Entity(EntityName.BOM, bomItemGenericSevice.Value);
                        //        bomTypeEntity[AttributeNames.BOM.Quantity] = quantity.Value - 1;
                        //        bomTypeEntity[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes); 
                        //        Execute(new UpdateRequest { Target = bomTypeEntity });
                        //    }
                        //}
                    }

                    fijiResponse.Message = Constants.ResponseMessages.BOMProductActionCode;
                    fijiResponse.ProjectId = ProjectId;
                    dictionaryData.Add(Constants.RemoveService, fijiResponse);
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("projectId", ProjectId), ("bomServices", bomServices));
        }

        private void UpdateBomService(List<UpdateBOMService> UpdbomServices, string ProjectId, Dictionary<string, Responses.BillofMaterial.CreateDeleteBOMResponse> dictionaryData)
        {
            TraceOperation(nameof(UpdateBomService), () =>
             {
                 try
                 {
                     Responses.BillofMaterial.CreateDeleteBOMResponse fijiResponse = new Responses.BillofMaterial.CreateDeleteBOMResponse();
                     fijiResponse.ServiceIds = new List<Responses.BillofMaterial.ServiceDtls>();

                     foreach (var bomService in UpdbomServices)
                     {
                         if (bomService.BomId != Guid.Empty && bomService.ProductComponentId != Guid.Empty)
                         {
                             Entity fiji_billofmaterials = new Entity(EntityName.BOM, new Guid(bomService.BomId.ToString()));
                             fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, bomService.ProductComponentId.ToString());
                             Execute(new UpdateRequest { Target = fiji_billofmaterials });
                         }
                     }
                     fijiResponse.Message = Constants.ResponseMessages.BomUpdatedSuccessfully;
                     fijiResponse.ProjectId = ProjectId;
                     foreach (var updService in UpdbomServices)
                     {
                         Responses.BillofMaterial.ServiceDtls srvcDtl = new Responses.BillofMaterial.ServiceDtls();
                         srvcDtl.ID = updService.BomId.ToString();
                         srvcDtl.ProductComponentId = updService.ProductComponentId.ToString();
                         fijiResponse.ServiceIds.Add(srvcDtl);
                     }
                     dictionaryData.Add(Constants.UpdateService, fijiResponse);
                 }
                 catch (Exception)
                 {
                     throw;
                 }
             }, ("projectId", ProjectId), ("updateBomServices", UpdbomServices));
        }

        public Guid? GetBomItemAssociateWithGenericServiceBy(Guid projectId, Guid componentTypeId, out int? quantity)
        {
            var result = TraceOperation(nameof(GetBomItemAssociateWithGenericServiceBy), () =>
            {
                int? localQuantity = 0;
                QueryExpression query = new QueryExpression(EntityName.BOM);
                query.PageInfo = new PagingInfo() { Count = 1, PageNumber = 1 };
                query.ColumnSet.AddColumns(AttributeNames.BOM.BOMId, AttributeNames.BOM.Quantity);
                query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, projectId);
                query.Criteria.AddCondition(AttributeNames.BOM.ProductActionCode, ConditionOperator.NotEqual, (int)BOM.eProductActionCode.Remove);
                query.AddLink(EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId);
                query.LinkEntities[0].LinkCriteria.AddCondition(AttributeNames.ProductComponent.ComponentType, ConditionOperator.Equal, componentTypeId);
                query.LinkEntities[0].LinkCriteria.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, (int)Model.ProductComponent.eServiceTypeGlobal.GenericService);

                Entity? bomRecord = this.DataverseClient.RetrieveMultiple(query).Entities.FirstOrDefault();

                if (bomRecord != null)
                {
                    localQuantity = bomRecord.GetAttributeValue<int>(AttributeNames.BOM.Quantity);
                    return (bomId: (Guid?)bomRecord.Id, quantity: localQuantity);
                }

                return (bomId: (Guid?)null, quantity: localQuantity);
            }, ("projectId", projectId), ("componentTypeId", componentTypeId));

            quantity = result.quantity;
            return result.bomId;
        }

        private const string ImportedFromOCIMessageText = "Imported from OCI config.";

        public void BOMInitialize(Guid Id, BOMRequest item)
        {
            TraceOperation(nameof(BOMInitialize), () =>
            {
                this.ProjectId = Id;
                this.ProductComponentId = item.ProductComponentId;
                this.CameFromOCI = item.CameFromOCI;
                this.ComponentTypeServiceNumber = item.ComponentTypeServiceNumber;
                this.Quantity = item.Quantity;
                this.Type = item.Type;
                this.Comments = (this.CameFromOCI) ? ImportedFromOCIMessageText : string.Empty;
            }, ("projectId", Id), ("productComponentId", item?.ProductComponentId));
        }

        internal void CreateBOM()
        {
            TraceOperation(nameof(CreateBOM), () =>
            {
                Model.ProductComponent pcModel = new ProductComponent(this.DataverseClient, memoryCache);
                var fijiBOM = new Entity(EntityName.BOM);
                fijiBOM.Id = Guid.NewGuid();
                fijiBOM[AttributeNames.BOM.Project] = Utils.GetEntityReference(EntityName.Project, this.ProjectId.ToString());

                Entity? pc = pcModel.GetBy(this.ProductComponentId, this.ComponentTypeServiceNumber);

                if (pc == null) return;

                this.ProductComponentId = pc.Id;

                if (pc.Contains(AttributeNames.ProductComponent.ServiceTypeGlobal))
                {
                    int serviceType = pc.GetAttributeValue<OptionSetValue>(AttributeNames.ProductComponent.ServiceTypeGlobal).Value;

                    //Not required to create TechnicalAVs It will be created by OCI Importing on CRM
                    if (serviceType == (int)eServiceTypeGlobal.TechnicalAV)
                        return;
                    if (pc.Contains(AttributeNames.ProductComponent.ComponentType) && pc.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType) != null)
                    {
                        Entity ct = DataverseClient.Retrieve(EntityName.ComponentType, pc.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType).Id, new ColumnSet(AttributeNames.ComponentType.ServiceNumber));
                        if (ct.Contains(AttributeNames.ComponentType.ServiceNumber) && ct.GetAttributeValue<string>(AttributeNames.ComponentType.ServiceNumber).Contains("-")) { }
                        //fijiBOM[AttributeNames.BOM.SkipBOMAutoParse] = null;

                    }
                    else if (serviceType != (int)eServiceTypeGlobal.PlaceholderAV)
                        fijiBOM[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                }

                if (this.ProductComponentId != null)
                {
                    fijiBOM[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, this.ProductComponentId.ToString());
                    fijiBOM[AttributeNames.BOM.ObjectActionCode] = this.GetActionCode(this.Type, this.ComponentTypeServiceNumber, this.CameFromOCI);
                    fijiBOM[AttributeNames.BOM.Quantity] = 1;
                    if (!string.IsNullOrEmpty(this.Comments))
                    {
                        fijiBOM[AttributeNames.BOM.Comments] = this.Comments;
                        fijiBOM[AttributeNames.BOM.Createdbyipcs] = true;
                    }

                    this.Execute(new CreateRequest { Target = fijiBOM });
                }
            });
        }

        /// <summary>
        /// SetObjectActionCode
        /// </summary>
        /// <param name="fijiBOM"></param>
        /// <param name="type"></param>
        /// <param name="typeServiceNumber"></param>
        /// <param name="cameFromOCI"></param>
        public EntityReference GetActionCode(int type, string typeServiceNumber, bool cameFromOCI)
        {
            return TraceOperation(nameof(GetActionCode), () =>
            {
                if (type.Equals((int)BOM.BillOfMaterialType.Generic_Service)
                || type.Equals((int)BOM.BillOfMaterialType.Pre_Defined_AV)
                || (type.Equals((int)BOM.BillOfMaterialType.CS_AV) && cameFromOCI && typeServiceNumber.Equals(Constants.AY108AV))
                || (type.Equals((int)BOM.BillOfMaterialType.Generic_Service) && !cameFromOCI))
                {
                    // Mapping for Nochange
                    Guid actionCode = _actionCode.GetActionCodeBy(Constants.ActionCode.NoChange);
                    if (actionCode != Guid.Empty)
                    {
                        return new EntityReference(EntityName.OAC, actionCode);
                    }
                }
                if (type.Equals((int)BOM.BillOfMaterialType.Placeholder_AV))
                {
                    return new EntityReference(EntityName.OAC, _actionCode.GetActionCodeBy(Constants.ActionCode.New));
                }

                if (type.Equals((int)BOM.BillOfMaterialType.CS_AV) && cameFromOCI && !typeServiceNumber.Equals(Constants.AY108AV))
                {
                    Guid actionCode = _actionCode.GetActionCodeBy(Constants.ActionCode.Reuse);
                    if (actionCode != Guid.Empty)
                    {
                        return new EntityReference(EntityName.OAC, actionCode);
                    }
                }


                return null;
            }, ("type", type), ("typeServiceNumber", typeServiceNumber), ("cameFromOCI", cameFromOCI));
        }

        // Update BOM item
        public void UpdateBOMOnServiceRevision(Requests.UpdateCSAVRequest UpdateCSAVRequest, Guid? ServiceSnapShotIdforBOM)
        {
            TraceOperation(nameof(UpdateBOMOnServiceRevision), () =>
            {
                if (ServiceSnapShotIdforBOM != null)
                {
                    Entity fiji_billofmaterials = new Entity(EntityName.BOM, new Guid(UpdateCSAVRequest.BomId.ToString()));
                    fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, UpdateCSAVRequest.ProductComponentId);

                    if (ServiceSnapShotIdforBOM != null)
                        fiji_billofmaterials[AttributeNames.BOM.ServiceRevision] = new EntityReference(EntityName.Servicesnapshot, ServiceSnapShotIdforBOM.Value);

                    this.Execute(new UpdateRequest { Target = fiji_billofmaterials });
                }
            }, ("bomId", UpdateCSAVRequest?.BomId), ("serviceSnapshotId", ServiceSnapShotIdforBOM));
        }

        // Create or update BOM

        public void CreateorUpdateBOMOnNewProductComponent(Requests.ProductComponentRequest productComponentRequest, Guid? ProductComponentID, Guid? ServiceSnapShotId, out Guid? BOMID)
        {
            BOMID = TraceOperation(nameof(CreateorUpdateBOMOnNewProductComponent), () =>
            {
                Guid? localBomId = null;
                Entity fiji_billofmaterials = new Entity(EntityName.BOM);


                if (string.IsNullOrEmpty(productComponentRequest.BomId))
                {

                    fiji_billofmaterials.Id = Guid.NewGuid();
                    localBomId = fiji_billofmaterials.Id;
                    fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, ProductComponentID.Value.ToString());
                    if (ServiceSnapShotId != null)
                        fiji_billofmaterials[AttributeNames.BOM.ServiceRevision] = Utils.GetEntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value.ToString());
                    fiji_billofmaterials[AttributeNames.BOM.Quantity] = productComponentRequest.Quantity;
                    fiji_billofmaterials[AttributeNames.BOM.Project] = Utils.GetEntityReference(EntityName.Project, productComponentRequest.ProjectId);
                    //fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                    this.Execute(new CreateRequest { Target = fiji_billofmaterials });
                }
                else if (!string.IsNullOrEmpty(productComponentRequest.BomId))
                {
                    localBomId = new Guid(productComponentRequest.BomId);
                    fiji_billofmaterials.Id = new Guid(productComponentRequest.BomId);
                    fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, ProductComponentID.Value.ToString());
                    if (ServiceSnapShotId != null)
                        fiji_billofmaterials[AttributeNames.BOM.ServiceRevision] = Utils.GetEntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value.ToString());

                    this.Execute(new UpdateRequest { Target = fiji_billofmaterials });
                }

                return localBomId;
            }, ("productComponentId", ProductComponentID), ("serviceSnapshotId", ServiceSnapShotId), ("existingBomId", productComponentRequest?.BomId));
        }

        private EntityCollection ListPCInformationByIds(List<string> bomItems, Guid project)
        {
            var query = new QueryExpression(EntityName.BOM);
            query.ColumnSet = new ColumnSet(AttributeNames.BOM.Quantity);
            //query.Criteria.AddCondition(AttributeNames.BOM.BOMId, ConditionOperator.In, bomItems.ToArray());
            query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, project);
            query.AddLink(EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId, JoinOperator.LeftOuter);
            query.LinkEntities[0].EntityAlias = "productComponent";
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ExternalId, AttributeNames.ProductComponent.ParentProductComponentId, AttributeNames.ProductComponent.Name, AttributeNames.ProductComponent.ServiceTypeGlobal);

            query.LinkEntities[0].AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.LeftOuter);
            query.LinkEntities[0].LinkEntities[0].EntityAlias = "componentType";
            query.LinkEntities[0].LinkEntities[0].Columns.AddColumns(AttributeNames.ComponentType.ComponentTypeId, AttributeNames.ComponentType.EnableReuse, AttributeNames.ComponentType.PortalDescription, AttributeNames.ComponentType.StatusCode, AttributeNames.ComponentType.ServiceNumber, AttributeNames.ComponentType.AdditionalInfoMultiModel, AttributeNames.ComponentType.IsConfigurable, AttributeNames.ComponentType.CanBeUsedAcrossCustomer);

            query.AddLink(EntityName.Servicesnapshot, AttributeNames.BOM.ServiceRevision, AttributeNames.Servicesnapshot.ServicesnapshotId, JoinOperator.LeftOuter);
            query.LinkEntities[1].EntityAlias = "serviceRevision";
            query.LinkEntities[1].Columns.AddColumns(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.ModifiedByPortalContact, AttributeNames.Servicesnapshot.ServiceRevisionVersion, AttributeNames.Servicesnapshot.ModifiedOn, AttributeNames.Servicesnapshot.StatusCode);

            var result = DataverseClient.RetrieveMultiple(query);
            return result;
        }

        /// <summary>
        /// It lists parent information (Product Component, Component Type, Service Revision) regarding to the given BOM Items
        /// </summary>
        public List<BOM> ListInfoRelatedToTheBOMItems(List<string> bomItems, Guid projectId)
        {
            return TraceOperation(nameof(ListInfoRelatedToTheBOMItems), () =>
            {
                List<BOM> result = new List<BOM>();
                EntityCollection bomList = ListPCInformationByIds(bomItems, projectId);
                if (bomList == null || bomList.Entities == null || bomList.Entities.Count == 0)
                    return result;

            foreach (Entity bomItem in bomList.Entities)
            {
                BOM bom = new()
                {
                    Id = bomItem.Id,
                    ProductComponentId = (Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value,
                    Quantity = bomItem.GetAttributeValue<int>("fiji_quantity")
                };

                if ((Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value != null)
                {
                    bom.ProductComponent = new ProductComponent()
                    {
                        Id = (Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value,
                        ProductComponentId = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_fiji_productcomponentid")?.Value?.ToString(),
                        Name = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_name")?.Value?.ToString(),
                        ExternalId = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_externalid")?.Value?.ToString(),
                        ServiceTypeGlobal = ((OptionSetValue?)(bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_servicetypeglobal")?.Value))?.Value
                    };

                    if ((Guid?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_componenttypeid")?.Value != null)
                    {
                        bom.ProductComponent.ComponentType = new ComponentType()
                        {
                            Id = (Guid?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_componenttypeid")?.Value,
                            EnableReuse = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_enable_reuse")?.Value,
                            PortalDescription = bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_portal_description")?.Value?.ToString(),
                            StatusCode = ((OptionSetValue?)(bomItem.GetAttributeValue<AliasedValue>("componentType.statuscode")?.Value))?.Value,
                            ServiceNumber = bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_servicenumber")?.Value?.ToString(),
                            RequiredAdditionalInfoMultiModel = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_req_addit_info_multi_model")?.Value,
                            IsConfigurable = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_is_configurable")?.Value,
                            CanBeUsedAcrossCustomer = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_can_be_used_across_customer")?.Value
                        };
                    }
                }

                if ((Guid?)bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_servicesnapshotid")?.Value != null)
                {
                    bom.ServiceRevision = new ServiceSnapshot()
                    {
                        Id = (Guid?)bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_servicesnapshotid")?.Value,
                        ServiceRevisionVersion = bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_servicerevisionversion")?.Value?.ToString(),
                        ModifiedOn = (DateTime?)(bomItem.GetAttributeValue<AliasedValue>("serviceRevision.modifiedon")?.Value),
                        StatusCode = (ServiceSnapshot.eStatusCode)((OptionSetValue?)(bomItem.GetAttributeValue<AliasedValue>("serviceRevision.statuscode")?.Value))?.Value
                    };

                    if (((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_modifiedbyportalcontact")?.Value))?.Id != null)
                    {
                        bom.ServiceRevision.ModifiedByPortalContact = new Contact()
                        {
                            Id = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_modifiedbyportalcontact")?.Value))?.Id,
                            Name = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_modifiedbyportalcontact")?.Value))?.Name
                        };
                    }
                }

                result.Add(bom);
            }

                return result;
            }, ("projectId", projectId), ("bomItemCount", bomItems?.Count));
        }

        public dynamic? GetProductComponentAndComponentTypeByBOMID(Guid BOMID)
        {
            return TraceOperation(nameof(GetProductComponentAndComponentTypeByBOMID), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.BOM);
            query.ColumnSet = new ColumnSet(AttributeNames.BOM.ProductComponent);
            query.AddLink(EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId);
            query.LinkEntities[0].EntityAlias = "ct";
            query.LinkEntities[0].Columns.AddColumn(AttributeNames.ProductComponent.ComponentType);

            int quantity = 0;
            Guid? componentTypeId = null, bomId = null, productComponentId = null;

            // Add filtering conditions
            query.Criteria.AddCondition(AttributeNames.BOM.BOMId, ConditionOperator.Equal, BOMID);

            // Execute the query and process the result
            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                var entity = result.Entities[0];
                bomId = entity.Id;

                if (entity.Contains("ct.fiji_componenttype"))
                    componentTypeId = ((EntityReference)entity.GetAttributeValue<AliasedValue>("ct.fiji_componenttype").Value).Id;

                if (entity.Contains("fiji_productcomponent"))
                    productComponentId = entity.GetAttributeValue<EntityReference>("fiji_productcomponent")?.Id;

                return new
                {
                    productComponentId,
                    componentTypeId,
                };
            }
                return null;
            }, ("bomId", BOMID));
        }

        public List<BOM> GetBOMBYProjectIDandServiceGlobalType(Guid projectID)
        {
            return TraceOperation(nameof(GetBOMBYProjectIDandServiceGlobalType), () =>
            {
                List<BOM> lsBOM = new List<BOM>();
                var query = new QueryExpression(EntityName.BOM);
            query.ColumnSet = new ColumnSet(AttributeNames.BOM.Project, AttributeNames.BOM.StateCode, AttributeNames.BOM.Quantity);

            query.AddLink(EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId, JoinOperator.Inner);
            query.LinkEntities[0].EntityAlias = "productComponent";
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ExternalId, AttributeNames.ProductComponent.ParentProductComponentId, AttributeNames.ProductComponent.Name, AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.MaterialProductLine, AttributeNames.ProductComponent.ServiceComplexity, AttributeNames.ProductComponent.HideFromPortal, AttributeNames.ProductComponent.PortalContact, AttributeNames.ProductComponent.GetMoreSource, AttributeNames.ProductComponent.StatusCode, AttributeNames.ProductComponent.PortalDescription);

            query.LinkEntities[0].AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.LeftOuter);
            query.LinkEntities[0].LinkEntities[0].EntityAlias = "componentType";
            query.LinkEntities[0].LinkEntities[0].Columns.AddColumns(AttributeNames.ComponentType.ComponentTypeId, AttributeNames.ComponentType.EnableReuse, AttributeNames.ComponentType.PortalDescription, AttributeNames.ComponentType.StatusCode, AttributeNames.ComponentType.ServiceNumber, AttributeNames.ComponentType.AdditionalInfoMultiModel, AttributeNames.ComponentType.IsConfigurable, AttributeNames.ComponentType.ServiceCategory, AttributeNames.ComponentType.CanBeUsedAcrossCustomer, AttributeNames.ComponentType.GetMoreServiceId);

            query.LinkEntities[0].AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.GetMoreSource, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.LeftOuter);
            query.LinkEntities[0].LinkEntities[1].EntityAlias = "getMoreSource";
            query.LinkEntities[0].LinkEntities[1].Columns.AddColumns(AttributeNames.ComponentType.ComponentTypeId, AttributeNames.ComponentType.ServiceNumber);

            var componentTypeLink = query.LinkEntities[0].LinkEntities[0];  // First ComponentType link

            var getMoreServiceLink = componentTypeLink.AddLink(EntityName.ComponentType, AttributeNames.ComponentType.GetMoreServiceId, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.LeftOuter);
            getMoreServiceLink.EntityAlias = "getMoreService";
            getMoreServiceLink.Columns.AddColumns(AttributeNames.ComponentType.ComponentTypeId, AttributeNames.ComponentType.ServiceNumber);

            FilterExpression filter1 = new FilterExpression(LogicalOperator.And);

            filter1.Conditions.Add(new ConditionExpression(AttributeNames.BOM.Project, ConditionOperator.Equal, projectID));

            filter1.Conditions.Add(new ConditionExpression(AttributeNames.BOM.StateCode, ConditionOperator.Equal, (int)eStateCode.Active));
            filter1.Conditions.Add(new ConditionExpression(AttributeNames.BOM.ProductActionCode, ConditionOperator.NotEqual, (int)eProductActionCode.Remove));

            int[] servicegloballist = { (int)ProductComponent.eServiceTypeGlobal.PreDefinedAV,
                                        (int)ProductComponent.eServiceTypeGlobal.GenericService,
                                        (int)ProductComponent.eServiceTypeGlobal.PlaceholderAV,
                                        (int)ProductComponent.eServiceTypeGlobal.CustomerSpecific
                                       };

            FilterExpression filter2 = new FilterExpression(LogicalOperator.Or);
            filter2.Conditions.Add(new ConditionExpression(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.In, servicegloballist));
            query.Criteria.Filters.Add(filter1);
            query.LinkEntities[0].LinkCriteria.Filters.Add(filter2);

            query.Criteria.AddCondition(new ConditionExpression(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project));

            query.Criteria.AddCondition(new ConditionExpression(AttributeNames.BOM.ProductRevision, ConditionOperator.Null));

            query.Criteria.AddCondition(new ConditionExpression(AttributeNames.BOM.ProductActionCode, ConditionOperator.NotEqual, (int)eProductActionCode.Remove));

            FilterExpression filter3 = new FilterExpression(LogicalOperator.And);
            filter3.Conditions.Add(new ConditionExpression(AttributeNames.ComponentType.IsFactoryService, ConditionOperator.Equal, true));
            query.LinkEntities[0].LinkEntities[0].LinkCriteria.Filters.Add(filter3);

            var result = DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities != null && result.Entities.Count != 0)
            {
                foreach (Entity bomItem in result.Entities)
                {
                    Guid? productcomponentid = null;
                    BOM bom = new()
                    {
                        Id = bomItem.Id,
                        ProductComponentId = (Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value,
                        ProjectId = projectID,
                        Quantity = bomItem.GetAttributeValue<int>("fiji_quantity")
                    };

                    if ((Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value != null)
                    {

                        productcomponentid = (Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value;
                        bom.ProductComponent = new ProductComponent()
                        {
                            Id = (Guid?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_productcomponentid")?.Value,
                            ProductComponentId = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_fiji_productcomponentid")?.Value?.ToString(),
                            Name = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_name")?.Value?.ToString(),
                            ExternalId = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_externalid")?.Value?.ToString(),
                            ServiceTypeGlobal = ((OptionSetValue?)(bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_servicetypeglobal")?.Value))?.Value,
                            BOMId = bomItem.Id,
                            MaterialProductLine = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_materialproductline")?.Value?.ToString(),
                            ServiceComplexity = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_servicecomplexity")?.Value))?.Id.ToString(),
                            HideFromPortal = (bool?)bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_hidefromportal")?.Value,
                            PortalContact = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_portalcontact")?.Value))?.Id.ToString(),
                            ServiceSnapShotId = (Guid?)bomItem.GetAttributeValue<AliasedValue>("serviceRevision.fiji_servicesnapshotid")?.Value,
                            StatusCode = ((OptionSetValue?)(bomItem.GetValue<AliasedValue>("productComponent.statuscode")?.Value))?.Value,
                            PortalDescription = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_portaldescription")?.Value.ToString() ?? null,
                        };

                        var getMoreSourceValue = bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_getmoresource");

                        if (getMoreSourceValue?.Value is EntityReference entityRef && entityRef.Id != Guid.Empty)
                        {
                            bom.ProductComponent.GetMoreSource = new ComponentType()
                            {
                                Id = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("productComponent.fiji_getmoresource")?.Value))?.Id,
                                ServiceNumber = Utils.GetValue<AliasedValue>(bomItem, "getMoreSource.fiji_servicenumber")?.Value.ToString(),
                            };
                        }

                        if ((Guid?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_componenttypeid")?.Value != null)
                        {
                            bom.ProductComponent.ComponentType = new ComponentType()
                            {
                                Id = (Guid?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_componenttypeid")?.Value,
                                EnableReuse = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_enable_reuse")?.Value,
                                PortalDescription = bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_portal_description")?.Value?.ToString(),
                                StatusCode = ((OptionSetValue?)(bomItem.GetAttributeValue<AliasedValue>("componentType.statuscode")?.Value))?.Value,
                                ServiceNumber = bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_servicenumber")?.Value?.ToString(),
                                RequiredAdditionalInfoMultiModel = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_req_addit_info_multi_model")?.Value,
                                IsConfigurable = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_is_configurable")?.Value,
                                ServiceCategory = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_service_category")?.Value))?.Id.ToString(),
                                CanBeUsedAcrossCustomer = (bool?)bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_can_be_used_across_customer")?.Value,
                                GetMoreService = new ComponentType
                                {
                                    Id = ((EntityReference?)(bomItem.GetAttributeValue<AliasedValue>("componentType.fiji_getmore_serviceid")?.Value))?.Id,
                                    ServiceNumber = Utils.GetValue<AliasedValue>(bomItem, "getMoreService.fiji_servicenumber")?.Value.ToString(),
                                }
                            };

                        }
                        ;
                    }

                    if (productcomponentid != null)
                        bom.ServiceRevision = _serviceSnapshotService.GetServiceRevisionByBOMId(bomItem.Id);

                    lsBOM.Add(bom);
                }
            }
                return lsBOM;
            }, ("projectId", projectID));
        }

        public void CreateBOMonNewInceptionCreation(Guid? ProductComponentId, string? externalId, Guid? currentProjectID, int? quantity, bool cameFromOCI)
        {
            TraceOperation(nameof(CreateBOMonNewInceptionCreation), () =>
            {
                ProductComponent pcModel = new ProductComponent(DataverseClient, memoryCache);
                var fijiBOM = new Entity(EntityName.BOM);

                if (ProductComponentId != null)
                {
                    //find and skip generic service
                    var isGenericService = DataverseClient.Retrieve(EntityName.ProductComponent, ProductComponentId.Value, new ColumnSet(AttributeNames.ProductComponent.ServiceTypeGlobal));
                    if (isGenericService.GetValue<OptionSetValue>(AttributeNames.ProductComponent.ServiceTypeGlobal)?.Value == (int)ProductComponent.eServiceTypeGlobal.GenericService)
                        return;
                }
                else
                {
                    Entity? pc = pcModel.GetBy(externalId);
                    if (pc != null)
                    {
                        //Not required to create TechnicalAVs It will be created by OCI Importing on CRM
                        if (pc.GetValue<OptionSetValue>(AttributeNames.ProductComponent.ServiceTypeGlobal)?.Value == (int)ProductComponent.eServiceTypeGlobal.TechnicalAV)
                            return;

                        ProductComponentId = pc.Id;
                        if (pc.Contains(AttributeNames.ProductComponent.ComponentType) && pc.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType) != null)
                        {
                            Entity ct = DataverseClient.Retrieve(EntityName.ComponentType, pc.GetAttributeValue<EntityReference>(AttributeNames.ProductComponent.ComponentType).Id, new ColumnSet(AttributeNames.ComponentType.ServiceNumber));
                            if (ct.Contains(AttributeNames.ComponentType.ServiceNumber) && ct.GetAttributeValue<string>(AttributeNames.ComponentType.ServiceNumber).Contains("-")) { }
                            //fijiBOM[AttributeNames.BOM.SkipBOMAutoParse] = null;

                        }
                        else
                            fijiBOM[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                    }
                }

                if (ProductComponentId != null)
                {
                    _serviceSnapshotService.SetTransaction(this.Transaction);

                    fijiBOM.Id = Guid.NewGuid();

                    if (currentProjectID != null)
                        fijiBOM[AttributeNames.BOM.Project] = Utils.GetEntityReference(EntityName.Project, currentProjectID.ToString());

                    fijiBOM[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, ProductComponentId.ToString());

                    ServiceSnapshot? serviceSnapShot = _serviceSnapshotService.GetLatestServiceRevisionByProductcomponent(ProductComponentId.ToString(), null);
                    if (serviceSnapShot != null)
                        fijiBOM[AttributeNames.BOM.ServiceRevision] = Utils.GetEntityReference(EntityName.Servicesnapshot, serviceSnapShot.Id.ToString());


                    if (quantity != null)
                        fijiBOM[AttributeNames.BOM.Quantity] = quantity;

                    if (cameFromOCI)
                    {
                        fijiBOM[AttributeNames.BOM.Comments] = ImportedFromOCIMessageText;
                        fijiBOM[AttributeNames.BOM.Createdbyipcs] = true;
                    }

                    //fijiBOM[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                    this.Execute(new CreateRequest { Target = fijiBOM });
                }
            }, ("productComponentId", ProductComponentId), ("projectId", currentProjectID), ("cameFromOCI", cameFromOCI));
        }

        public Guid? GetProjectIDByBOMID(Guid billofmaterialsID)
        {
            return TraceOperation(nameof(GetProjectIDByBOMID), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.BOM)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.BOM.Project)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.BOM.BOMId, ConditionOperator.Equal, billofmaterialsID);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    return (Guid?)entity.GetAttributeValue<EntityReference>(AttributeNames.BOM.Project).Id;
                }

                return (Guid?)null;
            }, ("bomId", billofmaterialsID));
        }

        public void GetBomItemsByProductComponentId(string productComponentId)
        {
            TraceOperation(nameof(GetBomItemsByProductComponentId), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.BOM)
                {
                    ColumnSet = new ColumnSet(AttributeNames.BOM.BOMId),
                };

            // BOM filters
            query.Criteria.AddCondition(AttributeNames.BOM.ProductComponent, ConditionOperator.Equal, productComponentId);
            query.Criteria.AddCondition(AttributeNames.BOM.StatusCode, ConditionOperator.Equal, (int)BOM.eStatusCode.Active);
            query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project);

            // Execute
                bool existsBomItems = DataverseClient.RetrieveMultiple(query).Entities.Any();

                if (existsBomItems)
                {
                    throw new InvalidPluginExecutionException(Constants.ErrorMessages.AvailableBomItems);
                }
            }, ("productComponentId", productComponentId));
        }

        public List<string>? GetRequestIdByCustomerIdAndServiceRevision(ProductComponent_HeaderDetails_Request request)
        {
            return TraceOperation(nameof(GetRequestIdByCustomerIdAndServiceRevision), () =>
            {
                List<string> lsfiji_requestid = new List<string>();

                try
                {
                QueryExpression query = new QueryExpression(EntityName.Project)
                {
                    Distinct = true,
                    ColumnSet = new ColumnSet(
                        AttributeNames.Project.Name,
                        AttributeNames.Project.CreatedOn,
                        AttributeNames.Project.ProjectId,
                        AttributeNames.Project.CustomerId,
                        AttributeNames.Project.RequestId,
                        AttributeNames.Project.StatusCode,
                        AttributeNames.Project.ProductExternalId)

                };

                query.AddOrder(AttributeNames.Project.CreatedOn, OrderType.Descending);

                // StatusCode NOT IN (Canceled, Rejected)
                query.Criteria.AddCondition( AttributeNames.Project.StatusCode, ConditionOperator.NotIn,  new object[]
                                  { (int)eProjectStatusCode.Canceled, (int)eProjectStatusCode.Rejected });
                 
                // Add CustomerId condition only if request.CustomerId is available
                if (request.CustomerId.HasValue && request.CustomerId.Value != Guid.Empty)
                {
                    query.Criteria.AddCondition( AttributeNames.Project.CustomerId, ConditionOperator.Equal, request.CustomerId.Value );
                }

                LinkEntity bomLink = query.AddLink(EntityName.BOM, AttributeNames.Project.ProjectId, AttributeNames.BOM.Project, JoinOperator.Inner);
                bomLink.EntityAlias = "bom";

                bomLink.LinkCriteria.AddCondition(AttributeNames.BOM.StatusCode, ConditionOperator.Equal, (int)BOM.eStatusCode.Active);
                bomLink.LinkCriteria.AddCondition(AttributeNames.BOM.ProductActionCode, ConditionOperator.NotEqual, (int)eProductActionCode.Remove);
                bomLink.LinkCriteria.AddCondition(
                    AttributeNames.BOM.ServiceRevision,
                    ConditionOperator.Equal,
                    request.ServiceRevisionId);


                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                if (result != null && result.Entities != null && result.Entities.Count > 0)
                {
                    // Group projects by Base Project Number
                    Dictionary<string, List<Entity>> groupedProjects = new Dictionary<string, List<Entity>>();

                    foreach (Entity entity in result.Entities)
                    {
                        string productExternalId = entity.GetAttributeValue<string>(AttributeNames.Project.ProductExternalId) ?? string.Empty;
                        string groupKey = !string.IsNullOrWhiteSpace(productExternalId) ? productExternalId : entity.Id.ToString();
                        if (!groupedProjects.ContainsKey(groupKey))
                        {
                            groupedProjects[groupKey] = new List<Entity>();
                        }
                        groupedProjects[groupKey].Add(entity);
                    }

                    // Select latest version from each group
                    List<Entity> latestProjects = new List<Entity>();

                    foreach (var group in groupedProjects)
                    {
                        List<Entity> versionedProjects = group.Value.Where(e => !string.IsNullOrWhiteSpace(e.GetAttributeValue<string>(AttributeNames.Project.RequestId)))
                            .OrderByDescending(e => e.GetAttributeValue<DateTime>(AttributeNames.Project.CreatedOn)).ToList();

                        if (!versionedProjects.Any())
                        {
                            continue;
                        }

                        Entity latestProject = versionedProjects.First();
                        latestProjects.Add(latestProject);
                    }

                    // Retrieve RequestId from latest projects
                    foreach (Entity latestProject in latestProjects)
                    {
                        string requestId = latestProject.GetAttributeValue<string>(AttributeNames.Project.RequestId);

                        if (!string.IsNullOrWhiteSpace(requestId))
                        {
                            lsfiji_requestid.Add(requestId);
                        }
                    }
                }
                }
                catch (Exception ex)
                {
                    throw new Exception($"Error in GetRequestIdByCustomerIdAndServiceRevision: {ex.Message}", ex);
                }

                return lsfiji_requestid;
            }, ("customerId", request?.CustomerId), ("serviceRevisionId", request?.ServiceRevisionId));
        }

    }
}