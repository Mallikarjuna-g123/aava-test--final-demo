﻿using FIJI.Portal.WebAPI.Integration.Model.Dev;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Identity.Client;
using Microsoft.Xrm.Sdk;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class SystemUser : Base<SystemUser>
    {
        public Guid? Id { get; set; }
        public string? Name { get; set; }
        public string? PrimaryEmail { get; set; }
        private DevBaseInfra? _devBaseInfra;
        public SystemUser(): base("systemuser") { }
        public SystemUser(IOrganizationService dataverseClient, IMemoryCache cache, ILogger<SystemUser>? logger = null) : base(dataverseClient, "systemuser", logger) { }
        
        public string ListFSPMUsers(string token)
        {
            return TraceOperation(nameof(ListFSPMUsers), () =>
            {
                _devBaseInfra = new DevBaseInfra(null, token);
                string query = $@"?$select=internalemailaddress,fullname,_businessunitid_value,title,address1_telephone1,_positionid_value,systemuserid&$expand=systemuserroles_association($select=name;$filter=(name eq '{Constants.SecurityRole.FIJIFSPM}'))&$filter=(isdisabled eq false and accessmode ne 3 and accessmode ne 5) and((systemuserroles_association/any(o1:(o1/name eq '{Constants.SecurityRole.FIJIFSPM}'))) or(teammembership_association/any(o1:(o1/name eq '{Constants.Team.FSPM}'))))&$orderby=fullname asc";
                return _devBaseInfra.retrieveMultipleRecords(EntityName.SystemUser, query, 0).Result;

            }, ("role", Constants.SecurityRole.FIJIFSPM), ("team", Constants.Team.FSPM));
        }
    }
}
