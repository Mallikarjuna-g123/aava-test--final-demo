﻿using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class PCPlatformStatus : Base<PCPlatformStatus>
    {
        public PCPlatformStatus(IOrganizationService dataverseClient, ILogger<PCPlatformStatus>? logger = null) : base(dataverseClient, "pcplatformstatus")
        { }

        public enum eStatusCode
        {
            Draft = 1,
            Approved = 622490001,
            Requested = 622490000
        }


        //Create a new PC Platform status 
        public void CreatePCPlatformStatusOnExtendModel(Requests.UpdateCSAVRequest UpdateCSAVRequest, Guid? projectid)
        {
            TraceOperation(nameof(CreatePCPlatformStatusOnExtendModel), () =>
            {
                //get the fiji name of productcomponent
                string? Productcomponentname = null;
                string? fiji_name_pcplatformStatus = null;
                if (UpdateCSAVRequest.ProductComponentId != null)
                {
                    var copyFijiProductcomponent = this.DataverseClient.Retrieve(EntityName.ProductComponent, Utils.ConvertInGuid(UpdateCSAVRequest.ProductComponentId), new ColumnSet(AttributeNames.ProductComponent.Name));
                    if (copyFijiProductcomponent != null)
                    {
                        Productcomponentname = copyFijiProductcomponent.GetAttributeValue<string?>(AttributeNames.ProductComponent.Name);
                    }
                }

                if (!string.IsNullOrWhiteSpace(UpdateCSAVRequest.ModelName))
                    fiji_name_pcplatformStatus = !string.IsNullOrWhiteSpace(Productcomponentname) ? Productcomponentname + "_" + UpdateCSAVRequest.ModelName : UpdateCSAVRequest.ModelName;
                else if (!string.IsNullOrWhiteSpace(Productcomponentname))
                    fiji_name_pcplatformStatus = Productcomponentname;

                // Create a new PC Platform Status when exten model is true
                Entity fiji_pc_platform_status = new Entity(EntityName.PCPlatformStatus);

                eStatusCode status = eStatusCode.Draft;

                if (projectid != null)
                {
                    fiji_pc_platform_status[AttributeNames.PCPlatformStatus.ProjectId] = projectid.ToString();
                    Entity project = this.DataverseClient.Retrieve(EntityName.Project, projectid.Value, new ColumnSet(AttributeNames.Project.StatusCode));
                    if (project.GetAttributeValue<OptionSetValue>(AttributeNames.Project.StatusCode).Value != (int)Project.eStatusCode.Unsubmitted)
                        status = eStatusCode.Requested;
                }

                fiji_pc_platform_status.Id = Guid.NewGuid();
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.Name] = fiji_name_pcplatformStatus ?? null;
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.ProductComponentId] = Utils.GetEntityReference(EntityName.ProductComponent, UpdateCSAVRequest.ProductComponentId);
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.PlatformId] = Utils.GetEntityReference(EntityName.ProductFamily, UpdateCSAVRequest.ModelId);
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.StatusCode] = new OptionSetValue((int)status);

                this.Execute(new CreateRequest { Target = fiji_pc_platform_status });
            }, ("productComponentId", UpdateCSAVRequest?.ProductComponentId), ("modelId", UpdateCSAVRequest?.ModelId), ("projectId", projectid));
        }


        //Create a new PC Platform status 
        public void DuplicatePCPlatformStatus(Guid pcplatformstatusid, Guid fiji_productcomponent, string? description)
        {
            TraceOperation(nameof(DuplicatePCPlatformStatus), () =>
            {
                // Create a new PC Platform Status when exten model is true
                var copyPcPlatformstatus = this.DataverseClient.Retrieve(EntityName.PCPlatformStatus, pcplatformstatusid, new ColumnSet(true));
                copyPcPlatformstatus.Remove(AttributeNames.PCPlatformStatus.ProductComponentId);
                copyPcPlatformstatus.Remove(AttributeNames.PCPlatformStatus.StatusCode);
                copyPcPlatformstatus.Remove(AttributeNames.PCPlatformStatus.PCPlatformStatusId);
                copyPcPlatformstatus.Remove(AttributeNames.PlatformAndPlacement.CreatedOn);
                copyPcPlatformstatus.Remove(AttributeNames.PlatformAndPlacement.CreatedBy);
                copyPcPlatformstatus.Remove(AttributeNames.PlatformAndPlacement.ModifiedOn);
                copyPcPlatformstatus.Remove(AttributeNames.PlatformAndPlacement.ModifiedBy);
                copyPcPlatformstatus.Id = Guid.NewGuid();
                copyPcPlatformstatus[AttributeNames.PCPlatformStatus.ProductComponentId] = Utils.GetEntityReference(EntityName.ProductComponent, fiji_productcomponent.ToString());
                copyPcPlatformstatus[AttributeNames.PCPlatformStatus.StatusCode] = (int)eStatusCode.Draft;
                if (!string.IsNullOrEmpty(description))
                {
                    string platformName = copyPcPlatformstatus.GetAttributeValue<EntityReference>(AttributeNames.PCPlatformStatus.PlatformId).Name;
                    string finalName = string.IsNullOrWhiteSpace(description) ? platformName ?? string.Empty : string.IsNullOrWhiteSpace(platformName) ? $"{description}_" : $"{description}_{platformName}";
                    copyPcPlatformstatus.Remove(AttributeNames.PlatformAndPlacement.Name);
                    copyPcPlatformstatus[AttributeNames.PCPlatformStatus.Name] = finalName;
                }

                this.Execute(new CreateRequest { Target = copyPcPlatformstatus });
            }, ("pcPlatformStatusId", pcplatformstatusid), ("productComponentId", fiji_productcomponent), ("hasDescription", !string.IsNullOrEmpty(description)));
        }

        // Update Pc Platform status by Product Component and ModelID
        public void UpdatePCPlatfromStatusOnStateCode(string ProductComponentID, string ModelID, string projectid)
        {
            TraceOperation(nameof(UpdatePCPlatfromStatusOnStateCode), () =>
            {
                Guid? PcplatformStatusID = null;
                int? statuscodePcPlatform = GetStatusCodePCPlatformStatus(ProductComponentID, ModelID, out PcplatformStatusID);
                if (statuscodePcPlatform != null && PcplatformStatusID != null)
                {
                    if (statuscodePcPlatform == (int)eStatusCode.Draft)
                    {
                        Entity fiji_pc_platform_status = new Entity(EntityName.PCPlatformStatus, PcplatformStatusID.Value);
                        fiji_pc_platform_status[AttributeNames.PCPlatformStatus.StatusCode] = new OptionSetValue((int)eStatusCode.Requested);
                        fiji_pc_platform_status[AttributeNames.PCPlatformStatus.ProjectId] = projectid;
                        this.Execute(new UpdateRequest { Target = fiji_pc_platform_status });
                    }
                }
            }, ("productComponentId", ProductComponentID), ("modelId", ModelID), ("projectId", projectid));
        }


        //Create a new PC Platform status 
        public void CreatePCPlatformStatusOnNewProductComponent(Requests.ProductComponentRequest productComponentRequest, string? fiji_name, Guid? ProductComponentId, int status, out Guid? PcplatformStatusID)
        {
            var createdId = TraceOperation(nameof(CreatePCPlatformStatusOnNewProductComponent), () =>
            {
                Entity fiji_pc_platform_status = new Entity(EntityName.PCPlatformStatus);
                fiji_pc_platform_status.Id = Guid.NewGuid();
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.PlatformId] = Utils.GetEntityReference(EntityName.ProductFamily, productComponentRequest.ModelId);
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.ProductComponentId] = Utils.GetEntityReference(EntityName.ProductComponent, ProductComponentId.Value.ToString());// lookup ;
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.Name] = fiji_name;
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.StatusCode] = new OptionSetValue(status);
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.ProjectId] = productComponentRequest.ProjectId;
                this.Execute(new CreateRequest { Target = fiji_pc_platform_status });
                return (Guid?)fiji_pc_platform_status.Id;
            }, ("productComponentId", ProductComponentId), ("modelId", productComponentRequest?.ModelId), ("status", status));

            PcplatformStatusID = createdId;
        }

        //Create a new PC Platform status 
        public void UpdatePCPlatformStatusDescription(string fiji_name, Guid? PcplatformStatusID, string modelname)
        {
            TraceOperation(nameof(UpdatePCPlatformStatusDescription), () =>
            {
                string? fiji_name_pcplatformStatus = null;

                if (!string.IsNullOrWhiteSpace(modelname))
                    fiji_name_pcplatformStatus = !string.IsNullOrWhiteSpace(fiji_name) ? fiji_name + "_" + modelname : modelname;
                else if (!string.IsNullOrWhiteSpace(fiji_name))
                    fiji_name_pcplatformStatus = fiji_name;

                Entity fiji_pc_platform_status = new Entity(EntityName.PCPlatformStatus, PcplatformStatusID.Value);
                fiji_pc_platform_status[AttributeNames.PCPlatformStatus.Name] = fiji_name_pcplatformStatus.Trim().ToString() ?? null;
                this.Execute(new UpdateRequest { Target = fiji_pc_platform_status });
            }, ("pcPlatformStatusId", PcplatformStatusID), ("modelName", modelname));
        }

        #region query Expression
        public int? GetStatusCodePCPlatformStatus(string fiji_productcomponentid, string ModelID, out Guid? pc_platform_statusid)
        {
            var resultTuple = TraceOperation(nameof(GetStatusCodePCPlatformStatus), () =>
            {
                int? StatusCode = null;
                Guid? localPlatformStatusId = null;

                QueryExpression query = new QueryExpression(EntityName.PCPlatformStatus)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.PCPlatformStatus.PCPlatformStatusId, AttributeNames.PCPlatformStatus.StatusCode)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.PCPlatformStatus.ProductComponentId, ConditionOperator.Equal, fiji_productcomponentid);
                query.Criteria.AddCondition(AttributeNames.PCPlatformStatus.PlatformId, ConditionOperator.Equal, ModelID);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(AttributeNames.PCPlatformStatus.StatusCode))
                    {
                        StatusCode = entity.GetAttributeValue<OptionSetValue>(AttributeNames.PCPlatformStatus.StatusCode).Value;
                        localPlatformStatusId = entity.Id;
                    }
                }

                return (StatusCode, localPlatformStatusId);
            }, ("productComponentId", fiji_productcomponentid), ("modelId", ModelID));

            pc_platform_statusid = resultTuple.localPlatformStatusId;
            return resultTuple.StatusCode;
        }
        #endregion

        public void DeletePcPlatformStatus(string productComponentId, string platformId)
        {
            TraceOperation(nameof(DeletePcPlatformStatus), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.PCPlatformStatus)
                {
                    ColumnSet = new ColumnSet(AttributeNames.PCPlatformStatus.PCPlatformStatusId),
                };
                query.Criteria.AddCondition(AttributeNames.PCPlatformStatus.ProductComponentId, ConditionOperator.Equal, productComponentId);
                query.Criteria.AddCondition(AttributeNames.PCPlatformStatus.PlatformId, ConditionOperator.Equal, platformId);

                EntityCollection pcPlatformStatuses = DataverseClient.RetrieveMultiple(query);

                foreach (var entity in pcPlatformStatuses.Entities)
                {
                    DataverseClient.Delete(EntityName.PCPlatformStatus, entity.Id);
                }
            }, ("productComponentId", productComponentId), ("platformId", platformId));
        }

        //Create a new PC Platform status with Extend Model is false
        public void DuplicatePCPlatformStatusandPlatformID(Guid pcplatformstatusid, Guid fiji_productcomponent, string? platformId, string? description)
        {
            TraceOperation(nameof(DuplicatePCPlatformStatusandPlatformID), () =>
            {
                string platformName = GetPlatformName(platformId);
                string finalName = string.IsNullOrWhiteSpace(description) ? platformName ?? string.Empty : string.IsNullOrWhiteSpace(platformName) ? description : $"{description}_{platformName}";
                Entity copyPcPlatformstatus = new Entity(EntityName.PCPlatformStatus);
                copyPcPlatformstatus.Id = Guid.NewGuid();
                copyPcPlatformstatus[AttributeNames.PCPlatformStatus.StatusCode] = (int)eStatusCode.Draft;
                copyPcPlatformstatus[AttributeNames.PCPlatformStatus.ProductComponentId] = Utils.GetEntityReference(EntityName.ProductComponent, fiji_productcomponent.ToString());
                if (!string.IsNullOrEmpty(platformId))
                    copyPcPlatformstatus[AttributeNames.PCPlatformStatus.PlatformId] = Utils.GetEntityReference(EntityName.ProductFamily, platformId);
                if (!string.IsNullOrEmpty(description))
                    copyPcPlatformstatus[AttributeNames.PCPlatformStatus.Name] = finalName;

                this.Execute(new CreateRequest { Target = copyPcPlatformstatus });
            }, ("pcPlatformStatusId", pcplatformstatusid), ("productComponentId", fiji_productcomponent), ("platformId", platformId));
        }

        public string GetPlatformName(string? platformId)
        {
            return TraceOperation(nameof(GetPlatformName), () =>
            {
                if (string.IsNullOrWhiteSpace(platformId))
                    return string.Empty;

                QueryExpression query = new QueryExpression(EntityName.PCPlatformStatus)
                {
                    ColumnSet = new ColumnSet(AttributeNames.PCPlatformStatus.PlatformId)
                };

                query.Criteria.AddCondition(AttributeNames.PCPlatformStatus.PlatformId, ConditionOperator.Equal, Guid.Parse(platformId));

                Entity entity = this.DataverseClient.RetrieveMultiple(query).Entities.FirstOrDefault();

                EntityReference platformRef = entity?.GetAttributeValue<EntityReference>(AttributeNames.PCPlatformStatus.PlatformId);

                return platformRef?.Name ?? string.Empty;
            }, ("platformId", platformId));
        }

        public List<string> GetAssociatedPlatformNamesByProductComponent(Guid fiji_productcomponent)
        {
            return TraceOperation(nameof(GetAssociatedPlatformNamesByProductComponent), () =>
            {
                try
                {
                    List<string> platformNames = new List<string>();

                    QueryExpression query = new QueryExpression(EntityName.PCPlatformStatus)
                    {
                        ColumnSet = new ColumnSet(AttributeNames.PCPlatformStatus.PlatformId, AttributeNames.PCPlatformStatus.PCPlatformStatusId)
                    };

                    // Filter by Product Component
                    query.Criteria.AddCondition(AttributeNames.PCPlatformStatus.ProductComponentId, ConditionOperator.Equal, fiji_productcomponent);

                    // Latest created records first
                    query.AddOrder(AttributeNames.PCPlatformStatus.Createdon, OrderType.Descending);

                    EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                    if (result != null && result.Entities.Count > 0)
                    {
                        foreach (Entity entity in result.Entities)
                        {
                            EntityReference platformRef =
                                entity.GetAttributeValue<EntityReference>(
                                    AttributeNames.PCPlatformStatus.PlatformId);

                            if (platformRef != null &&
                                !string.IsNullOrWhiteSpace(platformRef.Name))
                            {
                                platformNames.Add(platformRef.Name);
                            }
                        }
                    }

                    return platformNames;
                }
                catch (Exception ex)
                {
                    throw new Exception(
                        $"Error while fetching associated platform names for Product Component Id : {fiji_productcomponent}",
                        ex);
                }
            }, ("productComponentId", fiji_productcomponent));
        }
    }
}
