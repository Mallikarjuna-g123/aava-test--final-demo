﻿using FIJI.Portal.WebAPI.Integration.Model.Dev;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Requests.Customer;
using FIJI.Portal.WebAPI.Integration.Responses.Customer;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Contact : Base<Contact>
    {
        private readonly ServiceSnapshot? _ServiceSnapshotService;
        private readonly ProductComponent? _ProductComponentService;
        private DevBaseInfra? _devbaseinfra;
        private readonly ILogger<Contact> _logger;
        
        public Guid? Id { get; set; }
        public string? Name { get; set; }

        public enum eContactType
        {
            External = 219180001,
            Internal = 219180000
        }

        public Contact() : base("contact") { }

        public Contact(IOrganizationService dataverseClient, IMemoryCache cache, ILogger<Contact>? logger = null, ILoggerFactory? loggerFactory = null) : base(dataverseClient, "contact", logger)
        {
            loggerFactory ??= NullLoggerFactory.Instance;
            _ServiceSnapshotService = new ServiceSnapshot(dataverseClient, cache, loggerFactory.CreateLogger<ServiceSnapshot>(), loggerFactory);
            _ProductComponentService = new ProductComponent(dataverseClient, cache, loggerFactory.CreateLogger<ProductComponent>(), loggerFactory);
        }

        public CustomerRequestPayloadResponse GetRequestListbyCustomer(CustomerRequestPayloadRequest request)
        {
            return TraceOperation(nameof(GetRequestListbyCustomer), () =>
            {
                BeginTransaction();
                CustomerRequestPayloadResponse response = new CustomerRequestPayloadResponse();
                //convert to UTC before query data
                List<KeyValuePair<string, int>> timeZoneList = Utils.TimeZoneList(DataverseClient);
                var startDate = "";
                var endDate = "";
                if (request?.Timezone != null)
                {
                    if (request?.CreatedFrom != null && request?.CreatedTill != null)
                    {
                        request.CreatedFrom = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.CreatedFrom), timeZoneList);
                        request.CreatedTill = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.CreatedTill), timeZoneList);
                    }
                    if (request?.LastModifiedFrom != null && request?.LastModifiedTill != null)
                    {
                        request.LastModifiedFrom = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.LastModifiedFrom), timeZoneList);
                        request.LastModifiedTill = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.LastModifiedTill), timeZoneList);
                    }
                    if (request?.EndOfLifeFrom != null && request?.EndOfLifeTill != null)
                    {
                        request.EndOfLifeFrom = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.EndOfLifeFrom), timeZoneList);
                        request.EndOfLifeTill = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.EndOfLifeTill), timeZoneList);
                    }
                }
                response = GetRequestListbyCustomerQuery(request);
                response.TotalCount = GetRequestListCount(request);
                CommitTransaction();
                return response;
            }, ("timeZone", request?.Timezone), ("hasDateFilters", request?.CreatedFrom != null || request?.LastModifiedFrom != null || request?.EndOfLifeFrom != null));
        }

        public CustomerServicesResponse GetServicesListbyCustomer(CustomerServicesRequest request)
        {
            return TraceOperation(nameof(GetServicesListbyCustomer), () =>
            {
                BeginTransaction();
                CustomerServicesResponse response = new CustomerServicesResponse();
                //convert to UTC before query data
                List<KeyValuePair<string, int>> timeZoneList = Utils.TimeZoneList(DataverseClient);
                var startDate = "";
                var endDate = "";
                if (request?.Timezone != null)
                {
                    if (request?.CreatedFrom != null && request?.CreatedTill != null)
                    {
                        request.CreatedFrom = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.CreatedFrom), timeZoneList);
                        request.CreatedTill = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.CreatedTill), timeZoneList);
                    }
                    if (request?.LastModifiedFrom != null && request?.LastModifiedTill != null)
                    {
                        request.LastModifiedFrom = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.LastModifiedFrom), timeZoneList);
                        request.LastModifiedTill = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.LastModifiedTill), timeZoneList);
                    }
                    if (request?.EndOfLifeFrom != null && request?.EndOfLifeTill != null)
                    {
                        request.EndOfLifeFrom = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.EndOfLifeFrom), timeZoneList);
                        request.EndOfLifeTill = Utils.GetConvertedTimeSourceToUTC(Convert.ToInt32(request.Timezone), Convert.ToDateTime(request.EndOfLifeTill), timeZoneList);
                    }
                }
                response = GetServicesListbyCustomerQuery(request);
                response.TotalCount = GetServicesListCount(request);
                CommitTransaction();
                return response;
            }, ("timeZone", request?.Timezone), ("hasDateFilters", request?.CreatedFrom != null || request?.LastModifiedFrom != null || request?.EndOfLifeFrom != null));
        }

        public CustomerRequestPayloadResponse GetRequestListbyCustomerQuery(CustomerRequestPayloadRequest request)
        {
            return TraceOperation(nameof(GetRequestListbyCustomerQuery), () =>
            {
                CustomerRequestPayloadResponse response = new CustomerRequestPayloadResponse();
                response.Requests = new List<Responses.Customer.Requests>();

                var query = SqlQuery.GetSqlQueryForRequestsByCustomerSearch(request);
                string formattedQuery = string.Format(query);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(new FetchExpression(formattedQuery));
                if (result != null && result.Entities.Count > 0)
                {
                    HashSet<Guid> processedProjects = new HashSet<Guid>();
                    foreach (var tempentity in result.Entities)
                    {
                        var projectId = tempentity.GetAttributeValue<Guid?>("fiji_projectid");
                        if (projectId == null || !processedProjects.Add(projectId.Value))
                        {
                            continue;
                        }

                        Responses.Customer.Requests requests = new();

                        requests.Projectid = ((Guid?)tempentity.GetAttributeValue<Guid?>("fiji_projectid").Value) ?? null;

                        requests.RequestName = ((string?)tempentity.GetAttributeValue<string?>("fiji_configurationname")?.ToString()) ?? string.Empty;

                        requests.ProjectDueDate = ((string?)tempentity.GetAttributeValue<DateTime?>("fiji_projectduedate")?.ToString()) ?? null;

                        requests.OriginalProjectDueDate = ((string?)tempentity.GetAttributeValue<DateTime?>("fiji_originalprojectduedate")?.ToString()) ?? null;

                        requests.ProjectCompletedOn = ((string?)tempentity.GetAttributeValue<DateTime?>("fiji_projectcompletedon")?.ToString()) ?? null;

                        requests.Status = Utils.GetValue<OptionSetValue>(tempentity, "statuscode")?.Value ?? null;

                        requests.Stage = Utils.GetValue<OptionSetValue>(tempentity, "fiji_projectstage")?.Value.ToString() ?? null;

                        requests.PartNo = ((string?)tempentity.GetAttributeValue<string?>("fiji_productexternalid")?.ToString()) ?? null;

                        requests.OciId = ((int?)tempentity.GetAttributeValue<int?>("fiji_occid")) ?? null;

                        requests.RequestId = ((string?)tempentity.GetAttributeValue<string?>("fiji_requestid")?.ToString()) ?? null;

                        requests.LastModifiedBy = tempentity.GetAttributeValue<EntityReference>("modifiedby")?.Id ?? null;

                        requests.ModifiedbyPortalContact = (string?)(tempentity.GetAttributeValue<EntityReference>("fiji_modifiedbyportalcontact")?.Name.ToString()) ?? null;

                        requests.LastModifiedOn = ((string?)tempentity.GetAttributeValue<DateTime?>("modifiedon")?.ToString()) ?? null;

                        requests.Platform = new ProductFamily()
                        {
                            Name = ((string?)tempentity.GetAttributeValue<AliasedValue?>("platform.fiji_name")?.Value),
                            DeviceCategory = new DeviceCategory()
                            {
                                Iconurl = ((string?)tempentity.GetAttributeValue<AliasedValue?>("devicecategoryid.fiji_iconurl")?.Value)
                            }
                        };
                        // requests.PortalDescription = ((string?)tempentity.GetAttributeValue<AliasedValue?>("productcomponent.fiji_portaldescription")?.Value.ToString()) ?? null;
                        requests.CustomerName = ((string?)tempentity.GetAttributeValue<EntityReference>(AttributeNames.Project.CustomerId)?.Name) ?? null;
                        requests.ProjectName = ((string?)tempentity.GetAttributeValue<string?>(AttributeNames.Project.ProjectName)?.ToString()) ?? null;
                        requests.ProjectManagerEmail = ((string?)tempentity.GetAttributeValue<AliasedValue?>("projectmanager.internalemailaddress")?.Value.ToString()) ?? null;
                        //get project stage tracker
                        QueryExpression queryForProjectStageTracker = new QueryExpression(EntityName.ProjectStageTracker)
                        {
                            ColumnSet = new ColumnSet(AttributeNames.ProjectStageTracker.ProjectStage, AttributeNames.ProjectStageTracker.ProjectStageTrackerId, AttributeNames.ProjectStageTracker.StageCompletedOn)
                        };
                        queryForProjectStageTracker.Criteria.AddCondition(AttributeNames.ProjectStageTracker.ProjectId, ConditionOperator.Equal, tempentity.Id);
                        EntityCollection projectStageTrackerColl = this.DataverseClient.RetrieveMultiple(queryForProjectStageTracker);
                        if (projectStageTrackerColl != null && projectStageTrackerColl.Entities.Count > 0)
                        {
                            requests.StageTrackers = new List<ProjectStageTracker>();
                            foreach (var projectStageTracker in projectStageTrackerColl.Entities)
                            {
                                ProjectStageTracker projectStageTrackerObj = new ProjectStageTracker();
                                projectStageTrackerObj.ProjectStage = ((string?)projectStageTracker.GetAttributeValue<string?>(AttributeNames.ProjectStageTracker.ProjectStage)?.ToString()) ?? null;
                                projectStageTrackerObj.StageCompletedOn = ((string?)projectStageTracker.GetAttributeValue<DateTime?>(AttributeNames.ProjectStageTracker.StageCompletedOn)?.ToString()) ?? null;
                                requests.StageTrackers.Add(projectStageTrackerObj);
                            }
                        }
                        else
                        {
                            requests.StageTrackers = null;
                        }
                        requests.IsHidden = tempentity.GetAttributeValue<bool?>("fiji_portalcontrolledhidden") ?? false;

                        response.Requests.Add(requests);
                    }
                    return response;
                }
                response.TotalCount = 0;
                return response;
            }, ("request page number", request?.PageNumber));
        }

        public int? GetRequestListCount(CustomerRequestPayloadRequest request)
        {
            int? totalRecords = 0;
            return TraceOperation(nameof(GetRequestListCount), () =>
            {
                var query = SqlQuery.GetSqlQueryForRequestsByCustomerSearchForAggregate(request);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(new FetchExpression(query));
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    totalRecords = (int?)entity.GetAttributeValue<AliasedValue?>("TotalCount").Value;
                    return totalRecords;
                }
                return totalRecords;
            }, ("result count", totalRecords));
        }

        public CustomerServicesResponse GetServicesListbyCustomerQuery(CustomerServicesRequest request)
        {
            return TraceOperation(nameof(GetServicesListbyCustomerQuery), () =>
            {
                _ServiceSnapshotService.SetTransaction(this.Transaction);
                CustomerServicesResponse response = new();
                response.Services = new List<CustomerServices>();

                var query = SqlQuery.GetSqlQueryForServicesByCustomerSearch(request);
                string formattedQuery = string.Format(query);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(new FetchExpression(formattedQuery));
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        CustomerServices service = new();
                        Guid? productcomponentid = ((Guid?)tempentity.GetAttributeValue<Guid?>("fiji_productcomponentid")).Value;
                        service.Description = ((string?)tempentity.GetAttributeValue<string?>("fiji_name")?.ToString()) ?? null;
                        service.ExternalId = ((string?)tempentity.GetAttributeValue<string?>("fiji_externalid")?.ToString()) ?? null;
                        service.ProductComponentId = ((Guid?)tempentity.GetAttributeValue<Guid?>("fiji_productcomponentid").Value) ?? null;
                        service.Fiji_Fiji_Productcomponentid = ((string?)tempentity.GetAttributeValue<string?>("fiji_fiji_productcomponentid")?.ToString()) ?? null;
                        service.PortalDescription = ((string?)tempentity.GetAttributeValue<string?>("fiji_portaldescription")?.ToString()) ?? null;
                        service.ComponentType = new ComponentType()
                        {
                            Id = ((Guid?)tempentity.GetAttributeValue<AliasedValue?>("componentype.fiji_componenttypeid")?.Value) ?? null,
                            PortalDescription = ((string?)tempentity.GetAttributeValue<AliasedValue?>("componentype.fiji_portal_description")?.Value) ?? null,
                            ServiceCategory = ((EntityReference?)tempentity.GetAttributeValue<AliasedValue?>("componentype.fiji_service_category")?.Value)?.Name ?? null,
                            StatusCode = ((OptionSetValue?)tempentity.GetAttributeValue<AliasedValue?>("componentype.statuscode")?.Value)?.Value ?? null,
                            RequiredAdditionalInfoMultiModel = ((bool?)tempentity.GetAttributeValue<AliasedValue?>("componentype.fiji_req_addit_info_multi_model")?.Value) ?? false,
                            ServiceNumber = ((string?)tempentity.GetAttributeValue<AliasedValue?>("componentype.fiji_servicenumber")?.Value) ?? null,
                            IsMultiModel = ((bool?)tempentity.GetAttributeValue<AliasedValue?>("componentype.fiji_ismultimodel")?.Value) ?? null,
                            GetMoreService = new ComponentType
                            {
                                Id = ((Guid?)tempentity.GetAttributeValue<AliasedValue?>("getmoreCT.fiji_componenttypeid")?.Value) ?? null,
                                PortalDescription = ((string?)tempentity.GetAttributeValue<AliasedValue?>("getmoreCT.fiji_portal_description")?.Value) ?? null,
                                ServiceCategory = ((EntityReference?)tempentity.GetAttributeValue<AliasedValue?>("getmoreCT.fiji_service_category")?.Value)?.Name ?? null,
                                StatusCode = ((OptionSetValue?)tempentity.GetAttributeValue<AliasedValue?>("getmoreCT.statuscode")?.Value)?.Value ?? null,
                                RequiredAdditionalInfoMultiModel = ((bool?)tempentity.GetAttributeValue<AliasedValue?>("getmoreCT.fiji_req_addit_info_multi_model")?.Value) ?? false,
                            }
                        };
                        service.LastModifiedOn = tempentity.GetAttributeValue<DateTime?>("modifiedon") ?? null;
                        ServiceSnapshot? LatestServiceRevision = new ServiceSnapshot();
                        if (productcomponentid != null)
                            LatestServiceRevision = _ServiceSnapshotService.GetLatestServiceRevisionByProductcomponent(productcomponentid.ToString(), request.LatestServiceStatusCode);
                        service.LatestServiceRevision = LatestServiceRevision;
                        service.IsHidden = tempentity.GetAttributeValue<bool?>("fiji_portalcontrolledhidden") ?? false;

                        ComponentType GetMoreSource = new ComponentType();
                        if (productcomponentid != null)
                            GetMoreSource = _ProductComponentService.GetMoreSourceByProductComponentId(productcomponentid.ToString());
                        service.GetMoreSource = GetMoreSource;

                        response.Services.Add(service);
                    }
                    return response;
                }
                return response;
            }, ("request page number", request?.PageNumber));
        }

        public int? GetServicesListCount(CustomerServicesRequest request)
        {
            int? totalRecords = 0;
            return TraceOperation(nameof(GetServicesListCount), () =>
            {
                var query = SqlQuery.GetSqlQueryForServicesByCustomerSearchForAggregate(request);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(new FetchExpression(query));
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    totalRecords = (int?)entity.GetAttributeValue<AliasedValue?>("TotalCount").Value;
                    return totalRecords;
                }
                return totalRecords;
            }, ("result count", totalRecords));
        }

        public string GetFSPMUsingCustomerID(string customerId, string token)
        {
            return TraceOperation(nameof(GetFSPMUsingCustomerID), () =>
            {
                string query = $@"?$select=accountid&$expand=fiji_ProjectManager($select=systemuserid,isdisabled,internalemailaddress),fiji_BackupProjectManager($select=systemuserid,isdisabled,internalemailaddress),fiji_CustomerHeadquarterCountryId($select=fiji_countryid;$expand=fiji_ProjectManager($select=systemuserid,isdisabled,internalemailaddress),fiji_BackupProjectManager($select=systemuserid,isdisabled,internalemailaddress))&$filter=(accountid eq {customerId})";
                _devbaseinfra = new DevBaseInfra(null, token);
                return _devbaseinfra.retrieveMultipleRecords(EntityName.Account, query, 0).Result;
            }, ("customerId", customerId));
        }

        public string FetchVolumeLicenseManager(string customerId, string token)
        {
            return TraceOperation(nameof(FetchVolumeLicenseManager), () =>
            {
                string currentDate = DateTime.UtcNow.ToString("o");
                string query = $@"?$select=fiji_name,_fiji_contact_value,fiji_agreementnumber,fiji_activationmethod,_ownerid_value,fiji_expirationdate,fiji_multipleactivationkey&$expand=owninguser($select=fullname)&$filter=_fiji_customer_value eq '{customerId}' and statecode eq 0 and fiji_useby eq 2 and modifiedon le '{currentDate}'&$orderby=fiji_expirationdate desc";
                _devbaseinfra = new DevBaseInfra(null, token);
                return _devbaseinfra.retrieveMultipleRecords(EntityName.PortalManagementInfo, query, 0).Result;
            }, ("customerId", customerId));
        }
    }
}