﻿namespace FIJI.Portal.WebAPI.Integration.Model
{

    public class CreateDuplicateProject
    {
        public bool IsDuplicateProject { get; set; }
        public bool PortalInitiated { get; set; }
        public int ProjectType { get; set; }
        public int ProductType { get; set; }
        public int OCCID { get; set; }
        public int NewOrECN { get; set; }

        public string ProjectName { get; set; }
        public string CustomerId { get; set; }

        public string projectid { get; set; }

        public string entityname { get; set; }

    }
}
