﻿namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class CreateProject
    {
        public string accessToken { get; set; }
        public string Accountid { get; set; }
        public string Contactid { get; set; }
        public int OccId { get; set; }
        public string Platformid { get; set; }
        public string serviceurl { get; set; }

    }
}
