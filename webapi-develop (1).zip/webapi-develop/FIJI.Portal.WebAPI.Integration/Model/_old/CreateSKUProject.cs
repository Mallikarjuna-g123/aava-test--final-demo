﻿
namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class CreateSKUProject
    {

        public string accessToken { get; set; }
        public string Accountid { get; set; }
        public int OccId { get; set; }
        public int NeworECN { get; set; }
        public int projecttype { get; set; }
        public int producttype { get; set; }
        public string Platformid { get; set; }
        public string Kmatproductfamily { get; set; }
        public string ProjectOriginatingRegion { get; set; }
        public string AdditionalEmail { get; set; }
        public string Comments { get; set; }
        public string CustomerRequestDate { get; set; }
        public string ModifiedbyPortalContact { get; set; }
        public string ProjectManager { get; set; }
        public string ParentprojectId { get; set; }
        public string serviceurl { get; set; }


    }
}
