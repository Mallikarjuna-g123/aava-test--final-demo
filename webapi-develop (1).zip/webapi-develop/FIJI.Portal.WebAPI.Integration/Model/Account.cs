﻿using FIJI.Portal.WebAPI.Integration.Integration;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Account : Base<Account>
    {
        public Guid? Id { get; set; }

        public string? Name { get; set; }
        public Account() : base("account", NullLogger<Account>.Instance) { }
        
        public Account(IOrganizationService dataverseClient, ILogger<Account>? logger = null) : base(dataverseClient, "account", logger) { }
        
        /// <summary>
        /// Check if ManagerType is not null
        /// and is not desabled
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="managerType"></param>
        /// <returns></returns>
        public string GetManagerId(string customerId, string managerType)
        {
            return TraceOperation(nameof(GetManagerId), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.Account)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Account.AccountId, managerType)
                };

                // Add sorting by the "name" attribute in ascending order
                query.AddOrder(AttributeNames.Account.Name, OrderType.Ascending);

                // Add filtering conditions
                FilterExpression filter = new FilterExpression(LogicalOperator.And);
                filter.AddCondition(AttributeNames.Account.AccountId, ConditionOperator.Equal, Guid.Parse(customerId));
                filter.AddCondition(managerType, ConditionOperator.NotNull);
                query.Criteria.AddFilter(filter);

                // Create a link-entity for "systemuser"
                LinkEntity linkEntity = new LinkEntity(EntityName.Account, EntityName.SystemUser, managerType, AttributeNames.SystemUser.SystemUserId, JoinOperator.Inner);
                linkEntity.EntityAlias = "bt";

                // Add filtering conditions for the link-entity
                FilterExpression linkFilter = new FilterExpression(LogicalOperator.And);
                linkFilter.AddCondition(AttributeNames.SystemUser.IsDisabled, ConditionOperator.Equal, false);
                linkEntity.LinkCriteria = linkFilter;

                // Add the link-entity to the query
                query.LinkEntities.Add(linkEntity);
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(managerType))
                        return entity.GetAttributeValue<EntityReference>(managerType)?.Id.ToString() ?? string.Empty;
                }
                return string.Empty;
            }, ("customerId", customerId), ("managerType", managerType));
        }

        /// <summary>
        /// GetManagerIdByCountry
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="managerType"></param>
        /// <returns></returns>
        public string GetManagerIdByCountry(string customerId, string managerType)
        {
            return TraceOperation(nameof(GetManagerIdByCountry), () =>
            {
                // Create a QueryExpression for the "account" entity
                QueryExpression query = new QueryExpression(EntityName.Account);
                query.ColumnSet = new ColumnSet(AttributeNames.Account.AccountId, managerType);

                // Add filtering conditions 
                query.Criteria.AddCondition(AttributeNames.Account.AccountId, ConditionOperator.Equal, Guid.Parse(customerId));

                // Create a link-entity for "fiji_country"
                LinkEntity linkEntityCountry = new LinkEntity(EntityName.Account, EntityName.Country, AttributeNames.Account.CustomerHeadQuarterId, AttributeNames.Country.CountryId, JoinOperator.Inner);
                linkEntityCountry.Columns = new ColumnSet(managerType);
                linkEntityCountry.EntityAlias = "bk";

                // Add filtering conditions for the link-entity
                linkEntityCountry.LinkCriteria.AddCondition(managerType, ConditionOperator.NotNull);

                // Create a link-entity for "systemuser"
                LinkEntity linkEntityUser = new LinkEntity(EntityName.Country, EntityName.SystemUser, managerType, AttributeNames.SystemUser.SystemUserId, JoinOperator.Inner);
                linkEntityUser.Columns = new ColumnSet(AttributeNames.SystemUser.IsDisabled);
                linkEntityUser.EntityAlias = "br";

                // Add filtering conditions for the link-entity
                linkEntityUser.LinkCriteria.AddCondition(AttributeNames.SystemUser.IsDisabled, ConditionOperator.Equal, false);

                // Add link-entities to the main query
                linkEntityCountry.LinkEntities.Add(linkEntityUser);
                query.LinkEntities.Add(linkEntityCountry);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains("bk." + managerType))
                    {
                        var manager = (EntityReference)(entity.GetAttributeValue<AliasedValue>("bk." + managerType).Value);
                        return manager.Id.ToString();
                    }
                }
                return string.Empty;
            }, ("customerId", customerId), ("managerType", managerType));
        }


        public string GetCustomerNameorNumberByAccId(Guid accountId, out string customerAccountNumber)
        {
            var result = TraceOperation(nameof(GetCustomerNameorNumberByAccId), () =>
            {
                var accountNumber = string.Empty;
                Entity customer = this.DataverseClient.Retrieve(EntityName.Account, accountId, new ColumnSet(AttributeNames.Account.AccountId, AttributeNames.Account.Name, AttributeNames.Account.AccountNumber));
                if (customer != null && (customer.Contains(AttributeNames.Account.Name) || customer.Contains(AttributeNames.Account.AccountNumber)))
                {
                    accountNumber = customer.GetAttributeValue<string>(AttributeNames.Account.AccountNumber) ?? string.Empty;
                    var customerName = customer.GetAttributeValue<string>(AttributeNames.Account.Name);
                    return (customerName ?? string.Empty, accountNumber);
                }

                return (string.Empty, accountNumber);
            }, ("accountId", accountId));

            customerAccountNumber = result.Item2;
            return result.Item1;
        }

        public string? GetCustomerNames(List<Guid>? customerIds)
        {
            return TraceOperation(nameof(GetCustomerNames), () =>
            {
                if (customerIds == null || customerIds.Count == 0)
                    return null;

                QueryExpression query = new QueryExpression(EntityName.Account)
                {
                    ColumnSet = new ColumnSet(AttributeNames.Account.Name)
                };

                var customerIdObjects = customerIds.Cast<object>().ToArray();
                query.Criteria.AddCondition(AttributeNames.Account.AccountId, ConditionOperator.In, customerIdObjects);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                if (result != null && result.Entities.Count > 0)
                {
                    var names = result.Entities
                                      .Where(e => e.Contains(AttributeNames.Account.Name))
                                      .Select(e => e.GetAttributeValue<string>(AttributeNames.Account.Name))
                                      .ToList();

                    return string.Join(",", names); //comma-separated string
                }

                return null;
            }, ("customerCount", customerIds?.Count));
        }

        //public EntityCollection GetActiveCustomers(string accountId)
        //{
        //    EntityCollection entities = new EntityCollection();
        //    if (string.IsNullOrEmpty(accountId))
        //    {
        //        int pageNumber = 1;
        //        int fetchCount = 5000;
        //        string pagingCookie = null;


        //        while (true)
        //        {
        //            var query = new QueryExpression(EntityName.Account);
        //            query.PageInfo = new PagingInfo
        //            {
        //                Count = fetchCount,
        //                PageNumber = pageNumber,
        //                PagingCookie = pagingCookie
        //            };
        //            query.Distinct = true;
        //            query.ColumnSet.AddColumns(AttributeNames.Account.AccountId, AttributeNames.Account.Name);
        //            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
        //            query.Criteria.AddCondition("fiji_accounttype", ConditionOperator.Equal, 219180000); //customer account type
        //            EntityCollection entitiesPerPage = DataverseClient.RetrieveMultiple(query);
        //            entities.Entities.AddRange(entitiesPerPage.Entities);
        //            if (entities.MoreRecords)
        //            {
        //                pageNumber++;
        //                pagingCookie = entities.PagingCookie;
        //            }
        //            else
        //            {
        //                break;
        //            }
        //        }
        //    }
        //    else
        //    {
        //        Entity entity = DataverseClient.Retrieve(EntityName.Account, Guid.Parse(accountId), new ColumnSet(AttributeNames.Account.AccountId));
        //        entities.Entities.Add(entity);
        //    }

        //    return entities;
        //}

        //internal async Task<string> InitiateCreateFolder(string accountId)
        //{
        //    try
        //    {
        //        string? storageAccountName = Environment.GetEnvironmentVariable(Constants.StorageAccount);
        //        StorageAccountHelper storage = new StorageAccountHelper(storageAccountName, null);
        //        FileModel fileModel = new FileModel(DataverseClient, storage, false);

        //        EntityCollection entities = GetActiveCustomers(accountId);
        //        string folderCreated = await fileModel.CreateFileContainer(entities);

        //        return folderCreated;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
    }
}
