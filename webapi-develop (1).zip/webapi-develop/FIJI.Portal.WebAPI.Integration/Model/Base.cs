﻿using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.PluginTelemetry;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Base<T> where T : Base<T>
    {
        protected IOrganizationService? DataverseClient { get; private set; }
        protected ExecuteTransactionRequest? Transaction { get; set; }
        public bool TransactionStarted { get; set; }

        protected string ActivityPrefix { get; private set; }

        protected ILogger<T> Logger { get; private set; }

        public Base(string activityPrefix, ILogger<T>? logger = null) { 
            this.ActivityPrefix  = activityPrefix;
            this.Logger = logger ?? NullLogger<T>.Instance; 
        }
        public Base(IOrganizationService service, string activityPrefix, Microsoft.Extensions.Logging.ILogger<T>? logger = null)
        {
            DataverseClient = service;
            this.ActivityPrefix = activityPrefix;
            this.Logger = logger ?? NullLogger<T>.Instance; 
        }

        public void BeginTransaction(ExecuteTransactionRequest transaction = null)
        {
            if (transaction == null)
            {
                Transaction = new ExecuteTransactionRequest()
                {
                    Requests = new OrganizationRequestCollection(),
                    ReturnResponses = true
                };
            }
            else
            {
                this.Transaction = transaction;
            }
            TransactionStarted = true;
        }
        public ExecuteTransactionResponse CommitTransaction()
        {
            TransactionStarted = false;
            return (ExecuteTransactionResponse)DataverseClient.Execute(Transaction);
        }

        internal void SetTransaction(ExecuteTransactionRequest currentTransaction)
        {
            if (currentTransaction == null)
                throw new ArgumentNullException(Constants.ErrorMessages.NullTransaction);

            this.Transaction = currentTransaction;
            this.TransactionStarted = true;
        }

        internal OrganizationResponse Execute(OrganizationRequest request)
        {
            if (this.TransactionStarted)
                Transaction.Requests.Add(request);
            else
                return DataverseClient.Execute(request);

            return default(OrganizationResponse);
        }

        protected void TraceOperation(string operationName, Action action, params (string Key, object? Value)[] context)
        {
            OperationTraceHelper.TraceOperation(this.Logger, nameof(T), this.ActivityPrefix, operationName, action, context);
        }

        protected T TraceOperation<T>(string operationName, Func<T> action, params (string Key, object? Value)[] context)
        {
            return OperationTraceHelper.TraceOperation(this.Logger, nameof(T), this.ActivityPrefix, operationName, action, context);
        }

        protected Task<T> TraceOperationAsync<T>(string operationName, Func<Task<T>> action, params (string Key, object? Value)[] context)
        {
            return OperationTraceHelper.TraceOperationAsync(this.Logger, nameof(T), this.ActivityPrefix, operationName, action, context);
        }
    }
}
