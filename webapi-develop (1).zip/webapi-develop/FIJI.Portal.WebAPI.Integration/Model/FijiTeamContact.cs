﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class FijiTeamContact: Base<FijiTeamContact>
    {
        public FijiTeamContact(IOrganizationService dataverseClient) : base(dataverseClient, "fijiteamcontact")
        {

        }
    }
}
