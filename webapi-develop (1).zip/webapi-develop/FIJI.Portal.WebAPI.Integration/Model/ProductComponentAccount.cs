﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ProductComponentAccount: Base<ProductComponentAccount>
    {
        public ProductComponentAccount(IOrganizationService dataverseClient) : base(dataverseClient, "productcomponentaccount") { }
    }
}
