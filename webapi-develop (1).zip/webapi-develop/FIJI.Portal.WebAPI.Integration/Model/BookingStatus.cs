﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class BookingStatus: Base<BookingStatus>
    {
        public BookingStatus(IOrganizationService dataverseClient) : base(dataverseClient, "bookingstatus")
        {

        }
    }
}
