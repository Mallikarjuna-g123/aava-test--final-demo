﻿using FIJI.Portal.WebAPI.Integration.Responses.AuditSummary;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class AuditSummary : Base<AuditSummary>
    {
        
        public AuditSummary() : base("auditsummary", NullLogger<AuditSummary>.Instance) { }

        public AuditSummary(IOrganizationService dataverseClient, ILogger<AuditSummary>? logger = null) : base(dataverseClient, "auditsummary", logger)
        { }

        public AuditSummaryResponse GetAuditSummary(string entityName, int timeRange, string excludeUser)
        {
            return TraceOperation(nameof(GetAuditSummary), () =>
            {
                AuditSummaryResponse response = new AuditSummaryResponse();
                DateTime currentDate = DateTime.Now;
                DateTime date = currentDate.AddHours(-timeRange);
                List<string> excludeuserColl = excludeUser.Split(',').ToList();
                List<Guid> excludeUserCollGuid = excludeuserColl.Select(Guid.Parse).ToList();
                int pageNumber = 1;
                int fetchCount = 5000;
                string pagingCookie = null;
                EntityCollection results = new();
                while (true)
                {
                    var query = new QueryExpression("audit");
                    query.PageInfo = query.PageInfo = new PagingInfo
                    {
                        Count = fetchCount,
                        PageNumber = pageNumber,
                        PagingCookie = pagingCookie
                    };
                    query.ColumnSet.AddColumns("userid", "changedata", "additionalinfo", "createdon", "objectid", "objecttypecode", "objectid");
                    query.Criteria.AddCondition("objecttypecode", ConditionOperator.Equal, entityName);
                    query.Criteria.AddCondition("action", ConditionOperator.Equal, 3); //for delete action
                    query.Criteria.AddCondition("createdon", ConditionOperator.LessEqual, currentDate);
                    query.Criteria.AddCondition("createdon", ConditionOperator.GreaterEqual, date);
                    if (!string.IsNullOrEmpty(excludeUser) && excludeUserCollGuid.Count > 0)
                    {
                        ConditionExpression condition = new ConditionExpression("userid", ConditionOperator.NotIn);
                        foreach (Guid id in excludeUserCollGuid)
                            condition.Values.Add(id);
                        query.Criteria.AddCondition(condition);
                    }
                    query.Orders.Add(new OrderExpression("createdon", OrderType.Ascending));

                    EntityCollection resultPerPage = this.DataverseClient.RetrieveMultiple(query);
                    results.Entities.AddRange(resultPerPage.Entities);
                    if (results.MoreRecords)
                    {
                        pageNumber++;
                        pagingCookie = results.PagingCookie;
                    }
                    else
                    {
                        break;
                    }
                }

                //initialize
                response.UserId = Guid.Empty;
                response.UseridName = string.Empty;
                response.CreatedOn = DateTime.MinValue;
                response.Additionalinfo = string.Empty;
                response.AuditId = Guid.Empty;
                response.BomId = Guid.Empty;
                response.ProjectId = string.Empty;
                response.ProductId = string.Empty;
                response.BOMNumber = string.Empty;

                if (results != null && results.Entities.Count > 0)
                {
                    foreach (var i in results.Entities)
                    {
                        bool isdeleted = false;
                        var changedData = JObject.Parse(i.GetAttributeValue<string>("changedata"));
                        if (changedData != null && changedData["changedAttributes"].Any())
                        {
                            var data = changedData["changedAttributes"].FirstOrDefault(x =>
                                (string)x["logicalName"] == "fiji_bomtype"
                                && ((string)x["oldValue"] == "102420001"
                                    || (string)x["newValue"] == "102420001"));
                            if (data != null)
                            {
                                response.Count++;
                                if (response.Count > 1)
                                    continue;
                                isdeleted = true;
                                var projectId = changedData["changedAttributes"].FirstOrDefault(x => (string)x["logicalName"] == "fiji_project");
                                if (projectId != null)
                                {
                                    response.ProjectId = projectId["oldValue"].ToString() ?? string.Empty;
                                }
                                var productId = changedData["changedAttributes"].FirstOrDefault(x => (string)x["logicalName"] == "fiji_product");
                                if (productId != null)
                                {
                                    response.ProductId = productId["oldValue"].ToString() ?? string.Empty;
                                }
                                var bomNumber = changedData["changedAttributes"].FirstOrDefault(x => (string)x["logicalName"] == "fiji_name");
                                if (bomNumber != null)
                                {
                                    response.BOMNumber = bomNumber["oldValue"].ToString() ?? string.Empty;
                                }
                            }
                            if (isdeleted)
                            {
                                var userId = i.GetAttributeValue<EntityReference>("userid");
                                response.UserId = userId.Id;
                                response.UseridName = userId.Name ?? string.Empty;
                                response.CreatedOn = i.GetAttributeValue<DateTime>("createdon");
                                response.Additionalinfo = i.GetAttributeValue<string>("additionalinfo") ?? string.Empty;
                                response.AuditId = i.Id;
                                response.BomId = i.GetAttributeValue<EntityReference>("objectid").Id;
                            }
                        }
                    }
                }
                else
                {
                    response.UserId = Guid.Empty;
                    response.UseridName = string.Empty;
                    response.CreatedOn = DateTime.MinValue;
                    response.Additionalinfo = string.Empty;
                    response.AuditId = Guid.Empty;
                    response.BomId = Guid.Empty;
                    response.ProjectId = string.Empty;
                    response.ProductId = string.Empty;
                    response.BOMNumber = string.Empty;
                }

                return response;
            }, ("entityName", entityName), ("timeRangeHours", timeRange), ("hasExcludeUsers", !string.IsNullOrEmpty(excludeUser)));
        }
    }
}