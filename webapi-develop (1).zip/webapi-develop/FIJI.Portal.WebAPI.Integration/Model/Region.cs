﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Region : Base<Region>
    {
        public Region(IOrganizationService dataverseClient, ILogger<Region>? logger = null) : base(dataverseClient, "region") { }
     
        public Guid? GetRegionBy(Guid managerId)
        {
            return TraceOperation<Guid?>(nameof(GetRegionBy), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.Region);
                query.ColumnSet = new ColumnSet(AttributeNames.Region.RegionId);
                query.TopCount = 1;

                LinkEntity countryLink = new LinkEntity(EntityName.Region, EntityName.Country, AttributeNames.Region.RegionId, AttributeNames.Country.RegionId, JoinOperator.Inner);
                LinkEntity userLink = new LinkEntity(EntityName.Country, EntityName.SystemUser, AttributeNames.Country.CountryId, AttributeNames.SystemUser.CountryId, JoinOperator.Inner);

                FilterExpression filter = new FilterExpression();
                filter.FilterOperator = LogicalOperator.And;
                filter.AddCondition(AttributeNames.SystemUser.SystemUserId, ConditionOperator.Equal, managerId);

                userLink.LinkCriteria = filter;
                countryLink.LinkEntities.Add(userLink);
                query.LinkEntities.Add(countryLink);

                EntityCollection results = DataverseClient.RetrieveMultiple(query);

                if (results != null && results.Entities.Count > 0)
                {
                    var entity = results.Entities[0];
                    if (entity.Contains(AttributeNames.Region.RegionId))
                        return (Guid?)entity.Id;
                }
                return (Guid?)null;
            }, ("managerId", managerId));
        }
    }
}
