﻿using FIJI.Portal.WebAPI.Integration.Model.Dev;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Requests.Project;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Responses.Project;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.ServiceModel;
using System.Text;
using static FIJI.Portal.WebAPI.Integration.Model.BOM;
using static FIJI.Portal.WebAPI.Integration.Model.ProductComponent;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class Project : Base<Project>
    {
        private readonly BOM? _bomService;
        private readonly Account? _accountService;
        private readonly Country? _countryService;
        private readonly ProductFamily? _productFamilyService;
        private readonly Region? _regionService;
        private readonly SubRegion? _subRegionService;
        private Responses.UpdateCSAVResponse? updateCSAVResponse;
        private ServiceSnapshot? _serviceSnapshotService;
        private PlatformAndPlacement? _platformAndPlacementService;
        private PCPlatformStatus? _pcPlatformStatusService;
        private ProductComponent? _productComponentService;
        private ComponentType? _componentTypeService;
        private readonly ActionCode? _actionCode;
        private FijiAssettagsize? _assetTagSize;
        private DevBaseInfra? _devBaseInfra;
        private static readonly ConcurrentDictionary<string, object> _locks = new ConcurrentDictionary<string, object>();

        public const int COMMENTFIELDLIMIT = 2000;

        public Project() : base("project") { }

        public List<string>? ErrorList { get; set; }

        public string? ModelId { get; set; }
        public string? PortalUserId { get; set; }
        public string? RegionId { get; set; }
        public bool IsNewProject { get; set; }
        public string? CustomerId { get; set; }
        public int ProjectType { get; set; }
        public int ProductType { get; set; }
        public int OcciId { get; set; }
        public int ProjectSource { get; set; }
        public int CreatedFrom { get; set; }
        public Guid Id { get; set; }
        public int StatusCode { get; set; }

        public Guid PlatformPlacementId { get; set; }


        public Project(IOrganizationService dataverseClient, IMemoryCache cache, ILogger<Project>? logger = null, ILoggerFactory? loggerFactory = null) : base(dataverseClient, "project")
        {
            loggerFactory ??= NullLoggerFactory.Instance;
            _bomService = new BOM(dataverseClient, cache, loggerFactory.CreateLogger<BOM>(), loggerFactory);
            _accountService = new Account(dataverseClient, loggerFactory.CreateLogger<Account>());
            _countryService = new Country(dataverseClient);
            _productFamilyService = new ProductFamily(dataverseClient);
            _regionService = new Region(dataverseClient, loggerFactory.CreateLogger<Region>());
            _serviceSnapshotService = new ServiceSnapshot(dataverseClient, cache, loggerFactory.CreateLogger<ServiceSnapshot>(), loggerFactory);
            _platformAndPlacementService = new PlatformAndPlacement(dataverseClient, loggerFactory.CreateLogger<PlatformAndPlacement>());
            _pcPlatformStatusService = new PCPlatformStatus(dataverseClient, loggerFactory.CreateLogger<PCPlatformStatus>());
            _productComponentService = new ProductComponent(dataverseClient, cache, loggerFactory.CreateLogger<ProductComponent>(), loggerFactory);
            _componentTypeService = new ComponentType(dataverseClient, loggerFactory.CreateLogger<ComponentType>());
            _actionCode = new ActionCode(dataverseClient);
            _subRegionService = new SubRegion(dataverseClient, loggerFactory.CreateLogger<SubRegion>());
            _assetTagSize = new FijiAssettagsize(dataverseClient, loggerFactory.CreateLogger<FijiAssettagsize>());

            ErrorList = new List<string>();
        }

        public enum eProductAction
        {
            NoChange = 622490000,
            Add = 622490001,
            Remove = 622490002,
            Update = 622490003
        }

        public enum eStateCode
        {
            Active = 0,
            Inactive = 1
        }

        public enum eProjectlevel
        {
            GetMore = 219180001,
            Standard = 219180000
        }

        public enum eProjectType
        {
            ECN = 219180001,
            NEW = 219180000
        }

        public enum eProjectAction
        {
            ADDLOC = 622490002,
            Change = 622490001
        }

        public enum eStatusCode
        {
            Active = 1,
            Canceled = 219180001,
            Complete = 2,
            Feasibility = 622490004,
            FeasibilityComplete = 219180002,
            Initialization = 622490003,
            NPI = 622490006,
            OnHold = 219180000,
            OrderCatalogue = 622490007,
            Rejected = 622490008,
            Reopened = 219180003,
            Setup = 622490005,
            Submitted = 622490001,
            Unsubmitted = 622490000
        }

        public enum eProjectSourcecode
        {
            Bulk = 622490001,
            Duplicate = 622490002,
            Everest = 622490004,
            Single = 622490000,
            Wizard = 622490003
        }

        public enum eProjectstage
        {
            NULL = 219180007,
            Complete = 219180006,
            Draft = 219170000,
            Feasibility = 219180001,
            Initialization = 219180000,
            NPI = 219180003,

            [Display(Name = "Order/Catalog Setup")]
            OrderCatalogSetup = 219180004,

            Setup = 219180002
        }

        public enum eProjectPriority
        {
            HIGH = 219180001,
            LOW = 219180002,
            NORMAL = 219180000
        }

        public enum eFijiProjectType
        {
            ComplexSpecial = 219180002,
            GlobalSimple = 219180001,
            NoTouchSpecial = 219180003,
            PrintComplex = 219180004,
            PrintSimple = 219180005,
            RegionalSimple = 219180000
        }

        public enum eProductType
        {
            SKUProduct = 219180000,
            CTOProduct = 219180001,
            PCConfigSalesBOM = 219180003,
            PRINTBundle = 100000000,
            PanamaCCBOM = 102420008,
            PRINTReusableSuperBundle = 100000002,
            PRINTReusableBundle = 100000001,
            PRINTSuperBundle = 100000003,
            AMOProduct = 102420000,
            ComplexBundles = 219180002,
            PRINTERConfigSalesBOM = 219180005
        }


        public CreateProjectResponse CreateProjectAndBomItems(CreateProjectRequest projectRequest)
        {
            return TraceOperation(nameof(CreateProjectAndBomItems), () =>
            {
                CreateProjectResponse projectResponse = new();

                this.Id = Guid.NewGuid();
                try
                {
                    this.BeginTransaction();
                    _bomService.SetTransaction(this.Transaction);

                    this.CustomerId = projectRequest.CustomerId;
                    this.IsNewProject = projectRequest.IsNewProject;
                    this.ModelId = projectRequest.ModelId;
                    this.OcciId = projectRequest.OcciId;
                    this.PortalUserId = projectRequest.PortalUserId;
                    this.ProductType = projectRequest.ProductType;
                    this.ProjectType = projectRequest.ProjectType;
                    this.ProjectSource = projectRequest.ProjectSource;
                    this.CreatedFrom = projectRequest.CreatedFrom;
                    //this.RegionId = projectRequest.RegionId;

                    this.CreateProject();

                    foreach (var item in projectRequest.Services)
                    {
                        _bomService.BOMInitialize(Id, item);
                        _bomService.CreateBOM();
                    }

                    //Commit transaction
                    var responseRequest = this.CommitTransaction();

                    if (responseRequest.Responses.Count > 0)
                        GetProjectDetails(((CreateResponse)responseRequest.Responses[0]).id, Guid.Parse(projectRequest.CustomerId), Guid.Parse(projectRequest.ModelId), ref projectResponse);

                    List<string> BOMGuids = new List<string>();

                    for (int i = 1; i < responseRequest.Responses.Count; i++)
                        BOMGuids.Add(((CreateResponse)responseRequest.Responses[i]).id.ToString());

                    List<BOM> infoRelatedToTheBomItems = _bomService.ListInfoRelatedToTheBOMItems(BOMGuids, ((CreateResponse)responseRequest.Responses[0]).id);

                    projectResponse.BomItems = infoRelatedToTheBomItems;
                    projectResponse.Message = Constants.ResponseMessages.ProjectandBOMCreated;
                    projectResponse.ProjectId = this.Id.ToString();
                    projectResponse.ServiceIds = BOMGuids;
                    return projectResponse;
                }
                catch (FaultException fe)
                {
                    projectResponse.Error = fe.Message;
                    return projectResponse;
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("customerId", projectRequest?.CustomerId), ("modelId", projectRequest?.ModelId), ("serviceCount", projectRequest?.Services?.Count));
        }

        public Guid CreateProject()
        {
            return TraceOperation(nameof(CreateProject), () =>
            {
                OptionSetValue newOrECN = this.IsNewProject ? new OptionSetValue((int)eProjectType.NEW) : new OptionSetValue((int)eProjectType.ECN);
                Entity fijiProject = new Entity(EntityName.Project);
                fijiProject.Id = this.Id;
                fijiProject[AttributeNames.Project.ProductFamilyName] = Utils.GetEntityReference(EntityName.ProductFamily, this.ModelId);
                Guid kmatPF = _productFamilyService.GetProductFamily(Utils.ConvertInGuid(this.ModelId));
                if (kmatPF != Guid.Empty)
                {
                    fijiProject[AttributeNames.Project.KMATProductFamily] = Utils.GetEntityReference(EntityName.ProductFamily, kmatPF.ToString());
                }

                Guid productLine = _productFamilyService.GetKmatProductFamily(kmatPF);
                if (productLine != Guid.Empty)
                {
                    fijiProject[AttributeNames.Project.ProductLine] = Utils.GetEntityReference(EntityName.ProductLine, productLine.ToString());
                }
                fijiProject[AttributeNames.Project.IsNeworECN] = newOrECN;
                fijiProject[AttributeNames.Project.CustomerId] = Utils.GetEntityReference(EntityName.Account, this.CustomerId);
                fijiProject[AttributeNames.Project.ProjectType] = new OptionSetValue(this.ProjectType);
                fijiProject[AttributeNames.Project.ProductType] = new OptionSetValue(this.ProductType);
                fijiProject[AttributeNames.Project.ProjectSourceCode] = new OptionSetValue(this.ProjectSource);
                fijiProject[AttributeNames.Project.CreatedFrom] = new OptionSetValue(this.CreatedFrom);

                fijiProject[AttributeNames.Project.OCCId] = this.OcciId;
                fijiProject[AttributeNames.Project.ProjectStage] = new OptionSetValue((int)BOM.BillOfMaterialType.Fiji_Draft);
                fijiProject[AttributeNames.Project.PortalContact] = Utils.GetEntityReference(EntityName.Contact, this.PortalUserId);
                fijiProject[AttributeNames.Project.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, this.PortalUserId);
                fijiProject[AttributeNames.Project.PortalInitiated] = true;

                Dictionary<string, string> projectManagerData = this.GetProjectOwnerBy(this.CustomerId);
                string ownerId = projectManagerData.GetValueOrDefault("managerId");

                Guid? regionId = null;
                if (!string.IsNullOrEmpty(ownerId) && Guid.TryParse(ownerId, out Guid ownerGuid))
                {
                    fijiProject[AttributeNames.Project.OwnerId] = new EntityReference(EntityName.SystemUser, ownerGuid);
                    regionId = _regionService.GetRegionBy(ownerGuid);

                    Guid? reportingRegionId = _subRegionService.GetSubRegionBy(ownerGuid);
                    if (reportingRegionId.HasValue)
                        fijiProject[AttributeNames.Project.ProjectOriginatingSubRegion] = new EntityReference(EntityName.SubRegion, reportingRegionId.Value);
                }
                if (regionId != null)
                    fijiProject[AttributeNames.Project.ProjectOriginatingRegionId] = new EntityReference(EntityName.Region, regionId.Value);
                else
                    throw new Exception(Constants.ErrorMessages.NoRegion);

                this.Execute(new CreateRequest { Target = fijiProject });

                return this.Id;
            }, ("projectId", Id), ("customerId", CustomerId), ("modelId", ModelId));
        }

        /// <summary>
        /// validate project manager if null or disabled
        /// then validate project backup manager if null or disabled
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns return="OwnerId"></returns>
        public Dictionary<string, string> GetProjectOwnerBy(string customerId)
        {
            return TraceOperation(nameof(GetProjectOwnerBy), () =>
            {
                Dictionary<string, string> projectManagerData = new();

                try
                {
                    bool managerFound = false;
                    string managerType = "fiji_projectmanager";
                    string managerId = _accountService.GetManagerId(customerId, managerType);

                    if (!string.IsNullOrEmpty(managerId))
                    {
                        projectManagerData.Add("managerType", managerType);
                        projectManagerData.Add("managerId", managerId);
                        return projectManagerData;
                    }

                    //If ProjectManger is not found
                    //check Project Backup Manager
                    if (string.IsNullOrEmpty(managerId))
                    {
                        managerType = "fiji_backupprojectmanager";
                        managerId = _accountService.GetManagerId(customerId, managerType);
                        if (!string.IsNullOrEmpty(managerId))
                        {
                            projectManagerData.Add("managerType", managerType);
                            projectManagerData.Add("managerId", managerId);
                            return projectManagerData;
                        }
                    }

                    //If Project Manager and ProjectBackup Manager is not found
                    //Check Project Manager in Country
                    if (string.IsNullOrEmpty(managerId))
                    {
                        managerType = "fiji_projectmanager";
                        managerId = _accountService.GetManagerIdByCountry(customerId, managerType);
                        if (!string.IsNullOrEmpty(managerId))
                        {
                            projectManagerData.Add("managerType", managerType);
                            projectManagerData.Add("managerId", managerId);
                            return projectManagerData;
                        }
                    }

                    //If Project Manager and ProjectBackup Manager is not found
                    //If Project Manager in Country Not found
                    //Check Project Backup Manager in Country
                    if (string.IsNullOrEmpty(managerId))
                    {
                        managerType = "fiji_backupprojectmanager";
                        managerId = _accountService.GetManagerIdByCountry(customerId, managerType);
                        if (!string.IsNullOrEmpty(managerId))
                        {
                            projectManagerData.Add("managerType", managerType);
                            projectManagerData.Add("managerId", managerId);
                            return projectManagerData;
                        }
                    }

                    return projectManagerData;
                }
                catch (Exception ex)
                {
                    this.Logger.LogWarning(ex, "GetProjectOwnerBy fallback path used for customer {CustomerId}", customerId);
                    return projectManagerData;
                }
            }, ("customerId", customerId));
        }

        public void GetProjectDetails(Guid projectId, Guid customerId, Guid platformId, ref CreateProjectResponse createProjectResponse)
        {
            QueryExpression query = new QueryExpression(EntityName.Project);
            query.ColumnSet = new ColumnSet(AttributeNames.Project.RequestId, AttributeNames.Project.ConfigurationName, AttributeNames.Project.ProjectName, AttributeNames.Project.ProductFamilyName, AttributeNames.Project.CustomerRequestDate, AttributeNames.Project.CustomerPOCPreference, AttributeNames.Project.OwnerId, AttributeNames.Project.AdditionalEmail, AttributeNames.Project.ProjectComments, AttributeNames.Project.Opinel, AttributeNames.Project.ComponentModificationAcceptancePreference, AttributeNames.Project.IsNeworECN, AttributeNames.Project.ProjectStage, AttributeNames.Project.StatusCode);
            query.Criteria.AddCondition(AttributeNames.Project.ProjectId, ConditionOperator.Equal, projectId);

            query.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.ProductFamily, AttributeNames.Project.ProductFamilyName, AttributeNames.ProductFamily.ProductFamilyId, JoinOperator.Inner));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductFamily.Name, AttributeNames.ProductFamily.DeviceCategory);
            query.LinkEntities[0].EntityAlias = "platform";

            query.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.SystemUser, AttributeNames.Project.OwnerId, AttributeNames.SystemUser.SystemUserId, JoinOperator.Inner));
            query.LinkEntities[1].Columns.AddColumn(AttributeNames.SystemUser.InternalEmailAddress);
            query.LinkEntities[1].EntityAlias = "owner";

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                var entity = result.Entities[0];
                createProjectResponse.requestId = entity.GetAttributeValue<string>("fiji_requestid");
                createProjectResponse.requestName = entity.GetAttributeValue<string>("fiji_configurationname");
                createProjectResponse.Platform = new ProductFamily()
                {
                    Id = entity.GetAttributeValue<EntityReference>("fiji_productfamily")?.Id,
                    Name = entity.GetAttributeValue<EntityReference>("fiji_productfamily")?.Name,
                    DeviceCategory = new DeviceCategory()
                    {
                        Id = ((EntityReference)entity.GetAttributeValue<AliasedValue>("platform.fiji_devicecategoryid")?.Value)?.Id,
                        Name = ((EntityReference)entity.GetAttributeValue<AliasedValue>("platform.fiji_devicecategoryid")?.Value)?.Name
                    }
                };

                if (createProjectResponse.Platform?.Id != null)
                {
                    createProjectResponse.AvailableLocalizations = GetAvailableLocalizations(createProjectResponse.Platform?.Id);
                }

                createProjectResponse.SelectedLocalizations = GetSelectedLocalizations(projectId, customerId, platformId);
                createProjectResponse.ProjectName = entity.GetAttributeValue<string>("fiji_projectname");
                createProjectResponse.CustomerRequestDate = entity.GetAttributeValue<DateTime?>("fiji_customerrequestdate");
                createProjectResponse.CustomerPOCPreference = entity.GetAttributeValue<OptionSetValueCollection>("fiji_customerpocpreference")?.Select(x => x.Value)?.ToList();
                createProjectResponse.Owner = new SystemUser()
                {
                    Id = entity.GetAttributeValue<EntityReference>("ownerid").Id,
                    Name = entity.GetAttributeValue<EntityReference>("ownerid").Name,
                    PrimaryEmail = entity.GetAttributeValue<AliasedValue>("owner.internalemailaddress")?.Value?.ToString()
                };
                createProjectResponse.AdditionalEmail = entity.GetAttributeValue<string>("fiji_additionalemail");
                createProjectResponse.ProjectComments = entity.GetAttributeValue<string>("fiji_projectcomments");
                createProjectResponse.Opinel = entity.GetAttributeValue<bool>("fiji_opinel");
                createProjectResponse.ComponentModificationAcceptancePreference = entity.GetAttributeValue<OptionSetValue>("fiji_componentmodificationacceptancepreference")?.Value;
                createProjectResponse.Statuscode = entity.GetAttributeValue<OptionSetValue>("statuscode")?.Value.ToString();
                // createProjectResponse.IsNewOrECN = entity.GetAttributeValue<OptionSetValue>("fiji_isneworecn")?.Value.ToString();
                // createProjectResponse.ProjectStage = entity.GetAttributeValue<OptionSetValue>("fiji_projectstage")?.Value.ToString();
            }
        }

        private List<RegionLocale> GetAvailableLocalizations(Guid? PlatformID)
        {
            List<RegionLocale> AvailableLocalizations = new();

            string fetchXml = SqlQuery.GetSqlQueryForAvailableLocalizations(PlatformID);

            EntityCollection platformRegionLocaleResult = DataverseClient.RetrieveMultiple(new FetchExpression(fetchXml));
            if (platformRegionLocaleResult.Entities.Count > 0)
            {
                foreach (Entity platformRegionLocale in platformRegionLocaleResult.Entities)
                {
                    if ((Guid?)platformRegionLocale.GetAttributeValue<AliasedValue>("fiji_regionlocale1.fiji_regionlocaleid")?.Value != null)
                    {
                        AvailableLocalizations.Add(new RegionLocale()
                        {
                            Id = (Guid?)platformRegionLocale.GetAttributeValue<AliasedValue>("fiji_regionlocale1.fiji_regionlocaleid")?.Value,
                            LocalizationName = platformRegionLocale.GetAttributeValue<AliasedValue>("fiji_regionlocale1.fiji_localizationname")?.Value?.ToString(),
                            LocalizationCode = platformRegionLocale.GetAttributeValue<AliasedValue>("fiji_regionlocale1.fiji_regionlocalecode")?.Value?.ToString()
                        });
                    }
                }
            }

            return AvailableLocalizations.OrderBy(x => x.LocalizationName).ToList();
        }

        private List<RegionLocale> GetSelectedLocalizations(Guid? projectId, Guid? customerId, Guid? platformId)
        {
            List<RegionLocale> selectedLocalizations = new();

            QueryExpression queryProjectSelectedLocalizations = new QueryExpression(EntityName.Project);
            queryProjectSelectedLocalizations.Criteria.AddCondition(AttributeNames.Project.ProjectId, ConditionOperator.Equal, projectId);
            queryProjectSelectedLocalizations.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.ProjectRegionLocale, AttributeNames.Project.ProjectId, AttributeNames.ProjectRegionLocale.ProjectId, JoinOperator.Inner));
            queryProjectSelectedLocalizations.LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.ProjectRegionLocale, EntityName.RegionLocale, AttributeNames.ProjectRegionLocale.RegionLocaleId, AttributeNames.RegionLocale.RegionLocaleId, JoinOperator.Inner));
            queryProjectSelectedLocalizations.LinkEntities[0].LinkEntities[0].EntityAlias = "selectedLocalization";
            queryProjectSelectedLocalizations.LinkEntities[0].LinkEntities[0].Columns.AddColumns(AttributeNames.RegionLocale.RegionLocaleId, AttributeNames.RegionLocale.LocalizationName, AttributeNames.RegionLocale.RegionLocaleCode);
            queryProjectSelectedLocalizations.LinkEntities[0].LinkEntities[0].LinkCriteria.AddCondition(AttributeNames.RegionLocale.StateCode, ConditionOperator.Equal, 0);

            EntityCollection projectSelectedLocalizations = DataverseClient.RetrieveMultiple(queryProjectSelectedLocalizations);
            if (projectSelectedLocalizations?.Entities?.Count > 0)
            {
                foreach (Entity selectedLocalization in projectSelectedLocalizations.Entities)
                {
                    if ((Guid?)selectedLocalization.GetAttributeValue<AliasedValue>("selectedLocalization.fiji_regionlocaleid")?.Value != null)
                    {
                        selectedLocalizations.Add(new RegionLocale()
                        {
                            Id = (Guid?)selectedLocalization.GetAttributeValue<AliasedValue>("selectedLocalization.fiji_regionlocaleid")?.Value,
                            LocalizationName = selectedLocalization.GetAttributeValue<AliasedValue>("selectedLocalization.fiji_localizationname")?.Value?.ToString(),
                            LocalizationCode = selectedLocalization.GetAttributeValue<AliasedValue>("selectedLocalization.fiji_regionlocalecode")?.Value?.ToString()
                        });
                    }
                }
            }
            else if (customerId != null && platformId != null)
            {
                QueryExpression queryCommonLocalization = new QueryExpression(EntityName.AccountRegionLocale);
                queryCommonLocalization.Criteria.AddCondition(AttributeNames.AccountRegionLocale.AccountId, ConditionOperator.Equal, customerId);

                LinkEntity regionLocale = queryCommonLocalization.AddLink(EntityName.RegionLocale, AttributeNames.AccountRegionLocale.RegionLocaleId, AttributeNames.RegionLocale.RegionLocaleId);
                regionLocale.EntityAlias = "commonLocalization";
                regionLocale.Columns.AddColumns(AttributeNames.RegionLocale.RegionLocaleId, AttributeNames.RegionLocale.LocalizationName, AttributeNames.RegionLocale.RegionLocaleCode);

                LinkEntity platformLocale = regionLocale.AddLink(EntityName.PlatformRegionLocale, AttributeNames.RegionLocale.RegionLocaleId, AttributeNames.PlatformRegionLocale.RegionLocaleId);
                platformLocale.EntityAlias = "platformLocale";
                platformLocale.Columns.AddColumns(AttributeNames.PlatformRegionLocale.ProductFamilyRegionLocaleId);
                platformLocale.LinkCriteria.AddCondition(AttributeNames.PlatformRegionLocale.ProductFamilyId, ConditionOperator.Equal, platformId);
                platformLocale.LinkCriteria.AddCondition(AttributeNames.PlatformRegionLocale.StateCode, ConditionOperator.Equal, 0);

                EntityCollection commonLocalizations = DataverseClient.RetrieveMultiple(queryCommonLocalization);
                if (commonLocalizations?.Entities?.Count > 0)
                {
                    foreach (Entity commonLocalization in commonLocalizations.Entities)
                    {
                        if ((Guid?)commonLocalization.GetAttributeValue<AliasedValue>("commonLocalization.fiji_regionlocaleid")?.Value != null)
                        {
                            selectedLocalizations.Add(new RegionLocale()
                            {
                                Id = (Guid?)commonLocalization.GetAttributeValue<AliasedValue>("commonLocalization.fiji_regionlocaleid")?.Value,
                                LocalizationName = commonLocalization.GetAttributeValue<AliasedValue>("commonLocalization.fiji_localizationname")?.Value?.ToString(),
                                LocalizationCode = commonLocalization.GetAttributeValue<AliasedValue>("commonLocalization.fiji_regionlocalecode")?.Value?.ToString()
                            });
                        }
                    }
                }
            }

            return selectedLocalizations;
        }

        // This is the method to updateCSAV
        public UpdateCSAVResponse UpdateCSAV(UpdateCSAVRequest UpdateCSAVRequest)
        {
            return TraceOperation(nameof(UpdateCSAV), () =>
            {
                this.updateCSAVResponse = new UpdateCSAVResponse();
                var projectScopeChangeHelper = new ProjectScopeChangeHelper(DataverseClient);
                try
                {
                    var serviceRevision = _serviceSnapshotService.GetLatestServiceRevisionforUpdateCSAV(UpdateCSAVRequest.ProductComponentId);
                    Guid? projectid = null;
                    if (!string.IsNullOrWhiteSpace(UpdateCSAVRequest.BomId))
                        projectid = _bomService.GetProjectIDByBOMID(Utils.ConvertInGuid(UpdateCSAVRequest.BomId));
                    if (UpdateCSAVRequest.ExtendModel.GetValueOrDefault(false))
                    {
                        BeginTransaction();
                        _pcPlatformStatusService.SetTransaction(this.Transaction);
                        _serviceSnapshotService.SetTransaction(this.Transaction);
                        _platformAndPlacementService.SetTransaction(this.Transaction);
                        _bomService.SetTransaction(this.Transaction);
                        _pcPlatformStatusService.CreatePCPlatformStatusOnExtendModel(UpdateCSAVRequest, projectid);
                        Guid? newServiceRevisionId = null;

                        if (serviceRevision != null)
                        {
                            if ((serviceRevision.LatestServiceStatusCode == ServiceSnapshot.eStatusCode.Submitted) || (serviceRevision.LatestServiceStatusCode == ServiceSnapshot.eStatusCode.Completed))
                            {
                                if (serviceRevision != null)
                                    newServiceRevisionId = _serviceSnapshotService.CreateServiceRevision(UpdateCSAVRequest, serviceRevision);

                                _platformAndPlacementService.CreatePlatformAndPlacementOnServiceRevision(UpdateCSAVRequest, newServiceRevisionId, serviceRevision.Id, serviceRevision.LatestServiceStatusCode);
                                _bomService.UpdateBOMOnServiceRevision(UpdateCSAVRequest, newServiceRevisionId);
                            }
                            else
                            {
                                _serviceSnapshotService.UpdateServiceRevisionStatus(serviceRevision.Id, UpdateCSAVRequest.requiredAdditionalInfo);
                                _platformAndPlacementService.CreatePlatformAndPlacementOnServiceRevision(UpdateCSAVRequest, serviceRevision.Id, serviceRevision.Id, serviceRevision.LatestServiceStatusCode);
                                _bomService.UpdateBOMOnServiceRevision(UpdateCSAVRequest, serviceRevision.Id);
                            }

                            var projectScopeChangereponse = new ProjectScopeChangeRequest();

                            var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(UpdateCSAVRequest.BomId.ToString());
                            if (result != null)
                            {
                                projectScopeChangereponse.Sections ??= new Sections();

                                projectScopeChangereponse.Sections.Reuse ??= new List<BomItem>();
                                // Reuse the new BomItem
                                projectScopeChangereponse.Sections.Reuse.Add(new BomItem
                                {
                                    BomId = result.bomName,
                                    ExternalId = result.externalId,
                                    PortalDescription = result.description
                                });
                            }
                            projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, projectid.ToString());
                        }

                        CommitTransaction();

                        if (newServiceRevisionId != null)
                            serviceRevision = _serviceSnapshotService.GetBy(newServiceRevisionId.Value);
                        else
                            serviceRevision = _serviceSnapshotService.GetBy(serviceRevision.Id.Value);
                    }
                    else
                    {
                        _bomService.UpdateBOMOnServiceRevision(UpdateCSAVRequest, serviceRevision?.Id);

                        var projectScopeChangereponse = new ProjectScopeChangeRequest();

                        var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(UpdateCSAVRequest.BomId.ToString());
                        if (result != null)
                        {
                            projectScopeChangereponse.Sections ??= new Sections();

                            projectScopeChangereponse.Sections.Reuse ??= new List<BomItem>();
                            // Reuse the new BomItem
                            projectScopeChangereponse.Sections.Reuse.Add(new BomItem
                            {
                                BomId = result.bomName,
                                ExternalId = result.externalId,
                                PortalDescription = result.description
                            });
                        }
                        projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, projectid.ToString());
                    }
                    //check service revision JSON - if label size included, create additional BOM item
                    if (serviceRevision != null)
                    {
                        if (!String.IsNullOrWhiteSpace(serviceRevision.Configuration))
                        {
                            var serviceRevisionJson = JObject.Parse(serviceRevision.Configuration);
                            if (serviceRevisionJson["Details"] != null)
                            {
                                var details = serviceRevisionJson["Details"].ToObject<Dictionary<string, dynamic>>();
                                var screenNumber = Utils.GetDictionaryValue(details, "screenNumber");
                                if (screenNumber == Constants.AY111AV && details["overLay"] == true && details["labelsize"] != "")
                                {
                                    BeginTransaction();
                                    var assetTagSizePC = _assetTagSize.GetByLabelSize(details["labelsize"]);
                                    if (assetTagSizePC != null)
                                    {
                                        EntityCollection overlayPCDetails = _productComponentService.GetOverlayBy(assetTagSizePC);
                                        if (overlayPCDetails != null && overlayPCDetails.Entities.Count > 0)
                                        {
                                            foreach (var item in overlayPCDetails.Entities)
                                            {
                                                var fijiBOM = new Entity(EntityName.BOM);
                                                fijiBOM.Id = Guid.NewGuid();
                                                fijiBOM[AttributeNames.BOM.Project] = Utils.GetEntityReference(EntityName.Project, projectid.ToString());
                                                fijiBOM[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, item.Id.ToString());
                                                fijiBOM[AttributeNames.BOM.ObjectActionCode] = _bomService.GetActionCode(item.GetAttributeValue<OptionSetValue>("fiji_servicetypeglobal").Value, item.GetAttributeValue<AliasedValue>("ct.fiji_servicenumber").Value.ToString(), false);
                                                fijiBOM[AttributeNames.BOM.Quantity] = 1;
                                                fijiBOM[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                                                this.Execute(new CreateRequest { Target = fijiBOM });
                                            }
                                            CommitTransaction();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (string.IsNullOrEmpty(updateCSAVResponse.Error))
                    {
                        this.updateCSAVResponse.ProductComponent = _productComponentService.GetBy(new Guid(UpdateCSAVRequest.ProductComponentId));
                        this.updateCSAVResponse.ServiceRevision = serviceRevision;
                    }
                    return this.updateCSAVResponse;
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    this.updateCSAVResponse.ProductComponent = null;
                    this.updateCSAVResponse.ServiceRevision = null;
                    this.updateCSAVResponse.Error = ex.Detail.Message;
                    return this.updateCSAVResponse;
                }
                catch (Exception ex)
                {
                    StringBuilder strmsg = new StringBuilder();
                    foreach (var msg in ErrorList)
                    {
                        strmsg.Append(msg);
                    }

                    this.updateCSAVResponse.ProductComponent = null;
                    this.updateCSAVResponse.ServiceRevision = null;
                    this.updateCSAVResponse.Error = ex.Message + " " + strmsg;
                    return this.updateCSAVResponse;
                }
            }, ("productComponentId", UpdateCSAVRequest?.ProductComponentId), ("bomId", UpdateCSAVRequest?.BomId), ("extendModel", UpdateCSAVRequest?.ExtendModel));
        }

        // This is the method for Project Submit
        public SubmitProjectResponse Submit(SubmitProjectRequest SubmitProjectRequest)
        {
            return TraceOperation(nameof(Submit), () =>
            {
                SubmitProjectResponse submitProjectResponse = new();

                BeginTransaction();
                _serviceSnapshotService.SetTransaction(this.Transaction);
                _serviceSnapshotService.UpdateServiceRevisionOnProjectSubmit(SubmitProjectRequest);

                // Update the Project
                if (!string.IsNullOrEmpty(SubmitProjectRequest.ProjectId))
                {
                    //update Project on submit
                    UpdateProjectonSubmit(SubmitProjectRequest);
                    // update Localization : Add localization those are in  array and remove those are not in array
                    UpdatedLocalization(SubmitProjectRequest);
                }

                CommitTransaction();

                return submitProjectResponse;
            }, ("projectId", SubmitProjectRequest?.ProjectId), ("serviceCount", SubmitProjectRequest?.Services?.Count), ("status", SubmitProjectRequest?.status), ("localizationCount", SubmitProjectRequest?.Localizations?.Count));
        }

        protected void UpdateProjectonSubmit(SubmitProjectRequest SubmitProjectRequest)
        {
            TraceOperation(nameof(UpdateProjectonSubmit), () =>
            {
                Entity fiji_project = new Entity(EntityName.Project, new Guid(SubmitProjectRequest.ProjectId));
                if (!string.IsNullOrEmpty(SubmitProjectRequest.RequestName))
                    fiji_project[AttributeNames.Project.ConfigurationName] = SubmitProjectRequest.RequestName;
                if (!string.IsNullOrEmpty(SubmitProjectRequest.ProjectName))
                    fiji_project[AttributeNames.Project.ProjectName] = SubmitProjectRequest.ProjectName;
                if (!string.IsNullOrEmpty(SubmitProjectRequest.CustomerRequestDate))
                    fiji_project[AttributeNames.Project.CustomerRequestDate] = Convert.ToDateTime(SubmitProjectRequest.CustomerRequestDate);
                if (SubmitProjectRequest.CustomerPOCPreference != null)
                {
                    OptionSetValueCollection opsCollection = new OptionSetValueCollection();
                    foreach (var opsvalue in SubmitProjectRequest.CustomerPOCPreference)
                    {
                        OptionSetValue optionSet = new OptionSetValue();
                        optionSet.Value = Convert.ToInt32(opsvalue);
                        opsCollection.Add(optionSet);
                    }
                    fiji_project[AttributeNames.Project.CustomerPOCPreference] = opsCollection;
                }
                if (!string.IsNullOrEmpty(SubmitProjectRequest.Comments))
                    fiji_project[AttributeNames.Project.ProjectComments] = SubmitProjectRequest.Comments;
                if (!string.IsNullOrEmpty(SubmitProjectRequest.AdditionalEmail))
                    fiji_project[AttributeNames.Project.AdditionalEmail] = SubmitProjectRequest.AdditionalEmail;
                if (!string.IsNullOrEmpty(SubmitProjectRequest.status))
                {
                    if (SubmitProjectRequest.status == Constants.Submitted)
                    {
                        if (IsUnsubmittedProject(fiji_project.Id))
                            fiji_project[AttributeNames.Project.StatusCode] = new OptionSetValue((int)eStatusCode.Submitted);
                    }
                    else
                        fiji_project[AttributeNames.Project.StatusCode] = new OptionSetValue((int)eStatusCode.Unsubmitted);
                }
                if (SubmitProjectRequest.IsOpinel != null)
                    fiji_project[AttributeNames.Project.Opinel] = SubmitProjectRequest.IsOpinel;
                if (SubmitProjectRequest.IsTermsAndConditionAccepted != null)
                    fiji_project[AttributeNames.Project.AcceptedTermConditions] = SubmitProjectRequest.IsTermsAndConditionAccepted;
                if (!string.IsNullOrEmpty(SubmitProjectRequest.ModifiedByPortalContact))
                    fiji_project[AttributeNames.Project.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, SubmitProjectRequest.ModifiedByPortalContact);

                this.Execute(new UpdateRequest { Target = fiji_project });
            }, ("projectId", SubmitProjectRequest?.ProjectId), ("requestName", SubmitProjectRequest?.RequestName), ("projectName", SubmitProjectRequest?.ProjectName), ("customerRequestDate", SubmitProjectRequest?.CustomerRequestDate), ("customerPOCPreferenceCount", SubmitProjectRequest?.CustomerPOCPreference?.Count), ("comments", SubmitProjectRequest?.Comments), ("additionalEmail", SubmitProjectRequest?.AdditionalEmail), ("status", SubmitProjectRequest?.status), ("isOpinel", SubmitProjectRequest?.IsOpinel), ("isTermsAndConditionAccepted", SubmitProjectRequest?.IsTermsAndConditionAccepted), ("modifiedByPortalContact", SubmitProjectRequest?.ModifiedByPortalContact));
        }

        private bool IsUnsubmittedProject(Guid projectId)
        {
            Entity project = this.DataverseClient.Retrieve(EntityName.Project, projectId, new ColumnSet(AttributeNames.Project.StatusCode));
            return (project.GetAttributeValue<OptionSetValue>(AttributeNames.Project.StatusCode).Value == (int)eStatusCode.Unsubmitted);
        }

        protected void UpdatedLocalization(SubmitProjectRequest SubmitProjectRequest)
        {
            TraceOperation(nameof(UpdatedLocalization), () =>
            {
                List<Guid>? lsExistingRegionLocal = GetProjectAssociatedRegionLocal(new Guid(SubmitProjectRequest.ProjectId));
                if (lsExistingRegionLocal != null && SubmitProjectRequest.Localizations != null)
                {
                    List<Guid>? lsremoveGuid = new List<Guid>();
                    List<Guid>? lsAddGuid = new List<Guid>();

                    foreach (var RequiredRegionLocal in SubmitProjectRequest.Localizations)
                    {
                        if (!lsExistingRegionLocal.Contains(new Guid(RequiredRegionLocal)))
                        {
                            if (!lsAddGuid.Contains(new Guid(RequiredRegionLocal)))
                                lsAddGuid.Add(new Guid(RequiredRegionLocal));
                        }
                    }

                    foreach (var exisitsRegionLocal in lsExistingRegionLocal)
                    {
                        if (!SubmitProjectRequest.Localizations.Contains(exisitsRegionLocal.ToString()))
                        {
                            if (!lsremoveGuid.Contains(new Guid(exisitsRegionLocal.ToString())))
                            {
                                lsremoveGuid.Add(new Guid(exisitsRegionLocal.ToString()));
                            }
                        }
                    }

                    EntityReference fiji_project = new EntityReference(EntityName.Project, new Guid(SubmitProjectRequest.ProjectId));
                    if (lsAddGuid.Count > 0)
                    {  // Add Localization
                        var addEntityRegionLocale = new EntityReferenceCollection();

                        foreach (var addGuid in lsAddGuid)
                        {
                            EntityReference fiji_regionlocaleadd = new EntityReference(EntityName.RegionLocale, addGuid);
                            addEntityRegionLocale.Add(fiji_regionlocaleadd);
                        }

                        AssociateRequest associateRequest1 = new AssociateRequest()
                        {
                            Target = fiji_project,
                            Relationship = new Relationship(EntityName.ProjectRegionLocale),
                            RelatedEntities = addEntityRegionLocale
                        };

                        this.Execute(associateRequest1);
                    }

                    if (lsremoveGuid.Count > 0)
                    {
                        // Remove Localization
                        var removeEntityRegionLocale = new EntityReferenceCollection();
                        foreach (var removeGuid in lsremoveGuid)
                        {
                            EntityReference fiji_regionlocaleremove = new EntityReference(EntityName.RegionLocale, removeGuid);
                            removeEntityRegionLocale.Add(fiji_regionlocaleremove);
                        }
                        DisassociateRequest disassociateRequest1 = new DisassociateRequest()
                        {
                            Target = fiji_project,
                            Relationship = new Relationship(EntityName.ProjectRegionLocale),
                            RelatedEntities = removeEntityRegionLocale
                        };

                        this.Execute(disassociateRequest1);
                    }
                }
            }, ("projectId", SubmitProjectRequest?.ProjectId), ("localizationCount", SubmitProjectRequest?.Localizations?.Count));
        }

        public GetProjectByRequestIDResponse GetProjectByRequestID(GetProjectByRequestIDRequest request)
        {
            return TraceOperation(nameof(GetProjectByRequestID), () =>
            {
                Guid? CustomerID = null;
                Guid? PlatformID = null;

                GetProjectByRequestIDResponse GetProjectByRequestIDresponse = new GetProjectByRequestIDResponse();
            QueryExpression query = new QueryExpression(EntityName.Project);
            query.ColumnSet = new ColumnSet(AttributeNames.Project.RequestId, AttributeNames.Project.OCCId, AttributeNames.Project.ConfigurationName, AttributeNames.Project.ProjectName, AttributeNames.Project.ProductFamilyName, AttributeNames.Project.CustomerRequestDate, AttributeNames.Project.CustomerPOCPreference, AttributeNames.Project.OwnerId, AttributeNames.Project.AdditionalEmail, AttributeNames.Project.ProjectComments, AttributeNames.Project.Opinel, AttributeNames.Project.AcceptedTermConditions, AttributeNames.Project.ComponentModificationAcceptancePreference, AttributeNames.Project.CustomerId, AttributeNames.Project.IsNeworECN, AttributeNames.Project.ProjectStage, AttributeNames.Project.StatusCode);
            query.Criteria.AddCondition(AttributeNames.Project.ProjectId, ConditionOperator.Equal, request.RequestID);
            query.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.ProductFamily, AttributeNames.Project.ProductFamilyName, AttributeNames.ProductFamily.ProductFamilyId, JoinOperator.LeftOuter));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductFamily.DeviceCategory);
            query.LinkEntities[0].EntityAlias = "platform";
            query.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.SystemUser, AttributeNames.Project.OwnerId, AttributeNames.SystemUser.SystemUserId, JoinOperator.Inner));
            query.LinkEntities[1].Columns.AddColumn(AttributeNames.SystemUser.InternalEmailAddress);
            query.LinkEntities[1].EntityAlias = "owner";

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                var entity = result.Entities[0];

                GetProjectByRequestIDresponse.ProjectId = request.RequestID;
                GetProjectByRequestIDresponse.RequestId = entity.GetAttributeValue<string>("fiji_requestid");
                GetProjectByRequestIDresponse.RequestName = entity.GetAttributeValue<string>("fiji_configurationname");
                GetProjectByRequestIDresponse.ProjectName = entity.GetAttributeValue<string>("fiji_projectname");
                GetProjectByRequestIDresponse.OccId = entity.GetAttributeValue<int?>("fiji_occid");
                GetProjectByRequestIDresponse.CustomerRequestDate = entity.GetAttributeValue<DateTime?>("fiji_customerrequestdate");
                GetProjectByRequestIDresponse.CustomerPOCPreference = entity.GetAttributeValue<OptionSetValueCollection>("fiji_customerpocpreference")?.Select(x => x.Value)?.ToList();
                GetProjectByRequestIDresponse.AdditionalEmail = entity.GetAttributeValue<string>("fiji_additionalemail");
                GetProjectByRequestIDresponse.ProjectComments = entity.GetAttributeValue<string>("fiji_projectcomments");
                GetProjectByRequestIDresponse.Opinel = entity.GetAttributeValue<bool>("fiji_opinel");
                GetProjectByRequestIDresponse.TermsAndConditionAccepted = entity.GetAttributeValue<bool?>("fiji_accepted_term_cond");
                GetProjectByRequestIDresponse.ComponentModificationAcceptancePreference = entity.GetAttributeValue<OptionSetValue>("fiji_componentmodificationacceptancepreference")?.Value;
                GetProjectByRequestIDresponse.ServiceIds = GetServiceIDByProjectID(new Guid(request.RequestID));
                GetProjectByRequestIDresponse.IsNewOrECN = entity.GetAttributeValue<OptionSetValue>("fiji_isneworecn")?.Value.ToString();
                GetProjectByRequestIDresponse.ProjectStage = entity.GetAttributeValue<OptionSetValue>("fiji_projectstage")?.Value.ToString();
                GetProjectByRequestIDresponse.Statuscode = entity.GetAttributeValue<OptionSetValue>("statuscode")?.Value.ToString();

                CustomerID = entity.GetAttributeValue<EntityReference>("fiji_customerid")?.Id;
                PlatformID = entity.GetAttributeValue<EntityReference>("fiji_productfamily")?.Id;

                GetProjectByRequestIDresponse.Platform = new ProductFamily()
                {
                    Id = entity.GetAttributeValue<EntityReference>("fiji_productfamily")?.Id,
                    Name = entity.GetAttributeValue<EntityReference>("fiji_productfamily")?.Name,
                    DeviceCategory = new DeviceCategory()
                    {
                        Id = ((EntityReference)entity.GetAttributeValue<AliasedValue>("platform.fiji_devicecategoryid")?.Value)?.Id,
                        Name = ((EntityReference)entity.GetAttributeValue<AliasedValue>("platform.fiji_devicecategoryid")?.Value)?.Name
                    }
                };

                GetProjectByRequestIDresponse.Owner = new SystemUser()
                {
                    Id = entity.GetAttributeValue<EntityReference>("ownerid").Id,
                    Name = entity.GetAttributeValue<EntityReference>("ownerid").Name,
                    PrimaryEmail = entity.GetAttributeValue<AliasedValue>("owner.internalemailaddress")?.Value?.ToString()
                };

                GetProjectByRequestIDresponse.BomItems = _bomService.GetBOMBYProjectIDandServiceGlobalType(new Guid(request.RequestID));
                if (PlatformID != null)
                    GetProjectByRequestIDresponse.AvailableLocalizations = GetAvailableLocalizations(PlatformID.Value);
                if (request.RequestID != null)
                    GetProjectByRequestIDresponse.SelectedLocalizations = GetSelectedLocalizations(new Guid(request.RequestID), CustomerID, PlatformID);
            }
            else
            { GetProjectByRequestIDresponse.Error = Constants.ErrorMessages.InvalidRequestId; }

                return GetProjectByRequestIDresponse;
            }, ("requestId", request?.RequestID));
        }

        private List<String> GetServiceIDByProjectID(Guid projectId)
        {
            List<String> ServiceIDs = new List<String>();

            QueryExpression query = new QueryExpression(EntityName.Project);
            query.Criteria.AddCondition(AttributeNames.Project.ProjectId, ConditionOperator.Equal, projectId);
            query.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.BOM, AttributeNames.Project.ProjectId, AttributeNames.BOM.Project, JoinOperator.Inner));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.BOM.BOMId);
            query.LinkEntities[0].EntityAlias = "services";

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                if (result?.Entities?.Count > 0)
                {
                    foreach (Entity bomIDs in result.Entities)
                    {
                        if ((Guid?)bomIDs.GetAttributeValue<AliasedValue>("services.fiji_billofmaterialsid")?.Value != null)
                        {
                            ServiceIDs.Add(bomIDs.GetAttributeValue<AliasedValue>("services.fiji_billofmaterialsid")?.Value.ToString());
                        }
                    }
                }
            }
            return ServiceIDs;
        }

        // This method is for New Inception Creation
        public NewInceptionCreationResponse NewInceptionCreation(NewInceptionCreationRequest NewInceptionCreationRequest)
        {
            return TraceOperation(nameof(NewInceptionCreation), () =>
            {
                this.BeginTransaction();
                _bomService.SetTransaction(this.Transaction);
                NewInceptionCreationResponse response = new NewInceptionCreationResponse();
            List<Guid> lsProjectIds = new List<Guid>();// to store the project id's

            // Step 1: Create Bulk projects based on current OciID's
            if (NewInceptionCreationRequest.OciId != null)
            {
                foreach (var ociId in NewInceptionCreationRequest.OciId)
                {
                    CreateBulkProjects(NewInceptionCreationRequest, ociId, ref lsProjectIds);
                }
            }
            CommitTransaction();
            List<string> lsrequestid = new List<string>();
            if (lsProjectIds != null)
                lsrequestid = GetRequestIDbyProjectIDs(lsProjectIds);
            if (lsrequestid != null)
            {
                BeginTransaction();
                //update comment at the end to ensure project exists
                //updating status = Submitted post creation to have comments added to email notif - bug #642780
                foreach (var projectId in lsProjectIds)
                {
                    Entity project = GetRequestIDbyProjectID(projectId);

                    project[AttributeNames.Project.StatusCode] = new OptionSetValue((int)eStatusCode.Submitted);
                    if (!string.IsNullOrEmpty(NewInceptionCreationRequest.Comments))
                    {
                        var comments = NewInceptionCreationRequest.Comments;
                        if (comments.Contains("<requestid>"))
                        {
                            if (project != null && project.Contains(AttributeNames.Project.RequestId))
                            {
                                string requestId = project.GetAttributeValue<string>(AttributeNames.Project.RequestId) != null
                                    ? project.GetAttributeValue<string>(AttributeNames.Project.RequestId) : "";
                                comments = comments.Replace("<requestid>", requestId);
                                project[AttributeNames.Project.ProjectComments] = comments;
                            }
                        }
                    }

                    this.Execute(new UpdateRequest { Target = project });
                }
                CommitTransaction();
                response.RequestIDs = lsrequestid;
            }
                return response;
            }, ("modelId", NewInceptionCreationRequest?.ModelId), ("customerId", NewInceptionCreationRequest?.CustomerId), ("ociCount", NewInceptionCreationRequest?.OciId?.Count));
        }

        public void CreateBulkProjects(NewInceptionCreationRequest NewInceptionCreationRequest, string? currentOciID, ref List<Guid> lsProjectIds)
        {
            //Step2:create the project
            Entity fijiProject = new Entity(EntityName.Project);
            fijiProject.Id = Guid.NewGuid();

            if (!string.IsNullOrEmpty(currentOciID))
                fijiProject[AttributeNames.Project.OCCId] = Convert.ToInt32(currentOciID);

            fijiProject[AttributeNames.Project.ProductFamilyName] = Utils.GetEntityReference(EntityName.ProductFamily, NewInceptionCreationRequest.ModelId.ToString());
            Guid kmatPF = _productFamilyService.GetProductFamily(NewInceptionCreationRequest.ModelId);
            if (kmatPF != Guid.Empty)
            {
                fijiProject[AttributeNames.Project.KMATProductFamily] = Utils.GetEntityReference(EntityName.ProductFamily, kmatPF.ToString());
            }
            Guid productLine = _productFamilyService.GetKmatProductFamily(kmatPF);
            if (productLine != Guid.Empty)
                fijiProject[AttributeNames.Project.ProductLine] = Utils.GetEntityReference(EntityName.ProductLine, productLine.ToString());

            fijiProject[AttributeNames.Project.IsNeworECN] = new OptionSetValue((int)eProjectType.NEW);

            fijiProject[AttributeNames.Project.CustomerId] = Utils.GetEntityReference(EntityName.Account, NewInceptionCreationRequest.CustomerId.ToString());

            fijiProject[AttributeNames.Project.ProjectType] = new OptionSetValue(NewInceptionCreationRequest.ProjectType);

            fijiProject[AttributeNames.Project.ProductType] = new OptionSetValue(NewInceptionCreationRequest.ProductType);

            if (!string.IsNullOrEmpty(NewInceptionCreationRequest.CustomerRequestDate))
                fijiProject[AttributeNames.Project.CustomerRequestDate] = Convert.ToDateTime(NewInceptionCreationRequest.CustomerRequestDate);
            if (NewInceptionCreationRequest.CustomerPOCPreference != null)
            {
                OptionSetValueCollection opsCollection = new OptionSetValueCollection();
                foreach (var opsvalue in NewInceptionCreationRequest.CustomerPOCPreference)
                {
                    OptionSetValue optionSet = new OptionSetValue();
                    optionSet.Value = Convert.ToInt32(opsvalue);
                    opsCollection.Add(optionSet);
                }
                if (opsCollection != null)
                    fijiProject[AttributeNames.Project.CustomerPOCPreference] = opsCollection;
            }

            if (NewInceptionCreationRequest.FspmId != null)
                fijiProject[AttributeNames.Project.OwnerId] = new EntityReference(EntityName.SystemUser, NewInceptionCreationRequest.FspmId.Value);

            if (!string.IsNullOrEmpty(NewInceptionCreationRequest.AdditionalEmail))
                fijiProject[AttributeNames.Project.AdditionalEmail] = NewInceptionCreationRequest.AdditionalEmail;

            fijiProject[AttributeNames.Project.StatusCode] = new OptionSetValue((int)eStatusCode.Unsubmitted);

            fijiProject[AttributeNames.Project.Opinel] = NewInceptionCreationRequest.IsOpinel;

            fijiProject[AttributeNames.Project.ProjectStage] = new OptionSetValue((int)eProjectstage.Draft);

            fijiProject[AttributeNames.Project.PortalContact] = Utils.GetEntityReference(EntityName.Contact, NewInceptionCreationRequest.PortalUserId.ToString());

            fijiProject[AttributeNames.Project.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, NewInceptionCreationRequest.PortalUserId.ToString());

            fijiProject[AttributeNames.Project.AcceptedTermConditions] = NewInceptionCreationRequest.IsAcceptedTermCondition;

            if (NewInceptionCreationRequest.OciId.Count == 1)
                fijiProject[AttributeNames.Project.ProjectSourceCode] = new OptionSetValue((int)eProjectSourcecode.Single);
            else if (NewInceptionCreationRequest.OciId.Count > 1)
                fijiProject[AttributeNames.Project.ProjectSourceCode] = new OptionSetValue((int)eProjectSourcecode.Bulk);

            fijiProject[AttributeNames.Project.PortalInitiated] = true;

            fijiProject[AttributeNames.Project.DeterminedLocalization] = false;

            if (NewInceptionCreationRequest.FspmId != null)
            {
                Guid? regionId = _regionService.GetRegionBy(NewInceptionCreationRequest.FspmId.Value);
                Guid? subregionId = _subRegionService.GetSubRegionBy(NewInceptionCreationRequest.FspmId.Value);
                if (regionId != null)
                    fijiProject[AttributeNames.Project.ProjectOriginatingRegionId] = new EntityReference(EntityName.Region, regionId.Value);
                else
                    throw new Exception(Constants.ErrorMessages.NoRegionforFSPM);

                if (subregionId != null)
                {
                    fijiProject[AttributeNames.Project.ProjectOriginatingSubRegion] = new EntityReference(EntityName.SubRegion, subregionId.Value);
                }
            }

            this.Execute(new CreateRequest { Target = fijiProject });


            //Step3: create the BOM based of current project ID created
            if (NewInceptionCreationRequest.services != null)
            {
                foreach (var service in NewInceptionCreationRequest.services)
                    _bomService.CreateBOMonNewInceptionCreation(service.ProductComponentId, service.ExternalId, fijiProject.Id, service.Quantity, !string.IsNullOrEmpty(service.OciId));
            }

            //Step4:  create the Locationzation based on current project ID created
            if (NewInceptionCreationRequest.Localizations != null)
            {
                EntityReference fiji_project = new EntityReference(EntityName.Project, fijiProject.Id);
                var addEntityRegionLocale = new EntityReferenceCollection();
                foreach (var addGuid in NewInceptionCreationRequest.Localizations.Distinct())
                {
                    if (addGuid != null)
                    {
                        EntityReference fiji_regionlocaleadd = new EntityReference(EntityName.RegionLocale, addGuid);
                        addEntityRegionLocale.Add(fiji_regionlocaleadd);
                    }
                }
                AssociateRequest associateRequest1 = new AssociateRequest()
                {
                    Target = fiji_project,
                    Relationship = new Relationship(EntityName.ProjectRegionLocale),
                    RelatedEntities = addEntityRegionLocale
                };

                this.Execute(associateRequest1);
            }

            lsProjectIds.Add(fijiProject.Id);
        }

        private Entity GetRequestIDbyProjectID(Guid id)
        {
            return this.DataverseClient.Retrieve(EntityName.Project, id, new ColumnSet(AttributeNames.Project.RequestId));
        }

        //This Method is for ECNInceptionCreation
        public async Task<ECNInceptionCreationResponse> ECNInceptionCreation(ECNInceptionCreationRequest request)
        {
            return await TraceOperationAsync(nameof(ECNInceptionCreation), async () =>
            {
                ECNInceptionCreationResponse response = new();
            List<Guid> lsProjectIds = new List<Guid>();
            string message = string.Empty;

            if (request.ProjectId != null && request.ProjectId != Guid.Empty)
            {
                var result = await CreateECNProjectsAsync(request);

                lsProjectIds = result.ProjectIds;
                message = result.Message;
            }
            else
            {
                response.Message = Constants.ErrorMessages.InvalidProjectId;
                return response;
            }

            List<string> lsrequestid = new();

            if (lsProjectIds.Count > 0)
            {
                lsrequestid = GetRequestIDbyProjectIDs(lsProjectIds);
            }

            response.ProjectIds = lsProjectIds;
            response.RequestIDs = lsrequestid;

            if (!string.IsNullOrEmpty(message))
                response.Message = message;

                return response;
            }, ("projectId", request?.ProjectId), ("skuCount", request?.SKUNumbers?.Count));
        }
        public async Task<(List<Guid> ProjectIds, string Message)> CreateECNProjectsAsync(ECNInceptionCreationRequest request)
        {
            return await TraceOperationAsync(nameof(CreateECNProjectsAsync), async () =>
            {
                List<Guid> lsProjectIds = new();
                List<string> failedSkus = new();

            if (request.SKUNumbers == null || request.SKUNumbers.Count == 0)
                return (lsProjectIds, string.Empty);

            request.SKUNumbers = request.SKUNumbers.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList();

            bool skuAlreadyInProgress = false;
            string skus = string.Empty;

            lock (_locks)
            {
                foreach (var sku in request.SKUNumbers)
                {
                    if (_locks.ContainsKey(sku))
                    {
                        skuAlreadyInProgress = true;
                        skus += sku + ",";
                    }
                }

                if (skuAlreadyInProgress)
                {
                    string result = string.Format(Constants.ErrorMessages.SKUAlreadyInProgressPleaseWait, skus.TrimEnd(','));
                    return (lsProjectIds, result);
                }

                foreach (var sku in request.SKUNumbers)
                    _locks.TryAdd(sku, sku);
            }

            int maxParallelism = 2;
            var semaphore = new SemaphoreSlim(maxParallelism);

            try
            {
                var tasks = request.SKUNumbers.Select(async sku =>
                {
                    await semaphore.WaitAsync();
                    try
                    {
                        await ExecuteWithRetryAsync(nameof(CreateECNProjectsAsync), () =>
                        {
                            Guid? localProjectId = null;
                            string localExistingSku = string.Empty;

                            CreateECNProjectBasedOnSKU(request, sku, ref localProjectId, ref localExistingSku);

                            lock (lsProjectIds)
                            {
                                if (localProjectId != null)
                                    lsProjectIds.Add(localProjectId.Value);
                            }

                            lock (failedSkus)
                            {
                                if (!string.IsNullOrEmpty(localExistingSku))
                                    failedSkus.Add(localExistingSku);
                            }

                            return System.Threading.Tasks.Task.CompletedTask;
                        });
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                });

                await System.Threading.Tasks.Task.WhenAll(tasks);
            }
            finally
            {
                foreach (var sku in request.SKUNumbers)
                    _locks.TryRemove(sku, out _);
            }

            string message = failedSkus.Count > 0
                ? string.Format(Constants.ErrorMessages.NoProjectFoundForSKU, string.Join(",", failedSkus))
                : string.Empty;

                return (lsProjectIds, message);
            }, ("projectId", request?.ProjectId), ("skuCount", request?.SKUNumbers?.Count));
        }

        private async System.Threading.Tasks.Task ExecuteWithRetryAsync(string operationName, Func<System.Threading.Tasks.Task> action)
        {
            int retryCount = 3;

            for (int i = 0; i < retryCount; i++)
            {
                try
                {
                    await action();
                    return;
                }
                catch (Exception ex) when (
                    ex.Message.Contains("timeout") ||
                    ex.Message.Contains("throttl") ||
                    ex.Message.Contains("temporar"))
                {
                    int attempt = i + 1;
                    int delayMs = 1000 * attempt;
                    ObservabilityTelemetry.RecordRetry(nameof(Project), operationName, attempt, exhausted: attempt == retryCount);
                    this.Logger.LogWarning(ex,
                        "Transient failure on {Operation}, attempt {Attempt}/{MaxAttempts}, retrying in {DelayMs} ms",
                        operationName,
                        attempt,
                        retryCount,
                        delayMs);
                    await System.Threading.Tasks.Task.Delay(delayMs);
                }
            }

            throw new Exception("Retry failed.");
        }
        private void CreateECNProjectBasedOnSKU(ECNInceptionCreationRequest ECNInceptionCreationRequest, string sku, ref Guid? currentProjectID, ref string? existingSku)
        {
            string existingComments = string.Empty;
            this.BeginTransaction();
            var queryForProject = new QueryExpression(EntityName.Project);
            queryForProject.ColumnSet = new ColumnSet("fiji_parentprojectid", "fiji_customerid", "fiji_projecttype", "fiji_producttype", "fiji_occid", "fiji_productfamily", "fiji_productline", "fiji_projectcomments", "fiji_projectgroup", "fiji_productexternalid", "fiji_projectcomments", "statuscode", "fiji_pcrcode", "fiji_projectstage", "fiji_pricingmodel", "fiji_bundledescription");
            queryForProject.Criteria.AddCondition(AttributeNames.Project.ProductExternalId, ConditionOperator.Equal, sku);
            queryForProject.Criteria.AddCondition(AttributeNames.Project.CustomerId, ConditionOperator.Equal, ECNInceptionCreationRequest.CustomerId);
            queryForProject.AddOrder(AttributeNames.Project.CreatedOn, OrderType.Descending);

            var existingSKUProjects = this.DataverseClient.RetrieveMultiple(queryForProject); // copy the project details from the lookup project                    

            var NewProject = existingSKUProjects.Entities.Where(e => e.GetAttributeValue<OptionSetValue>("statuscode").Value != (int)eStatusCode.Canceled && e.GetAttributeValue<OptionSetValue>("statuscode").Value != (int)eStatusCode.Rejected && e.GetAttributeValue<OptionSetValue>("statuscode").Value != (int)eStatusCode.FeasibilityComplete).FirstOrDefault();
            if (NewProject != null && NewProject.Contains(AttributeNames.Project.ProjectStage) &&
                !(NewProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProjectStage).Value == (int)eProjectstage.NPI ||
                NewProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProjectStage).Value == (int)eProjectstage.OrderCatalogSetup ||
                NewProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.StatusCode).Value == (int)eStatusCode.Complete))
            {
                existingSku += sku + ',';
                return;
            }
            var parentProjectId = NewProject.Id;
            NewProject.Remove(AttributeNames.Project.ProjectId);
            if (NewProject.Contains(AttributeNames.Project.ProjectType) && NewProject.Contains(AttributeNames.Project.ProductType) && NewProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProjectType).Value == (int)eFijiProjectType.ComplexSpecial && NewProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProductType).Value == (int)eProductType.AMOProduct)
            {
                NewProject.Remove(AttributeNames.Project.PCRCode);
            }
            NewProject.Remove(AttributeNames.Project.ParentProjectId);
            NewProject.Id = Guid.NewGuid();
            currentProjectID = NewProject.Id;

            NewProject[AttributeNames.Project.IsNeworECN] = new OptionSetValue((int)eProjectType.ECN);
            if (!string.IsNullOrEmpty(ECNInceptionCreationRequest.CustomerRequestDate))
                NewProject[AttributeNames.Project.CustomerRequestDate] = Convert.ToDateTime(ECNInceptionCreationRequest.CustomerRequestDate);

            NewProject[AttributeNames.Project.ParentProjectId] = new EntityReference(EntityName.Project, parentProjectId);
            NewProject[AttributeNames.Project.CopyDuplicateSourceProjectId] = new EntityReference(EntityName.Project, ECNInceptionCreationRequest.ProjectId);

            if (ECNInceptionCreationRequest.CustomerPOCPreference != null)
            {
                OptionSetValueCollection opsCollection = new OptionSetValueCollection();
                foreach (var opsvalue in ECNInceptionCreationRequest.CustomerPOCPreference)
                {
                    if (!string.IsNullOrEmpty(opsvalue.ToString()))
                    {
                        OptionSetValue optionSet = new OptionSetValue();
                        optionSet.Value = Convert.ToInt32(opsvalue);
                        opsCollection.Add(optionSet);
                    }
                }
                if (opsCollection != null)
                    NewProject[AttributeNames.Project.CustomerPOCPreference] = opsCollection;
            }

            if (ECNInceptionCreationRequest.ISOpinel != null)
                NewProject[AttributeNames.Project.Opinel] = ECNInceptionCreationRequest.ISOpinel;

            if (!string.IsNullOrEmpty(ECNInceptionCreationRequest.AdditionalEmail))
                NewProject[AttributeNames.Project.AdditionalEmail] = ECNInceptionCreationRequest.AdditionalEmail;

            NewProject[AttributeNames.Project.ProjectStage] = new OptionSetValue((int)eProjectstage.Draft);

            NewProject[AttributeNames.Project.ProjectPriority] = new OptionSetValue((int)eProjectPriority.NORMAL);

            if (ECNInceptionCreationRequest.ISAcceptedTermCondition != null)
                NewProject[AttributeNames.Project.AcceptedTermConditions] = ECNInceptionCreationRequest.ISAcceptedTermCondition;

            //if (!string.IsNullOrEmpty(ECNInceptionCreationRequest.Comments))
            //{
            //string existingComments = string.Empty;
            if (NewProject.GetAttributeValue<string?>(AttributeNames.Project.ProjectComments) != null)
            {
                existingComments = NewProject.GetAttributeValue<string>(AttributeNames.Project.ProjectComments);
            }
            //existingComments = existingComments + " " + ECNInceptionCreationRequest.Comments;
            //if (!string.IsNullOrEmpty(ECNInceptionCreationRequest.UpdateServiceDetails))
            //    existingComments = existingComments + " " + ECNInceptionCreationRequest.UpdateServiceDetails;

            //NewProject[AttributeNames.Project.ProjectComments] = existingComments;
            //}
            if (ECNInceptionCreationRequest.FspmId != null)
                NewProject[AttributeNames.Project.OwnerId] = new EntityReference(EntityName.SystemUser, ECNInceptionCreationRequest.FspmId);

            if (ECNInceptionCreationRequest.FspmId != null)
            {
                Guid? regionId = _regionService.GetRegionBy(ECNInceptionCreationRequest.FspmId);
                Guid? subregionId = _subRegionService.GetSubRegionBy(ECNInceptionCreationRequest.FspmId);
                if (regionId != null)
                {
                    NewProject[AttributeNames.Project.ProjectOriginatingRegionId] = new EntityReference(EntityName.Region, regionId.Value);
                }
                else
                    throw new Exception(Constants.ErrorMessages.NoRegionforFSPM);

                if (subregionId != null)
                {
                    NewProject[AttributeNames.Project.ProjectOriginatingSubRegion] = new EntityReference(EntityName.SubRegion, subregionId.Value);
                }
            }

            NewProject[AttributeNames.Project.PortalInitiated] = true;
            NewProject[AttributeNames.Project.DeterminedLocalization] = false;

            if (ECNInceptionCreationRequest.SKUNumbers != null)
            {
                if (ECNInceptionCreationRequest.SKUNumbers.Count > 1)
                    NewProject[AttributeNames.Project.ProjectSourceCode] = new OptionSetValue((int)eProjectSourcecode.Bulk);
                else if (ECNInceptionCreationRequest.SKUNumbers.Count == 1)
                    NewProject[AttributeNames.Project.ProjectSourceCode] = new OptionSetValue((int)eProjectSourcecode.Single);
            }
            NewProject[AttributeNames.Project.HideFromPortal] = false;
            if (ECNInceptionCreationRequest.PortalUserId != null)
                NewProject[AttributeNames.Project.PortalContact] = Utils.GetEntityReference(EntityName.Contact, ECNInceptionCreationRequest.PortalUserId.ToString());
            if (ECNInceptionCreationRequest.PortalUserId != null)
                NewProject[AttributeNames.Project.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, ECNInceptionCreationRequest.PortalUserId.ToString());

            NewProject[AttributeNames.Project.StatusCode] = new OptionSetValue((int)eStatusCode.Unsubmitted);

            NewProject[AttributeNames.Project.StateCode] = new OptionSetValue((int)eStateCode.Active);

            // select project level
            //bool isGetMoreService = IsGetmoreService(ECNInceptionCreationRequest.ProjectId);
            //if (isGetMoreService)
            //{
            //    NewProject[AttributeNames.Project.ProjectLevel] = new OptionSetValue((int)eProjectlevel.GetMore);
            //}
            //else
            //    NewProject[AttributeNames.Project.ProjectLevel] = new OptionSetValue((int)eProjectlevel.Standard);

            #region project product action update
            if (ECNInceptionCreationRequest?.Localizations != null && ECNInceptionCreationRequest.Localizations?.Count > 0)
            {
                string allLocalizationCodes = "";
                string projectproductactioncomments = "";
                string projectactioncommentvalue = String.Empty;
                List<Guid> localizations = ECNInceptionCreationRequest.Localizations;

                Object[] obj = new object[localizations.Count];
                for (int i = 0; i < localizations.Count; i++)
                {
                    obj[i] = localizations[i];
                }
                //get localization name
                QueryExpression query = new QueryExpression(EntityName.RegionLocale);
                query.ColumnSet = new ColumnSet(AttributeNames.RegionLocale.RegionLocaleCode, AttributeNames.RegionLocale.RegionLocaleId);
                query.Criteria.AddCondition(AttributeNames.RegionLocale.RegionLocaleId, ConditionOperator.In, obj);
                EntityCollection localizationRecords = DataverseClient.RetrieveMultiple(query);

                foreach (var localizationRecord in localizationRecords.Entities)
                {
                    if (localizationRecord.Contains(AttributeNames.RegionLocale.RegionLocaleCode))
                    {
                        string localizationCodeName = localizationRecord.GetAttributeValue<string>(AttributeNames.RegionLocale.RegionLocaleCode);
                        allLocalizationCodes += localizationCodeName + ", ";
                    }
                }
                if (!string.IsNullOrEmpty(projectactioncommentvalue)) { projectactioncommentvalue = projectactioncommentvalue + ","; }
                allLocalizationCodes = allLocalizationCodes.Substring(0, allLocalizationCodes.Length - 1);
                projectproductactioncomments = projectactioncommentvalue + allLocalizationCodes;
                if (projectproductactioncomments.Length > COMMENTFIELDLIMIT)
                {
                    projectproductactioncomments = projectproductactioncomments.Substring(0, COMMENTFIELDLIMIT);
                }

                NewProject[AttributeNames.Project.ProjectProductActionComments] = projectproductactioncomments;
                NewProject[AttributeNames.Project.ProjectProductAction] = new OptionSetValue((int)eProjectAction.ADDLOC);
            }
            #endregion

            this.Execute(new CreateRequest { Target = NewProject });

            this.CommitTransaction();

            this.BeginTransaction();
            //update comment after creation
            Entity project = GetRequestIDbyProjectID(NewProject.Id);
            //updating status = Submitted post creation to have comments added to email notif - bug #642780
            project[AttributeNames.Project.StatusCode] = new OptionSetValue((int)eStatusCode.Submitted);
            if (!string.IsNullOrEmpty(ECNInceptionCreationRequest.Comments))
            {
                var comments = ECNInceptionCreationRequest.Comments;
                if (comments.Contains("<requestid>"))
                {
                    if (project != null && project.Contains(AttributeNames.Project.RequestId))
                    {
                        string requestId = project.GetAttributeValue<string>(AttributeNames.Project.RequestId) != null
                            ? project.GetAttributeValue<string>(AttributeNames.Project.RequestId) : "";
                        comments = comments.Replace("<requestid>", requestId);
                        if (!string.IsNullOrEmpty(ECNInceptionCreationRequest.UpdateServiceDetails))
                            comments += " " + ECNInceptionCreationRequest.UpdateServiceDetails;
                        if (!string.IsNullOrEmpty(existingComments))
                        {
                            comments += "\n" + existingComments;
                        }
                        // Trim to 8000 chars
                        if (!string.IsNullOrEmpty(comments))
                        {
                            comments = comments?.Length > 8000 ? comments.Substring(0, 8000) : comments;
                        }
                        project[AttributeNames.Project.ProjectComments] = comments;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(existingComments))
                {
                    project[AttributeNames.Project.ProjectComments] = existingComments;
                }
            }
            this.Execute(new UpdateRequest { Target = project });
            //Associate localization to ECN Projects
            AddLocalizationToENCPRoject(ECNInceptionCreationRequest.ProjectId, currentProjectID.Value, ECNInceptionCreationRequest.Localizations);

            ProcessBOMforECNproject(currentProjectID.Value, ECNInceptionCreationRequest.ProjectId, ECNInceptionCreationRequest);
            this.CommitTransaction();
        }

        protected void AddLocalizationToENCPRoject(Guid lookupProject, Guid NewProject, List<Guid>? lspayloadLocalization)
        {
            EntityReference fiji_project = new EntityReference(EntityName.Project, NewProject);

            List<Guid> lsLocalization = new List<Guid>();

            // To finc the exsiting local region associated with the project
            List<Guid>? lsexistinglocalizations = GetProjectAssociatedRegionLocal(lookupProject);

            // This will add the request payload localization to the list
            if (lspayloadLocalization != null)
            {
                foreach (var payloadlocalization in lspayloadLocalization)
                {
                    if (!lsexistinglocalizations.Contains(payloadlocalization))
                        lsLocalization.Add(payloadlocalization);
                }
            }

            if (lsLocalization.Count > 0)
            {  // Add Localization
                var addEntityRegionLocale = new EntityReferenceCollection();

                foreach (var addGuid in lsLocalization)
                {
                    EntityReference fiji_regionlocaleadd = new EntityReference(EntityName.RegionLocale, addGuid);
                    addEntityRegionLocale.Add(fiji_regionlocaleadd);
                }

                AssociateRequest associateRequest1 = new AssociateRequest()
                {
                    Target = fiji_project,
                    Relationship = new Relationship(EntityName.ProjectRegionLocale),
                    RelatedEntities = addEntityRegionLocale
                };

                this.Execute(associateRequest1);
            }
        }

        protected void ProcessBOMforECNproject(Guid currentprojectid, Guid? currentlookupProject, ECNInceptionCreationRequest requestECNInceptionCreation)
        {

            List<Guid>? lsBOMHardware = GetBOMHardwarebyProjectID(currentprojectid, requestECNInceptionCreation.RemoveHardwares);

            // update the product action code to remove for hardware
            RemoveHardware(lsBOMHardware);

            // update the product action code to add for hardware
            AddHardware(currentprojectid, lsBOMHardware, requestECNInceptionCreation);

            /* BOM Services Processing */
            List<Guid>? lsBOMServices = GetBOMServicesToRemovebyProjectID(currentprojectid, requestECNInceptionCreation.RemoveServices);

            // update the product action code to remove for services
            RemoveService(lsBOMServices);

            // update the product action code to remove for services
            List<Guid>? lsBOMServicesForUpdateService = GetBOMServicesbyProjectID(currentprojectid, requestECNInceptionCreation.UpdateServices);
            UpdateService(lsBOMServicesForUpdateService);

            //Add Services
            AddServices(currentprojectid, lsBOMServices, requestECNInceptionCreation);
        }

        // This is a method to remove hardware
        protected void RemoveHardware(List<Guid>? associatedHardwares)
        {
            if (associatedHardwares != null && associatedHardwares.Count > 0)
            {
                foreach (var bomRemoveHardware in associatedHardwares)
                {
                    Entity fiji_billofmaterials = new Entity(EntityName.BOM, bomRemoveHardware);

                    fiji_billofmaterials[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductAction.Remove);
                    fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                    Execute(new UpdateRequest { Target = fiji_billofmaterials });
                }
            }
        }

        // This is a method to Add hardware
        protected void AddHardware(Guid newprojectid, List<Guid>? associatedHardwaresPC, ECNInceptionCreationRequest requestECNInceptionCreation)
        {
            List<Guid>? lsAddHardwares = new List<Guid>();

            if (requestECNInceptionCreation.AddHardwares != null)
            {
                foreach (var pcAddHardware in requestECNInceptionCreation.AddHardwares)
                {
                    if (associatedHardwaresPC != null)
                    {
                        if (pcAddHardware != null && !associatedHardwaresPC.Contains(pcAddHardware))
                        {
                            lsAddHardwares.Add(pcAddHardware);
                        }
                    }
                    else
                    {
                        lsAddHardwares.Add(pcAddHardware);
                    }
                }
            }

            if (lsAddHardwares != null)
            {
                foreach (var pcAddHardware in lsAddHardwares)
                {
                    if (pcAddHardware != null)
                    {
                        Entity fiji_billofmaterials = new Entity(EntityName.BOM);
                        fiji_billofmaterials.Id = Guid.NewGuid();

                        fiji_billofmaterials[AttributeNames.BOM.Project] = Utils.GetEntityReference(EntityName.Contact, newprojectid.ToString());
                        fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, pcAddHardware.ToString());
                        fiji_billofmaterials[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductAction.Add);
                        fiji_billofmaterials[AttributeNames.BOM.Quantity] = 1;
                        fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                        Execute(new CreateRequest { Target = fiji_billofmaterials });
                    }
                }
            }
        }

        // This is a method to remove service
        protected void RemoveService(List<Guid>? associatedServices)
        {
            if (associatedServices != null && associatedServices.Count > 0)
            {
                foreach (var bomRemoveService in associatedServices)
                {
                    Entity fiji_billofmaterials = new Entity(EntityName.BOM, bomRemoveService);
                    fiji_billofmaterials[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductAction.Remove);
                    fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                    Execute(new UpdateRequest { Target = fiji_billofmaterials });
                }
            }
        }

        // Update the Services
        protected void UpdateService(List<Guid>? associatedServices)
        {
            if (associatedServices != null && associatedServices.Count > 0)
            {
                foreach (var bomUpdateService in associatedServices)
                {
                    Entity fiji_billofmaterials = new Entity(EntityName.BOM, bomUpdateService);
                    fiji_billofmaterials[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductAction.Update);
                    fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                    Execute(new UpdateRequest { Target = fiji_billofmaterials });

                }
            }
        }

        // This is a method to Add Services
        protected void AddServices(Guid newprojectid, List<Guid>? associatedServicesPC, ECNInceptionCreationRequest requestECNInceptionCreation)
        {
            List<Guid>? lsAddServices = new List<Guid>();

            if (requestECNInceptionCreation.AddServices != null)
            {
                foreach (var pcAddServices in requestECNInceptionCreation.AddServices)
                {
                    if (associatedServicesPC != null)
                    {
                        if (pcAddServices != null && !associatedServicesPC.Contains(pcAddServices))

                        {
                            lsAddServices.Add(pcAddServices);
                        }
                    }
                    else
                    {
                        lsAddServices.Add(pcAddServices);
                    }
                }
            }

            if (lsAddServices != null)
            {
                foreach (var pcAddService in lsAddServices)
                {
                    int? serviceTypeGlobal = GetServicesTypebyServiceID(pcAddService);
                    if (pcAddService != null)
                    {
                        Entity fiji_billofmaterials = new Entity(EntityName.BOM);
                        fiji_billofmaterials.Id = Guid.NewGuid();
                        fiji_billofmaterials[AttributeNames.BOM.Project] = Utils.GetEntityReference(EntityName.Contact, newprojectid.ToString());
                        fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = Utils.GetEntityReference(EntityName.ProductComponent, pcAddService.ToString());
                        //fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                        if ((serviceTypeGlobal == (int)eServiceTypeGlobal.GenericService) || (serviceTypeGlobal == (int)eServiceTypeGlobal.PreDefinedAV))
                        {
                            fiji_billofmaterials[AttributeNames.BOM.ProductActionCode] = new OptionSetValue((int)eProductAction.Add);
                        }

                        fiji_billofmaterials[AttributeNames.BOM.Quantity] = 1;
                        Execute(new CreateRequest { Target = fiji_billofmaterials });
                    }
                }
            }
        }

        //This Method is for ECNInceptionCreation
        public ProjectDuplicateResponse Duplicate(ProjectDuplicateRequest request)
        {
            return TraceOperation(nameof(Duplicate), () =>
            {
                this.BeginTransaction();
                ProjectDuplicateResponse response = new ProjectDuplicateResponse();

            var copyProject = this.DataverseClient.Retrieve(EntityName.Project, request.SourceRequestId,
                new ColumnSet(AttributeNames.Project.CustomerId, AttributeNames.Project.ProjectName, AttributeNames.Project.IsNeworECN, AttributeNames.Project.OCCId, AttributeNames.Project.ProjectType, AttributeNames.Project.ProductType));

            string ProjectName = request.NewRequestName;
            int? OOCID = null;
            string? CustomerId = null;
            OptionSetValue? NewOrECN = new OptionSetValue();
            OptionSetValue? ProjectType = new OptionSetValue();
            OptionSetValue? ProductType = new OptionSetValue();

            if (copyProject.GetAttributeValue<int?>(AttributeNames.Project.OCCId) != null)
            {
                OOCID = copyProject.GetAttributeValue<int?>(AttributeNames.Project.OCCId).Value;
            }

            if (copyProject.GetAttributeValue<EntityReference>(AttributeNames.Project.CustomerId) != null)
            {
                CustomerId = copyProject.GetAttributeValue<EntityReference>(AttributeNames.Project.CustomerId).Id.ToString();
            }

            if (copyProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.IsNeworECN) != null)
            {
                NewOrECN = new OptionSetValue(copyProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.IsNeworECN).Value);
            }

            if (copyProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProjectType) != null)
            {
                ProjectType = new OptionSetValue(copyProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProjectType).Value);
            }

            if (copyProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProductType) != null)
            {
                ProductType = new OptionSetValue(copyProject.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProductType).Value);
            }

            bool PortalInitiated = true;

            ParameterCollection pc = new ParameterCollection();
            if (!string.IsNullOrEmpty(CustomerId))
                pc.Add("CustomerId", CustomerId);
            else
                throw new Exception(Constants.ErrorMessages.NoCustomerInSourceProject);
            pc.Add("ProjectName", ProjectName);
            pc.Add("OCCID", OOCID);
            if (NewOrECN != null)
                pc.Add("NewOrECN", NewOrECN);
            else throw new Exception(Constants.ErrorMessages.NoNewECNInSourceProject);
            if (ProjectType != null)
                pc.Add("ProjectType", ProjectType);
            else throw new Exception(Constants.ErrorMessages.NoProjectTypeInSourceProject);
            if (ProductType != null)
                pc.Add("ProductType", ProductType);
            else throw new Exception(Constants.ErrorMessages.NoProductTypeInSourceProject);
            pc.Add("PortalInitiated", PortalInitiated);
            pc.Add("Target", (new EntityReference(EntityName.Project, request.SourceRequestId)));

            var executionDuplicateProj = this.DataverseClient.Execute(new OrganizationRequest()
            {
                RequestName = Constants.WorkFlows.CreateDuplicateProject,

                Parameters = pc
            });

            var outrArg1 = executionDuplicateProj.Results["DuplicateProjectId"];
            var outrArg2 = executionDuplicateProj.Results["DuplicateProjectName"];

            CommitTransaction();
            Guid duplicateProjectID = Guid.Empty;
            if (Guid.TryParse(outrArg1.ToString(), out duplicateProjectID))
                response.DuplicateProjectId = duplicateProjectID;
            response.DuplicateProjectName = !string.IsNullOrEmpty(outrArg2.ToString()) ? outrArg2.ToString() : null;

            BeginTransaction();
            //update the fiji_portalcontact for record with GUID = duplicateProjectID
            Entity fijiProject = new Entity(EntityName.Project, duplicateProjectID);
            fijiProject[AttributeNames.Project.PortalContact] = Utils.GetEntityReference(EntityName.Contact, request.ContactId.ToString());
            this.Execute(new UpdateRequest { Target = fijiProject });
            CommitTransaction();

                return response;
            }, ("sourceRequestId", request?.SourceRequestId), ("contactId", request?.ContactId));
        }

        #region Query Expression

        // Is get more services
        public bool IsGetmoreService(Guid fiji_projectid)
        {
            return TraceOperation(nameof(IsGetmoreService), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.Project)
            {
                // Define the columns to retrieve
                ColumnSet = new ColumnSet(AttributeNames.Project.ProjectId)
            };
            //Add condition
            query.Criteria.AddCondition(AttributeNames.Project.ProjectId, ConditionOperator.Equal, fiji_projectid);
            query.LinkEntities.Add(new LinkEntity(EntityName.Project, EntityName.BOM, AttributeNames.Project.ProjectId, AttributeNames.BOM.Project, JoinOperator.Inner));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.BOM.BOMId);
            query.LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.BOM, EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId, JoinOperator.Inner));
            query.LinkEntities[0].LinkEntities[0].LinkEntities.Add(new LinkEntity(EntityName.ProductComponent, EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId, JoinOperator.Inner));
            query.LinkEntities[0].LinkEntities[0].LinkEntities[0].LinkCriteria.AddCondition(AttributeNames.ComponentType.ServiceCategoryName, ConditionOperator.Equal, "Get More Services");
            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                    return true;
                else
                    return false;
            }, ("projectId", fiji_projectid));
        }

        // Get the BOM (Hardware)
        public List<Guid>? GetBOMHardwarebyProjectID(Guid fiji_projectid, List<Guid>? removeHardwares)
        {
            return TraceOperation(nameof(GetBOMHardwarebyProjectID), () =>
            {
                List<Guid>? lsBOMHardware = new List<Guid>();
            if (removeHardwares != null && removeHardwares.Count <= 0)
            {
                return null;
            }
            QueryExpression query = new QueryExpression(EntityName.BOM)
            {
                // Define the columns to retrieve
                ColumnSet = new ColumnSet(AttributeNames.BOM.Project, AttributeNames.BOM.BOMId)
            };

            //Add condition
            query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, fiji_projectid);
            query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project);
            query.Criteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);
            query.Criteria.AddCondition(AttributeNames.BOM.StateCode, ConditionOperator.Equal, (int)BOM.eStateCode.Active);

            if (removeHardwares != null && removeHardwares.Count > 0)
            {
                ConditionExpression condition = new ConditionExpression(AttributeNames.BOM.ProductComponent, ConditionOperator.In);
                foreach (Guid taskId in removeHardwares)
                    condition.Values.Add(taskId);
                query.Criteria.AddCondition(condition);
            }
            query.LinkEntities.Add(new LinkEntity(EntityName.BOM, EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId, JoinOperator.Inner));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ComponentType);
            query.LinkEntities[0].EntityAlias = "productcomponent";
            query.LinkEntities[0].AddLink(EntityName.ComponentType, AttributeNames.ProductComponent.ComponentType, AttributeNames.ComponentType.ComponentTypeId);
            query.LinkEntities[0].LinkEntities[0].LinkCriteria.AddCondition(new ConditionExpression(AttributeNames.ComponentType.IsFactoryService, ConditionOperator.Equal, false));

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        lsBOMHardware.Add(tempentity.Id);
                    }
                    return lsBOMHardware.Distinct().ToList<Guid>();
                }
                return null;
            }, ("projectId", fiji_projectid), ("removeHardwareCount", removeHardwares?.Count));
        }

        // Get the BOM (Services)
        public List<Guid>? GetBOMServicesbyProjectID(Guid fiji_projectid, List<Guid>? removeServices)
        {
            return TraceOperation(nameof(GetBOMServicesbyProjectID), () =>
            {
                int[] servicegloballist = { (int)ProductComponent.eServiceTypeGlobal.PreDefinedAV,
                                        (int)ProductComponent.eServiceTypeGlobal.GenericService,
                                        (int)ProductComponent.eServiceTypeGlobal.PlaceholderAV,
                                        (int)ProductComponent.eServiceTypeGlobal.CustomerSpecific
                                       };
            if (removeServices != null && removeServices.Count <= 0)
            {
                return null;
            }
            List<Guid>? lsBOMServices = new List<Guid>();
            QueryExpression query = new QueryExpression(EntityName.BOM)
            {
                // Define the columns to retrieve
                ColumnSet = new ColumnSet(AttributeNames.BOM.Project, AttributeNames.BOM.BOMId)
            };

            //Add condition
            query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, fiji_projectid);
            query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project);
            query.Criteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);
            query.Criteria.AddCondition(AttributeNames.BOM.StateCode, ConditionOperator.Equal, (int)BOM.eStateCode.Active);
            if (removeServices != null && removeServices.Count > 0)
            {
                ConditionExpression condition = new ConditionExpression(AttributeNames.BOM.ProductComponent, ConditionOperator.In);
                foreach (Guid taskId in removeServices)
                    condition.Values.Add(taskId);
                query.Criteria.AddCondition(condition);
            }
            query.LinkEntities.Add(new LinkEntity(EntityName.BOM, EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId, JoinOperator.Inner));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ProductComponentId);
            query.LinkEntities[0].EntityAlias = "productcomponent";

            FilterExpression filter = new FilterExpression(LogicalOperator.Or);
            filter.Conditions.Add(new ConditionExpression(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.In, servicegloballist));
            query.LinkEntities[0].LinkCriteria.Filters.Add(filter);

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        lsBOMServices.Add(tempentity.Id);
                    }
                    return lsBOMServices.Distinct().ToList<Guid>();
                }
                return null;
            }, ("projectId", fiji_projectid), ("removeServiceCount", removeServices?.Count));
        }

        // Get the BOM (Services) to remove 
        public List<Guid>? GetBOMServicesToRemovebyProjectID(Guid fiji_projectid, List<Guid>? removeServices)
        {
            return TraceOperation(nameof(GetBOMServicesToRemovebyProjectID), () =>
            {
                int[] servicegloballist = { (int)ProductComponent.eServiceTypeGlobal.PreDefinedAV,
                                        (int)ProductComponent.eServiceTypeGlobal.GenericService,
                                        (int)ProductComponent.eServiceTypeGlobal.PlaceholderAV,
                                        (int)ProductComponent.eServiceTypeGlobal.CustomerSpecific
                                       };
            if (removeServices != null && removeServices.Count <= 0)
            {
                return null;
            }

            List<Guid>? lsBOMServices = new List<Guid>();
            EntityCollection bomColl = new EntityCollection();
            QueryExpression query = new QueryExpression(EntityName.BOM)
            {
                // Define the columns to retrieve
                ColumnSet = new ColumnSet(AttributeNames.BOM.Project, AttributeNames.BOM.BOMId, AttributeNames.BOM.BomType, AttributeNames.BOM.ProductRevision)
            };

            //Add condition
            query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, fiji_projectid);
            query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project);
            query.Criteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);
            query.Criteria.AddCondition(AttributeNames.BOM.StateCode, ConditionOperator.Equal, (int)BOM.eStateCode.Active);

            if (removeServices != null && removeServices.Count > 0)
            {
                ConditionExpression condition = new ConditionExpression(AttributeNames.BOM.ProductComponent, ConditionOperator.In);
                foreach (Guid serviceId in removeServices)
                    condition.Values.Add(serviceId);
                query.Criteria.AddCondition(condition);
            }
            query.LinkEntities.Add(new LinkEntity(EntityName.BOM, EntityName.ProductComponent, AttributeNames.BOM.ProductComponent, AttributeNames.ProductComponent.ProductComponentId, JoinOperator.Inner));
            query.LinkEntities[0].Columns.AddColumns(AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ComponentType);
            query.LinkEntities[0].EntityAlias = "productcomponent";

            FilterExpression filter = new FilterExpression(LogicalOperator.Or);
            filter.Conditions.Add(new ConditionExpression(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.In, servicegloballist));
            query.LinkEntities[0].LinkCriteria.Filters.Add(filter);

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                foreach (var tempentity in result.Entities)
                {
                    lsBOMServices.Add(tempentity.Id);
                    if (tempentity.Contains("productcomponent.fiji_servicetypeglobal") && (((OptionSetValue)(tempentity.GetAttributeValue<AliasedValue>("productcomponent.fiji_servicetypeglobal")?.Value))?.Value == (int)ProductComponent.eServiceTypeGlobal.PreDefinedAV || ((OptionSetValue)(tempentity.GetAttributeValue<AliasedValue>("productcomponent.fiji_servicetypeglobal")?.Value))?.Value == (int)ProductComponent.eServiceTypeGlobal.CustomerSpecific))
                    {
                        bomColl.Entities.Add(tempentity);
                    }
                }
                var genericPC = GetGenericPCbyComponentType(bomColl, fiji_projectid);
                lsBOMServices.AddRange(genericPC);
                return lsBOMServices;
            }
            return null;
            }, ("projectId", fiji_projectid), ("removeServiceCount", removeServices?.Count));
        }

        // Get the Generic PC by Component Type
        public List<Guid> GetGenericPCbyComponentType(EntityCollection bomColl, Guid projectId)
        {
            return TraceOperation(nameof(GetGenericPCbyComponentType), () =>
            {
                List<Guid> genericPCId = new List<Guid>();

            //get generic PC BOM where BOM type is Project and Product Revision is empty
            var componentTypeId = bomColl.Entities.Where(x => x.GetAttributeValue<OptionSetValue>("fiji_bomtype")?.Value == 102420000 && x.GetAttributeValue<EntityReference>("fiji_productrevision")?.Id == null).Select(x => ((EntityReference)x.GetAttributeValue<AliasedValue>("productcomponent.fiji_componenttype")?.Value)?.Id).ToList();

            object[] arrCt = componentTypeId
                        .Where(x => x != null)
                        .Cast<object>()
                        .Distinct()
                        .ToArray();

            if (arrCt.Length > 0)
            {
                var query = new QueryExpression(EntityName.BOM);
                query.ColumnSet.AddColumns(AttributeNames.BOM.BOMId, AttributeNames.BOM.Name);
                query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, projectId);
                query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, 102420000);
                query.Criteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);

                var aa = query.AddLink(EntityName.ProductComponent, EntityName.ProductComponent, AttributeNames.ProductComponent.ProductComponentId);
                aa.EntityAlias = "aa";
                aa.LinkCriteria.AddCondition(AttributeNames.ProductComponent.ComponentType, ConditionOperator.In, arrCt);
                aa.LinkCriteria.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, (int)ProductComponent.eServiceTypeGlobal.GenericService);
                aa.Columns.AddColumns(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ComponentType);
                var result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var i in arrCt)
                    {
                        var quantity = 0;
                        var genericBOM = result.Entities.Where(x => ((EntityReference)x.GetAttributeValue<AliasedValue>("aa.fiji_componenttype")?.Value)?.Id == (Guid)i).ToList();
                        foreach (var j in componentTypeId)
                        {
                            if ((Guid)i == j)
                            {
                                quantity++;
                            }
                        }
                        if (quantity > 0)
                        {
                            for (int x = 0; x < quantity; x++)
                            {
                                genericPCId.Add(genericBOM[x].Id);
                            }
                        }
                    }
                }
            }

            //get generic PC BOM where BOM type is Project and Product Revision is not empty
            var componentTypeId1 = bomColl.Entities.Where(x => x.GetAttributeValue<OptionSetValue>("fiji_bomtype")?.Value == 102420000 && x.GetAttributeValue<EntityReference>("fiji_productrevision")?.Id != null).Select(x => ((EntityReference)x.GetAttributeValue<AliasedValue>("productcomponent.fiji_componenttype")?.Value)?.Id).ToList();
            Object[] arrCt1 = new Object[componentTypeId1.Count];
            foreach (var i in componentTypeId1)
            {
                arrCt1[componentTypeId1.IndexOf(i)] = i;
            }
            arrCt1 = arrCt1.Distinct().ToArray();
            if (arrCt1.Length > 0)
            {
                var query = new QueryExpression(EntityName.BOM);
                query.ColumnSet.AddColumns(AttributeNames.BOM.BOMId, AttributeNames.BOM.Name);
                query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, projectId);
                query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, 102420000);
                query.Criteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);

                var aa = query.AddLink(EntityName.ProductComponent, EntityName.ProductComponent, AttributeNames.ProductComponent.ProductComponentId);
                aa.EntityAlias = "aa";
                aa.LinkCriteria.AddCondition(AttributeNames.ProductComponent.ComponentType, ConditionOperator.In, arrCt1);
                aa.LinkCriteria.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, (int)ProductComponent.eServiceTypeGlobal.GenericService);
                aa.Columns.AddColumns(AttributeNames.ProductComponent.ProductComponentId, AttributeNames.ProductComponent.ComponentType);
                var result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var quantity = 0;
                    foreach (var i in arrCt1)
                    {
                        var genericBOM = result.Entities.Where(x => ((EntityReference)x.GetAttributeValue<AliasedValue>("aa.fiji_componenttype")?.Value)?.Id == (Guid)i).ToList();
                        foreach (var j in componentTypeId1)
                        {
                            if ((Guid)i == j)
                            {
                                quantity++;
                            }
                        }
                        if (quantity > 0)
                        {
                            for (int x = 0; x < quantity; x++)
                            {
                                genericPCId.Add(genericBOM[x].Id);
                            }
                        }
                    }
                }
            }

                return genericPCId;
            }, ("projectId", projectId), ("bomCount", bomColl?.Entities?.Count));
        }
        public List<Guid> GetProjectAssociatedRegionLocal(Guid fiji_projectid)
        {
            return TraceOperation(nameof(GetProjectAssociatedRegionLocal), () =>
            {
                List<Guid> lsRegionLocal = new List<Guid>();

            QueryExpression query = new QueryExpression(EntityName.ProjectRegionLocale)
            {
                // Define the columns to retrieve
                ColumnSet = new ColumnSet(AttributeNames.ProjectRegionLocale.RegionLocaleId)
            };
            //Add condition
            query.Criteria.AddCondition(AttributeNames.ProjectRegionLocale.ProjectId, ConditionOperator.Equal, fiji_projectid);

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                foreach (var tempentity in result.Entities)
                {
                    if (tempentity.Contains(AttributeNames.ProjectRegionLocale.RegionLocaleId))
                        lsRegionLocal.Add(tempentity.GetAttributeValue<Guid>(AttributeNames.ProjectRegionLocale.RegionLocaleId));
                }
                return lsRegionLocal;
            }

                return lsRegionLocal;
            }, ("projectId", fiji_projectid));
        }

        public List<string> GetRequestIDbyProjectIDs(List<Guid> lsProjectID)
        {
            return TraceOperation(nameof(GetRequestIDbyProjectIDs), () =>
            {
                List<string> lsfiji_requestid = new List<string>();

            QueryExpression query = new QueryExpression(EntityName.Project)
            {
                // Define the columns to retrieve
                ColumnSet = new ColumnSet(AttributeNames.Project.RequestId)
            };
            Object[] obj = new object[lsProjectID.Count];
            for (int i = 0; i < lsProjectID.Count; i++)
            {
                obj[i] = lsProjectID[i];
            }
            //Add condition
            query.Criteria.AddCondition(AttributeNames.Project.ProjectId, ConditionOperator.In, obj);

            EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
            if (result != null && result.Entities.Count > 0)
            {
                foreach (var tempentity in result.Entities)
                {
                    if (tempentity.Contains(AttributeNames.Project.RequestId))
                        lsfiji_requestid.Add(tempentity.GetAttributeValue<string>(AttributeNames.Project.RequestId));
                }
                return lsfiji_requestid;
            }

                return lsfiji_requestid;
            }, ("projectCount", lsProjectID?.Count));
        }

        public HttpResponseMessage AddLocalizationToEcnProject(AddLocalizationToEcnProjectRequest request)
        {
            return TraceOperation(nameof(AddLocalizationToEcnProject), () =>
            {
                var response = new HttpResponseMessage();
            string projectid = request.projectId;
            Guid projectguid = Guid.Parse(projectid);
            string allLocalizationNames = "";
            string projectproductactioncomments = "";
            Entity project = DataverseClient.Retrieve(EntityName.Project, projectguid,
                                             new ColumnSet(AttributeNames.Project.IsNeworECN,
                                             AttributeNames.Project.ProjectProductActionComments,
                                             AttributeNames.Project.ProjectProductAction));
            if (project == null || !project.Contains(AttributeNames.Project.IsNeworECN) || project.GetAttributeValue<OptionSetValue>(AttributeNames.Project.IsNeworECN).Value != (int)eProjectType.ECN)

            {
                response = new HttpResponseMessage(HttpStatusCode.NoContent); // responce = 204
            }
            else
            {
                string projectactioncommentvalue = project.GetAttributeValue<string>(AttributeNames.Project.ProjectProductActionComments);
                List<Localization> localizations = request.localizations;

                var arrayLocalizations = request.localizations.ToArray();

                if (localizations.Count == 0)
                {
                    throw new InvalidPluginExecutionException(Constants.ErrorMessages.NoLocalization);
                }

                Object[] obj = new object[localizations.Count];
                for (int i = 0; i < arrayLocalizations.Length; i++)
                {
                    obj[i] = localizations[i].localizationId;
                }

                // First, let's get all the localization IDs into a list
                List<Guid> localizationIds = localizations.Select(l => Guid.Parse(l.localizationId)).ToList();
                // Next, let's make a single query to the dataverse to retrieve all the localization records at once
                QueryExpression query = new QueryExpression(EntityName.RegionLocale);
                query.ColumnSet = new ColumnSet(AttributeNames.RegionLocale.RegionLocaleId, AttributeNames.RegionLocale.RegionLocaleCode);
                query.Criteria.AddCondition(AttributeNames.RegionLocale.RegionLocaleId, ConditionOperator.In, obj);
                EntityCollection localizationRecords = DataverseClient.RetrieveMultiple(query);
                // Now let's iterate over the returned records and build the allLocalizationNames string

                var count = localizationRecords.Entities.Count();
                var values = localizationRecords.Entities
                                .Where(e => e.Contains(AttributeNames.RegionLocale.RegionLocaleCode) && e[AttributeNames.RegionLocale.RegionLocaleCode] != null)
                                .Select(e => e[AttributeNames.RegionLocale.RegionLocaleCode].ToString())
                                .ToList();
                if (values.Count == 0)
                {
                    allLocalizationNames = string.Empty;

                }
                allLocalizationNames = values.Any() ? string.Join(",", values):String.Empty;

                //foreach (var localizationRecord in localizationRecords.Entities)
                //{
                //    if (localizationRecord.Contains(AttributeNames.RegionLocale.RegionLocaleCode))
                //    {
                //        string localizationName = localizationRecord.GetAttributeValue<string>(AttributeNames.RegionLocale.RegionLocaleCode);
                //        allLocalizationNames += localizationName + ", ";
                //    }
                //}
                if (!string.IsNullOrEmpty(projectactioncommentvalue)) { projectactioncommentvalue = projectactioncommentvalue + ","; }
                //allLocalizationNames = allLocalizationNames.Substring(0, allLocalizationNames.Length - 1);
                projectproductactioncomments = projectactioncommentvalue + allLocalizationNames;
                if (projectproductactioncomments.Length > COMMENTFIELDLIMIT)
                {
                    projectproductactioncomments = projectproductactioncomments.Substring(0, COMMENTFIELDLIMIT);
                }
                Entity pproject = new Entity(EntityName.Project);
                pproject.Id = projectguid;
                pproject[AttributeNames.Project.ProjectProductActionComments] = projectproductactioncomments;
                if (project.Contains(AttributeNames.Project.ProjectProductAction) && project.GetAttributeValue<OptionSetValue>(AttributeNames.Project.ProjectProductAction).Value != (int)eProjectAction.Change)
                    pproject[AttributeNames.Project.ProjectProductAction] = new OptionSetValue((int)eProjectAction.ADDLOC);

                DataverseClient.Update(pproject);
                response = new HttpResponseMessage(HttpStatusCode.OK); // responce = 200
            }

                return response;
            }, ("projectId", request?.projectId), ("localizationCount", request?.localizations?.Count));
        }

        public int? GetServicesTypebyServiceID(Guid removeServices)
        {
            return TraceOperation(nameof(GetServicesTypebyServiceID), () =>
            {
                if (removeServices == null)
                {
                    return null;
                }

                QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.ProductComponent.ServiceTypeGlobal, AttributeNames.ProductComponent.ProductComponentId)
                };

                //Add condition
                query.Criteria.AddCondition(AttributeNames.ProductComponent.ProductComponentId, ConditionOperator.Equal, removeServices);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    foreach (var tempentity in result.Entities)
                    {
                        int? ServiceTypeGlobal;
                        if (tempentity.Contains(AttributeNames.ProductComponent.ServiceTypeGlobal))
                        {
                            ServiceTypeGlobal = tempentity.GetValue<OptionSetValue>(AttributeNames.ProductComponent.ServiceTypeGlobal)?.Value;
                            return ServiceTypeGlobal;
                        }
                    }
                }
                return null;
            }, ("serviceId", removeServices));
        }

        public string FetchProjectBySkuNumber(string skuNumber, Guid customerId, string token)
        {
            return TraceOperation(nameof(FetchProjectBySkuNumber), () =>
            {
                string query = SqlQuery.FetchProjectBySkuNumber(skuNumber, customerId.ToString());
                _devBaseInfra = new DevBaseInfra(null, token);
                return _devBaseInfra.retrieveMultipleRecords(EntityName.Project, query, 0).Result;
                
            }, ("skuNumber", skuNumber));
        }
    }
}

        #endregion Query Expression