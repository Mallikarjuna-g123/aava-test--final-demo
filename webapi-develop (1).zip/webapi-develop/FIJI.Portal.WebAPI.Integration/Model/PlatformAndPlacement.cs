﻿using DocumentFormat.OpenXml.Spreadsheet;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Requests.ServiceRevision;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class PlatformAndPlacement : Base<PlatformAndPlacement>
    {
        public PlatformAndPlacement(IOrganizationService dataverseClient, ILogger<PlatformAndPlacement>? logger = null) : base(dataverseClient, "platformandplacement")
        { }

        public List<Guid>? GetPlatformandPlacementByServiceRevision(Guid? latestservicesnapshotid, out List<Guid?> plfId)
        {
            var result = TraceOperation(nameof(GetPlatformandPlacementByServiceRevision), () =>
            {
                List<Guid?> localPlfId = new List<Guid?>();
                if (latestservicesnapshotid != null)
                {
                    List<Guid> lsGuid = new List<Guid>();
                    QueryExpression query = new QueryExpression(EntityName.PlatformAndPlacement)
                    {
                        // Define the columns to retrieve
                        ColumnSet = new ColumnSet(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId, AttributeNames.PlatformAndPlacement.Platform)
                    };

                    // Add filtering conditions
                    query.Criteria.AddCondition(AttributeNames.PlatformAndPlacement.ServicesnapshotId, ConditionOperator.Equal, latestservicesnapshotid);
                    query.Orders.Add(new OrderExpression()
                    {
                        AttributeName = AttributeNames.PlatformAndPlacement.ModifiedOn,
                        OrderType = OrderType.Ascending
                    });
                    EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                    if (result != null && result.Entities.Count > 0)
                    {

                        foreach (var tempentity in result.Entities)
                        {
                            if (tempentity.Contains(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId))
                                lsGuid.Add(tempentity.Id);
                            if (tempentity.Contains(AttributeNames.PlatformAndPlacement.Platform)
                              && tempentity.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform) != null)
                                localPlfId.Add(tempentity.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform).Id);
                        }
                        return (placements: (List<Guid>?)lsGuid, plfIds: localPlfId);
                    }
                }
                return (placements: (List<Guid>?)null, plfIds: localPlfId);
            }, ("latestServiceSnapshotId", latestservicesnapshotid));

            plfId = result.plfIds;
            return result.placements;

        }

        //Create New Platform and Placement Record
        // Here second parameter take the copied or latest revision based on calle function
        // And third parameter take the Latest Servision revion
        public void CreatePlatformAndPlacementOnServiceRevision(Requests.UpdateCSAVRequest UpdateCSAVRequest, Guid? ServiceSnapShotId, Guid? latestServiceRevisionId, ServiceSnapshot.eStatusCode? latestServiceStatusCode)
        {
            TraceOperation(nameof(CreatePlatformAndPlacementOnServiceRevision), () =>
            {
                try
                {
                    bool createNew = true;
                    if (ServiceSnapShotId != null)
                    {
                        List<Guid?> plfId = new List<Guid?>();
                        List<Guid>? lsplatformAndPlacementId = GetPlatformandPlacementByServiceRevision(latestServiceRevisionId.Value, out plfId);

                        if (latestServiceStatusCode == ServiceSnapshot.eStatusCode.Submitted || latestServiceStatusCode == ServiceSnapshot.eStatusCode.Completed)
                        {
                            if (lsplatformAndPlacementId != null)
                            {
                                foreach (var platformAndPlacementId in lsplatformAndPlacementId)
                                {
                                    if (platformAndPlacementId != null)
                                    {
                                        var copyFijiPlatformAndPlacement = this.DataverseClient.Retrieve(EntityName.PlatformAndPlacement, platformAndPlacementId, new ColumnSet(true)); // get all records of Platfrom and Placement records

                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId);
                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.EverestId);
                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.OwnerId);
                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedOn);
                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedBy);
                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedOn);
                                        copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedBy);

                                        copyFijiPlatformAndPlacement.Id = Guid.NewGuid();

                                        copyFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = new EntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value);

                                        this.Execute(new CreateRequest { Target = copyFijiPlatformAndPlacement });
                                    }
                                }

                            }
                        }
                        //check if already exists
                        createNew = !plfId.Contains(new Guid(UpdateCSAVRequest.ModelId));
                        if (createNew)
                        {
                            Entity newFijiPlatformAndPlacement = new Entity(EntityName.PlatformAndPlacement);
                            newFijiPlatformAndPlacement.Id = Guid.NewGuid();

                            newFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Name] = UpdateCSAVRequest.ModelName;

                            newFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Platform] = Utils.GetEntityReference(EntityName.ProductFamily, UpdateCSAVRequest.ModelId);

                            newFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = new EntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value);// here ServiceSnapShotId can be latest service revision or New service Revision

                            this.Execute(new CreateRequest { Target = newFijiPlatformAndPlacement });
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }, ("serviceSnapshotId", ServiceSnapShotId), ("latestServiceRevisionId", latestServiceRevisionId), ("modelId", UpdateCSAVRequest?.ModelId));
        }

        public void CreatePlatformAndPlacementOnServiceRevisionUpdate(Guid? CopyFromServiceSnapShotId, Guid? CopyToServiceSnapShotId, ServiceRevisionUpdateRequest reqValues, out Guid? PlacementIDInResponse)
        {
            var placementId = TraceOperation(nameof(CreatePlatformAndPlacementOnServiceRevisionUpdate), () =>
            {
                Guid? localPlacementId = null;
                if (CopyFromServiceSnapShotId != null && CopyToServiceSnapShotId != null)
                {
                    List<Guid>? lsplatformAndPlacementId = GetPlatformandPlacementByServiceRevision(CopyFromServiceSnapShotId.Value, out _);


                    if (lsplatformAndPlacementId != null)
                    {
                        foreach (var platformAndPlacementId in lsplatformAndPlacementId)
                        {

                            var currentPlacement = this.DataverseClient.Retrieve(EntityName.PlatformAndPlacement, platformAndPlacementId, new ColumnSet(true)); // get all records of Platfrom and Placement records
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId);
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.EverestId);
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.OwnerId);
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedOn);
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedBy);
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedOn);
                            currentPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedBy);
                            currentPlacement.Id = Guid.NewGuid();

                            if (currentPlacement.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform) != null)
                            {
                                EntityReference platform = currentPlacement.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform);

                                currentPlacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = new EntityReference(EntityName.Servicesnapshot, CopyToServiceSnapShotId.Value);

                                if (reqValues.ModelId == platform.Id)
                                {
                                    localPlacementId = currentPlacement.Id;
                                }

                                this.Execute(new CreateRequest { Target = currentPlacement });
                            }
                        }
                    }
                }
                return localPlacementId;
            }, ("copyFromServiceSnapshotId", CopyFromServiceSnapShotId), ("copyToServiceSnapshotId", CopyToServiceSnapShotId), ("modelId", reqValues?.ModelId));

            PlacementIDInResponse = placementId;
        }


        // Create Platfrom and placement on new product component creation 
        public void CreatePlatformandPlacementOnNewProductComponent(Requests.ProductComponentRequest productComponentRequest, Guid? ServiceSnapShotId)
        {
            TraceOperation(nameof(CreatePlatformandPlacementOnNewProductComponent), () =>
            {
                if (productComponentRequest.QuestionnaireDetails != "")
                {

                    Entity fiji_platformplacement = new Entity(EntityName.PlatformAndPlacement);
                    fiji_platformplacement.Id = Guid.NewGuid();

                    if (productComponentRequest.CustomAssetTag != null && productComponentRequest.Placement != null && productComponentRequest.Orientation != null)
                    {
                        if (!string.IsNullOrEmpty(productComponentRequest?.ModelName))
                        {
                            var placement = string.IsNullOrEmpty(productComponentRequest.Placement) ? "" : "-" + productComponentRequest.Placement;
                            fiji_platformplacement[AttributeNames.PlatformAndPlacement.Name] = productComponentRequest.ModelName + placement;
                        }

                    }

                    fiji_platformplacement[AttributeNames.PlatformAndPlacement.Platform] = Utils.GetEntityReference(EntityName.ProductFamily, productComponentRequest.ModelId);
                    if (ServiceSnapShotId != null)
                        fiji_platformplacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = Utils.GetEntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value.ToString());

                    if (productComponentRequest.RequireCustomAssetTag != null)
                    {
                        fiji_platformplacement[AttributeNames.PlatformAndPlacement.RequiredCustomAssetTag] = Convert.ToBoolean(productComponentRequest.RequireCustomAssetTag);
                        fiji_platformplacement[AttributeNames.PlatformAndPlacement.Placement] = productComponentRequest.Placement;

                        if (productComponentRequest.Orientation != null)
                            fiji_platformplacement[AttributeNames.PlatformAndPlacement.Orientation] = new OptionSetValue(productComponentRequest.Orientation.Value);
                        else
                            fiji_platformplacement[AttributeNames.PlatformAndPlacement.Orientation] = null;

                        fiji_platformplacement[AttributeNames.PlatformAndPlacement.CustomAssetTag] = productComponentRequest.CustomAssetTag;

                    }
                    this.Execute(new CreateRequest { Target = fiji_platformplacement });
                }
            }, ("serviceSnapshotId", ServiceSnapShotId), ("modelId", productComponentRequest?.ModelId));
        }
        // update the platfrom and placement records on service revision
        public void UpdatePPonServiceRevisionUpdate(ServiceRevisionUpdateRequest updaterequest)
        {
            TraceOperation(nameof(UpdatePPonServiceRevisionUpdate), () =>
            {
                if (updaterequest.RequireCustomAssetTag != null)
                {
                    Entity FijiPlatformAndPlacement = this.DataverseClient.Retrieve(EntityName.PlatformAndPlacement, updaterequest.PlacementId, new ColumnSet(AttributeNames.PlatformAndPlacement.Platform));

                    if (FijiPlatformAndPlacement.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform) != null)
                    {
                        Guid? currentplatformId = FijiPlatformAndPlacement.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform).Id;

                        var platformName = FijiPlatformAndPlacement.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform).Name;
                        FijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Name] = string.IsNullOrEmpty(updaterequest?.Placement) ? platformName : platformName + "-" + updaterequest.Placement;

                    }

                    if (bool.TryParse(updaterequest.RequireCustomAssetTag, out _))
                    {
                        FijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.RequiredCustomAssetTag] = Convert.ToBoolean(updaterequest.RequireCustomAssetTag);
                    }
                    else
                    {
                        throw new FormatException($"The provided RequireCustomAssetTag  = " + updaterequest.RequireCustomAssetTag + " is not a valid boolean value!");
                    }


                    if (!string.IsNullOrEmpty(updaterequest.Placement))
                        FijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Placement] = updaterequest.Placement;

                    if (updaterequest.Orientation != null)
                    {
                        if (int.TryParse(updaterequest.Orientation, out _))
                        { FijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Orientation] = new OptionSetValue(Convert.ToInt32(updaterequest.Orientation)); }
                        else
                            throw new FormatException($"The provided Orientation= " + updaterequest.Orientation + " is not a valid Number!");
                    }
                    else
                    {
                        FijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Orientation] = null;
                    }


                    if (updaterequest.CustomAssetTag != null)
                        FijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.CustomAssetTag] = updaterequest.CustomAssetTag;

                    this.Execute(new UpdateRequest { Target = FijiPlatformAndPlacement });

                }
            }, ("placementId", updaterequest?.PlacementId), ("hasCustomAssetTag", !string.IsNullOrEmpty(updaterequest?.CustomAssetTag)));
        }


        // Create Platform and placement for duplicate product component
        public void CreatePlatformandPlacementForDuplicateProductComponent(Guid? ServiceSnapShotId, Guid? copiedPlatformandPlacementRec)
        {
            TraceOperation(nameof(CreatePlatformandPlacementForDuplicateProductComponent), () =>
            {
                var copyFijiPlatformAndPlacement = this.DataverseClient.Retrieve(EntityName.PlatformAndPlacement, copiedPlatformandPlacementRec.Value, new ColumnSet(true)); // get all records of Platfrom and Placement records
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ServicesnapshotId);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedOn);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedBy);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedOn);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedBy);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.EverestId);
                copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.OwnerId);
                copyFijiPlatformAndPlacement.Id = Guid.NewGuid();
                if (ServiceSnapShotId != null)
                    copyFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = Utils.GetEntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value.ToString());
                this.Execute(new CreateRequest { Target = copyFijiPlatformAndPlacement });
            }, ("serviceSnapshotId", ServiceSnapShotId), ("sourcePlacementId", copiedPlatformandPlacementRec));

        }

        public void ReassociatePlatformPlacements(Guid? oldServiceRevisionId, Guid? newServiceRevisionId, string platformId)
        {
            TraceOperation(nameof(ReassociatePlatformPlacements), () =>
            {
                // clone the Platform and Placement by respect to service revision and excluding PlatformId.
                List<Guid>? lsplatformAndPlacementId = GetPlatformandPlacementByServiceRevisionExcludingPlatformId(oldServiceRevisionId, platformId);

                if (lsplatformAndPlacementId == null || !lsplatformAndPlacementId.Any())
                    return;

                foreach (Guid platformPlacementId in lsplatformAndPlacementId)
                {
                    // get all records of Platfrom and Placement records
                    Entity copyFijiPlatformAndPlacement = this.DataverseClient.Retrieve(EntityName.PlatformAndPlacement, platformPlacementId, new ColumnSet(true));

                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ServicesnapshotId);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedOn);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.CreatedBy);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedOn);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.ModifiedBy);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.EverestId);
                    copyFijiPlatformAndPlacement.Remove(AttributeNames.PlatformAndPlacement.OwnerId);
                    copyFijiPlatformAndPlacement.Id = Guid.NewGuid();

                    if (newServiceRevisionId != null)
                        copyFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = Utils.GetEntityReference(EntityName.Servicesnapshot, newServiceRevisionId.Value.ToString());

                    this.Execute(new CreateRequest { Target = copyFijiPlatformAndPlacement });
                }
            }, ("oldServiceRevisionId", oldServiceRevisionId), ("newServiceRevisionId", newServiceRevisionId), ("platformId", platformId));
        }

        public List<Guid>? GetPlatformandPlacementByServiceRevisionExcludingPlatformId(Guid? oldServiceRevisionId, string platformId)
        {
            return TraceOperation(nameof(GetPlatformandPlacementByServiceRevisionExcludingPlatformId), () =>
            {
                if (oldServiceRevisionId != null)
                {
                    List<Guid> lsGuid = new List<Guid>();
                    QueryExpression query = new QueryExpression(EntityName.PlatformAndPlacement)
                    {
                        // Define the columns to retrieve
                        ColumnSet = new ColumnSet(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId)
                    };

                    // Add filtering conditions
                    query.Criteria.AddCondition(AttributeNames.PlatformAndPlacement.ServicesnapshotId, ConditionOperator.Equal, oldServiceRevisionId);
                    // Exclude PlatformId
                    query.Criteria.AddCondition(AttributeNames.PlatformAndPlacement.Platform, ConditionOperator.NotEqual, new Guid(platformId));

                    EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                    if (result != null && result.Entities.Count > 0)
                    {

                        foreach (var tempentity in result.Entities)
                        {
                            if (tempentity.Contains(AttributeNames.PlatformAndPlacement.PlatformAndPlacementId))
                                lsGuid.Add(tempentity.Id);
                        }
                        return lsGuid;
                    }
                }
                return null;
            }, ("oldServiceRevisionId", oldServiceRevisionId), ("platformId", platformId));
        }

        public void CreatePlatformandPlacementForDuplicateProductComponentWithPlatformId(Guid? ServiceSnapShotId, Guid? copiedPlatformandPlacementRec, string platformId)
        {
            TraceOperation(nameof(CreatePlatformandPlacementForDuplicateProductComponentWithPlatformId), () =>
            {
                Entity copyFijiPlatformAndPlacement = new Entity(EntityName.PlatformAndPlacement);
                copyFijiPlatformAndPlacement.Id = Guid.NewGuid();
                if (ServiceSnapShotId != null)
                    copyFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = Utils.GetEntityReference(EntityName.Servicesnapshot, ServiceSnapShotId.Value.ToString());
                if (!string.IsNullOrEmpty(platformId))
                    copyFijiPlatformAndPlacement[AttributeNames.PlatformAndPlacement.Platform] = Utils.GetEntityReference(EntityName.ProductFamily, platformId);

                this.Execute(new CreateRequest { Target = copyFijiPlatformAndPlacement });
            }, ("serviceSnapshotId", ServiceSnapShotId), ("sourcePlacementId", copiedPlatformandPlacementRec), ("platformId", platformId));
        }

        public void UpdateNewPlacementDetails(ServiceRevisionUpdateRequest reqValues, Guid? PlacementIDInResponse)
        {
            TraceOperation(nameof(UpdateNewPlacementDetails), () =>
            {
                //fetch platform placement
                if (reqValues.RequireCustomAssetTag != null && reqValues.Placement != null)
                {
                    Thread.Sleep(5000);
                    Entity currentPlacement = this.DataverseClient.Retrieve(EntityName.PlatformAndPlacement, PlacementIDInResponse.Value, new ColumnSet(true));
                    if (currentPlacement != null)
                    {
                        EntityReference platform = currentPlacement.GetAttributeValue<EntityReference>(AttributeNames.PlatformAndPlacement.Platform);
                        currentPlacement.Remove(AttributeNames.PlatformAndPlacement.Name);
                        currentPlacement.Remove(AttributeNames.PlatformAndPlacement.RequiredCustomAssetTag);
                        currentPlacement.Remove(AttributeNames.PlatformAndPlacement.Placement);
                        currentPlacement.Remove(AttributeNames.PlatformAndPlacement.Orientation);
                        currentPlacement.Remove(AttributeNames.PlatformAndPlacement.CustomAssetTag);

                        if (!string.IsNullOrEmpty(platform.Name))
                        {
                            var placement = string.IsNullOrEmpty(reqValues.Placement) ? "" : "-" + reqValues.Placement;
                            currentPlacement[AttributeNames.PlatformAndPlacement.Name] = platform.Name + placement;
                        }
                        if (bool.TryParse(reqValues.RequireCustomAssetTag, out _))
                        {
                            currentPlacement[AttributeNames.PlatformAndPlacement.RequiredCustomAssetTag] = Convert.ToBoolean(reqValues.RequireCustomAssetTag);
                        }
                        else
                        {
                            throw new FormatException($"The provided RequireCustomAssetTag  = " + reqValues.RequireCustomAssetTag + " is not a valid boolean value!");
                        }

                        if (!string.IsNullOrEmpty(reqValues.Placement))
                            currentPlacement[AttributeNames.PlatformAndPlacement.Placement] = reqValues.Placement;

                        if (!string.IsNullOrEmpty(reqValues.Orientation))
                        {
                            if (int.TryParse(reqValues.Orientation, out _))
                            { currentPlacement[AttributeNames.PlatformAndPlacement.Orientation] = new OptionSetValue(Convert.ToInt32(reqValues.Orientation)); }
                            else
                                throw new FormatException($"The provided Orientation = " + reqValues.Orientation + " is not a valid Number!");
                        }
                        else
                        {
                            currentPlacement[AttributeNames.PlatformAndPlacement.Orientation] = null;
                        }

                        if (reqValues.CustomAssetTag != null)
                            currentPlacement[AttributeNames.PlatformAndPlacement.CustomAssetTag] = reqValues.CustomAssetTag;
                        this.DataverseClient.Update(currentPlacement);
                    }
                }
            }, ("placementId", PlacementIDInResponse), ("hasCustomAssetTag", !string.IsNullOrEmpty(reqValues?.CustomAssetTag)));
        }

        public void CreatePlatformAndPlacementForNewService(string modelId, string? modelName, Guid? serviceSnapShotId, out Guid? placementId)
        {
            var result = TraceOperation(nameof(CreatePlatformAndPlacementForNewService), () =>
            {
                Entity fiji_platformplacement = new Entity(EntityName.PlatformAndPlacement);
                fiji_platformplacement.Id = Guid.NewGuid();
                fiji_platformplacement[AttributeNames.PlatformAndPlacement.Platform] = Utils.GetEntityReference(EntityName.ProductFamily, modelId);
                if (serviceSnapShotId != null)
                {
                    fiji_platformplacement[AttributeNames.PlatformAndPlacement.ServicesnapshotId] = Utils.GetEntityReference(EntityName.Servicesnapshot, serviceSnapShotId.Value.ToString());
                }
                if (!string.IsNullOrWhiteSpace(modelName))
                {
                    fiji_platformplacement[AttributeNames.PlatformAndPlacement.Name] = modelName;
                }
                this.Execute(new CreateRequest { Target = fiji_platformplacement });
                return (Guid?)fiji_platformplacement.Id;
            }, ("modelId", modelId), ("serviceSnapShotId", serviceSnapShotId));
            placementId = result;
        }
    }
}
