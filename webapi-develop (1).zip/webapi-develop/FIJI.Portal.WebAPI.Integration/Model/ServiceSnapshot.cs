﻿using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Requests.ProductComponent;
using FIJI.Portal.WebAPI.Integration.Requests.Project;
using FIJI.Portal.WebAPI.Integration.Requests.ServiceRevision;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Responses.ServiceRevision;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Dynamic;
using System.Net.Http.Headers;
using System.Text;
using static FIJI.Portal.WebAPI.Integration.Model.BOM;
using static FIJI.Portal.WebAPI.Integration.Model.ProductComponent;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ServiceSnapshot : Base<ServiceSnapshot>
    {
        private PlatformAndPlacement? _platformAndPlacementService;
        public eStatusCode LatestServiceStatusCode { get; set; }
        private PCPlatformStatus? _pcPlatformStatusService;
        private readonly FijiConfiguration? _fijiConfig;

        public Guid? Id { get; set; }
        public string? ServiceRevisionVersion { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public eStatusCode? StatusCode { get; set; }
        public Contact? ModifiedByPortalContact { get; set; }
        public string? Configuration { get; set; }

        public int? AutomationFlag { get; set; }

        private readonly IMemoryCache? _memoryCache;

        public enum Action
        {
            SaveExit = 1,
            Save = 2,
            SaveSubmit = 3
        }

        public enum eStatusCode
        {
            Completed = 219180000,
            InProgress = 219180001,
            Inactive = 2,
            Submitted = 1,
            FilledOut = 622490000
        }
        public enum eStatusReason
        {
            Draft = 102420001,
            Inactive = 2,
            Published = 1
        }

        public enum eDataType
        {
            Text = 1,
            RadioButton = 2,
            MultipleRadioButton = 3,
            DropdownList = 4,
            DragDropComponent = 5,
            MultilineTextbox = 6
        }

        public ServiceSnapshot() : base("servicesnapshot") { }
        

        public ServiceSnapshot(IOrganizationService dataverseClient, IMemoryCache cache, ILogger<ServiceSnapshot>? logger = null, ILoggerFactory? loggerFactory = null) : base(dataverseClient, "servicesnapshot")
        {
            this._memoryCache = cache;
            loggerFactory ??= NullLoggerFactory.Instance;
            _platformAndPlacementService = new PlatformAndPlacement(dataverseClient, loggerFactory.CreateLogger<PlatformAndPlacement>());
            _pcPlatformStatusService = new PCPlatformStatus(dataverseClient, loggerFactory.CreateLogger<PCPlatformStatus>());
            _fijiConfig = new FijiConfiguration(dataverseClient, loggerFactory.CreateLogger<FijiConfiguration>());
        }

        //create a latest service revision
        public Guid? CreateServiceRevision(UpdateCSAVRequest UpdateCSAVRequest, ServiceSnapshot serviceRevision)
        {
            return TraceOperation(nameof(CreateServiceRevision), () =>
            {
                if (serviceRevision.Id != Guid.Empty)
                {
                    // it will enter in this loop only if latest service revision exists
                    if (serviceRevision.LatestServiceStatusCode != null)
                    {
                        if (serviceRevision.LatestServiceStatusCode == eStatusCode.Submitted || serviceRevision.LatestServiceStatusCode == eStatusCode.Completed)
                        {
                            var copyServiceRevision = this.DataverseClient.Retrieve(EntityName.Servicesnapshot, serviceRevision.Id.Value, new ColumnSet(true)); // get all records of latest service revision

                            RemoveFieldsfromCopiedServiceRevision(serviceRevision.LatestServiceStatusCode, serviceRevision.ServiceRevisionVersion, ref copyServiceRevision);

                            copyServiceRevision.Id = Guid.NewGuid();

                            bool requiredAdditionalInfo = UpdateCSAVRequest.requiredAdditionalInfo;
                            if (requiredAdditionalInfo == true)
                                copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(((int)eStatusCode.InProgress));
                            else if (requiredAdditionalInfo == false && (serviceRevision.LatestServiceStatusCode == eStatusCode.Completed ||
                                serviceRevision.LatestServiceStatusCode == eStatusCode.FilledOut || serviceRevision.LatestServiceStatusCode == eStatusCode.Submitted))
                            {
                                copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(((int)eStatusCode.FilledOut));
                            }
                            this.Execute(new CreateRequest { Target = copyServiceRevision });
                            return (Guid?)copyServiceRevision.Id;
                        }
                    } // check LatestServiceStatusCode empty or null condition falls
                }
                return (Guid?)null;
            }, ("serviceRevisionId", (object?)serviceRevision.Id), ("latestStatus", (object?)serviceRevision.LatestServiceStatusCode.ToString()), ("requiredAdditionalInfo", (object?)UpdateCSAVRequest.requiredAdditionalInfo));
        }

        // Update Service Revision on  Latest Servicion revision status
        public void UpdateServiceRevisionStatus(Guid? serviceRevisionid, bool requiredAdditionalInfo)
        {
            TraceOperation(nameof(UpdateServiceRevisionStatus), () =>
            {
                if (serviceRevisionid != null && requiredAdditionalInfo)
                {
                    Entity fiji_servicesnapshot = new Entity(EntityName.Servicesnapshot, serviceRevisionid.Value);
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue((int)eStatusCode.InProgress);
                    this.Execute(new UpdateRequest { Target = fiji_servicesnapshot });
                }
            }, ("serviceRevisionId", serviceRevisionid), ("requiredAdditionalInfo", requiredAdditionalInfo));
        }

        public string RemoveFieldsfromCopiedServiceRevision(eStatusCode statuscode, string? serviceRevison, ref Entity copyServiceRevision)
        {
            string newversion = string.Empty;
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServicesnapshotId);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.Name);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ModifiedBy);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ModifiedOn);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ChangeComments);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ChangeMadeByUser);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ObjectAction);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.CreatedBy);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.CreatedOn);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.EverestId);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.DataSource);
            copyServiceRevision.Remove(AttributeNames.Servicesnapshot.Externalid);

            // Status code is Submitted
            if (statuscode == eStatusCode.Submitted)
            {
                newversion = MinorVersionIncrement(serviceRevison);
                copyServiceRevision[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = newversion;
            }
            // Status code is Completed
            else if (statuscode == eStatusCode.Completed)
            {
                newversion = MajorVersionIncrement(serviceRevison);
                copyServiceRevision[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = newversion;
            }

            return newversion;
        }

        //This method is used to increment the minor service revision x.y to x.(y+1)
        protected string MinorVersionIncrement(string? serviceRevision)
        {
            int incrementbyone = 0;
            string newversion = string.Empty;

            if (serviceRevision != null)
            {
                string[] splitrevision = serviceRevision.Split(new char[] { '.' });
                if (splitrevision.Length == 2)
                {
                    if (splitrevision[1] != null)
                    {
                        incrementbyone = Convert.ToInt32(splitrevision[1]);
                        incrementbyone = incrementbyone + 1;

                        newversion = splitrevision[0] + "." + incrementbyone.ToString();
                    }
                }
            }
            else newversion = Constants.Version1;

            return newversion;
        }

        //This method is used to increment the Major service revision
        protected string MajorVersionIncrement(string? serviceRevision)
        {
            int incrementbyone = 0;
            string newversion = string.Empty;

            if (serviceRevision != null)
            {
                string[] splitrevision = serviceRevision.Split(new char[] { '.' });
                if (splitrevision.Length == 2)
                {
                    if (splitrevision[0] != null)
                    {
                        incrementbyone = Convert.ToInt32(splitrevision[0]);
                        incrementbyone = incrementbyone + 1;

                        newversion = incrementbyone.ToString() + Constants.Version0;
                    }
                }
            }
            else newversion = Constants.Version1;

            return newversion;
        }

        public void UpdateServiceRevisionOnProjectSubmit(Requests.Project.SubmitProjectRequest SubmitProjectRequest)
        {
            TraceOperation(nameof(UpdateServiceRevisionOnProjectSubmit), () =>
            {
                try
                {
                    if (SubmitProjectRequest.Services != null)
                    {
                        foreach (var lsServices in SubmitProjectRequest.Services)
                        {
                            // update the service revision
                            if (lsServices.ServiceRevisionId != null)
                            {
                                int? statuscodeServiceRevision = GetStatusCodeByServiceRevisonID(lsServices.ServiceRevisionId);
                                if (statuscodeServiceRevision != null)
                                {
                                    if ((statuscodeServiceRevision == (int)eStatusCode.FilledOut) || (statuscodeServiceRevision == (int)eStatusCode.InProgress))
                                    {
                                        Entity fiji_servicesnapshot = new Entity(EntityName.Servicesnapshot, new Guid(lsServices.ServiceRevisionId));

                                        fiji_servicesnapshot[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue((int)eStatusCode.Submitted);
                                        this.Execute(new UpdateRequest { Target = fiji_servicesnapshot });

                                    }
                                    int? AutomationFlag = GetAutomationFlagDetailsByServiceRevisionId(lsServices.ServiceRevisionId);

                                    Entity fijiProductComponent = new Entity(EntityName.ProductComponent, new Guid(lsServices.ProductComponentId));
                                    if (AutomationFlag != null)
                                        fijiProductComponent[AttributeNames.ProductComponent.AutomationFlag] = new OptionSetValue((int)AutomationFlag);
                                    this.Execute(new UpdateRequest { Target = fijiProductComponent });
                                }
                            }

                            // update the PC Platform Status
                            if (lsServices.ProductComponentId != null && SubmitProjectRequest.ModelId != null)
                            {
                                _pcPlatformStatusService.SetTransaction(this.Transaction);
                                _pcPlatformStatusService.UpdatePCPlatfromStatusOnStateCode(lsServices.ProductComponentId, SubmitProjectRequest.ModelId, SubmitProjectRequest.ProjectId);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.LogError(ex, "UpdateServiceRevisionOnProjectSubmit encountered a non-fatal error for project {ProjectId} - {Error}", SubmitProjectRequest?.ProjectId, ex.Message);
                }
            }, ("projectId", SubmitProjectRequest?.ProjectId), ("serviceCount", SubmitProjectRequest?.Services?.Count));
        }

        // Create Service Revision
        public void CreateServiceRevisionOnNewProductComponent(Requests.ProductComponentRequest productComponentRequest, Guid ProductComponentID, bool? triggerEmailNotification, out Guid? ServiceSnapShotId, out string ServiceRevisonVersion, int? AutomationFlag)
        {
            var result = TraceOperation(nameof(CreateServiceRevisionOnNewProductComponent), () =>
            {
                Guid? localServiceSnapshotId = null;
                string localServiceRevisionVersion = string.Empty;

                if (productComponentRequest.QuestionnaireDetails != "")
                {
                    Entity fiji_servicesnapshot = new Entity(EntityName.Servicesnapshot);
                    fiji_servicesnapshot.Id = Guid.NewGuid();

                    localServiceSnapshotId = fiji_servicesnapshot.Id; // this needs to be added in the response
                    localServiceRevisionVersion = Constants.Version1;
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = localServiceRevisionVersion;
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.ParentService] = Utils.GetEntityReference(EntityName.ProductComponent, ProductComponentID.ToString());// lookup ;
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, productComponentRequest.ComponentTypeId);
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(Convert.ToInt32(productComponentRequest.StatusCodeServiceRevision));
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.ServiceDetailInJson] = productComponentRequest.QuestionnaireDetails.ToString();
                    if (productComponentRequest.PortalUserId != "" && productComponentRequest.PortalUserId != null)
                        fiji_servicesnapshot[AttributeNames.Servicesnapshot.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, productComponentRequest.PortalUserId);
                    if (AutomationFlag != null)
                        fiji_servicesnapshot[AttributeNames.Servicesnapshot.IsAutomated] = new OptionSetValue((int)AutomationFlag);
                    if (triggerEmailNotification.HasValue)
                        fiji_servicesnapshot[AttributeNames.Servicesnapshot.TriggerEmailNotification] = triggerEmailNotification;
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.FileId] = productComponentRequest?.FileId ?? string.Empty;

                    this.Execute(new CreateRequest { Target = fiji_servicesnapshot });
                }

                return (localServiceSnapshotId, localServiceRevisionVersion);
            }, ("productComponentId", ProductComponentID), ("componentTypeId", productComponentRequest?.ComponentTypeId), ("triggerEmailNotification", triggerEmailNotification));

            ServiceSnapShotId = result.localServiceSnapshotId;
            ServiceRevisonVersion = result.localServiceRevisionVersion;
        }

        //Update Service Revision
        public ServiceRevisionUpdateResponse UpdateServiceRevision(ServiceRevisionUpdateRequest updaterequest)
        {
            return TraceOperation(nameof(UpdateServiceRevision), () =>
            {
                ServiceRevisionUpdateResponse response = new ServiceRevisionUpdateResponse();
                ServiceSnapshot? serviceSnapshot = null;
                Guid? PlacementIDInResponse = null;

                this.BeginTransaction();
                //update the product component
                if (updaterequest.ProductComponentId != null && updaterequest.ComponentTypeId != null)
                {
                    Entity fijiProductComponent = new Entity(EntityName.ProductComponent, updaterequest.ProductComponentId.Value);
                    fijiProductComponent[AttributeNames.ProductComponent.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, updaterequest.ComponentTypeId.Value.ToString());

                    if (updaterequest.sourceComponentTypeid != null && updaterequest.sourceComponentTypeid != Guid.Empty)
                        fijiProductComponent[AttributeNames.ProductComponent.GetMoreSource] = Utils.GetEntityReference(EntityName.ComponentType, updaterequest.sourceComponentTypeid.Value.ToString());

                    if (updaterequest.ServiceRevisionId.HasValue)
                    {
                        serviceSnapshot = GetBy(updaterequest.ServiceRevisionId.Value);

                        if (serviceSnapshot?.StatusCode == eStatusCode.Submitted && !string.IsNullOrEmpty(updaterequest.AutomationFlagName) &&
                               updaterequest.AutomationFlagName.Trim().Equals(Constants.Automated, StringComparison.OrdinalIgnoreCase))
                            fijiProductComponent[AttributeNames.ProductComponent.AutomationFlag] = new OptionSetValue((int)eAutomationFlag.Automated);

                        if (serviceSnapshot?.StatusCode == eStatusCode.Submitted && !string.IsNullOrEmpty(updaterequest.AutomationFlagName) &&
                                updaterequest.AutomationFlagName.Trim().Equals(Constants.Manual, StringComparison.OrdinalIgnoreCase))
                            fijiProductComponent[AttributeNames.ProductComponent.AutomationFlag] = new OptionSetValue((int)eAutomationFlag.Manual);
                    }
                    this.Execute(new UpdateRequest { Target = fijiProductComponent });
                }
                this.CommitTransaction();

                this.BeginTransaction();

                if (!updaterequest.ServiceRevisionId.HasValue && updaterequest.ProductComponentId.HasValue)
                {
                    ServiceSnapshot latestServiceRevision = GetLatestServiceRevisionByProductcomponent(updaterequest.ProductComponentId.ToString(), null);
                    if (latestServiceRevision != null)
                        updaterequest.ServiceRevisionId = latestServiceRevision.Id;
                }

                if (updaterequest.ServiceRevisionId.HasValue)
                {
                    serviceSnapshot = GetBy(updaterequest.ServiceRevisionId.Value);
                    response.Version = serviceSnapshot.ServiceRevisionVersion;

                    if ((serviceSnapshot.StatusCode == eStatusCode.Submitted) || (serviceSnapshot.StatusCode == eStatusCode.Completed))
                    {
                        var copyServiceRevision = this.DataverseClient.Retrieve(EntityName.Servicesnapshot, updaterequest.ServiceRevisionId.Value, new ColumnSet(true));
                        string newversion = RemoveFieldsfromCopiedServiceRevision(serviceSnapshot.StatusCode.Value, serviceSnapshot.ServiceRevisionVersion, ref copyServiceRevision);

                        copyServiceRevision.Id = Guid.NewGuid();
                        response.ServiceRevisionId = copyServiceRevision.Id;

                        response.Version = newversion;

                        copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = GetServiceRevisionStatusCodeByAction(updaterequest.Action);
                        var serviceRevisionResponseStatus = GetResponseStatusByAction(updaterequest.Action);

                        if (serviceRevisionResponseStatus != null)
                            response.Status = serviceRevisionResponseStatus.Value;

                        copyServiceRevision[AttributeNames.Servicesnapshot.TriggerEmailNotification] = false;
                        if (updaterequest.TriggerNotification)
                            copyServiceRevision[AttributeNames.Servicesnapshot.TriggerEmailNotification] = updaterequest.TriggerNotification;

                        copyServiceRevision[AttributeNames.Servicesnapshot.ServiceDetailInJson] = updaterequest.Configuration;
                        copyServiceRevision[AttributeNames.Servicesnapshot.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, updaterequest?.PortalUserId?.ToString());
                        copyServiceRevision[AttributeNames.Servicesnapshot.FileId] = updaterequest?.FileId ?? string.Empty;

                        this.Execute(new CreateRequest { Target = copyServiceRevision });
                        this.CommitTransaction();

                        this.BeginTransaction();
                        _platformAndPlacementService.SetTransaction(this.Transaction);
                        _platformAndPlacementService.CreatePlatformAndPlacementOnServiceRevisionUpdate(updaterequest.ServiceRevisionId, copyServiceRevision.Id, updaterequest, out PlacementIDInResponse);
                        this.CommitTransaction();
                        if (PlacementIDInResponse != null)
                        {
                            this.BeginTransaction();
                            _platformAndPlacementService.UpdateNewPlacementDetails(updaterequest, PlacementIDInResponse);
                            this.CommitTransaction();
                        }
                        this.BeginTransaction();
                        //update BOM with latest service revision
                        if (updaterequest.BomId != null)
                        {
                            Entity fiji_billofmaterials = new Entity(EntityName.BOM, updaterequest.BomId.Value);
                            fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                            fiji_billofmaterials[AttributeNames.BOM.ServiceRevision] = new EntityReference(EntityName.Servicesnapshot, copyServiceRevision.Id);
                            this.Execute(new UpdateRequest { Target = fiji_billofmaterials });

                            //get it's generic pair and update 
                            if (updaterequest.ComponentTypeId != null && updaterequest.sourceComponentTypeid != null && updaterequest.ComponentTypeId != updaterequest.sourceComponentTypeid)
                            {
                                Entity genericBomEntity = GetGenericBom(updaterequest.sourceComponentTypeid.Value, updaterequest.BomId.Value);
                                if (genericBomEntity != null)
                                {
                                    //get getMore PC
                                    EntityCollection getMoreGenericPC = getProductComponentbyComponentType(updaterequest.ComponentTypeId.Value, (int)ProductComponent.eServiceTypeGlobal.GenericService);
                                    if (getMoreGenericPC != null && getMoreGenericPC.Entities.Count > 0)
                                    {
                                        Guid getMoreGenericPCId = getMoreGenericPC.Entities.FirstOrDefault().Id;
                                        //update generic BOM to getMore
                                        Entity getmoreBom = new Entity(EntityName.BOM, genericBomEntity.Id);
                                        getmoreBom[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                                        getmoreBom[AttributeNames.BOM.ProductComponent] = new EntityReference(EntityName.ProductComponent, getMoreGenericPCId);
                                        this.Execute(new UpdateRequest { Target = getmoreBom });
                                    }
                                }
                            }

                        }
                        if (updaterequest.BomId != null)
                        {
                            var projectScopeChangeHelper = new ProjectScopeChangeHelper(DataverseClient);
                            var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(updaterequest.BomId.ToString());

                            var projectScopeChangereponse = new ProjectScopeChangeRequest();
                            if (result != null)
                            {

                                projectScopeChangereponse.Sections ??= new Sections();

                                projectScopeChangereponse.Sections.Edit ??= new List<BomItem>();
                                // Edit the new BomItem
                                projectScopeChangereponse.Sections.Edit.Add(new BomItem
                                {
                                    BomId = result.bomName,
                                    ExternalId = result.externalId,
                                    PortalDescription = result.description
                                });
                            }
                            var projectId = projectScopeChangeHelper.GetProjectIDByBOMID(updaterequest.BomId ?? Guid.Empty);
                            projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, projectId.ToString());
                        }
                        this.CommitTransaction();
                    }
                    else if ((serviceSnapshot.StatusCode != eStatusCode.Submitted) || (serviceSnapshot.StatusCode != eStatusCode.Completed))
                    {
                        this.BeginTransaction();
                        Entity updfiji_servicesnapshot = new Entity(EntityName.Servicesnapshot, updaterequest.ServiceRevisionId.Value);
                        response.ServiceRevisionId = updaterequest.ServiceRevisionId.Value;

                        updfiji_servicesnapshot[AttributeNames.Servicesnapshot.StatusCode] = GetServiceRevisionStatusCodeByAction(updaterequest.Action);

                        var serviceRevisionResponseStatus = GetResponseStatusByAction(updaterequest.Action);
                        if (serviceRevisionResponseStatus != null)
                            response.Status = serviceRevisionResponseStatus.Value;

                        updfiji_servicesnapshot[AttributeNames.Servicesnapshot.TriggerEmailNotification] = false;
                        if (updaterequest.TriggerNotification)
                            updfiji_servicesnapshot[AttributeNames.Servicesnapshot.TriggerEmailNotification] = updaterequest.TriggerNotification;

                        updfiji_servicesnapshot[AttributeNames.Servicesnapshot.ServiceDetailInJson] = updaterequest.Configuration;
                        updfiji_servicesnapshot[AttributeNames.Servicesnapshot.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, updaterequest?.PortalUserId?.ToString());
                        if (!string.IsNullOrEmpty(updaterequest.AutomationFlagName) &&
                              updaterequest.AutomationFlagName.Trim().Equals(Constants.Automated, StringComparison.OrdinalIgnoreCase))
                            updfiji_servicesnapshot[AttributeNames.Servicesnapshot.IsAutomated] = new OptionSetValue((int)eAutomationFlag.Automated);

                        if (!string.IsNullOrEmpty(updaterequest.AutomationFlagName) &&
                                updaterequest.AutomationFlagName.Trim().Equals(Constants.Manual, StringComparison.OrdinalIgnoreCase))
                            updfiji_servicesnapshot[AttributeNames.Servicesnapshot.IsAutomated] = new OptionSetValue((int)eAutomationFlag.Manual);
                        updfiji_servicesnapshot[AttributeNames.Servicesnapshot.FileId] = updaterequest?.FileId ?? string.Empty;

                        this.Execute(new UpdateRequest { Target = updfiji_servicesnapshot });
                        this.CommitTransaction();
                        this.BeginTransaction();
                        _platformAndPlacementService.SetTransaction(this.Transaction);
                        //update the platform and placement record
                        PlacementIDInResponse = updaterequest.PlacementId;
                        _platformAndPlacementService.UpdatePPonServiceRevisionUpdate(updaterequest);

                        //update BOM with latest service revision
                        if (updaterequest.BomId != null)
                        {
                            Entity fiji_billofmaterials = new Entity(EntityName.BOM, updaterequest.BomId.Value);
                            fiji_billofmaterials[AttributeNames.BOM.ServiceRevision] = new EntityReference(EntityName.Servicesnapshot, updaterequest.ServiceRevisionId.Value);
                            fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                            fiji_billofmaterials[AttributeNames.BOM.ProductComponent] = new EntityReference(EntityName.ProductComponent, updaterequest.ProductComponentId.Value);
                            this.Execute(new UpdateRequest { Target = fiji_billofmaterials });

                            //get it's generic pair and update 
                            if (updaterequest.ComponentTypeId != null && updaterequest.sourceComponentTypeid != null && updaterequest.ComponentTypeId != updaterequest.sourceComponentTypeid)
                            {
                                Entity genericBomEntity = GetGenericBom(updaterequest.sourceComponentTypeid.Value, updaterequest.BomId.Value);
                                if (genericBomEntity != null)
                                {
                                    //get getMore PC
                                    EntityCollection getMoreGenericPC = getProductComponentbyComponentType(updaterequest.ComponentTypeId.Value, (int)ProductComponent.eServiceTypeGlobal.GenericService);
                                    if (getMoreGenericPC != null && getMoreGenericPC.Entities.Count > 0)
                                    {
                                        Guid getMoreGenericPCId = getMoreGenericPC.Entities.FirstOrDefault().Id;
                                        //update generic BOM to getMore
                                        Entity getmoreBom = new Entity(EntityName.BOM, genericBomEntity.Id);
                                        getmoreBom[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                                        getmoreBom[AttributeNames.BOM.ProductComponent] = new EntityReference(EntityName.ProductComponent, getMoreGenericPCId);
                                        this.Execute(new UpdateRequest { Target = getmoreBom });
                                    }
                                }
                            }

                            var projectScopeChangeHelper = new ProjectScopeChangeHelper(DataverseClient);
                            var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(updaterequest.BomId.ToString());

                            var projectScopeChangereponse = new ProjectScopeChangeRequest();
                            if (result != null)
                            {

                                projectScopeChangereponse.Sections ??= new Sections();

                                projectScopeChangereponse.Sections.Edit ??= new List<BomItem>();
                                // Edit the new BomItem
                                projectScopeChangereponse.Sections.Edit.Add(new BomItem
                                {
                                    BomId = result.bomName,
                                    ExternalId = result.externalId,
                                    PortalDescription = result.description
                                });
                            }
                            var projectId = projectScopeChangeHelper.GetProjectIDByBOMID(updaterequest.BomId ?? Guid.Empty);
                            projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, projectId.ToString());
                        }
                    }
                    this.CommitTransaction();
                }

                else
                {
                    this.BeginTransaction();
                    string componentTypeId = updaterequest?.ComponentTypeId?.ToString();

                    var serviceRevisionStatusCode = GetServiceRevisionStatusCodeByAction(updaterequest.Action);
                    var serviceRevisionResponseStatus = GetResponseStatusByAction(updaterequest.Action);
                    if (serviceRevisionResponseStatus != null)
                        response.Status = serviceRevisionResponseStatus.Value;

                    bool triggerEmailNotification = false;
                    int? AutomationFlag = null;
                    if (updaterequest.TriggerNotification)
                        triggerEmailNotification = updaterequest.TriggerNotification;

                    ProductComponentRequest productComponentRequest = new()
                    {
                        ComponentTypeId = componentTypeId,
                        StatusCodeServiceRevision = serviceRevisionStatusCode.ToString(),
                        QuestionnaireDetails = updaterequest?.Configuration,
                        PortalUserId = updaterequest?.PortalUserId?.ToString()
                    };

                    CreateServiceRevisionOnNewProductComponent(productComponentRequest, updaterequest.ProductComponentId.Value, triggerEmailNotification, out Guid? NewServiceSnapShotId, out _, AutomationFlag);
                    this.CommitTransaction();
                    this.BeginTransaction();
                    //update BOM with latest service revision
                    if (updaterequest.BomId != null)
                    {
                        Entity fiji_billofmaterials = new Entity(EntityName.BOM, updaterequest.BomId.Value);
                        fiji_billofmaterials[AttributeNames.BOM.ServiceRevision] = new EntityReference(EntityName.Servicesnapshot, NewServiceSnapShotId.Value);
                        fiji_billofmaterials[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                        this.Execute(new UpdateRequest { Target = fiji_billofmaterials });

                        //get it's generic pair and update 
                        if (updaterequest.ComponentTypeId != null && updaterequest.sourceComponentTypeid != null && updaterequest.ComponentTypeId != updaterequest.sourceComponentTypeid)
                        {
                            Entity genericBomEntity = GetGenericBom(updaterequest.sourceComponentTypeid.Value, updaterequest.BomId.Value);
                            if (genericBomEntity != null)
                            {
                                //get getMore PC
                                EntityCollection getMoreGenericPC = getProductComponentbyComponentType(updaterequest.ComponentTypeId.Value, (int)ProductComponent.eServiceTypeGlobal.GenericService);
                                if (getMoreGenericPC != null && getMoreGenericPC.Entities.Count > 0)
                                {
                                    Guid getMoreGenericPCId = getMoreGenericPC.Entities.FirstOrDefault().Id;
                                    //update generic BOM to getMore
                                    Entity getmoreBom = new Entity(EntityName.BOM, genericBomEntity.Id);
                                    getmoreBom[AttributeNames.BOM.SkipBOMAutoParse] = new OptionSetValue((int)eSkipBOMAutoParse.Yes);
                                    getmoreBom[AttributeNames.BOM.ProductComponent] = new EntityReference(EntityName.ProductComponent, getMoreGenericPCId);
                                    this.Execute(new UpdateRequest { Target = getmoreBom });
                                }
                            }
                        }

                        var projectScopeChangeHelper = new ProjectScopeChangeHelper(DataverseClient);
                        var result = projectScopeChangeHelper.GetProductExternalIdByBOMID(updaterequest.BomId.ToString());

                        var projectScopeChangereponse = new ProjectScopeChangeRequest();
                        if (result != null)
                        {

                            projectScopeChangereponse.Sections ??= new Sections();

                            projectScopeChangereponse.Sections.Edit ??= new List<BomItem>();
                            // Edit the new BomItem
                            projectScopeChangereponse.Sections.Edit.Add(new BomItem
                            {
                                BomId = result.bomName,
                                ExternalId = result.externalId,
                                PortalDescription = result.description
                            });
                        }
                        var projectId = projectScopeChangeHelper.GetProjectIDByBOMID(updaterequest.BomId ?? Guid.Empty);
                        projectScopeChangeHelper.UpdateProjectScopeChangeByProjectId(projectScopeChangereponse, projectId.ToString());
                    }

                    response.ServiceRevisionId = NewServiceSnapShotId.Value;
                    updaterequest.ServiceRevisionId = NewServiceSnapShotId;
                }
                CommitTransaction();

                if (updaterequest.ServiceRevisionId.HasValue)
                {
                    serviceSnapshot = GetBy(response.ServiceRevisionId);
                    response = new ServiceRevisionUpdateResponse()
                    {
                        ServiceRevisionId = response.ServiceRevisionId,
                        Version = serviceSnapshot.ServiceRevisionVersion,
                        PlacementId = PlacementIDInResponse,
                        Status = (int)serviceSnapshot.StatusCode,
                        ModifiedOn = serviceSnapshot.ModifiedOn,
                        ModifiedByPortalContact = serviceSnapshot.ModifiedByPortalContact?.Name
                    };
                }

                //Transform API for AY103AV Service for the Existing API 
                QuestionnaireDetails details = JsonConvert.DeserializeObject<QuestionnaireDetails>(updaterequest?.Configuration);

                if (details?.ScreenNumber == Constants.PartNumber_AY103AV)
                {
                    var api = TransformAPIAY103AVService(details, updaterequest.ServiceRevisionId, updaterequest?.PortalUserId);
                }

                return response;
            }, ("serviceRevisionId", updaterequest?.ServiceRevisionId), ("productComponentId", updaterequest?.ProductComponentId), ("bomId", updaterequest?.BomId), ("action", updaterequest?.Action));
        }

        public Entity GetGenericBom(Guid componentTypeId, Guid bomId)
        {
            return TraceOperation(nameof(GetGenericBom), () =>
            {
                Entity bomItem = this.DataverseClient.Retrieve(EntityName.BOM, bomId, new ColumnSet(AttributeNames.BOM.Project));
                if (bomItem != null && bomItem.Contains(AttributeNames.BOM.Project))
                {
                    EntityReference projectId = bomItem.GetAttributeValue<EntityReference>(AttributeNames.BOM.Project);

                    QueryExpression query = new QueryExpression(EntityName.BOM)
                    {
                        ColumnSet = new ColumnSet(
                            AttributeNames.BOM.Project,
                        AttributeNames.BOM.ProductComponent,
                        AttributeNames.BOM.Name,
                        AttributeNames.BOM.ObjectActionCode,
                        AttributeNames.BOM.ProductActionCode,
                        AttributeNames.BOM.BOMId)
                    };

                    query.Criteria.AddCondition(AttributeNames.BOM.BomType, ConditionOperator.Equal, (int)eBomtype.Project);
                    query.Criteria.AddCondition(AttributeNames.BOM.ProductRevision, ConditionOperator.Null);
                    query.Criteria.AddCondition(AttributeNames.BOM.StateCode, ConditionOperator.Equal, (int)BOM.eStateCode.Active);
                    query.Criteria.AddCondition(AttributeNames.BOM.ProductActionCode, ConditionOperator.NotEqual, (int)BOM.eProductActionCode.Remove);
                    query.Criteria.AddCondition(AttributeNames.BOM.Project, ConditionOperator.Equal, projectId.Id);

                    var pc = query.AddLink(
                        EntityName.ProductComponent,
                        EntityName.ProductComponent,
                        AttributeNames.ProductComponent.ProductComponentId);
                    pc.EntityAlias = "pc";
                    pc.LinkCriteria.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, (int)ProductComponent.eServiceTypeGlobal.GenericService);
                    var ct = pc.AddLink(EntityName.ComponentType, EntityName.ComponentType, AttributeNames.ComponentType.ComponentTypeId);
                    ct.EntityAlias = "ct";
                    ct.LinkCriteria.AddCondition(AttributeNames.ComponentType.IsFactoryService, ConditionOperator.Equal, true);
                    ct.LinkCriteria.AddCondition(AttributeNames.ComponentType.ComponentTypeId, ConditionOperator.Equal, componentTypeId);

                    EntityCollection genericBomColl = this.DataverseClient.RetrieveMultiple(query);
                    if (genericBomColl != null && genericBomColl.Entities.Count > 0)
                    {
                        return genericBomColl.Entities.FirstOrDefault();
                    }
                    else
                    {
                        return null;
                    }
                }
                return null;
            }, ("componentTypeId", componentTypeId), ("bomId", bomId));
        }

        public async Task<string?> TransformAPIAY103AVService(QuestionnaireDetails details, Guid? NewServiceSnapShotId, Guid? PortalContact)
        {
            return await TraceOperationAsync(nameof(TransformAPIAY103AVService), async () =>
            {
                if (details != null)
                {
                    TransformAPIAY103AVServiceRequest transformAPIAY103AVServiceRequest = new()
                    {
                        ConfigurationId = details?.ConfigurationId,
                        AccountId = details?.CustomerId.ToString(),
                        ContactId = PortalContact.ToString(),
                        ServiceRevisionId = NewServiceSnapShotId,
                        ValueList = details?.ValueList,
                        TypeCode = details?.IsBCUSetting == true ? 1 : 2
                    };

                    if (transformAPIAY103AVServiceRequest.TypeCode == 1 && details?.BCUData != null)
                    {
                        var urlCollection = await _fijiConfig.GetFijiConfigKeyValue(new List<string>() { Constants.Customer_Files_HostUrl });
                        string fileBaseUrl = urlCollection?.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == Constants.Customer_Files_HostUrl)?.GetAttributeValue<string>("fiji_value");
                        var BCUFileUrl = details?.BCUData?.BCUFile != null ? $"{fileBaseUrl}{transformAPIAY103AVServiceRequest.AccountId}/{details?.BCUData?.BCUFile?.Description}" : null;
                        var HPScriptUrl = details?.BCUData?.HPSureAdminScriptFile != null ? $"{fileBaseUrl}{transformAPIAY103AVServiceRequest.AccountId}/{details?.BCUData?.HPSureAdminScriptFile?.Description}" : null;

                        transformAPIAY103AVServiceRequest.BCUData = new()
                        {
                            BCUFilePath = BCUFileUrl,
                            KeyboardLocalization = details.BCUData.KeyboardLocalization,
                            PasswordMinLength = details.BCUData.PasswordMinLength,
                            AdministratorPassword = details.BCUData.AdministratorPassword,
                            PostPowerOnPassword = details.BCUData.PostPowerOnPassword,
                            HPSureAdmin = details.BCUData.HPSureAdmin,
                            ProvisionSecurePlatformManagementKey = details.BCUData.ProvisionSecurePlatformManagementKey,
                            HPSureAdminScriptFilePath = HPScriptUrl
                        };
                    }

                    if (transformAPIAY103AVServiceRequest.TypeCode.HasValue && transformAPIAY103AVServiceRequest.ValueList != null && transformAPIAY103AVServiceRequest.ValueList.Count > 0)
                    {
                        var urlCollection = await _fijiConfig.GetFijiConfigKeyValue(new List<string>() { Constants.AY103AV_API_BaseURL,
                                                                                                         Constants.AY103AV_API_Code,
                                                                                                         Constants.AzureAccessScope });
                        Uri TransformApiBaseUri = new Uri($"{urlCollection.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == Constants.AY103AV_API_BaseURL)?.GetAttributeValue<string>("fiji_value")}");
                        string ApiCodeValue = urlCollection?.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == Constants.AY103AV_API_Code)?.GetAttributeValue<string>("fiji_value") ?? null;
                        string azureAccessScopeUrl = urlCollection.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == "AzureAccessScope")?.GetAttributeValue<string>("fiji_value") ?? null;

                        using (HttpClient client = new())
                        {
                            client.DefaultRequestHeaders.UserAgent.ParseAdd(Constants.UserAgentHeaderValue);
                            var url = $"{TransformApiBaseUri}save";

                            if (!string.IsNullOrEmpty(azureAccessScopeUrl))
                            {
                                string token = await Authentication.GetToken(azureAccessScopeUrl, new Azure.Identity.DefaultAzureCredential(), _memoryCache);
                                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                            }


                            // Create the request body
                            var requestBody = transformAPIAY103AVServiceRequest;
                            var jsonBody = JsonConvert.SerializeObject(requestBody);
                            var content = new StringContent(jsonBody, Encoding.UTF8, Constants.JsonApplication);

                            // Make the POST request
                            var response = await client.PostAsync(url, content);
                            if (response.IsSuccessStatusCode)
                            {
                                string responseContent = await response.Content.ReadAsStringAsync();
                                return responseContent;
                            }
                        }
                    }
                }
                return string.Empty;
            }, ("serviceRevisionId", NewServiceSnapShotId), ("portalContactId", PortalContact), ("screen", details?.ScreenNumber));
        }

        private OptionSetValue GetServiceRevisionStatusCodeByAction(int action)
        {
            int serviceRevisionStatusCode = (int)eStatusCode.InProgress;

            if (action == (int)Action.SaveExit)
            {
                serviceRevisionStatusCode = ((int)eStatusCode.InProgress);
            }
            else if (action == (int)Action.Save)
            {
                serviceRevisionStatusCode = ((int)eStatusCode.FilledOut);
            }
            else if (action == (int)Action.SaveSubmit)
            {
                serviceRevisionStatusCode = ((int)eStatusCode.Submitted);
            }

            return new OptionSetValue(serviceRevisionStatusCode);
        }

        private int? GetResponseStatusByAction(int action)
        {
            int? responseStatus = null;

            if (action == (int)Action.SaveExit)
            {
                responseStatus = (int)eStatusCode.InProgress;
            }
            else if (action == (int)Action.Save)
            {
                responseStatus = ((int)eStatusCode.FilledOut);
            }

            return responseStatus;
        }

        public void CreateServiceRevisionOnDuplicateProductComponent(ProductComponent_Duplicate_Request reqpayloadProductcomponent, Guid newproductcomponent, out Guid? ServicesnapshotID)
        {
            ServicesnapshotID = TraceOperation(nameof(CreateServiceRevisionOnDuplicateProductComponent), () =>
            {
                Guid reqpayloadProductcomponentId = reqpayloadProductcomponent.ProductComponentId;
                Guid? localServiceSnapshotId = null;
                ServiceSnapshot? LatestServiceRevision = GetLatestServiceRevisionByProductcomponent(reqpayloadProductcomponentId.ToString(), null);

                if (LatestServiceRevision != null)
                {
                    var copyServiceRevision = this.DataverseClient.Retrieve(EntityName.Servicesnapshot, LatestServiceRevision.Id.Value, new ColumnSet(true));
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.CustomerId);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServiceRevisionVersion);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.CreatedOn);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.CreatedBy);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ModifiedOn);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ModifiedBy);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.EverestId);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.DataSource);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.Externalid);

                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServicesnapshotId);
                    copyServiceRevision.Id = Guid.NewGuid();
                    localServiceSnapshotId = copyServiceRevision.Id;
                    copyServiceRevision[AttributeNames.Servicesnapshot.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, reqpayloadProductcomponent.PortalUserId.ToString());
                    if (copyServiceRevision.GetAttributeValue<EntityReference>(AttributeNames.Servicesnapshot.CustomerId) != null)
                        copyServiceRevision[AttributeNames.Servicesnapshot.CustomerId] = copyServiceRevision.GetAttributeValue<EntityReference>(AttributeNames.Servicesnapshot.CustomerId).Id;

                    copyServiceRevision[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = Constants.Version1;
                    copyServiceRevision[AttributeNames.Servicesnapshot.ParentService] = Utils.GetEntityReference(EntityName.ProductComponent, newproductcomponent.ToString());

                    if ((int)copyServiceRevision.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value != (int)eStatusCode.InProgress)
                        copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(((int)eStatusCode.FilledOut));
                    else
                        copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(((int)eStatusCode.InProgress));

                    string joncontent = copyServiceRevision.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson);
                    if (!string.IsNullOrEmpty(joncontent))
                    {
                        JObject jObject = JObject.Parse(joncontent);
                        if (jObject.ContainsKey("Details"))
                        {
                            var details = jObject["Details"];
                            if (details.SelectTokens("getmore") != null)
                                details["getmore"] = false;
                        }
                        else
                        {
                            if (jObject.ContainsKey("getMore"))
                                jObject.Remove("getMore");
                            jObject["getMore"] = false;
                        }
                        if (jObject.ContainsKey("getMoreServiceNumber"))
                            jObject.Remove("getMoreServiceNumber");
                        if (jObject.ContainsKey("questionnaireScreen"))
                            jObject.Remove("questionnaireScreen");
                        copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServiceDetailInJson);
                        copyServiceRevision[AttributeNames.Servicesnapshot.ServiceDetailInJson] = jObject.ToString();
                    }
                    this.Execute(new CreateRequest { Target = copyServiceRevision });
                }

                return localServiceSnapshotId;
            }, ("sourceProductComponentId", reqpayloadProductcomponent?.ProductComponentId), ("newProductComponentId", newproductcomponent));
        }

        #region Query Expression


        public Model.ServiceSnapshot? GetLatestServiceRevisionforUpdateCSAV(string productComponentId)
        {
            return TraceOperation(nameof(GetLatestServiceRevisionforUpdateCSAV), () =>
            {
                Model.ServiceSnapshot? serviceSnapshot = null;

                QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.ServiceRevisionVersion, AttributeNames.Servicesnapshot.StatusCode, AttributeNames.Servicesnapshot.ModifiedByPortalContact, AttributeNames.Servicesnapshot.ModifiedOn, AttributeNames.Servicesnapshot.ServiceDetailInJson)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.ParentService, ConditionOperator.Equal, productComponentId);
                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.StatusCode, ConditionOperator.NotEqual, (int)eStatusCode.Inactive);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                if (result != null && result.Entities.Count > 0)
                {
                    var sortedResults = result.Entities.Select(e => new
                    {
                        Entity = e,
                        Version = Version.TryParse(e.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion), out var v) ? v : null
                    }).Where(x => x.Version != null).OrderByDescending(x => x.Version)
                                                                        .Select(x => x.Entity).ToList();

                    if (sortedResults != null && sortedResults.Count > 0)
                    {
                        var entity = sortedResults.FirstOrDefault();

                        serviceSnapshot = new ServiceSnapshot()
                        {
                            ServiceRevisionVersion = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion),
                            LatestServiceStatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                            ModifiedOn = entity.GetAttributeValue<DateTime>(AttributeNames.Servicesnapshot.ModifiedOn),
                            Id = entity.Id,
                            Configuration = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson)
                        };

                        if (entity.Contains(AttributeNames.Servicesnapshot.ModifiedByPortalContact))
                        {
                            EntityReference contact = entity.GetAttributeValue<EntityReference>(AttributeNames.Servicesnapshot.ModifiedByPortalContact);
                            serviceSnapshot.ModifiedByPortalContact = new Contact()
                            {
                                Id = contact.Id,
                                Name = contact.Name,
                            };
                        }
                    }
                }
                return serviceSnapshot;
            }, ("productComponentId", productComponentId));
        }

        public Model.ServiceSnapshot? GetLatestServiceRevisionByProductcomponent(string productComponentId, List<int> CustomerServicesRequest)
        {
            return TraceOperation(nameof(GetLatestServiceRevisionByProductcomponent), () =>
            {
                Model.ServiceSnapshot? serviceSnapshot = null;

                QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.ServiceRevisionVersion, AttributeNames.Servicesnapshot.StatusCode, AttributeNames.Servicesnapshot.ModifiedByPortalContact, AttributeNames.Servicesnapshot.ModifiedOn),
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.ParentService, ConditionOperator.Equal, productComponentId);
                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.StatusCode, ConditionOperator.NotEqual, (int)eStatusCode.Inactive);

                if (CustomerServicesRequest != null)
                {
                    FilterExpression filterLatestServiceStatusCode = new FilterExpression(LogicalOperator.Or);

                    foreach (var StatusCode in CustomerServicesRequest)
                    {
                        filterLatestServiceStatusCode.AddCondition(AttributeNames.Servicesnapshot.StatusCode, ConditionOperator.Equal, StatusCode);
                        query.Criteria.AddFilter(filterLatestServiceStatusCode);
                    }
                }

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var sortedResults = result.Entities.Select(e => new
                    {
                        Entity = e,
                        Version = Version.TryParse(e.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion), out var v) ? v : null
                    }).Where(x => x.Version != null).OrderByDescending(x => x.Version)
                                                                .Select(x => x.Entity).ToList();

                    if (sortedResults != null && sortedResults.Count > 0)
                    {
                        var entity = sortedResults.FirstOrDefault();
                        serviceSnapshot = new ServiceSnapshot()
                        {
                            ServiceRevisionVersion = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion),
                            LatestServiceStatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                            StatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                            ModifiedOn = entity.GetAttributeValue<DateTime>(AttributeNames.Servicesnapshot.ModifiedOn),
                            Id = entity.Id
                        };

                        if (entity.Contains(AttributeNames.Servicesnapshot.ModifiedByPortalContact))
                        {
                            EntityReference contact = entity.GetAttributeValue<EntityReference>(AttributeNames.Servicesnapshot.ModifiedByPortalContact);
                            serviceSnapshot.ModifiedByPortalContact = new Contact()
                            {
                                Id = contact.Id,
                                Name = contact.Name,
                            };
                        }
                    }
                }

                return serviceSnapshot;
            }, ("productComponentId", productComponentId), ("statusFilterCount", CustomerServicesRequest?.Count));
        }

        public int GetStatusCodeByServiceRevisonID(string fiji_servicesnapshotid)
        {
            return TraceOperation(nameof(GetStatusCodeByServiceRevisonID), () =>
            {
                int? ServiceRevisionStatusCode = null;

                QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.StatusCode)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.ServicesnapshotId, ConditionOperator.Equal, fiji_servicesnapshotid);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    ServiceRevisionStatusCode = entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value;
                    return ServiceRevisionStatusCode.Value;
                }

                return ServiceRevisionStatusCode.Value;
            }, ("serviceRevisionId", fiji_servicesnapshotid));
        }

        internal ServiceSnapshot? GetBy(Guid id)
        {
            return ConvertEntityToModel(this.DataverseClient.Retrieve(EntityName.Servicesnapshot, id, new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.ServiceRevisionVersion, AttributeNames.Servicesnapshot.StatusCode, AttributeNames.Servicesnapshot.ModifiedByPortalContact, AttributeNames.Servicesnapshot.ModifiedOn, AttributeNames.Servicesnapshot.ServiceDetailInJson)));
        }

        private Model.ServiceSnapshot ConvertEntityToModel(Entity entity)
        {
            var serviceSnapshot = new ServiceSnapshot()
            {
                ServiceRevisionVersion = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion),
                LatestServiceStatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                StatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                ModifiedOn = entity.GetAttributeValue<DateTime>(AttributeNames.Servicesnapshot.ModifiedOn),
                Id = entity.Id,
                Configuration = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson)
            };

            if (entity.Contains(AttributeNames.Servicesnapshot.ModifiedByPortalContact))
            {
                EntityReference contact = entity.GetAttributeValue<EntityReference>(AttributeNames.Servicesnapshot.ModifiedByPortalContact);
                serviceSnapshot.ModifiedByPortalContact = new Contact()
                {
                    Id = contact.Id,
                    Name = contact.Name,
                };
            }
            return serviceSnapshot;
        }

        public Model.ServiceSnapshot? GetServiceRevisionByBOMId(Guid BOMId)
        {
            return TraceOperation(nameof(GetServiceRevisionByBOMId), () =>
            {
                Model.ServiceSnapshot? serviceSnapshot = null;

                QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.ServiceRevisionVersion, AttributeNames.Servicesnapshot.StatusCode, AttributeNames.Servicesnapshot.ModifiedByPortalContact, AttributeNames.Servicesnapshot.ModifiedOn),
                    PageInfo = new PagingInfo() { Count = 1, PageNumber = 1 }
                };
                query.LinkEntities.Add(new LinkEntity(EntityName.Servicesnapshot, EntityName.BOM, AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.BOM.ServiceRevision, JoinOperator.Inner));
                query.LinkEntities[0].Columns.AddColumn(AttributeNames.BOM.BOMId);
                query.LinkEntities[0].EntityAlias = "BOM";

                //Add condition
                query.LinkEntities[0].LinkCriteria.AddCondition(AttributeNames.BOM.BOMId, ConditionOperator.Equal, BOMId);

                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.StatusCode, ConditionOperator.NotEqual, (int)eStatusCode.Inactive);

                // Add sorting by the "createdon" attribute in descending order
                query.AddOrder(AttributeNames.Servicesnapshot.CreatedOn, OrderType.Descending);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];

                    serviceSnapshot = new ServiceSnapshot()
                    {
                        ServiceRevisionVersion = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion),
                        LatestServiceStatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                        StatusCode = (ServiceSnapshot.eStatusCode)entity.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value,
                        ModifiedOn = entity.GetAttributeValue<DateTime>(AttributeNames.Servicesnapshot.ModifiedOn),
                        Id = entity.Id
                    };

                    if (entity.Contains(AttributeNames.Servicesnapshot.ModifiedByPortalContact))
                    {
                        EntityReference contact = entity.GetAttributeValue<EntityReference>(AttributeNames.Servicesnapshot.ModifiedByPortalContact);
                        serviceSnapshot.ModifiedByPortalContact = new Contact()
                        {
                            Id = contact.Id,
                            Name = contact.Name,
                        };
                    }
                }

                return serviceSnapshot;
            }, ("bomId", BOMId));
        }

        public int? GetAutomationFlagDetailsByServiceRevisionId(string fiji_servicesnapshotid)
        {
            return TraceOperation(nameof(GetAutomationFlagDetailsByServiceRevisionId), () =>
            {
                int? AutomationFlag = null;

                QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                {
                    // Define the columns to retrieve
                    ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId, AttributeNames.Servicesnapshot.ServiceDetailInJson, AttributeNames.Servicesnapshot.IsAutomated)
                };
                //Add condition
                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.ServicesnapshotId, ConditionOperator.Equal, fiji_servicesnapshotid);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    var ConfigurationDetails = entity.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson);

                    QuestionnaireDetails details = JsonConvert.DeserializeObject<QuestionnaireDetails>(ConfigurationDetails);
                    if (details?.ScreenNumber == Constants.PartNumber_AY103AV)
                    {
                        if (details != null && !string.IsNullOrEmpty(details.AutomationFlagName)
                        && details.AutomationFlagName.Trim().Equals(Constants.Automated, StringComparison.OrdinalIgnoreCase))
                        {
                            AutomationFlag = (int)eAutomationFlag.Automated;
                        }

                        if (details != null && !string.IsNullOrEmpty(details.AutomationFlagName)
                                                && details.AutomationFlagName.Trim().Equals(Constants.Manual, StringComparison.OrdinalIgnoreCase))
                        {
                            AutomationFlag = (int)eAutomationFlag.Manual;
                        }
                    }
                    else
                    {
                        AutomationFlag = Utils.GetValue<OptionSetValue>(entity, AttributeNames.Servicesnapshot.IsAutomated)?.Value;
                    }
                }
                return AutomationFlag;
            }, ("serviceRevisionId", fiji_servicesnapshotid));
        }

        public EntityCollection getProductComponentbyComponentType(Guid componentTypeId, int serviceType)
        {
            return TraceOperation(nameof(getProductComponentbyComponentType), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.ProductComponent)
                {
                    ColumnSet = new ColumnSet(true)
                };
                query.Criteria.AddCondition(AttributeNames.ProductComponent.ComponentType, ConditionOperator.Equal, componentTypeId);
                query.Criteria.AddCondition(AttributeNames.ProductComponent.ServiceTypeGlobal, ConditionOperator.Equal, serviceType);
                query.Criteria.AddCondition(AttributeNames.ProductComponent.StateCode, ConditionOperator.Equal, (int)ProductComponent.eStateCode.Active);

                EntityCollection productComponentColl = this.DataverseClient.RetrieveMultiple(query);
                if (productComponentColl != null && productComponentColl.Entities.Count > 0)
                {
                    return productComponentColl;
                }
                else
                {
                    return null;
                }
            }, ("componentTypeId", componentTypeId), ("serviceType", serviceType));
        }
        #endregion Query Expression

        public dynamic CreateNewServiceRevisionForRemoveAssiociatedModel(string productComponentId, string platformId)
        {
            return TraceOperation(nameof(CreateNewServiceRevisionForRemoveAssiociatedModel), () =>
            {
                dynamic response = new ExpandoObject();
                response.OldServiceRevisionId = null;
                response.NewServiceRevisionId = null;

                string newversion = string.Empty;
                ServiceSnapshot? LatestServiceRevision = GetLatestServiceRevisionByProductcomponent(productComponentId, null);

                if (LatestServiceRevision != null)
                {
                    var copyServiceRevision = this.DataverseClient.Retrieve(EntityName.Servicesnapshot, LatestServiceRevision.Id.Value, new ColumnSet(true));
                    response.OldServiceRevisionId = LatestServiceRevision.Id;

                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.EverestId);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.DataSource);
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServicesnapshotId);
                    copyServiceRevision.Id = Guid.NewGuid();
                    response.NewServiceRevisionId = copyServiceRevision.Id;
                    // Get current values
                    string currentVersion = copyServiceRevision.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceRevisionVersion);
                    int currentStatusReason = copyServiceRevision.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value;

                    copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(currentStatusReason);

                    // Status code is Submitted
                    if (currentStatusReason == (int)eStatusCode.InProgress || currentStatusReason == (int)eStatusCode.FilledOut
                            || currentStatusReason == (int)eStatusCode.Submitted)
                    {
                        newversion = MinorVersionIncrement(currentVersion);
                        copyServiceRevision[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = newversion;
                    }

                    // Status code is Completed
                    else if (currentStatusReason == (int)eStatusCode.Completed)
                    {
                        newversion = MajorVersionIncrement(currentVersion);
                        copyServiceRevision[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = newversion;
                    }

                    this.Execute(new CreateRequest { Target = copyServiceRevision });
                    return response;
                }
                return response;
            }, ("productComponentId", productComponentId), ("platformId", platformId));
        }

        public UpdateClearComparisonModelResponse GetAllServiceRevisionToClearCompareJSONByProductcomponent(string productComponentId)
        {
            return TraceOperation(nameof(GetAllServiceRevisionToClearCompareJSONByProductcomponent), () =>
            {
                try
                {
                    QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                    {
                        // Define the columns to retrieve
                        ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServicesnapshotId)
                    };

                    //Add condition
                    query.Criteria.AddCondition(AttributeNames.Servicesnapshot.ParentService, ConditionOperator.Equal, productComponentId);
                    query.Criteria.AddCondition(AttributeNames.Servicesnapshot.StatusCode, ConditionOperator.NotEqual, (int)eStatusCode.Inactive);
                    query.Criteria.AddCondition(AttributeNames.Servicesnapshot.CompareJSON, ConditionOperator.NotNull);

                    EntityCollection result = DataverseClient.RetrieveMultiple(query);

                    if (result != null && result.Entities.Count > 0)
                    {
                        foreach (var entity in result.Entities)
                        {
                            JObject compareJson = new JObject
                            {
                                ["BIOS"] = new JArray()
                            };
                            Entity serviceSnapshot = new Entity(EntityName.Servicesnapshot, entity.Id);
                            serviceSnapshot[AttributeNames.Servicesnapshot.CompareJSON] = compareJson.ToString();
                            this.Execute(new UpdateRequest { Target = serviceSnapshot });
                        }

                        return new UpdateClearComparisonModelResponse
                        {
                            IsSuccess = true,
                            Message = Constants.ResponseMessages.CompareJSOnUpdated
                        };
                    }

                    return new UpdateClearComparisonModelResponse
                    {
                        IsSuccess = false,
                        Message = Constants.ErrorMessages.NoServiceRevisionsFound
                    };
                }

                catch (Exception ex)
                {
                    return new UpdateClearComparisonModelResponse
                    {
                        IsSuccess = false,
                        Message = ex.Message
                    };
                }
            }, ("productComponentId", productComponentId));
        }

        public string CreateServiceRevisionOnDuplicateV1ProductComponent(Guid reqpayloadProductcomponent, string portalUserId, Guid newproductcomponent, string? componentType_ServiceNumber, string? platformId, Guid? componentTypeid, out Guid? ServicesnapshotID, out string serviceDetailInJson)
        {
            var result = TraceOperation(nameof(CreateServiceRevisionOnDuplicateV1ProductComponent), () =>
            {
                string FinalcompareJson = string.Empty;
                string FinalServiceDetailInJson = string.Empty;
                Guid? localServiceSnapshotId = null;
                ServiceSnapshot? LatestServiceRevision = GetLatestServiceRevisionByProductcomponent(reqpayloadProductcomponent.ToString(), null);

                if (LatestServiceRevision != null)
                {
                    Entity copyServiceRevision = new Entity(EntityName.Servicesnapshot);
                    var existingServiceRevision = GetRequiredServiceRevisionFields(LatestServiceRevision.Id.Value);
                    // Copy retrieved attributes
                    foreach (var attribute in existingServiceRevision.Attributes)
                    {
                        copyServiceRevision[attribute.Key] = attribute.Value;
                    }
                    copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServicesnapshotId);
                    copyServiceRevision.Id = Guid.NewGuid();
                    localServiceSnapshotId = copyServiceRevision.Id;
                    copyServiceRevision[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = Constants.Version1;
                    copyServiceRevision[AttributeNames.Servicesnapshot.ParentService] = Utils.GetEntityReference(EntityName.ProductComponent, newproductcomponent.ToString());
                    copyServiceRevision[AttributeNames.Servicesnapshot.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Account, portalUserId);
                    copyServiceRevision[AttributeNames.Servicesnapshot.HideFromPortal] = false;
                    copyServiceRevision[AttributeNames.Servicesnapshot.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, componentTypeid.Value.ToString());
                    if ((int)existingServiceRevision.GetAttributeValue<OptionSetValue>(AttributeNames.Servicesnapshot.StatusCode).Value != (int)eStatusCode.InProgress)
                        copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(((int)eStatusCode.FilledOut));
                    else
                        copyServiceRevision[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue(((int)eStatusCode.InProgress));

                    string joncontent = copyServiceRevision.GetAttributeValue<string>(AttributeNames.Servicesnapshot.ServiceDetailInJson);
                    if (!string.IsNullOrEmpty(joncontent))
                    {
                        JObject jObject = JObject.Parse(joncontent);
                        if (jObject.ContainsKey("Details"))
                        {
                            var details = jObject["Details"];
                            if (details.SelectTokens("getmore") != null)
                                details["getmore"] = false;
                        }
                        else
                        {
                            if (jObject.ContainsKey("getmore"))
                                jObject.Remove("getmore");
                            jObject["getmore"] = false;
                            if (jObject.ContainsKey("getMore"))
                                jObject.Remove("getMore");
                            jObject["getMore"] = false;
                            if (jObject.ContainsKey("ConvertGetMoreService"))
                                jObject.Remove("ConvertGetMoreService");
                            jObject["ConvertGetMoreService"] = false;
                        }
                        if (jObject.ContainsKey("getMoreServiceNumber"))
                            jObject.Remove("getMoreServiceNumber");
                        if (jObject.ContainsKey("questionnaireScreen"))
                            jObject.Remove("questionnaireScreen");

                        FinalServiceDetailInJson = jObject.ToString();

                        if (componentType_ServiceNumber.Equals("AY153AV", StringComparison.OrdinalIgnoreCase))
                        {
                            bool isSupported;
                            if (jObject.ContainsKey("operatingSystem"))
                            {
                                var osName = (string?)jObject["operatingSystem"];
                                isSupported = GetQualifiedPlatformOperatingSystems(platformId, osName, componentTypeid);
                                if (!isSupported)
                                {
                                    // No active qualified OS found
                                    FinalServiceDetailInJson = null;
                                }
                                else
                                {
                                    FinalServiceDetailInJson = jObject.ToString();
                                }
                            }
                        }
                        if (componentType_ServiceNumber.Equals("AY103AV", StringComparison.OrdinalIgnoreCase))
                        {
                            bool isStandardBios = jObject?["IsStandardBIOSSetting"]?.Value<bool>() == true;

                            if (isStandardBios)
                            {
                                var valueListToken = jObject?["ValueList"];

                                if (valueListToken != null && valueListToken.Type == JTokenType.Array)
                                {
                                    var idList = valueListToken
                                        .Select(v => v["Id"]?.ToString())
                                        .Where(id => !string.IsNullOrWhiteSpace(id))
                                        .ToList();

                                    if (idList != null && idList.Any())
                                    {
                                        List<Guid> guidList = idList
                                            .Where(id => Guid.TryParse(id, out _))
                                            .Select(Guid.Parse)
                                            .ToList();

                                        var biosNames = GetBiosConfigurationLineNames(guidList);
                                        if (biosNames != null && biosNames.Any())
                                        {
                                            if (Guid.TryParse(platformId, out Guid platformGuid))
                                            {
                                                var valueList = valueListToken.ToObject<List<ValueItem>>();
                                                var compatibilityResults = GetBiosCompatibilityResults(platformGuid, biosNames, valueList);
                                                var finalValueList = BuildCompatibleValueList(compatibilityResults, valueList);
                                                // If ValueList exists, remove it
                                                if (jObject.ContainsKey("ValueList"))
                                                    jObject.Remove("ValueList");

                                                // Add the new ValueList from finalValueList
                                                jObject["ValueList"] = JArray.FromObject(finalValueList);
                                                FinalServiceDetailInJson = jObject.ToString();

                                                //Compare Json
                                                JObject compareJson = BuildCompareJson(compatibilityResults, valueList);
                                                FinalcompareJson = compareJson.ToString();
                                                copyServiceRevision[AttributeNames.Servicesnapshot.CompareJSON] = compareJson.ToString();
                                            }
                                        }
                                    }

                                }
                            }
                        }
                        copyServiceRevision.Remove(AttributeNames.Servicesnapshot.ServiceDetailInJson);
                        copyServiceRevision[AttributeNames.Servicesnapshot.ServiceDetailInJson] = FinalServiceDetailInJson;
                    }
                    this.Execute(new CreateRequest { Target = copyServiceRevision });
                }

                return (FinalcompareJson, localServiceSnapshotId, FinalServiceDetailInJson);
            }, ("sourceProductComponentId", reqpayloadProductcomponent), ("newProductComponentId", newproductcomponent), ("componentTypeId", componentTypeid), ("platformId", platformId));

            ServicesnapshotID = result.localServiceSnapshotId;
            serviceDetailInJson = result.FinalServiceDetailInJson;
            return result.FinalcompareJson;
        }

        public Entity GetRequiredServiceRevisionFields(Guid serviceRevisionId)
        {
            return TraceOperation(nameof(GetRequiredServiceRevisionFields), () =>
            {
                QueryExpression query = new QueryExpression(EntityName.Servicesnapshot)
                {
                    ColumnSet = new ColumnSet(AttributeNames.Servicesnapshot.ServiceDetailInJson, AttributeNames.Servicesnapshot.IsAutomated,
                                                AttributeNames.Servicesnapshot.FileURL, AttributeNames.Servicesnapshot.FileId,
                                                AttributeNames.Servicesnapshot.StatusCode, AttributeNames.Servicesnapshot.CompareJSON)
                };

                query.Criteria.AddCondition(AttributeNames.Servicesnapshot.ServicesnapshotId, ConditionOperator.Equal, serviceRevisionId);

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var seviceRevision = result.Entities[0];

                    return seviceRevision;
                }

                return null;
            }, ("serviceRevisionId", serviceRevisionId));
        }

        public bool GetQualifiedPlatformOperatingSystems(string? platformId, string? osName, Guid? componentTypeId)
        {
            return TraceOperation(nameof(GetQualifiedPlatformOperatingSystems), () =>
            {
                if (string.IsNullOrEmpty(osName) == null || componentTypeId == null || componentTypeId == Guid.Empty ||
                    string.IsNullOrEmpty(osName))
                {
                    return false;
                }

                QueryExpression query = new QueryExpression(EntityName.PlatformOperatingSystem)
                {
                    Distinct = true,
                    ColumnSet = new ColumnSet(AttributeNames.PlatformOperatingSystem.PlatformOperatingSystemId, AttributeNames.PlatformOperatingSystem.Name, AttributeNames.PlatformOperatingSystem.CreatedOn)
                };

                // Main entity filters
                query.Criteria.AddCondition(AttributeNames.PlatformOperatingSystem.IsQualified, ConditionOperator.Equal, true); // if Two Options
                query.Criteria.AddCondition(AttributeNames.PlatformOperatingSystem.StateCode, ConditionOperator.Equal, 0);
                query.Criteria.AddCondition(AttributeNames.PlatformOperatingSystem.PlatformId, ConditionOperator.Equal, platformId);

                // Order By
                query.AddOrder(AttributeNames.PlatformOperatingSystem.Name, OrderType.Ascending);

                // Link: fiji_operatingsystem
                LinkEntity linkOS = query.AddLink(EntityName.OperatingSystem, AttributeNames.PlatformOperatingSystem.OperatingSystem, AttributeNames.OperatingSystem.OperatingSystemId, JoinOperator.Inner);

                linkOS.EntityAlias = "ai";
                linkOS.LinkCriteria.AddCondition(AttributeNames.OperatingSystem.StateCode, ConditionOperator.Equal, 0);
                linkOS.LinkCriteria.AddCondition(AttributeNames.OperatingSystem.DisplayName, ConditionOperator.Equal, osName);

                // Link: fiji_componenttypeoperatingsystem
                LinkEntity linkCTOS = linkOS.AddLink(EntityName.ComponentTypeOperatingSystem, AttributeNames.OperatingSystem.OperatingSystemId, AttributeNames.ComponentTypeOperatingSystem.OperatingSystem, JoinOperator.Inner);

                linkCTOS.EntityAlias = "aj";
                linkCTOS.LinkCriteria.AddCondition(AttributeNames.ComponentTypeOperatingSystem.StateCode, ConditionOperator.Equal, 0);
                linkCTOS.LinkCriteria.AddCondition(AttributeNames.ComponentTypeOperatingSystem.ComponentType, ConditionOperator.Equal, componentTypeId);

                // Execute
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                return result.Entities.Count > 0;
            }, ("platformId", platformId), ("osName", osName), ("componentTypeId", componentTypeId));
        }

        public List<BiosConfigurationLineInfo> GetBiosConfigurationLineNames(List<Guid> biosConfigLineIds)
        {
            return TraceOperation(nameof(GetBiosConfigurationLineNames), () =>
            {
                try
                {
                    if (biosConfigLineIds == null || biosConfigLineIds.Count == 0)
                        return new List<BiosConfigurationLineInfo>();

                    var distinctIds = biosConfigLineIds.Distinct().ToList();

                    QueryExpression query = new QueryExpression(EntityName.BIOSConfigurationLine)
                    {
                        ColumnSet = new ColumnSet(
                            AttributeNames.BIOSConfigurationLine.BIOSConfigurationLineId,
                            AttributeNames.BIOSConfigurationLine.Name,
                            AttributeNames.BIOSConfigurationLine.DataType,
                            AttributeNames.BIOSConfigurationLine.Value
                        ),
                        NoLock = true
                    };

                    query.Criteria.AddCondition(AttributeNames.BIOSConfigurationLine.BIOSConfigurationLineId, ConditionOperator.In, distinctIds.Cast<object>().ToArray());

                    EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                    if (result?.Entities == null || result.Entities.Count == 0)
                        return new List<BiosConfigurationLineInfo>();

                    return result.Entities
                                .Where(e => e.Id != Guid.Empty)
                                .Select(e => new BiosConfigurationLineInfo
                                {
                                    Id = e.Id,
                                    Name = e.GetAttributeValue<string>(
                                        AttributeNames.BIOSConfigurationLine.Name),

                                    DataType = e.GetAttributeValue<OptionSetValue>(
                                        AttributeNames.BIOSConfigurationLine.DataType)?.Value,

                                    Value = e.GetAttributeValue<string>(
                                        AttributeNames.BIOSConfigurationLine.Value)
                                })
                                .ToList();
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException($"Error in Processing GetBiosConfigurationLineNames Details: {ex.Message}", ex);
                }
            }, ("biosConfigLineCount", biosConfigLineIds?.Count));
        }

        public List<BiosCompatibilityResult> GetBiosCompatibilityResults(Guid platformId, List<BiosConfigurationLineInfo> bioNames, List<ValueItem> valueList)
        {
            return TraceOperation(nameof(GetBiosCompatibilityResults), () =>
            {
                if (platformId == Guid.Empty || bioNames == null || bioNames.Count == 0)
                {
                    return new List<BiosCompatibilityResult>();
                }

                var selectedNames = bioNames.Where(x => !string.IsNullOrWhiteSpace(x.Name)).Select(x => x.Name).ToList();

                // Query BIOSConfigurationLine + Platform match
                QueryExpression query = new QueryExpression(EntityName.BIOSConfigurationLine)
                {
                    ColumnSet = new ColumnSet(AttributeNames.BIOSConfigurationLine.BIOSConfigurationLineId, AttributeNames.BIOSConfigurationLine.Name, AttributeNames.BIOSConfigurationLine.ConfigurationId,
                                              AttributeNames.BIOSConfigurationLine.DataType, AttributeNames.BIOSConfigurationLine.Value, AttributeNames.BIOSConfigurationLine.StatusCode,
                                              AttributeNames.BIOSConfigurationLine.IsReadOnly),
                    NoLock = true
                };

                query.Criteria.AddCondition(AttributeNames.BIOSConfigurationLine.Name, ConditionOperator.In, selectedNames.Cast<object>().ToArray());
                query.Criteria.AddCondition(AttributeNames.BIOSConfigurationLine.StatusCode, ConditionOperator.Equal, 1);   // Active
                query.Criteria.AddCondition(AttributeNames.BIOSConfigurationLine.IsReadOnly, ConditionOperator.Equal, false);   // No

                LinkEntity biosConfigLink = query.AddLink(EntityName.BIOSConfiguration, AttributeNames.BIOSConfigurationLine.ConfigurationId, AttributeNames.BIOSConfiguration.BIOSConfigurationId, JoinOperator.Inner);
                biosConfigLink.LinkCriteria.AddCondition(AttributeNames.BIOSConfiguration.PlatformId, ConditionOperator.Equal, platformId);
                biosConfigLink.LinkCriteria.AddCondition(AttributeNames.BIOSConfiguration.StatusCode, ConditionOperator.Equal, (int)eStatusReason.Published); // Published

                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);

                // Build lookup from query (Name -> Entity)
                var queryLookup = result.Entities
                                             .Where(e => !string.IsNullOrWhiteSpace(
                                                 e.GetAttributeValue<string>(AttributeNames.BIOSConfigurationLine.Name)))
                                             .Select(e => new BiosConfigurationLineInfo
                                             {
                                                 Id = e.Id,
                                                 Name = e.GetAttributeValue<string>(
                                                     AttributeNames.BIOSConfigurationLine.Name),

                                                 DataType = e.GetAttributeValue<OptionSetValue>(
                                                     AttributeNames.BIOSConfigurationLine.DataType)?.Value,

                                                 Value = e.GetAttributeValue<string>(
                                                     AttributeNames.BIOSConfigurationLine.Value)
                                             })
                                             .GroupBy(x => x.Name)
                                             .ToDictionary(
                                                 g => g.Key,
                                                 g => g.ToList(),
                                                 StringComparer.OrdinalIgnoreCase);

                var finalResults = bioNames.Select(input =>
                {
                    bool existsInQuery = queryLookup.TryGetValue(input.Name, out var matchedEntities);

                    bool isCompatible = false;
                    Guid matchedId = Guid.Empty;

                    if (existsInQuery && matchedEntities != null)
                    {
                        foreach (var entity in matchedEntities)
                        {
                            if (input.DataType == (int)eDataType.DragDropComponent)
                            {
                                if (string.Equals(input.Value, entity.Value, StringComparison.OrdinalIgnoreCase))
                                {
                                    isCompatible = true;
                                    matchedId = entity.Id;
                                    break;
                                }
                            }
                            else if (input.DataType == (int)eDataType.DropdownList)
                            {
                                var selectedValue = valueList.FirstOrDefault(v => v.Id == input.Id)?.Value;

                                if (!string.IsNullOrEmpty(selectedValue) && !string.IsNullOrEmpty(entity.Value))
                                {
                                    if (entity.Value
                                            .Split(',', StringSplitOptions.RemoveEmptyEntries)
                                            .Select(v => v.Replace("*", "").Trim())
                                            .Any(v => v.Equals(selectedValue.Trim(), StringComparison.OrdinalIgnoreCase)))
                                    {
                                        isCompatible = true;
                                        matchedId = entity.Id;
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                isCompatible = true;
                                matchedId = entity.Id;
                                break;
                            }
                        }
                    }

                    return new BiosCompatibilityResult
                    {
                        Id = input.Id,
                        BiosConfigurationLineId = matchedId,
                        Name = input.Name,
                        IsCompatible = isCompatible
                    };
                }).ToList();

                return finalResults;
            }, ("platformId", platformId), ("biosNameCount", bioNames?.Count), ("valueCount", valueList?.Count));
        }

        public List<ValueItem> BuildCompatibleValueList(List<BiosCompatibilityResult> compatibilityResults, List<ValueItem> valueList)
        {
            return TraceOperation(nameof(BuildCompatibleValueList), () =>
            {
                if (compatibilityResults == null || valueList == null ||
                    !compatibilityResults.Any() || !valueList.Any())
                {
                    return new List<ValueItem>();
                }

                var valueLookup = valueList.GroupBy(v => v.Id).ToDictionary(g => g.Key, g => g.ToList());

                // Build final list
                var finalList = compatibilityResults.Where(r => r.IsCompatible && r.BiosConfigurationLineId != Guid.Empty)
                                                    .Where(r => valueLookup.ContainsKey(r.Id))
                                                    .SelectMany(r =>
                                                        valueLookup[r.Id].Select(v => new ValueItem
                                                        {
                                                            Id = r.BiosConfigurationLineId,
                                                            Value = v.Value
                                                        }))
                                                    .ToList();

                return finalList;
            }, ("compatibilityCount", compatibilityResults?.Count), ("valueCount", valueList?.Count));
        }

        public JObject BuildCompareJson(List<BiosCompatibilityResult> compatibilityResults, List<ValueItem> valueList)
        {
            return TraceOperation(nameof(BuildCompareJson), () =>
            {
                if (compatibilityResults == null || valueList == null)
                    return new JObject { ["BIOS"] = new JArray() };

                var valueLookup = valueList.GroupBy(v => v.Id).ToDictionary(
                                                                g => g.Key,
                                                                g => g.Select(x => x.Value).ToList());

                var biosArray = compatibilityResults.Select(r =>
                {
                    string value = string.Empty;

                    if (valueLookup.TryGetValue(r.Id, out var values))
                    {
                        value = string.Join(", ", values.Distinct());
                    }

                    return new JObject
                    {
                        ["Name"] = r.Name,
                        ["Value"] = value,
                        ["isCompatible"] = r.IsCompatible
                    };
                }).ToArray();

                return new JObject
                {
                    ["BIOS"] = new JArray(biosArray)
                };
            }, ("compatibilityCount", compatibilityResults?.Count), ("valueCount", valueList?.Count));
        }

        public void CreateServiceRevisionForNewService(Guid productComponentId, string componentTypeId, string? portalUserId, out Guid? ServiceSnapShotId, out string ServiceRevisionVersion)
        {
            var result = TraceOperation(nameof(CreateServiceRevisionForNewService), () =>
            {
                Entity fiji_servicesnapshot = new Entity(EntityName.Servicesnapshot);
                fiji_servicesnapshot.Id = Guid.NewGuid();
                string version = Constants.Version1;
                fiji_servicesnapshot[AttributeNames.Servicesnapshot.ServiceRevisionVersion] = version;
                fiji_servicesnapshot[AttributeNames.Servicesnapshot.ParentService] = Utils.GetEntityReference(EntityName.ProductComponent, productComponentId.ToString());
                fiji_servicesnapshot[AttributeNames.Servicesnapshot.ComponentType] = Utils.GetEntityReference(EntityName.ComponentType, componentTypeId);
                fiji_servicesnapshot[AttributeNames.Servicesnapshot.StatusCode] = new OptionSetValue((int)eStatusCode.InProgress);
                fiji_servicesnapshot[AttributeNames.Servicesnapshot.ServiceDetailInJson] = string.Empty;   // blank questionnaire 
                if (!string.IsNullOrEmpty(portalUserId))
                {
                    fiji_servicesnapshot[AttributeNames.Servicesnapshot.ModifiedByPortalContact] = Utils.GetEntityReference(EntityName.Contact, portalUserId);
                }
                this.Execute(new CreateRequest { Target = fiji_servicesnapshot });
                return (fiji_servicesnapshot.Id, version);
            }, ("productComponentId", productComponentId), ("componentTypeId", componentTypeId));
            ServiceSnapShotId = result.Item1;
            ServiceRevisionVersion = result.Item2;
        }
    }
}