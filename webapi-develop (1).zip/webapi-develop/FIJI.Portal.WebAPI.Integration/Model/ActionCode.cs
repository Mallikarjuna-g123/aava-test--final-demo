﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ActionCode : Base<ActionCode>
    {
       
        public ActionCode(IOrganizationService dataverseClient, ILogger<ActionCode>? logger = null) : base(dataverseClient, "actioncode", logger)
        { }
        
        /// <summary>
        /// Get Action Code
        /// </summary>
        /// <param name="ownerId"></param>
        /// <returns></returns>
        public Guid GetActionCodeBy(string actionName)
        {
            return TraceOperation(nameof(GetActionCodeBy), () =>
            {
                // Create a QueryExpression for the "fiji_objectactioncode" entity
                QueryExpression query = new QueryExpression(EntityName.OAC);
                query.ColumnSet = new ColumnSet(ObjectActionCode.ObjectActionCodeId);

                // Add filtering condition for systemuser ID
                query.Criteria.AddCondition(ObjectActionCode.ActionName, ConditionOperator.Equal, actionName);

                // Execute the query and process the result
                EntityCollection result = this.DataverseClient.RetrieveMultiple(query);
                if (result != null && result.Entities.Count > 0)
                {
                    var entity = result.Entities[0];
                    if (entity.Contains(ObjectActionCode.ObjectActionCodeId))
                        return entity.Id;
                }
                return Guid.Empty;
            }, ("actionName", actionName));

        }
    }
}
