﻿using System.Text;
using Azure.Storage.Blobs;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using static FIJI.Portal.FileReception.Model.BlobFile;
using static FIJI.Portal.FileReception.Model.Enums;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class FileModel
    {
        private readonly ILogger<FileModel> _logger;

        private readonly Account _accountService;

        private readonly StorageAccountHelper _storageHelper;

        private readonly bool _enableVirusCheck;

        public FileModel(IOrganizationService service, StorageAccountHelper storageHelper, bool enableVirusCheck, ILogger<FileModel>? logger = null)
        {
            String? StorageAccount = Environment.GetEnvironmentVariable(Constants.StorageAccount);
            String? StorageAccountKey = Environment.GetEnvironmentVariable(Constants.StorageAccountKey);
            _accountService = new Account(service);
            _enableVirusCheck = enableVirusCheck;
            _storageHelper = storageHelper;
            _logger = logger ?? NullLogger<FileModel>.Instance;
        }

        private T TraceOperation<T>(string operationName, Func<T> action, params (string Key, object? Value)[] context)
        {
            return OperationTraceHelper.TraceOperation(_logger, nameof(FileModel), "filemodel", operationName, action, context);
        }

        private (FileUploadResponse Response, BlobClient BlobClient) InitializeUpload(IFormFile formFile, string fileName, string accountId, string Folder, eFileType fileType)
        {
            return TraceOperation(nameof(InitializeUpload), () =>
            {
                FileUploadResponse fileUploadResponse = new FileUploadResponse();
                BlobContainerClient blobContainerClient = _storageHelper.InitializeAccountContainer(accountId);
            BlobClient blobClient = _storageHelper.GenerateFileName(accountId, fileName, fileType, out _, blobContainerClient);

                using (var fileStream = formFile.OpenReadStream())
                {
                    var d = blobClient.UploadAsync(fileStream);
                    Azure.Response res = d.Result.GetRawResponse();
                    fileUploadResponse.Message = FileReception.Commons.Constants.Generic.FileNotUploaded;

                    if (!res.IsError)
                    {
                        if (res.Status == 201)
                        {
                            string base64Name = Convert.ToBase64String(Encoding.UTF8.GetBytes(blobClient.Name));
                            fileUploadResponse.relativeUrl = $"{blobClient.BlobContainerName}/{base64Name.Replace("/", "_").Replace("+", "-")}";
                            fileUploadResponse.fileName = Path.GetFileName(blobClient.Name);
                            fileUploadResponse.Message = FileReception.Commons.Constants.Generic.FileUploadSuccessfully;
                        }
                    }
                }

                return (fileUploadResponse, blobClient);
            }, ("accountId", accountId), ("fileName", fileName), ("fileType", fileType.ToString()));
        }

        public FileUploadResponse UploadAndVirusCheck(IFormFile formFile, string FileName, string AccountId, string Folder, eFileType fileType)
        {
            return TraceOperation(nameof(UploadAndVirusCheck), () =>
            {
                FileName = FileReception.Commons.Helpers.Utility.SanitizeFilename(FileName);
            
                if (fileType == null)
                {
                    fileType = FileReception.Model.BlobFile.eFileType.Default;
                }

                var uploadResult = InitializeUpload(formFile, FileName, AccountId, Folder, fileType);
                FileUploadResponse response = uploadResult.Response;
                BlobClient blobClient = uploadResult.BlobClient;

                if (!string.IsNullOrEmpty(response.relativeUrl) && _enableVirusCheck)
                {
                    DateTime stopTime = DateTime.Now.AddSeconds(30);

                    while (DateTime.Now < stopTime)
                    {
                        string scanResult = string.Empty;

                        if (blobClient.GetProperties().Value.Metadata.TryGetValue(eMetadataProps.MalwareScanningscanresult.ToString(), out scanResult))
                        {
                            if (scanResult == FileReception.Commons.Constants.Generic.ThreatFound)
                            {
                                try
                                {
                                    blobClient.Delete(Azure.Storage.Blobs.Models.DeleteSnapshotsOption.IncludeSnapshots);
                                }
                                catch { }
                                throw new Exception($"MaliciousFile||{FileName}");
                            }
                            break;
                        }
                        Thread.Sleep(300);
                    }
                }
                return response;
            }, ("accountId", AccountId), ("fileName", FileName), ("virusCheckEnabled", _enableVirusCheck));
        }

        public byte[]? FileDataDownload(string accountId, string fileName)
        {
            return TraceOperation(nameof(FileDataDownload), () =>
            {
                BlobContainerClient blobContainerClient = _storageHelper.InitializeAccountContainer(accountId);
                BlobClient blobClient = blobContainerClient.GetBlobClient(fileName);

                if (!blobClient.Exists())
                {
                    return (byte[]?)null;
                }

                using (var ms = new MemoryStream())
                {
                    blobClient.DownloadTo(ms);
                    return ms.ToArray();
                }
            }, ("accountId", accountId), ("fileName", fileName));
        }

        internal string GetDecodedUrl(string encodedFileUrl)
        {
            return TraceOperation(nameof(GetDecodedUrl), () =>
            {
                string returnString = System.Text.UTF8Encoding.UTF8.GetString(Convert.FromBase64String(encodedFileUrl.Replace("_", "/").Replace("-", "+")));
                return returnString = returnString.Replace("?", "é").Replace("\0", "");
            }, ("encodedLength", encodedFileUrl?.Length));
        }

        //internal async Task<string> CreateFileContainer(EntityCollection entityCollection)
        //{
        //    try
        //    {
        //        bool isAccOnboarded = false;
        //        StringBuilder accountContainer = new StringBuilder();
        //        if (entityCollection != null && entityCollection.Entities.Count > 0)
        //        {
        //            foreach (Entity entity in entityCollection.Entities)
        //            {
        //                isAccOnboarded = await _storageHelper.InitializeAccountContainer(entity.Id.ToString(), isAccOnboarded);
        //                if (isAccOnboarded)
        //                    accountContainer.Append(entity.GetAttributeValue<string>(AttributeNames.Account.AccountId).ToString()).Append("\n ");
        //            }
        //        }

        //        return accountContainer.ToString();
        //    }
        //    catch (Exception ex) {
        //        throw ex;
        //    }
        //}

        
    }
}