using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using Constants = FIJI.Portal.FileReception.Commons.Constants;

namespace FIJI.Portal.WebAPI.Integration.Model.Dev
{
    public class DevBaseInfra : Base<DevBaseInfra>
    {
        private readonly string token;
        
        private readonly string _crmUrl;

        public DevBaseInfra(IOrganizationService dataverseClient, string token, ILogger<DevBaseInfra>? logger = null) : base(dataverseClient, "devbaseinfra")
        {
            this.token = token;
            _crmUrl = Environment.GetEnvironmentVariable(Utilities.Constants.CRMUrl) ?? "https://fiji-phase2-dev.crm.dynamics.com/";
        }

        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<string> retrieveMultipleRecords(string entityName, string query, int? maxPageSize)
        {
            return await TraceOperationAsync(nameof(retrieveMultipleRecords), async () =>
            {
                string resultMessage = string.Empty;
                try
                {
                entityName = Utils.PluralEntityName(entityName);
                string prefer = Constants.Generic.ODataIncludeAnnotations;
                string sqlQuery = _crmUrl + "/api/data/v9.1/" + entityName + query;
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Utilities.Constants.UserAgentHeaderValue);
                    client.BaseAddress = new Uri(_crmUrl);
                    client.Timeout = new TimeSpan(0, 2, 0);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataMaxVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataVersion, Constants.Generic.Version4); client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(Constants.Generic.JsonApplication));


                        if (maxPageSize.GetValueOrDefault(0) != 0)
                            prefer += $",odata.maxpagesize={maxPageSize}";

                        client.DefaultRequestHeaders.Add(Constants.Generic.Prefer, prefer);

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, sqlQuery); //Set the access token
                        request.Headers.Authorization = new AuthenticationHeaderValue(Constants.Api.Bearer, token);
                        HttpResponseMessage response = client.SendAsync(request).Result;
                        resultMessage = await response.Content.ReadAsStringAsync();
                        if (response.IsSuccessStatusCode)
                        {
                            //Get the response content and parse it.
                            dynamic json = JToken.Parse(response.Content.ReadAsStringAsync().Result);
                            return json.ToString();
                        }
                    }
                    return string.Empty;
                }
                catch (Exception ex)
                {
                    if (string.IsNullOrWhiteSpace(resultMessage))
                        resultMessage = ex.Message;
                    throw new Exception(resultMessage);
                }
            }, ("entityName", entityName), ("hasQuery", !string.IsNullOrWhiteSpace(query)), ("maxPageSize", maxPageSize));
        }

        /// <summary>
        /// To be used only in dev environment for mock porpouse
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="id"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<string> retrieveRecord(string entityName, string id, string query, Uri? recordUrl = null)
        {
            return await TraceOperationAsync(nameof(retrieveRecord), async () =>
            {
                string resultMessage = string.Empty;
                try
                {
                    entityName = Utils.PluralEntityName(entityName);
                    string sqlQuery = _crmUrl + "/api/data/v9.1/" + entityName + "(" + id + ")" + query;

                    if (recordUrl != null)
                        sqlQuery = recordUrl.ToString();

                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Utilities.Constants.UserAgentHeaderValue);
                    client.BaseAddress = new Uri(_crmUrl);
                    client.Timeout = new TimeSpan(0, 2, 0);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataMaxVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataVersion, Constants.Generic.Version4); client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(Constants.Generic.JsonApplication));
                    client.DefaultRequestHeaders.Add(Constants.Generic.Prefer, Constants.Generic.ODataIncludeAnnotations);
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, sqlQuery); //Set the access token
                    request.Headers.Authorization = new AuthenticationHeaderValue(Constants.Api.Bearer, token);
                    HttpResponseMessage response = client.SendAsync(request).Result;
                    resultMessage = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode)
                    {
                            //Get the response content and parse it.
                            dynamic json = JToken.Parse(response.Content.ReadAsStringAsync().Result);
                            return json.ToString();
                        }
                    }
                    return string.Empty;
                }
                catch (Exception ex)
                {
                    if (string.IsNullOrWhiteSpace(resultMessage))
                        resultMessage = ex.Message;
                    throw new Exception(resultMessage);
                }
            }, ("entityName", entityName), ("recordId", id), ("hasRecordUrl", recordUrl != null));
        }

        public async Task<string> createRecord(string entityName, string responseBody)
        {
            return await TraceOperationAsync(nameof(createRecord), async () =>
            {
                string resultMessage = string.Empty;
                try
                {
                    string apiUrl = _crmUrl + "/api/data/v9.1/";
                    entityName = Utils.PluralEntityName(entityName);
                    HttpClient client = new HttpClient();
                    client.Timeout = TimeSpan.FromSeconds(360);
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(Constants.Api.Bearer, token);
                    client.BaseAddress = new Uri(apiUrl);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(Constants.Generic.JsonApplication));
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataMaxVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Utilities.Constants.UserAgentHeaderValue);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.CacheControl, Constants.Generic.NoCache);
                    client.DefaultRequestHeaders.Add(Constants.Generic.Prefer, Constants.Generic.ODataIncludeAnnotations);

                    HttpRequestMessage createHttpRequest = new HttpRequestMessage(HttpMethod.Post, apiUrl + entityName);
                    createHttpRequest.Content = new StringContent(responseBody, Encoding.UTF8, Constants.Generic.JsonApplication);
                    var response = await client.SendAsync(createHttpRequest);
                    resultMessage = await response.Content.ReadAsStringAsync();
                    var result = response.EnsureSuccessStatusCode();
                    var recordUrl = response.Headers.GetValues(Constants.Generic.ODataEntityId).FirstOrDefault();
                    if (recordUrl != null)
                        return Utils.GetIdFromUrl(recordUrl);
                }
                catch (Exception ex)
                {
                    if (string.IsNullOrWhiteSpace(resultMessage))
                        resultMessage = ex.Message;
                    throw new Exception(resultMessage);
                }
                return string.Empty;
            }, ("entityName", entityName), ("hasBody", !string.IsNullOrWhiteSpace(responseBody)));
        }

        public async Task<string> updateRecord(string entityName, string id, string responseBody)
        {
            return await TraceOperationAsync(nameof(updateRecord), async () =>
            {
                string resultMessage = string.Empty;
                try
                {
                    JObject json;
                    try
                    {
                        json = JObject.Parse(responseBody);
                    }
                    catch (JsonReaderException jex)
                    {
                        throw new Exception("Invalid JSON in request body: " + jex.Message);
                    }

                    if (json["fiji_portaldescription"] != null)
                    {
                        string desc = json["fiji_portaldescription"].ToString();
                        string forbiddenCharsPattern = @"[<>\[\]{}|\\^~]";
                        string sanitized = Regex.Replace(desc, forbiddenCharsPattern, "");

                        json["fiji_portaldescription"] = sanitized;
                    }

                    responseBody = json.ToString();

                    string apiUrl = _crmUrl + "/api/data/v9.1/";

                    entityName = Utils.PluralEntityName(entityName);
                    HttpClient client = new HttpClient();
                    client.Timeout = TimeSpan.FromSeconds(360);
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(Constants.Api.Bearer, token);
                    client.BaseAddress = new Uri(apiUrl);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(Constants.Generic.JsonApplication));
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataMaxVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Utilities.Constants.UserAgentHeaderValue);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.CacheControl, Constants.Generic.NoCache);
                    client.DefaultRequestHeaders.Add(Constants.Generic.Prefer, Constants.Generic.ODataIncludeAnnotations);

                    HttpRequestMessage createHttpRequest = new HttpRequestMessage(HttpMethod.Patch, apiUrl + entityName + "(" + id + ")");
                    createHttpRequest.Content = new StringContent(responseBody, Encoding.UTF8, Constants.Generic.JsonApplication);
                    var response = await client.SendAsync(createHttpRequest);
                    resultMessage = await response.Content.ReadAsStringAsync();
                    var result = response.EnsureSuccessStatusCode();
                    var recordUrl = response.Headers.GetValues(Constants.Generic.ODataEntityId).FirstOrDefault();
                    if (recordUrl != null)
                        return Utils.GetIdFromUrl(recordUrl);
                }
                catch (Exception ex)
                {
                    if (string.IsNullOrWhiteSpace(resultMessage))
                        resultMessage = ex.Message;
                    throw new Exception(resultMessage);
                }
                return string.Empty;
            }, ("entityName", entityName), ("recordId", id), ("hasBody", !string.IsNullOrWhiteSpace(responseBody)));
        }

        public async Task<string> deleteRecord(string entityName, string id)
        {
            return await TraceOperationAsync(nameof(deleteRecord), async () =>
            {
                string resultMessage = string.Empty;
                try
                {
                    string apiUrl = _crmUrl + "/api/data/v9.1/";
                    entityName = Utils.PluralEntityName(entityName);
                    HttpClient client = new HttpClient();
                    client.Timeout = TimeSpan.FromSeconds(360);
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(Constants.Api.Bearer, token);
                    client.BaseAddress = new Uri(apiUrl);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(Constants.Generic.JsonApplication));
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataMaxVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.ODataVersion, Constants.Generic.Version4);
                    client.DefaultRequestHeaders.Add(Constants.Generic.CacheControl, Constants.Generic.NoCache);
                    client.DefaultRequestHeaders.Add(Constants.Generic.Prefer, Constants.Generic.ODataIncludeAnnotations);
                    client.DefaultRequestHeaders.UserAgent.ParseAdd(Utilities.Constants.UserAgentHeaderValue);

                    HttpRequestMessage createHttpRequest = new HttpRequestMessage(HttpMethod.Delete, apiUrl + entityName + "(" + id + ")");
                    var response = await client.SendAsync(createHttpRequest);
                    resultMessage = await response.Content.ReadAsStringAsync();
                    var result = response.EnsureSuccessStatusCode();
                    return result.StatusCode.ToString();
                }
                catch (Exception ex)
                {
                    if (string.IsNullOrWhiteSpace(resultMessage))
                        resultMessage = ex.Message;
                    throw new Exception(resultMessage);
                }
            }, ("entityName", entityName), ("recordId", id));
        }
    }
}
