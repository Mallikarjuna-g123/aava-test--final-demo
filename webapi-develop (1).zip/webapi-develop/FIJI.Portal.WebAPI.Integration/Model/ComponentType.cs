﻿using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Observability;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Text.Json.Serialization;
using static FIJI.Portal.WebAPI.Integration.Utilities.AttributeNames;

namespace FIJI.Portal.WebAPI.Integration.Model
{
    public class ComponentType : Base<ComponentType>
    {

        public ComponentType() : base("componenttype") { }

        public ComponentType(IOrganizationService dataverseClient, ILogger<ComponentType>? logger = null) : base(dataverseClient, "componenttype", logger) { }
        
        [JsonPropertyName("id")]
        public Guid? Id { get; set; }

        [JsonPropertyName("canBeAddedMultipleTimesDifConfg")]
        public bool? CanBeAddedMultipleTimesDifConfig { get; set; }

        [JsonPropertyName("portalDescription")]
        public string? PortalDescription { get; set; }

        [JsonPropertyName("serviceCategory")]
        public string? ServiceCategory { get; set; }

        [JsonPropertyName("isConfigurable")]
        public bool? IsConfigurable { get; set; }

        [JsonPropertyName("serviceNumber")]
        public string? ServiceNumber { get; set; }

        [JsonPropertyName("incompatibleServices")]
        public List<string>? IncompatibleService { get; set; }

        [JsonPropertyName("getMoreService")]
        public ComponentType? GetMoreService { get; set; }

        [JsonPropertyName("dependentServices")]
        public DependencyGroup? DependentService { get; set; }
        [JsonPropertyName("statusCode")]
        public int? StatusCode { get; set; }
        [JsonPropertyName("enableReuse")]
        public bool? EnableReuse { get; set; }

        [JsonPropertyName("requiredAdditionalInfoMultiModel")]
        public bool? RequiredAdditionalInfoMultiModel { get; set; }

        [JsonPropertyName("canBeUsedAcrossCustomer")]
        public bool? CanBeUsedAcrossCustomer { get; set; }

        public bool? IsMultiModel { get; set; }
        public enum eStateCode
        {
            Active = 0,
            Inactive = 1
        }

        public enum eStatusCode
        {
            Delete = 622490003,
            InUse = 1,
            Legacy = 622490001,
            Obsolete = 2
        }

        internal ComponentType? GetBy(Guid id)
        {
            return TraceOperation(nameof(GetBy), () =>
            {
                return ConvertEntityToModel(this.DataverseClient.Retrieve(EntityName.ComponentType, id, new ColumnSet(AttributeNames.ComponentType.MultipleDifferentConfig, AttributeNames.ComponentType.PortalDescription, AttributeNames.ComponentType.ServiceCategory, AttributeNames.ComponentType.IsConfigurable,
                    AttributeNames.ComponentType.ServiceNumber, AttributeNames.ComponentType.StatusCode, AttributeNames.ComponentType.EnableReuse, AttributeNames.ComponentType.AdditionalInfoMultiModel)));
            }, ("componentTypeId", id));
        }

        private Model.ComponentType ConvertEntityToModel(Entity entity)
        {
            var ct = new ComponentType()
            {
                Id = entity.Id,
                CanBeAddedMultipleTimesDifConfig = Convert.ToBoolean(entity.GetValue<string>(AttributeNames.ComponentType.MultipleDifferentConfig)),
                PortalDescription = entity.GetValue<string>(AttributeNames.ComponentType.PortalDescription),
                ServiceCategory = entity.GetValue<OptionSetValue>(AttributeNames.ComponentType.ServiceCategory)?.Value.ToString(),
                IsConfigurable = Convert.ToBoolean(entity.GetValue<string>(AttributeNames.ComponentType.IsConfigurable)),
                ServiceNumber = entity.GetValue<string>(AttributeNames.ComponentType.ServiceNumber).ToString(),
                IncompatibleService = null,
                DependentService = null,
                StatusCode = Convert.ToInt32(entity.GetValue<string>(AttributeNames.ComponentType.StatusCode)),
                EnableReuse = Convert.ToBoolean(entity.GetValue<string>(AttributeNames.ComponentType.EnableReuse)),
                RequiredAdditionalInfoMultiModel = Convert.ToBoolean(entity.GetValue<string>(AttributeNames.ComponentType.AdditionalInfoMultiModel).ToString())

            };
            return ct;
        }

        public string? GetServiceNumberFromComponentId(Guid componentId)
        {
            return TraceOperation(nameof(GetServiceNumberFromComponentId), () =>
            {
                var entity = this.DataverseClient.Retrieve(
                    EntityName.ComponentType,
                    componentId,
                    new ColumnSet(AttributeNames.ComponentType.ServiceNumber)
                );

                return entity?.GetAttributeValue<string>(AttributeNames.ComponentType.ServiceNumber);
            }, ("componentId", componentId));
        }
    }
}

