﻿using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Requests;
using FIJI.Portal.WebAPI.Integration.Responses;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using ADRConstants = FIJI.Portal.FileReception.Commons.Constants;

namespace FIJI.Portal.WebAPI.Integration.Integration
{
    public class ADRConsent : Base<ADRConsent>
    {
        private readonly FijiConfiguration _fijiConfig;
        private readonly IMemoryCache _memoryCache;
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public ADRConsent() : base("adrconsent", NullLogger<ADRConsent>.Instance) { }

        public ADRConsent(IOrganizationService dataverseClient, IMemoryCache cache, HttpClient httpClient, IConfiguration configuration, ILogger<ADRConsent>? logger = null) : base(dataverseClient, "adrconsent", logger)
        {
            _fijiConfig = new FijiConfiguration(dataverseClient);
            _memoryCache = cache;
            _httpClient = httpClient;
            _configuration = configuration;
        }
        public async Task<CheckTenantConsentResponse> CheckTenantConsent(CheckTenantConsentRequest request)
        {

            List<string> keys = new List<string>
            {
                Constants.ADRCheckTenantConsentEndpoint,
                Constants.ADRTokenUrl,
                Constants.ADRConsentURL,
                Constants.ADRTokenURL
            };

            EntityCollection configValues = await _fijiConfig.GetFijiConfigKeyValue(keys);
            string GetValue(string key) => configValues.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == key)?.GetAttributeValue<string>("fiji_value");

            string endpoint = GetValue(Constants.ADRCheckTenantConsentEndpoint);
            string tokenUrl = GetValue(Constants.ADRTokenUrl);
            string? clientId = _configuration[ADRConstants.Generic.ADRClientId];
            string? clientSecret = _configuration[ADRConstants.Generic.ADRClientSecret];
            string token = await Authentication.GetADRToken(_httpClient, tokenUrl, clientId, clientSecret, Constants.ADRConsentScope);

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var payload = new
            {
                tenantId = request.TenantId,
                tenantDomain = request.TenantDomain,
                soldToCustomerID = Constants.ADRSoldToCustomerId,
                receivedFromCustomerID = Constants.ADRSoldToCustomerId
            };

            const int maxRetries = 2;

            for (int attempt = 0; attempt <= maxRetries; attempt++)
            {
                using var httpRequest = new HttpRequestMessage(HttpMethod.Post, endpoint)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json")
                };
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                HttpResponseMessage response = await _httpClient.SendAsync(httpRequest);
                string body = await response.Content.ReadAsStringAsync();

                switch (response.StatusCode)
                {
                    case HttpStatusCode.OK:
                    case HttpStatusCode.BadRequest:
                        return JsonConvert.DeserializeObject<CheckTenantConsentResponse>(body);
                    case HttpStatusCode.Unauthorized:
                        throw new Exception("Unauthorized: token invalid or expired");
                    case HttpStatusCode.NotFound:
                        throw new Exception("Check-tenant-consent endpoint not found — verify configured URL");
                    case (HttpStatusCode)429:
                    case HttpStatusCode.InternalServerError:
                    case HttpStatusCode.ServiceUnavailable:
                        if (attempt < maxRetries)
                        {
                            await Task.Delay(TimeSpan.FromMilliseconds(500 * Math.Pow(2, attempt)));
                            continue;
                        }
                        throw new Exception($"ADR service returned {(int)response.StatusCode} after {maxRetries} retries");
                    default:
                        throw new Exception(body);
                }
            }
            throw new Exception("Exhausted retries calling check-tenant-consent");
        }
    }
}