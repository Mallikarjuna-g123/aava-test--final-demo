﻿
using Azure.ResourceManager;
using FIJI.Portal.WebAPI.Integration.Utilities;
using FIJI.Portal.WebAPI.Integration.Model;
using Microsoft.Xrm.Sdk;
using System.Xml.Linq;
using System.Xml;
using FIJI.Portal.FileReception.Commons.Helpers;
using Microsoft.Extensions.Caching.Memory;
using System.Net.Http.Headers;
using Microsoft.Extensions.Logging.Abstractions;

namespace FIJI.Portal.WebAPI.Integration.Integration
{
    public class OCI : Base<OCI>
    {
        private readonly FijiConfiguration _fijiConfig;
        private readonly IMemoryCache _memoryCache;
        private readonly HttpClient _httpClient;

        public OCI() : base("oci", NullLogger<OCI>.Instance) { }
        public OCI(IOrganizationService dataverseClient, IMemoryCache cache, HttpClient httpClient, ILogger<OCI>? logger = null) : base(dataverseClient, "oci", logger)
        {
            _fijiConfig = new FijiConfiguration(dataverseClient);
            _memoryCache = cache;
            _httpClient = httpClient;
        }

        public async Task<string> GetData(string id)
        {

            List<string> urlKeys = new List<string>() { Constants.GetURLAzure, Constants.GetHomeURL, Constants.AzureAccessScope };
            EntityCollection urlValues = await _fijiConfig.GetFijiConfigKeyValue(urlKeys);
            Uri baseUri = new Uri($"{urlValues.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == "GetURLAzure")?.GetAttributeValue<string>("fiji_value")}");
            string ociUrl = urlValues.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == "GetHomeURL")?.GetAttributeValue<string>("fiji_value") ?? null;

            string azureAccessScopeUrl = urlValues.Entities.FirstOrDefault(s => s.GetAttributeValue<string>("fiji_key") == "AzureAccessScope")?.GetAttributeValue<string>("fiji_value") ?? null;

            string url = baseUri + ociUrl + id;
            string resultMessage = string.Empty;
            try
            {
                
                    if (!string.IsNullOrEmpty(azureAccessScopeUrl))
                    {
                        string token = await Authentication.GetToken(azureAccessScopeUrl, new Azure.Identity.DefaultAzureCredential(), _memoryCache);
                        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    }

                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url);
                    HttpResponseMessage response = await _httpClient.SendAsync(request);
                    resultMessage = await response.Content.ReadAsStringAsync();

                    if (!response.IsSuccessStatusCode && resultMessage.TrimStart().StartsWith("{"))
                    {
                        // Structured OCI conflict response from integration
                        var conflictResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<OCIConflictResponse>(resultMessage);
                        if (conflictResponse?.Status == "conflict" && conflictResponse.Conflicts?.Count > 0)
                        {
                            var portalError = new OCIPortalError
                            {
                                IsConflict = true,
                                Title = "There are issues with current configuration.",
                                Subtitle = "The below part numbers have conflicts",
                                Conflicts = conflictResponse.Conflicts
                                    .GroupBy(c => c.PartNo)
                                    .Select(g => g.First())
                                    .ToList()
                            };
                            throw new Exception(Newtonsoft.Json.JsonConvert.SerializeObject(portalError));
                        }
                        throw new Exception(Newtonsoft.Json.JsonConvert.SerializeObject(
                            new { isConflict = false, message = conflictResponse?.OriginalMessage ?? resultMessage }));
                    }

                    try
                    {
                        var xmlDoc = XDocument.Parse(resultMessage);
                        var ipcItems = xmlDoc.Descendants("IPCSLineItem");

                        if (!ipcItems.Any())
                            throw new Exception(xmlDoc?.Root?.Value.Trim());

                        return resultMessage;
                    }
                    catch (XmlException)
                    {
                        throw new Exception($"Malformed XML in response.");
                    }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
