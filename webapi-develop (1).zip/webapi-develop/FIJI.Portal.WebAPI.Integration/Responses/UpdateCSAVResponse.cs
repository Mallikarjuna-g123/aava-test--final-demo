﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class UpdateCSAVResponse: Base
    {
        public Model.ProductComponent? ProductComponent { get; set; }

        public Model.ServiceSnapshot? ServiceRevision { get; set; }
    }
}
