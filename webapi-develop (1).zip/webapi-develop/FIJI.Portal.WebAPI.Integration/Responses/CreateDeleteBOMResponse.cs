﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace BillofMaterial
    {
        public class CreateDeleteBOMResponse : Base
        {
            public string ProjectId { get; set; }
            public List<ServiceDtls> ServiceIds { get; set; }

        }

        public class ServiceDtls
        {
            public string ID { get; set; }
            public string ProductComponentId { get; set; }
        }
    }

}
