﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class FileUploadResponse : Base
    {
        public string relativeUrl { get; set; }
        public string fileName { get; set; }
        public string ModifiedFileName { get; set; }
    }

}
