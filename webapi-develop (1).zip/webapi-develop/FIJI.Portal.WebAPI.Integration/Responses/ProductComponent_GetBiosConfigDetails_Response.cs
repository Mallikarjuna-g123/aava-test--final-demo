﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace ProductComponent
    {
        public class ProductComponent_GetBiosConfigDetails_Response : Base
        {
            public string? BiosConfigDetails { get; set; }
        }
    }

}
