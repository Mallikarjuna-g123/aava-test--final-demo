﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class ValidationResultItem
    {
        public int Code { get; set; }
        public string Description { get; set; }
    }

    public class DeviceValidationError
    {
        public int ErrorCode { get; set; }
        public string ErrorName { get; set; }
    }

    public class DeviceValidationResultItem
    {
        public List<DeviceValidationError> Errors { get; set; } = new();
    }

    public class CheckTenantConsentResponse
    {
        public List<ValidationResultItem> ValidationResults { get; set; } = new();
        public List<DeviceValidationResultItem> DeviceValidationResults { get; set; } = new();

        public bool ConsentConfirmed => (ValidationResults?.Count ?? 0) == 0 && (DeviceValidationResults?.Count ?? 0) == 0;

    }
}
