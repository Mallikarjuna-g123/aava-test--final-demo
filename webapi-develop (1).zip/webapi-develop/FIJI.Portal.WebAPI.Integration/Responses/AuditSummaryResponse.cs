﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace AuditSummary
    {
        public class AuditSummaryResponse : Base
        {
            public Guid UserId { get; set; }
            public string UseridName { get; set; }
            public string? Additionalinfo { get; set; }
            public DateTime CreatedOn { get; set; }
            public Guid AuditId { get; set; }
            public Guid BomId { get; set; }
            public string? ProjectId { get; set; }
            public string? ProductId { get; set; }
            public int Count { get; set; }
            public string BOMNumber { get; set; }
        }
    }

}
