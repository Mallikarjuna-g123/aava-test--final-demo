﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace Project
    {
        public class ECNInceptionCreationResponse:Base
        {
            public List<Guid> ProjectIds { set; get; }

            public List<string> RequestIDs { set; get; }
        }
    }

}
