﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class CreateProjectResponse : Base
    {
        public string? ProjectId { get; set; }
        public string? requestId { get; set; }
        public string? requestName { get; set; }
        public List<string>? ServiceIds { get; set; }
        public ProductFamily? Platform { get; set; }
        public string? ProjectName { get; set; }
        public DateTime? CustomerRequestDate { get; set; }
        public List<int>? CustomerPOCPreference { get; set; }
        public SystemUser? Owner { get; set; }
        public string? AdditionalEmail { get; set; }
        public string? ProjectComments { get; set; }
        public bool? Opinel { get; set; }
        public int? ComponentModificationAcceptancePreference { get; set; }
        public string IsNewOrECN { get; set; }
        public string ProjectStage { get; set; }
        public List<BOM>? BomItems { get; set; }
        public List<RegionLocale>? AvailableLocalizations { get; set; }
        public List<RegionLocale>? SelectedLocalizations { get; set; }
        public string Statuscode { get; set; }
    }
}
