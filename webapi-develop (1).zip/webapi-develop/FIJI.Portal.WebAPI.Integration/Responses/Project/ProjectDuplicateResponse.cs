﻿namespace FIJI.Portal.WebAPI.Integration.Responses.Project
{
    public class ProjectDuplicateResponse : Base
    {
        public Guid? DuplicateProjectId { get; set; }
        public string? DuplicateProjectName { get; set; }
    }
}
