﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace ServiceRevision
    {
        public class ServiceRevisionUpdateResponse : Base
        {
            public Guid ServiceRevisionId { get; set; }
            public int Status { get; set; }
            public string Version { get; set; }
            public Guid? PlacementId { get; set; }
            public DateTime? ModifiedOn { get; set; }
            public string ModifiedByPortalContact { get; set; }
        }
    }

}
