﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace Project
    {
        public class GetProjectByRequestIDResponse : Base
        {
            public string? ProjectId { get; set; }
            public string? RequestId { get; set; }
            public string? RequestName { get; set; }
            public int? OccId { get; set; }
            public List<string>? ServiceIds { get; set; }
            public ProductFamily? Platform { get; set; }
            public string? ProjectName { get; set; }
            public DateTime? CustomerRequestDate { get; set; }
            public List<int>? CustomerPOCPreference { get; set; }
            public SystemUser? Owner { get; set; }
            public string? AdditionalEmail { get; set; }
            public string? ProjectComments { get; set; }
            public bool? Opinel { get; set; }
            public bool? TermsAndConditionAccepted { get; set; }
            public int? ComponentModificationAcceptancePreference { get; set; }
            public List<BOM>? BomItems { get; set; }
            public List<RegionLocale>? AvailableLocalizations { get; set; }
            public List<RegionLocale>? SelectedLocalizations { get; set; }
            public string IsNewOrECN { get; set; }
            public string ProjectStage { get; set; }
            public string Statuscode { get; set; }
        }
    }

}
