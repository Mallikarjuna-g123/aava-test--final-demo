﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class FactoryDashboardResponse
    {
        public List<TasksResponse> factoryDashboardTasks { get; set; }
        public int totalRecordCount { get; set; }
        public List<string>? UnmatchedProjectIds { get; set; }
    }

    public class TasksResponse
    {
        public Guid Id { get; set; }
        public string? Fiji_poctype { get; set; }
        public Guid? Regardingobjectid { get; set; }
        public string? Regardingobjectidname { get; set; }
        public string Fiji_productfamily { get; set; }
        public string Fiji_productexternalid { get; set; }
        public string Fiji_customername { get; set; }
        public string Fiji_projectoriginatingregionid { get; set; }
        public string FactoryName { get; set; }
        public string ProjectStage { get; set; }
        public string ProjectType { get; set; }
        public string? Fiji_taskassigneddate { get; set; }
        public string? Fiji_taskduedateadjusted { get; set; }
        public string? Actualend { get; set; }
        public int? Fiji_tasktatdays { get; set; }
        public int? FactoryTat { get; set; }
        public string Statuscode { get; set; }
        public int Fiji_taskoudays { get; set; }
        public string Fiji_pstticketnumber { get; set; }
        public string Fiji_pstticketurl { get; set; }
        public string? Description { get; set; }
        public string Ownerid { get; set; }
        public string Internalemailaddress { get; set; }
        public int? Fiji_hpdelaydays { get; set; }
        public string? DelayReason { get; set; }
        public string? DelaySubreason { get; set; }
        public string ServiceList { get; set; }
        public string Fiji_kvmkeyboard { get; set; }
    }

    public class UpdateTasksResponse
    {
        public string Message { get; set; }
    }
}