﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class FactoryDashboardBookings : Base
    {
        public List<BookingResponse> Bookings { get; set; }
        public int? TotalCount { get; set; }
    }

    public class BookingResponse
    {
        public Guid? Id { get; set; }
        public string? ProjectId { get; set; }

        public string? Fiji_customername { get; set; }

        public string? Fiji_kvmkeyboard { get; set; }

        public string? Start { get; set; }

        public string? End { get; set; }

        public int? Duration { get; set; }

        public bool? Attended { get; set; }

        public string? Comments { get; set; }

        public string? TestBench { get; set; }

        public string? CreatedOn { get; set; }
    }
}