﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace Project
    {
        public class SubmitProjectResponse : Base
        {
            public string Status { get; set; }
        }
    }

}
