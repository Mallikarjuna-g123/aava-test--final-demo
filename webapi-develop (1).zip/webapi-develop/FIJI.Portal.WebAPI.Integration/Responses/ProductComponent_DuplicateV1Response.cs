﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class ProductComponent_DuplicateV1Response: Base
    {
        public string NewProductComponentId { get; set; }

        public string? ChangedBIOS { get; set; }

        public string? NewPCId { get; set; }
    }

    public class BiosCompatibilityResult
    {
        public Guid Id { get; set; }
        public Guid BiosConfigurationLineId { get; set; }
        public string? Name { get; set; }
        public bool IsCompatible { get; set; }
    }

    public class ValueItem
    {
        public Guid Id { get; set; }
        public string? Value { get; set; }
    }

    public class BiosConfigurationLineInfo
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int? DataType { get; set; }
        public string Value { get; set; }
    }

}
