﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace Project
    {
        public class NewInceptionCreationResponse : Base
        {
            public List<string> RequestIDs { set; get; }
        }
    }

}
