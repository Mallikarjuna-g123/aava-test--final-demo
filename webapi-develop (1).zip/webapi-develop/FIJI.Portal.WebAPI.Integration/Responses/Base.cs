﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class Base
    {
        public string? Message { get; set; }
        public string? Error { get; set; }
        
    }
}
