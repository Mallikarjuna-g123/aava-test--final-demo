﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    namespace ProductComponent
    {
        public class ProductComponent_DuplicateResponse: Base
        {
            public Guid NewProductComponentId { get; set; }
        }
    }

}
