﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace FIJI.Portal.WebAPI.Integration.Responses.IAMICT
{
    public class GenerateUploadUrlResponse
    {
        [JsonPropertyName("uploadUrl")]
        public required string UploadUrl { get; set; }

        [JsonPropertyName("fileUrl")]
        public required string FileUrl { get; set; }

        [JsonPropertyName("fileId")]
        public required Guid? FileId { get; set; }

        [SetsRequiredMembers]
        public GenerateUploadUrlResponse(Guid? fileId, string uploadUrl, string fileUrl) => (FileId, UploadUrl, FileUrl) = (fileId, uploadUrl, fileUrl);
    }
}
