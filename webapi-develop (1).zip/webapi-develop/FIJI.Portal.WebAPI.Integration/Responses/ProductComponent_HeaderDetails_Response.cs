﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class ProductComponent_HeaderDetails_Response : Base
    {
        public string? PartNumber { get; set; }

        public string? CustomerName { get; set; }

        public string? PortalDescription { get; set; }

        public List<string>? ModelsList { get; set; }

        public List<string>? RequestIds { get; set; }
    }
}
