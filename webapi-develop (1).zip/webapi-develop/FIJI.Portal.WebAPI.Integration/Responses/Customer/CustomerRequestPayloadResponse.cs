﻿
namespace FIJI.Portal.WebAPI.Integration.Responses.Customer
{
    using FIJI.Portal.WebAPI.Integration.Model;

    public class CustomerRequestPayloadResponse : FIJI.Portal.WebAPI.Integration.Responses.Base
    {
        public List<Requests> Requests { get; set; }
        public int? TotalCount { get; set; }
    }

    public class Requests
    {
        public Guid? Projectid { get; set; } // This is for only development purpose 
        public string RequestName { get; set; }
        public string? ProjectDueDate { get; set; }
        public string? OriginalProjectDueDate { get; set; }
        public string? ProjectCompletedOn { get; set; }
        public int? Status { get; set; }
        public string Stage { get; set; }
        public string PartNo { get; set; }
        public int? OciId { get; set; }
        public string? RequestId { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public string? ModifiedbyPortalContact { get; set; }
        public string? LastModifiedOn { get; set; }
        public ProductFamily Platform { get; set; }
        public string CustomerName { get; set; }
        public string ProjectName { get; set; }
        public string ProjectManagerEmail { get; set; }
        public List<ProjectStageTracker> StageTrackers { get; set; }
        public string? PortalDescription { get; set; }
        public bool IsHidden { get; set; }
    }

    public class ProjectStageTracker
    {
        public string? StageCompletedOn { get; set; }
        public string? ProjectStage { get; set; }
    }
}
