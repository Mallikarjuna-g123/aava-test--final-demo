﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Responses.Customer
{
    public class CustomerServicesResponse : Base
    {
        public List<CustomerServices> Services { get; set; }
        public int? TotalCount { get; set; }
    }

    public class CustomerServices
    {
        public Guid? ProductComponentId { get; set; }
        public string? Fiji_Fiji_Productcomponentid { get; set; }
        public string? Description { get; set; }
        public string? ExternalId { get; set; }
        public string? Stage { get; set; }
        public string? PortalDescription { get; set; }
        public ComponentType ComponentType { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public ServiceSnapshot? LatestServiceRevision { get; set; }
        public ComponentType? GetMoreSource { get; set; }
        public bool IsHidden { get; set; }
    }

}
