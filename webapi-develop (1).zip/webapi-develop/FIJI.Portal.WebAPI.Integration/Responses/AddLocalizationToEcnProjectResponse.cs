﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class AddLocalizationToEcnProjectResponse : Base
    {
        public string? ProjectId { get; set; }
        public List<string>? LocalizationId { get; set; }
    }
}
