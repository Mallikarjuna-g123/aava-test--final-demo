﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class ScheduleRecords
    {
        public string? TestBench { get; set; }
        public string? type { get; set; }
        public string? startDate { get; set; }
        public string? endDate { get; set; }
        public string? startTime { get; set; }
        public string? endTime { get; set; }
        public string? repeat { get; set; }
        public string? days { get; set; }
        public string? Factory { get; set; }
        public string? TimeZoneCode { get; set; }
        public string? StartDateTime { get; set; }
        public string? EndDateTime { get; set; }
    }

    public class ScheduleResponse
    {
        public List<ScheduleRecords>? Data { get; set; }
        public int TotalRecords { get; set; }
    }
}