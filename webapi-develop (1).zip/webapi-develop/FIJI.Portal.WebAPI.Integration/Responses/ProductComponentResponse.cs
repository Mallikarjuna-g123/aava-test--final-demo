﻿namespace FIJI.Portal.WebAPI.Integration.Responses
{
    public class ProductComponentResponse : Base
    {
        // 5 items in response payload
        public Model.ProductComponent? ProductComponent { get; set; }
        public Model.ServiceSnapshot? ServiceRevision { get; set; }
        public string BomId { get; set; }
        public Guid? SourceComponentTypeid { get; set; }
    }
}
