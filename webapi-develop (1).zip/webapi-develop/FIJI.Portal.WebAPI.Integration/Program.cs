using Azure.Identity;
using Azure.Monitor.OpenTelemetry.AspNetCore;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.WebAPI.Integration.Controllers.Dev;
using FIJI.Portal.WebAPI.Integration.Model;
using FIJI.Portal.WebAPI.Integration.Observability;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Server.IIS;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using OpenTelemetry.Logs;
using OpenTelemetry.Trace;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

const long defaultMaxRequestBodySizeBytes = 100L * 1024L * 1024L;
var maxRequestBodySizeBytes = builder.Configuration.GetValue<long?>("RequestLimits:MaxRequestBodySizeBytes")
    ?? builder.Configuration.GetValue<long?>(Constants.RequestLimitsMaxRequestBodySizeBytes)
    ?? defaultMaxRequestBodySizeBytes;

builder.WebHost.ConfigureKestrel(options =>
{
    options.Limits.MaxRequestBodySize = maxRequestBodySizeBytes;
});

builder.Services.Configure<IISServerOptions>(options =>
{
    options.MaxRequestBodySize = maxRequestBodySizeBytes;
});

// Add services to the container.
builder.Services.AddCors();
builder.Services.AddScoped<ControllerActionLoggingFilter>();
builder.Services.AddControllers(options =>
{
    options.Filters.Add<ControllerActionLoggingFilter>();
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddScoped<Project>();
builder.Services.AddScoped<BOM>();
builder.Services.AddScoped<ServiceSnapshot>();
builder.Services.AddScoped<SystemUser>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddScoped<IGetCount, GetCountOfRecordsBaseBusiness>();
builder.Configuration.AddEnvironmentVariables();

builder.Services.AddSwaggerGen(c =>
{
    c.TagActionsBy(api =>
    {
        if (api.GroupName != null)
        {
            return new[] { api.GroupName };
        }

        var controllerActionDescriptor = api.ActionDescriptor as ControllerActionDescriptor;
        if (controllerActionDescriptor != null)
        {
            return new[] { controllerActionDescriptor.ControllerName };
        }

        throw new InvalidOperationException(Constants.ErrorMessages.UnableToTagEndPoint);
    });

    c.DocInclusionPredicate((name, api) => true);

    c.AddSecurityDefinition(Constants.Bearer, new OpenApiSecurityScheme
    {
        Name = Constants.Authorization,
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = Constants.Bearer,
    });

    c.AddSecurityRequirement(_ => new OpenApiSecurityRequirement()
    {
        {
            new OpenApiSecuritySchemeReference(Constants.Bearer),
            new List<string>()
        }
    });
});

if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("APPLICATIONINSIGHTS_CONNECTION_STRING")))
{
    builder.Services.AddOpenTelemetry().UseAzureMonitor()
    .WithTracing(tracing =>
    {
        // Drop noisy Azure Identity token spans at sampling time before export processing.
        tracing.SetSampler(new AzureIdentitySpanExclusionSampler());
        tracing.AddProcessor(new AppNameActivityProcessor());
    })
    .WithLogging(logging =>
    {
        logging.AddProcessor(new AppNameLogRecordProcessor());
    });
}

builder.Logging.AddFilter("MSAL", LogLevel.None);
builder.Logging.AddFilter("Microsoft.Identity", LogLevel.None);
builder.Logging.AddFilter("Microsoft.IdentityModel", LogLevel.None);
builder.Logging.AddFilter("Azure.Identity", LogLevel.None);
builder.Logging.AddFilter("Azure.Core", LogLevel.None);
builder.Logging.AddFilter("Azure.Messaging.ServiceBus", LogLevel.None);
builder.Logging.AddFilter("Microsoft.AspNetCore", LogLevel.Error);
builder.Logging.AddFilter("System.Net.Http", LogLevel.Error);

Utils.JVWSecret = Encoding.ASCII.GetBytes(builder.Configuration.GetValue<string>(Constants.JWTSecret));
Utils.EnableVirusCheck = builder.Configuration.GetValue<bool>(Constants.EnableVirusCheck);

builder.Services.AddAuthentication(x =>
{
    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(x =>
{
    x.RequireHttpsMetadata = false;
    x.SaveToken = true;
    x.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Utils.JVWSecret),
        ValidateIssuer = false,
        ValidateAudience = false
    };
    x.Events = new JwtBearerEvents
    {
        OnAuthenticationFailed = context =>
        {
            var logger = context.HttpContext.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger("Auth.JwtBearer");
            logger.LogWarning("JWT authentication failed for {Method} {Path}: {Error}",
                context.HttpContext.Request.Method,
                context.HttpContext.Request.Path,
                context.Exception.Message);
            return Task.CompletedTask;
        },
        OnChallenge = context =>
        {
            var logger = context.HttpContext.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger("Auth.JwtBearer");
            logger.LogWarning("JWT challenge issued for {Method} {Path}: {Error}",
                context.HttpContext.Request.Method,
                context.HttpContext.Request.Path,
                context.ErrorDescription ?? context.Error ?? "No token provided");
            return Task.CompletedTask;
        }
    };
});

builder.Services.AddMemoryCache();
builder.Services.AddSingleton(new DefaultAzureCredential());

builder.Services.AddTransient<OutboundHttpLoggingHandler>();
builder.Services.AddHttpClient("OCI")
    .AddHttpMessageHandler<OutboundHttpLoggingHandler>();
builder.Services.AddHttpClient("ADRConsent").AddHttpMessageHandler<OutboundHttpLoggingHandler>();

builder.Services.AddTransient<ServiceClient>(provider =>
{
    string? crm_url = builder.Configuration.GetValue<string>(Constants.CRMUrl);
    string? crmConnectionString = builder.Configuration.GetValue<string>(Constants.CRMConnectionString);

    return Dataverse.CreateConnection(provider, crm_url, crmConnectionString);
});

builder.Services.AddTransient<IOrganizationService>(provider =>
{
    var serviceClient = provider.GetRequiredService<ServiceClient>();
    var logger = provider.GetRequiredService<ILoggerFactory>().CreateLogger("Dataverse.IOrganizationService");
    return new OrganizationServiceLoggingProxy(serviceClient, logger);
});

builder.Services.AddSingleton<StorageAccountHelper, StorageAccountHelper>(helper =>
{
    string? storageAccount = builder.Configuration.GetValue<string?>(FIJI.Portal.FileReception.Commons.Constants.Generic.StorageAccount);
    string? storageAccountKey = builder.Configuration.GetValue<string?>(FIJI.Portal.FileReception.Commons.Constants.Generic.StorageAccountKey);
    return new StorageAccountHelper(storageAccount, storageAccountKey);
});

builder.Services.AddSingleton<FileReceptionNotification>(helper =>
{
    string? storageAccount = builder.Configuration.GetValue<string?>(FIJI.Portal.FileReception.Commons.Constants.Generic.StorageAccount);
    string? queueName = builder.Configuration.GetValue<string>(FIJI.Portal.FileReception.Commons.Constants.Generic.QueueNameFileReception);
    string? serviceBusEndPoint = builder.Configuration.GetValue<string>(FIJI.Portal.FileReception.Commons.Constants.Generic.ServiceBusEndPoint);
    return new FileReceptionNotification(serviceBusEndPoint, queueName, storageAccount);
});

builder.Services.Configure<FIJI.Portal.WebAPI.Integration.Utilities.BrowserServiceOptions>(
    builder.Configuration.GetSection(FIJI.Portal.WebAPI.Integration.Utilities.BrowserServiceOptions.SectionName));
builder.Services.AddSingleton<FIJI.Portal.WebAPI.Integration.Utilities.BrowserService>();
builder.Services.AddSingleton<FIJI.Portal.WebAPI.Integration.Utilities.IBrowserService>(
    p => p.GetRequiredService<FIJI.Portal.WebAPI.Integration.Utilities.BrowserService>());
builder.Services.AddHostedService(
    p => p.GetRequiredService<FIJI.Portal.WebAPI.Integration.Utilities.BrowserService>());
builder.Services.AddHostedService<FIJI.Portal.WebAPI.Integration.Utilities.PlaywrightInstaller>();

builder.Services.AddTransient<Task<string>>(provider =>
{
    string? crm_url = builder.Configuration.GetValue<string>(Constants.CRMUrl);
    string? crmConnectionString = builder.Configuration.GetValue<string>(Constants.CRMConnectionString);

    var managedIdentity = provider.GetRequiredService<DefaultAzureCredential>();
    var cache = provider.GetService<IMemoryCache>();

    if (string.IsNullOrEmpty(crmConnectionString))
        return Authentication.GetToken(crm_url, managedIdentity, cache);
    else
        return Authentication.AccessTokenGenerator(
            builder.Configuration.GetValue<string>(Constants.ClientId),
            builder.Configuration.GetValue<string>(Constants.Secret),
            crm_url);
});
builder.Logging.AddFilter("MSAL", LogLevel.None);
builder.Logging.AddFilter("Microsoft.Identity", LogLevel.None);
builder.Logging.AddFilter("Microsoft.IdentityModel", LogLevel.None);
builder.Logging.AddFilter("Azure.Identity", LogLevel.None);
builder.Logging.AddFilter("Azure.Core", LogLevel.None);
builder.Logging.AddFilter("Microsoft.AspNetCore", LogLevel.Error);
builder.Logging.AddFilter("System.Net.Http", LogLevel.Error);


var app = builder.Build();

app.UseExceptionHandler(handler =>
{
    handler.Run(async context =>
    {
        var exceptionFeature = context.Features.Get<IExceptionHandlerFeature>();
        if (exceptionFeature?.Error != null)
        {
            app.Logger.LogError(exceptionFeature.Error, "Unhandled exception for request {Method} {Path}", context.Request.Method, context.Request.Path);
        }

        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsJsonAsync(new { error = "An unexpected error occurred.", correlationId = context.TraceIdentifier });
    });
});

app.UseMiddleware<CorrelationAndRequestLoggingMiddleware>();

app.UseSwagger(c => c.OpenApiVersion = Microsoft.OpenApi.OpenApiSpecVersion.OpenApi2_0);
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseRouting();
app.UseCors(x => x
        .SetIsOriginAllowed(origin => true)
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials());
app.UseAuthorization();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

using (var scope = app.Services.CreateScope())
{
    try
    {
        var serviceProvider = scope.ServiceProvider;
        var memoryCache = serviceProvider.GetRequiredService<IMemoryCache>();
        FijiConfiguration fijiConfiguration = new FijiConfiguration(app.Services.GetRequiredService<IOrganizationService>());
        var configEntities = await fijiConfiguration.GetFijiConfigKeyValue(new List<string>() { Constants.MaliciousKeywords });
        if (configEntities?.Entities.Any() == true)
        {
            string? keywordsValue = configEntities.Entities
                            .FirstOrDefault(entity => entity.GetAttributeValue<string>(Constants.FijiKeyAttribute) == Constants.MaliciousKeywords)
                                    ?.GetAttributeValue<string>(Constants.FijiValueAttribute);

            if (!string.IsNullOrEmpty(keywordsValue))
            {
                memoryCache.Set(Constants.CachedMaliciousKeywordsKey, keywordsValue);
            }
        }
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "Failed to load malicious keywords configuration.");
    }
}

app.Logger.LogInformation("FIJI.Portal.WebAPI.Integration started successfully.");

app.Run();