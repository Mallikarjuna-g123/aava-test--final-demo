using FIJI.Portal.WebAPI.Integration.Utilities;
using OpenTelemetry;
using OpenTelemetry.Logs;

namespace FIJI.Portal.WebAPI.Integration.Observability;

/// <summary>
/// Ensures exported log records always include appName for stable customDimensions filtering.
/// </summary>
public sealed class AppNameLogRecordProcessor : BaseProcessor<LogRecord>
{
    public override void OnEnd(LogRecord data)
    {
        if (data is null)
        {
            return;
        }

        var attributes = data.Attributes?.ToList() ?? new List<KeyValuePair<string, object?>>();
        var hasAppName = attributes.Any(kvp => kvp.Key == "appName" && kvp.Value is string s && !string.IsNullOrWhiteSpace(s));

        if (!hasAppName)
        {
            attributes.Add(new KeyValuePair<string, object?>("appName", Constants.PortalWebApi));
            data.Attributes = attributes;
        }
    }
}