using System.Diagnostics;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace FIJI.Portal.WebAPI.Integration.Observability;

public sealed class CorrelationAndRequestLoggingMiddleware
{
    private const string CorrelationIdHeader = "X-Correlation-ID";
    private readonly RequestDelegate _next;
    private readonly ILogger<CorrelationAndRequestLoggingMiddleware> _logger;

    public CorrelationAndRequestLoggingMiddleware(
        RequestDelegate next,
        ILogger<CorrelationAndRequestLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task Invoke(HttpContext context)
    {
        var correlationId = context.Request.Headers.TryGetValue(CorrelationIdHeader, out var incoming) && !string.IsNullOrWhiteSpace(incoming)
            ? incoming.ToString()
            : Guid.NewGuid().ToString("D");

        context.TraceIdentifier = correlationId;
        context.Response.Headers[CorrelationIdHeader] = correlationId;

        Activity.Current?.SetTag("correlation.id", correlationId);
        Activity.Current?.SetTag("http.request.method", context.Request.Method);
        Activity.Current?.SetTag("http.request.path", context.Request.Path.Value);
        Activity.Current?.SetTag("appName", Constants.PortalWebApi);

        var startedAt = Stopwatch.GetTimestamp();

        using (_logger.BeginScope(new Dictionary<string, object>
               {
                   ["CorrelationId"] = correlationId,
                   ["RequestPath"] = context.Request.Path.Value ?? string.Empty,
                   ["RequestMethod"] = context.Request.Method,
                   ["appName"] = Constants.PortalWebApi
               }))
        {
            _logger.LogInformation("Request started: {Method} {Path}", context.Request.Method, context.Request.Path.Value);

            try
            {
                await _next(context);
            }
            finally
            {
                var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;
                Activity.Current?.SetTag("http.response.status_code", context.Response.StatusCode);
                Activity.Current?.SetTag("request.duration.ms", elapsedMs);
                ObservabilityTelemetry.RecordRequest(context.Request.Method, context.Response.StatusCode, elapsedMs);

                _logger.LogInformation(
                    "Request finished: {Method} {Path} => {StatusCode} in {ElapsedMs} ms (appName: {appName})",
                    context.Request.Method,
                    context.Request.Path.Value,
                    context.Response.StatusCode,
                    elapsedMs,
                    Constants.PortalWebApi);
            }
        }
    }
}
