using FIJI.Portal.WebAPI.Integration.Utilities;
using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace FIJI.Portal.WebAPI.Integration.Observability;

public static class ObservabilityTelemetry
{
    public static readonly ActivitySource ActivitySource = new("FIJI.Portal.WebAPI.Integration");

    private static readonly Meter Meter = new("FIJI.Portal.WebAPI.Integration");
    private static readonly Counter<long> RequestCount = Meter.CreateCounter<long>("http.server.request.count");
    private static readonly Counter<long> RequestFailureCount = Meter.CreateCounter<long>("http.server.request.failure.count");
    private static readonly Histogram<double> RequestDurationMs = Meter.CreateHistogram<double>("http.server.request.duration.ms");
    private static readonly Counter<long> ActionCount = Meter.CreateCounter<long>("app.action.count");
    private static readonly Counter<long> ActionFailureCount = Meter.CreateCounter<long>("app.action.failure.count");
    private static readonly Histogram<double> ActionDurationMs = Meter.CreateHistogram<double>("app.action.duration.ms");
    private static readonly Counter<long> OperationCount = Meter.CreateCounter<long>("app.operation.count");
    private static readonly Counter<long> OperationFailureCount = Meter.CreateCounter<long>("app.operation.failure.count");
    private static readonly Histogram<double> OperationDurationMs = Meter.CreateHistogram<double>("app.operation.duration.ms");
    private static readonly Counter<long> DependencyCount = Meter.CreateCounter<long>("app.dependency.count");
    private static readonly Counter<long> DependencyFailureCount = Meter.CreateCounter<long>("app.dependency.failure.count");
    private static readonly Histogram<double> DependencyDurationMs = Meter.CreateHistogram<double>("app.dependency.duration.ms");
    private static readonly Counter<long> RetryAttemptCount = Meter.CreateCounter<long>("app.retry.attempt.count");
    private static readonly Counter<long> RetryExhaustedCount = Meter.CreateCounter<long>("app.retry.exhausted.count");

    public static void RecordRequest(string method, int statusCode, double elapsedMs)
    {
        var tags = new[]
        {
            new KeyValuePair<string, object?>("http.method", method),
            new KeyValuePair<string, object?>("http.status_code", statusCode),
            new KeyValuePair<string, object?>("appName", Constants.PortalWebApi)
        };

        RequestCount.Add(1, tags);
        RequestDurationMs.Record(elapsedMs, tags);

        if (statusCode >= 500)
        {
            RequestFailureCount.Add(1, tags);
        }
    }

    public static void RecordAction(string controller, string action, int statusCode, double elapsedMs, bool failed)
    {
        var tags = new[]
        {
            new KeyValuePair<string, object?>("controller", controller),
            new KeyValuePair<string, object?>("action", action),
            new KeyValuePair<string, object?>("status_code", statusCode),
            new KeyValuePair<string, object?>("appName", Constants.PortalWebApi)
        };

        ActionCount.Add(1, tags);
        ActionDurationMs.Record(elapsedMs, tags);

        if (failed)
        {
            ActionFailureCount.Add(1, tags);
        }
    }

    public static void RecordOperation(string component, string operation, double elapsedMs, bool failed)
    {
        var tags = new[]
        {
            new KeyValuePair<string, object?>("component", component),
            new KeyValuePair<string, object?>("operation", operation),
            new KeyValuePair<string, object?>("appName", Constants.PortalWebApi)
        };

        OperationCount.Add(1, tags);
        OperationDurationMs.Record(elapsedMs, tags);

        if (failed)
        {
            OperationFailureCount.Add(1, tags);
        }
    }

    public static void RecordDependency(string dependencyType, string operation, string target, double elapsedMs, bool failed)
    {
        var tags = new[]
        {
            new KeyValuePair<string, object?>("dependency.type", dependencyType),
            new KeyValuePair<string, object?>("dependency.operation", operation),
            new KeyValuePair<string, object?>("dependency.target", target),
            new KeyValuePair<string, object?>("appName", Constants.PortalWebApi)
        };

        DependencyCount.Add(1, tags);
        DependencyDurationMs.Record(elapsedMs, tags);

        if (failed)
        {
            DependencyFailureCount.Add(1, tags);
        }
    }

    public static void RecordRetry(string component, string operation, int attempt, bool exhausted)
    {
        var tags = new[]
        {
            new KeyValuePair<string, object?>("component", component),
            new KeyValuePair<string, object?>("operation", operation),
            new KeyValuePair<string, object?>("attempt", attempt),
            new KeyValuePair<string, object?>("appName", Constants.PortalWebApi)
        };

        RetryAttemptCount.Add(1, tags);

        if (exhausted)
        {
            RetryExhaustedCount.Add(1, tags);
        }
    }
}