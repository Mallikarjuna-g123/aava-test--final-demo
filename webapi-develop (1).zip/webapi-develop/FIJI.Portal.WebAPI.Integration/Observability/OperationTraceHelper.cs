using System.Diagnostics;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;

namespace FIJI.Portal.WebAPI.Integration.Observability;

public static class OperationTraceHelper
{
    public static void TraceOperation(
        ILogger logger,
        string componentName,
        string activityPrefix,
        string operationName,
        Action action,
        params (string Key, object? Value)[] context)
    {
        TraceOperation<object?>(logger, componentName, activityPrefix, operationName, () =>
        {
            action();
            return null;
        }, context);
    }

    public static T TraceOperation<T>(
        ILogger logger,
        string componentName,
        string activityPrefix,
        string operationName,
        Func<T> action,
        params (string Key, object? Value)[] context)
    {
        var startedAt = Stopwatch.GetTimestamp();
        using var activity = ObservabilityTelemetry.ActivitySource.StartActivity($"{componentName}.{operationName}", ActivityKind.Internal);
        var currentActivity = activity ?? Activity.Current;
        currentActivity?.SetTag("appName", Constants.PortalWebApi);
        var scopeData = new Dictionary<string, object?>
        {
            ["Component"] = componentName,
            ["Operation"] = operationName,
            ["appName"] = Constants.PortalWebApi
        };

        foreach (var (key, value) in context)
        {
            scopeData[key] = value;
            currentActivity?.SetTag($"{activityPrefix}.{operationName}.{key}", value?.ToString());
        }

        using (logger.BeginScope(scopeData))
        {
            logger.LogInformation("{Operation} started", operationName);

            try
            {
                var result = action();
                var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

                currentActivity?.SetTag($"{activityPrefix}.operation", operationName);
                currentActivity?.SetTag($"{activityPrefix}.duration_ms", elapsedMs);
                activity?.SetStatus(ActivityStatusCode.Ok);
                ObservabilityTelemetry.RecordOperation(componentName, operationName, elapsedMs, failed: false);

                logger.LogInformation("{Operation} completed in {ElapsedMs:F1} ms", operationName, elapsedMs);
                return result;
            }
            catch (Exception ex)
            {
                var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

                currentActivity?.SetTag($"{activityPrefix}.operation", operationName);
                currentActivity?.SetTag($"{activityPrefix}.duration_ms", elapsedMs);
                currentActivity?.SetTag($"{activityPrefix}.error", true);
                activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
                ObservabilityTelemetry.RecordOperation(componentName, operationName, elapsedMs, failed: true);

                logger.LogError(ex, "{Operation} failed in {ElapsedMs:F1} ms", operationName, elapsedMs);
                throw;
            }
        }
    }

    public static async Task<T> TraceOperationAsync<T>(
        ILogger logger,
        string componentName,
        string activityPrefix,
        string operationName,
        Func<Task<T>> action,
        params (string Key, object? Value)[] context)
    {
        var startedAt = Stopwatch.GetTimestamp();
        using var activity = ObservabilityTelemetry.ActivitySource.StartActivity($"{componentName}.{operationName}", ActivityKind.Internal);
        var currentActivity = activity ?? Activity.Current;
        currentActivity?.SetTag("appName", Constants.PortalWebApi);
        var scopeData = new Dictionary<string, object?>
        {
            ["Component"] = componentName,
            ["Operation"] = operationName,
            ["appName"] = Constants.PortalWebApi
        };

        foreach (var (key, value) in context)
        {
            scopeData[key] = value;
            currentActivity?.SetTag($"{activityPrefix}.{operationName}.{key}", value?.ToString());
        }

        using (logger.BeginScope(scopeData))
        {
            logger.LogInformation("{Operation} started", operationName);

            try
            {
                var result = await action();
                var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

                currentActivity?.SetTag($"{activityPrefix}.operation", operationName);
                currentActivity?.SetTag($"{activityPrefix}.duration_ms", elapsedMs);
                activity?.SetStatus(ActivityStatusCode.Ok);
                ObservabilityTelemetry.RecordOperation(componentName, operationName, elapsedMs, failed: false);

                logger.LogInformation("{Operation} completed in {ElapsedMs:F1} ms", operationName, elapsedMs);
                return result;
            }
            catch (Exception ex)
            {
                var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

                currentActivity?.SetTag($"{activityPrefix}.operation", operationName);
                currentActivity?.SetTag($"{activityPrefix}.duration_ms", elapsedMs);
                currentActivity?.SetTag($"{activityPrefix}.error", true);
                activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
                ObservabilityTelemetry.RecordOperation(componentName, operationName, elapsedMs, failed: true);

                logger.LogError(ex, "{Operation} failed in {ElapsedMs:F1} ms", operationName, elapsedMs);
                throw;
            }
        }
    }
}
