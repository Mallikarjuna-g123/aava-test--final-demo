using System.Diagnostics;
using FIJI.Portal.WebAPI.Integration.Utilities;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.WebAPI.Integration.Observability;

/// <summary>
/// Decorator for IOrganizationService that adds observability (tracing, logging, metrics).
/// Uses explicit implementation instead of DispatchProxy to work with WCF service contracts.
/// </summary>
public sealed class OrganizationServiceLoggingProxy : IOrganizationService
{
    private readonly IOrganizationService _inner;
    private readonly ILogger _logger;

    public OrganizationServiceLoggingProxy(IOrganizationService inner, ILogger logger)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public static IOrganizationService Create(IOrganizationService inner, ILogger logger) 
        => new OrganizationServiceLoggingProxy(inner, logger);

    public Guid Create(Entity entity)
    {
        return InvokeOperation(nameof(Create), () => _inner.Create(entity));
    }

    public Entity Retrieve(string entityLogicalName, Guid id, ColumnSet columnSet)
    {
        return InvokeOperation(nameof(Retrieve), () => _inner.Retrieve(entityLogicalName, id, columnSet));
    }

    public void Update(Entity entity)
    {
        InvokeOperation(nameof(Update), () => { _inner.Update(entity); return (object?)null; });
    }

    public void Delete(string entityLogicalName, Guid id)
    {
        InvokeOperation(nameof(Delete), () => { _inner.Delete(entityLogicalName, id); return (object?)null; });
    }

    public EntityCollection RetrieveMultiple(QueryBase query)
    {
        return InvokeOperation(nameof(RetrieveMultiple), () => _inner.RetrieveMultiple(query));
    }

    public OrganizationResponse Execute(OrganizationRequest request)
    {
        return InvokeOperation(nameof(Execute), () => _inner.Execute(request));
    }

    public void Associate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
    {
        InvokeOperation(nameof(Associate), () => 
        { 
            _inner.Associate(entityName, entityId, relationship, relatedEntities);
            return (object?)null;
        });
    }

    public void Disassociate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
    {
        InvokeOperation(nameof(Disassociate), () => 
        { 
            _inner.Disassociate(entityName, entityId, relationship, relatedEntities);
            return (object?)null;
        });
    }

    private T InvokeOperation<T>(string operation, Func<T> action)
    {
        var startedAt = Stopwatch.GetTimestamp();
        using var activity = ObservabilityTelemetry.ActivitySource.StartActivity($"Dataverse.{operation}", ActivityKind.Client);

        try
        {
            var result = action();
            var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

            activity?.SetTag("appName", Constants.PortalWebApi);
            activity?.SetTag("dataverse.operation", operation);
            activity?.SetTag("dataverse.duration.ms", elapsedMs);
            activity?.SetStatus(ActivityStatusCode.Ok);
            ObservabilityTelemetry.RecordDependency("dataverse", operation, "IOrganizationService", elapsedMs, failed: false);

            _logger.LogInformation("Dataverse operation {Operation} succeeded in {ElapsedMs} ms", operation, elapsedMs);
            return result;
        }
        catch (Exception ex)
        {
            var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;
            activity?.SetTag("appName", Constants.PortalWebApi);
            activity?.SetTag("dataverse.operation", operation);
            activity?.SetTag("dataverse.duration.ms", elapsedMs);
            activity?.SetTag("dataverse.error", true);
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            ObservabilityTelemetry.RecordDependency("dataverse", operation, "IOrganizationService", elapsedMs, failed: true);

            _logger.LogError(ex, "Dataverse operation {Operation} failed in {ElapsedMs} ms", operation, elapsedMs);
            throw;
        }
    }
}
