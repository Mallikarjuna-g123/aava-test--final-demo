using OpenTelemetry.Trace;

namespace FIJI.Portal.WebAPI.Integration.Observability;

/// <summary>
/// Drops known Azure Identity credential token acquisition spans to reduce trace noise.
/// All other spans follow parent-based sampling semantics with an always-on root sampler.
/// </summary>
public sealed class AzureIdentitySpanExclusionSampler : Sampler
{
    private static readonly HashSet<string> ExcludedSpanNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "DefaultAzureCredential.GetToken",
        "ManagedIdentityCredential.GetToken",
        "EnvironmentCredential.GetToken",
        "WorkloadIdentityCredential.GetToken",
        "AzureCliCredential.GetToken",
        "VisualStudioCredential.GetToken"
    };

    private readonly Sampler fallbackSampler;

    public AzureIdentitySpanExclusionSampler()
        : this(new ParentBasedSampler(new AlwaysOnSampler()))
    {
    }

    public AzureIdentitySpanExclusionSampler(Sampler fallbackSampler)
    {
        this.fallbackSampler = fallbackSampler ?? throw new ArgumentNullException(nameof(fallbackSampler));
    }

    public override SamplingResult ShouldSample(in SamplingParameters samplingParameters)
    {
        if (!string.IsNullOrEmpty(samplingParameters.Name) && ExcludedSpanNames.Contains(samplingParameters.Name))
        {
            return new SamplingResult(SamplingDecision.Drop);
        }

        return fallbackSampler.ShouldSample(in samplingParameters);
    }

}
