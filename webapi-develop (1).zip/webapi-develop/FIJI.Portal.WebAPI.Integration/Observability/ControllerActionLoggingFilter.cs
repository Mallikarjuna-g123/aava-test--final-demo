using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using FIJI.Portal.WebAPI.Integration.Utilities;

namespace FIJI.Portal.WebAPI.Integration.Observability;

/// <summary>
/// Global action filter that logs controller action start, completion, and failure
/// with timing and correlation context for all controllers.
/// </summary>
public sealed class ControllerActionLoggingFilter : IAsyncActionFilter
{
    private readonly ILogger<ControllerActionLoggingFilter> _logger;

    public ControllerActionLoggingFilter(ILogger<ControllerActionLoggingFilter> logger)
    {
        _logger = logger;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var descriptor = context.ActionDescriptor as ControllerActionDescriptor;
        var controllerName = descriptor?.ControllerName ?? "Unknown";
        var actionName = descriptor?.ActionName ?? "Unknown";
        var correlationId = context.HttpContext.TraceIdentifier;
        var method = context.HttpContext.Request.Method;
        var path = context.HttpContext.Request.Path.Value ?? string.Empty;
        var argumentCount = context.ActionArguments.Count;

        using (_logger.BeginScope(new Dictionary<string, object>
        {
            ["CorrelationId"] = correlationId,
            ["Controller"] = controllerName,
            ["Action"] = actionName,
            ["appName"] = Constants.PortalWebApi
        }))
        {
            _logger.LogInformation(
                "Action started: {Controller}.{Action} ({Method} {Path}), args: {ArgumentCount}",
                controllerName, actionName, method, path, argumentCount);

            var startedAt = Stopwatch.GetTimestamp();
            ActionExecutedContext executedContext;

            try
            {
                executedContext = await next();
            }
            catch (Exception ex)
            {
                var failedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;
                Activity.Current?.SetTag("action.controller", controllerName);
                Activity.Current?.SetTag("action.name", actionName);
                Activity.Current?.SetTag("action.duration_ms", failedMs);
                Activity.Current?.SetTag("action.error", true);
                Activity.Current?.SetTag("appName", Constants.PortalWebApi);
                ObservabilityTelemetry.RecordAction(controllerName, actionName, StatusCodes.Status500InternalServerError, failedMs, failed: true);

                _logger.LogError(ex,
                    "Action failed: {Controller}.{Action} in {ElapsedMs:F1} ms",
                    controllerName, actionName, failedMs);
                throw;
            }

            var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;
            var statusCode = ResolveStatusCode(executedContext, context.HttpContext.Response.StatusCode);

            Activity.Current?.SetTag("action.controller", controllerName);
            Activity.Current?.SetTag("action.name", actionName);
            Activity.Current?.SetTag("action.duration_ms", elapsedMs);
            Activity.Current?.SetTag("action.status_code", statusCode);
            Activity.Current?.SetTag("appName", Constants.PortalWebApi);
            ObservabilityTelemetry.RecordAction(
                controllerName,
                actionName,
                statusCode,
                elapsedMs,
                failed: (executedContext.Exception != null && !executedContext.ExceptionHandled) || statusCode >= StatusCodes.Status500InternalServerError);

            if (executedContext.Exception != null && !executedContext.ExceptionHandled)
            {
                _logger.LogError(executedContext.Exception,
                    "Action error: {Controller}.{Action} => {StatusCode} in {ElapsedMs:F1} ms",
                    controllerName, actionName, statusCode, elapsedMs);
            }
            else
            {
                _logger.LogInformation(
                    "Action completed: {Controller}.{Action} => {StatusCode} in {ElapsedMs:F1} ms (appName: {appName})",
                    controllerName, actionName, statusCode, elapsedMs, Constants.PortalWebApi);
            }
        }
    }

    private static int ResolveStatusCode(ActionExecutedContext executedContext, int fallback)
    {
        if (executedContext.Result is ObjectResult objectResult && objectResult.StatusCode.HasValue)
            return objectResult.StatusCode.Value;

        if (executedContext.Result is StatusCodeResult statusCodeResult)
            return statusCodeResult.StatusCode;

        return fallback;
    }
}
