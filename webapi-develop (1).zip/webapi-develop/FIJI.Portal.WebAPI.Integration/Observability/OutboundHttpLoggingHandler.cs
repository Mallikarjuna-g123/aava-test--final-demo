using System.Diagnostics;

namespace FIJI.Portal.WebAPI.Integration.Observability;

/// <summary>
/// Logs outbound HTTP requests and responses with timing for any HttpClient
/// registered through IHttpClientFactory with this handler.
/// </summary>
public sealed class OutboundHttpLoggingHandler : DelegatingHandler
{
    private readonly ILogger<OutboundHttpLoggingHandler> _logger;

    public OutboundHttpLoggingHandler(ILogger<OutboundHttpLoggingHandler> logger)
    {
        _logger = logger;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var method = request.Method.Method;
        var uri = request.RequestUri?.AbsoluteUri ?? "unknown";
        var host = request.RequestUri?.Host ?? "unknown";

        _logger.LogInformation("Outbound HTTP started: {Method} {Host}{Path}",
            method, host, request.RequestUri?.PathAndQuery);

        var startedAt = Stopwatch.GetTimestamp();

        try
        {
            var response = await base.SendAsync(request, cancellationToken);
            var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

            Activity.Current?.SetTag("http.outbound.method", method);
            Activity.Current?.SetTag("http.outbound.host", host);
            Activity.Current?.SetTag("http.outbound.status_code", (int)response.StatusCode);
            Activity.Current?.SetTag("http.outbound.duration_ms", elapsedMs);
            Activity.Current?.SetTag("appName", Utilities.Constants.PortalWebApi);
            ObservabilityTelemetry.RecordDependency("http", method, host, elapsedMs, failed: !response.IsSuccessStatusCode);

            _logger.LogInformation("Outbound HTTP completed: {Method} {Host}{Path} => {StatusCode} in {ElapsedMs:F1} ms",
                method, host, request.RequestUri?.PathAndQuery, (int)response.StatusCode, elapsedMs);

            return response;
        }
        catch (Exception ex)
        {
            var elapsedMs = Stopwatch.GetElapsedTime(startedAt).TotalMilliseconds;

            Activity.Current?.SetTag("http.outbound.method", method);
            Activity.Current?.SetTag("http.outbound.host", host);
            Activity.Current?.SetTag("http.outbound.error", true);
            Activity.Current?.SetTag("http.outbound.duration_ms", elapsedMs);
            Activity.Current?.SetTag("appName", Utilities.Constants.PortalWebApi);
            ObservabilityTelemetry.RecordDependency("http", method, host, elapsedMs, failed: true);

            _logger.LogError(ex, "Outbound HTTP failed: {Method} {Host}{Path} in {ElapsedMs:F1} ms",
                method, host, request.RequestUri?.PathAndQuery, elapsedMs);

            throw;
        }
    }
}
