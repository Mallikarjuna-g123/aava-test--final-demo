using System.Diagnostics;
using FIJI.Portal.WebAPI.Integration.Utilities;
using OpenTelemetry;

namespace FIJI.Portal.WebAPI.Integration.Observability;

/// <summary>
/// Ensures all emitted Activities carry a stable appName tag for downstream queryability.
/// </summary>
public sealed class AppNameActivityProcessor : BaseProcessor<Activity>
{
    public override void OnStart(Activity data)
    {
        if (data is null)
        {
            return;
        }

        var existing = data.GetTagItem("appName")?.ToString();
        if (string.IsNullOrWhiteSpace(existing))
        {
            data.SetTag("appName", Constants.PortalWebApi);
        }
    }
}