﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class ProductComponent_RemoveAssociatedModel
    {
        public string? ProductComponentId { get; set; }
        public string? PlatformId { get; set; }
    }

    public class UpdateRemoveAssociatedModelResponse
    {
        public string Message { get; set; }
    }
}
