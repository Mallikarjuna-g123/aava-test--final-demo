﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace Project
    {
        public class ECNInceptionCreationRequest
        {
            public List<string> SKUNumbers { get; set; }
            public string CustomerRequestDate { get; set; }
            public List<int>? CustomerPOCPreference { get; set; }
            public bool? ISOpinel { get; set; }
            public string AdditionalEmail { get; set; }
            public bool ISAcceptedTermCondition { get; set; }
            public string? Comments { get; set; }
            public string UpdateServiceDetails { get; set; }
            public Guid FspmId { get; set; }
            public Guid PortalUserId { get; set; }
            public List<Guid>? Localizations { get; set; }
            public List<Guid>? RemoveHardwares { get; set; }
            public List<Guid>? AddHardwares { get; set; }
            public List<Guid>? RemoveServices { get; set; }
            public List<Guid>? UpdateServices { get; set; }
            public List<Guid>? AddServices { get; set; }
            public Guid ProjectId { get; set; }
            public Guid CustomerId { get; set; }
        }
    }

}
