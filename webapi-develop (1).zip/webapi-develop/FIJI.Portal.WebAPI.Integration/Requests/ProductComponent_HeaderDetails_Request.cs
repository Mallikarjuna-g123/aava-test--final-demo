﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class ProductComponent_HeaderDetails_Request
    {
        public Guid? CustomerId { get; set; }

        public Guid? ProductComponentId { get; set; }

        public Guid? ServiceRevisionId { get; set; }
    }
}
