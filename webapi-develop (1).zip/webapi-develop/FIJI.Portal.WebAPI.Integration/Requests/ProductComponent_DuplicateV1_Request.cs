﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class ProductComponent_DuplicateV1_Request
    {
        public string ProductComponentId { get; set; }
        public string Description { get; set; }
        public string PortalUserId { get; set; }
        public string? PlatformId { get; set; }
    }
}
