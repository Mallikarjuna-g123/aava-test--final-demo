﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class CreateProjectRequest
    {
        public string ModelId { get; set; }
        public string PortalUserId { get; set; }
        public bool IsNewProject { get; set; }
        public string CustomerId { get; set; }
        public int ProjectType { get; set; }
        public int ProductType { get; set; }
        public int OcciId { get; set; }
        public int ProjectSource { get; set; }
        public int CreatedFrom { get; set; }
        public List<BOMRequest> Services { get; set; }

    }
}
