namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class GeneratePdfRequest
    {
        public string HtmlContent { get; set; } = string.Empty;
        public bool Landscape { get; set; } = false;
        public string? Format { get; set; } = "A4";
        public string? HeaderTemplate { get; set; }
        public string? FooterTemplate { get; set; }
        public bool DisplayHeaderFooter { get; set; } = false;
        public double? MarginTop { get; set; }
        public double? MarginBottom { get; set; }
        public double? MarginLeft { get; set; }
        public double? MarginRight { get; set; }
    }
}
