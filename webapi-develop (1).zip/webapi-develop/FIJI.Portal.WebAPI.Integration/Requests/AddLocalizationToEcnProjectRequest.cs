﻿using System.Security.Policy;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Localization
    {
        public string localizationId { get; set; }
    }

    public class AddLocalizationToEcnProjectRequest
    {
        public string projectId { get; set; }
        public List<Localization> localizations { get; set; }
    }

}
