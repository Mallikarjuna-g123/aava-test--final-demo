﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace ProductComponent
    {
        public class ProductComponent_GetBiosConfigDetails_Request
        {
            public Guid PlatformId { get; set; }

        }
    }

}