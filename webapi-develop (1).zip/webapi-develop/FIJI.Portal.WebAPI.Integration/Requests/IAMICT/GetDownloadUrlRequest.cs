﻿using DocumentFormat.OpenXml.Spreadsheet;
using System.Text.Json.Serialization;
using static FIJI.Portal.FileReception.Model.BlobFile;

namespace FIJI.Portal.WebAPI.Integration.Requests.IAMICT
{
    public class GetDownloadUrlRequest
    {
        [JsonPropertyName("fileUrl")]
        public required string FileUrl { get; set; }
    }
}
