﻿using System.Text.Json.Serialization;

namespace FIJI.Portal.WebAPI.Integration.Requests.IAMICT
{
    public class SetSHA256Request
    {
        [JsonPropertyName("fileId")]
        public required Guid FileId { get; set; }

        [JsonPropertyName("sha256")]
        public required string SHA256 { get; set; }

    }
}
