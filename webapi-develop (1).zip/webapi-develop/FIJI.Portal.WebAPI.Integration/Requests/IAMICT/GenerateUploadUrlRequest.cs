﻿using DocumentFormat.OpenXml.Spreadsheet;
using System.Text.Json.Serialization;
using static FIJI.Portal.FileReception.Model.BlobFile;

namespace FIJI.Portal.WebAPI.Integration.Requests.IAMICT
{
    public class GenerateUploadUrlRequest
    {
        [JsonPropertyName("accountId")]
        public required string AccountId { get; set; }

        [JsonPropertyName("fileName")]
        public required string FileName { get; set; }

        [JsonPropertyName("fileType")]
        public required eFileType FileType { get; set; }
    }
}
