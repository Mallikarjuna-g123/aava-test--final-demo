﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace Project
    {
        public class SubmitProjectRequest
        {
            public string? ModelId { get; set; }
            public string? ProjectId { get; set; }
            public string? ProjectName { get; set; }
            public string? RequestName { get; set; }
            public string? CustomerRequestDate { get; set; }
            public List<string>? CustomerPOCPreference { get; set; }
            public string? AdditionalEmail { get; set; }
            public string? Comments { get; set; }
            public bool? IsOpinel { get; set; }
            public List<string>? Localizations { get; set; }
            public List<Services> Services { get; set; }
            public bool? IsTermsAndConditionAccepted { get; set; }
            public string? status { get; set; }
            public string? ModifiedByPortalContact { get; set; }
        }

        public class Services
        {
            public string ProductComponentId { get; set; }
            public string ServiceRevisionId { get; set; }
        }
    }
}
