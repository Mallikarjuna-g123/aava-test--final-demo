﻿using FIJI.Portal.WebAPI.Integration.Model;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class CreateUpdateBomItemRquest
    {
        public string ProjectId { get; set; }
        public List<BOMRequest>? NewService { get; set; }
        public List<RemoveBOMService>? RemoveService { get; set; }
        public List<UpdateBOMService>? UpdateServices { get; set; }
        public string? ModifiedByPortalContact { get; set; }
    }

    public class RemoveBOMService
    {
        public string BomId { get; set; }
    }

    public class UpdateBOMService
    {
        public Guid ProductComponentId { get; set; }
        public Guid BomId { get; set; }
    }
}
