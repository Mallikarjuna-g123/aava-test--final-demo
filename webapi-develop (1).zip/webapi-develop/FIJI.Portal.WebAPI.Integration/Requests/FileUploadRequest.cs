﻿using static FIJI.Portal.FileReception.Model.BlobFile;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class FileUploadRequest
    {
        public string AccountId { get; set; }
        public string FileName { get; set; }
        public Guid ProjectID { get; set; }
        public IFormFile FileContent { get; set; }
        public eFileType? FileType { get; set; }
    }

}
