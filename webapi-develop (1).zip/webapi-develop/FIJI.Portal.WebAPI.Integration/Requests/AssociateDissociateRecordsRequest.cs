﻿using Microsoft.Xrm.Sdk;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class AssociateDissociateRecordsRequest
    {
        public string RelationName { get; set; }
        public EntityReference Target { get; set; }
        public List<EntityReference> RelatedEntities { get; set; }

    }
}
