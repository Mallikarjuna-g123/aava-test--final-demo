﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class TaskRequest
    {
        public string? TimeZone { get; set; }
        public string TaskType { get; set; }
        public Guid? Contact { get; set; }
        public int? StateCode { get; set; }
        public Page? Page { get; set; }
        public Sort? Sort { get; set; }
        public Filters? Filters { get; set; }
        public List<string>? TaskIds { get; set; }
    }

    public class Page
    {
        public int? PageNumber { get; set; }
        public int? PageSize { get; set; }
    }

    public class Sort
    {
        public string? ColumnName { get; set; }
        public int? SortOrder { get; set; }
    }

    public class Filters
    {
        public string? Search { get; set; }
        public string? Factory { get; set; }
        public DateTime? StartDateRange { get; set; }
        public DateTime? EndDateRange { get; set; }
        public string? Statuscode { get; set; }
        public string? SearchMode { get; set; }
    }

    public class UpdateTasksRequest
    {
        public List<Update> UpdateTasks { get; set; }
        public int eTrigger { get; set; }
        public string ModifiedByPortalContact { get; set; }
        public bool CommentOnlyUpdate { get; set; }
    }

    public class Update
    {
        public Guid Id { get; set; }
        public int? Fiji_pstticketnumber { get; set; }
        public string? Fiji_pstticketurl { get; set; }
        public int? Fiji_hpdelaydays { get; set; }
        public string? Description { get; set; }
        public int? Statuscode { get; set; }
    }
}