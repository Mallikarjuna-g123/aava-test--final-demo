﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class AuditSummaryRequest
    {
        public string? EntityName { get; set; }
        public int? TimeRange { get; set; }
        public string? ExcludeUser { get; set; }
    }
}
