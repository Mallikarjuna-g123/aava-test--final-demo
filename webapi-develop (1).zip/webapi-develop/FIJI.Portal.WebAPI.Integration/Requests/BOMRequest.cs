﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class BOMRequest
    {
        public Guid? ProductComponentId { get; set; }
        public int Type { get; set; }
        public string ComponentTypeServiceNumber { get; set; }
        public bool CameFromOCI { get; set; }
        public int Quantity { get; set; }
    }
}
