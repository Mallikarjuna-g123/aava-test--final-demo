﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace ServiceRevision
    {
        public class ServiceRevisionUpdateRequest
        {
            public Guid? ServiceRevisionId { get; set; }
            public int Action { get; set; }
            public string? Configuration { get; set; }
            public Guid? BomId { get; set; }
            public Guid? ProductComponentId { get; set; }
            public Guid? ComponentTypeId { get; set; }
            public string? RequireCustomAssetTag { get; set; }
            public string? Placement { get; set; }
            public string? Orientation { get; set; }
            public string? CustomAssetTag { get; set; }
            public Guid PlacementId { get; set; }
            public Guid ModelId { get; set; }
            public Guid? sourceComponentTypeid { get; set; }
            public bool TriggerNotification { get; set; }
            public string? AutomationFlagName { get; set; }
            public Guid? PortalUserId{ get; set; }
            public string? FileId { get; set; }
        }
    }

}
