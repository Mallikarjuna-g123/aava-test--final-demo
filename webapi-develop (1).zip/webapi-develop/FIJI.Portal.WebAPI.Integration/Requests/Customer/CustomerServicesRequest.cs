﻿namespace FIJI.Portal.WebAPI.Integration.Requests.Customer
{
    public class CustomerServicesRequest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public Guid CustomerId { get; set; }
        public string? SearchText { get; set; }
        public List<string>? Models { get; set; }
        public List<int>? LatestServiceStatusCode { get; set; }
        public List<Guid>? Category { get; set; }
        public List<Guid>? ComponenttypeIDs { get; set; }
        public string? CreatedFrom { get; set; }
        public string? CreatedTill { get; set; }
        public string? LastModifiedFrom { get; set; }
        public string? LastModifiedTill { get; set; }
        public string? EndOfLifeFrom { get; set; }
        public string? EndOfLifeTill { get; set; }
        public int? Timezone { get; set; }
        public bool ShowAll { get; set; }
    }
}
