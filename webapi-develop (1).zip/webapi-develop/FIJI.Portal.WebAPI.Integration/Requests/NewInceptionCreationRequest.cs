﻿using DocumentFormat.OpenXml.Math;

namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace Project
    {
        public class NewInceptionCreationRequest
        {
            public List<string> OciId { get; set; }
            public Guid ModelId { get; set; }
            public Guid PortalUserId { get; set; }
            public bool IsNewProject { get; set; }
            public Guid CustomerId { get; set; }

            public int ProjectType { get; set; }

            public int ProductType { get; set; }

            public int ProjectSource { get; set; }

            public string CustomerRequestDate { get; set; }

            public List<int> CustomerPOCPreference { get; set; }

            public Guid? FspmId { get; set; }

            public string? AdditionalEmail { get; set; }

            public string? Comments { get; set; }

            public bool IsOpinel { get; set; }

            public bool IsAcceptedTermCondition { get; set; }

            public List<Guid> Localizations { get; set; }

            public List<NewInceptionServicesDtl> services { get; set; }

        }

        public class NewInceptionServicesDtl
        {
            public Guid? ProductComponentId { get; set; }
            public int Quantity { get; set; }
            public string? OciId { get; set; }

            public string? ExternalId { get; set; }
        }
    }

}
