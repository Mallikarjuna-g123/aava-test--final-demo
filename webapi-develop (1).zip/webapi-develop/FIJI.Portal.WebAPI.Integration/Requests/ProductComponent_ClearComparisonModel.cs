﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class ProductComponent_ClearComparisonModel
    {
        public string? ProductComponentId { get; set; }
    }

    public class UpdateClearComparisonModelResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
