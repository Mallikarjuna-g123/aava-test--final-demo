﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class BookingRequest
    {
        public int TimeZone { get; set; }
        public string Tab { get; set; }
        public Guid Contact { get; set; }
        public Page? Page { get; set; }
        public Sort? Sort { get; set; }
        public BookingFilters? Filter { get; set; }
    }

    public class BookingFilters
    {
        public string? Factory { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool? Attended { get; set; }
    }
}