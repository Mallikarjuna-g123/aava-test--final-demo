﻿namespace FIJI.Portal.WebAPI.Integration.Requests.Project
{
    public class ProjectDuplicateRequest
    {
        public Guid SourceRequestId { get; set; }
        public string NewRequestName { get; set; }
        public Guid ContactId { get; set; }
    }
}
