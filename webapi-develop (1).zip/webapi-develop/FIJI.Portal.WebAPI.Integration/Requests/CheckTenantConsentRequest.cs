﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class CheckTenantConsentRequest
    {
        public string TenantId { get; set; }
        public string TenantDomain { get; set; }
    }
}
