﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class ProjectScopeChangeRequest
    {
        public Sections? Sections { get; set; }

    }

    public class BomItem
    {
        public string? BomId { get; set; }
        public string? ExternalId { get; set; }
        public string? PortalDescription { get; set; }
    }

    public class Sections
    {
        public List<BomItem> Add { get; set; } = new List<BomItem>();
        public List<BomItem> Remove { get; set; } = new List<BomItem>();
        public List<BomItem> Reuse { get; set; } = new List<BomItem>();
        public List<BomItem> Customize { get; set; } = new List<BomItem>();
        public List<BomItem> Edit { get; set; } = new List<BomItem>();
    }
}
