﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace ProductComponent
    {
        public class ProductComponent_Duplicate_Request
        {
            public Guid ProductComponentId { get; set; }
            public Guid PortalUserId { get; set; }
        }
    }

}
