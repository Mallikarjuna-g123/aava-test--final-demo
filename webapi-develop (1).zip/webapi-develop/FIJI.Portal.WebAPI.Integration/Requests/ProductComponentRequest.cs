﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class ProductComponentRequest
    {
        public string ComponentTypeId { get; set; }
        public string? PortalUserId { get; set; }
        public string PartNumber { get; set; }
        public Guid? SourceComponentTypeid { get; set; }
        public string CustomerName { get; set; }
        public string CustomerId { get; set; }
        public bool CanBeUsedAcrossCustomers { get; set; }
        public string ModelName { get; set; }
        public string? BiosRevision { get; set; }
        public string ModelId { get; set; }
        public string QuestionnaireDetails { get; set; }
        public string StatusCodeServiceRevision { get; set; }
        public string? RequireCustomAssetTag { get; set; }
        public string? Placement { get; set; }
        public int? Orientation { get; set; }
        public string? CustomAssetTag { get; set; }
        public string? BomId { get; set; }
        public int Quantity { get; set; }
        public string ProjectId { get; set; }
        public string? AutomationFlagName { get; set; }
        public string? FileId { get; set; }
        public string? ServiceDescription { get; set; }

    }
}
