﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class TransformAPIAY103AVServiceRequest
    {
        public Guid? ConfigurationId { get; set; }

        public string? AccountId { get; set; }

        public string? ContactId { get; set; }

        public Guid? ServiceRevisionId { get; set; }

        public int? TypeCode { get; set; }

        public BCUDataResponse? BCUData { get; set; }

        public List<ValueListItem>? ValueList { get; set; }
    }

    public class ValueListItem
    {
        public string? Id { get; set; }
        public string? Value { get; set; }
    }

    public class BCUDataResponse
    { 
        public string? BCUFilePath { get; set; }

        public string? KeyboardLocalization { get; set; }

        public string? PasswordMinLength { get; set; }

        public string? AdministratorPassword { get; set; }

        public string? PostPowerOnPassword { get; set; }

        public bool? HPSureAdmin { get; set; }

        public bool? ProvisionSecurePlatformManagementKey { get; set; }

        public string? HPSureAdminScriptFilePath { get; set; }

    }

    public class QuestionnaireDetails
    {
        public string? ScreenNumber { get; set; }
        public bool? IsStandardBIOSSetting { get; set; }
        public bool? IsBCUSetting { get; set; }
        public List<ValueListItem>? ValueList { get; set; }
        public string? AdditionalRequirements { get; set; }
        public List<FileDetail>? Files { get; set; }
        public BCUData? BCUData { get; set; }
        public Guid? ConfigurationId { get; set; }
        public string? CustomerId { get; set; }
        public string? AutomationFlagName { get; set; }
    }

    public class BCUData
    {
        public FileDetail? BCUFile { get; set; }
        public string? KeyboardLocalization { get; set; }
        public string? PasswordMinLength { get; set; }
        public string? AdministratorPassword { get; set; }
        public string? PostPowerOnPassword { get; set; }
        public bool? HPSureAdmin { get; set; }
        public bool? ProvisionSecurePlatformManagementKey { get; set; }
        public FileDetail? HPSureAdminScriptFile { get; set; }
    }

    public class FileDetail
    {
        public string? FileName { get; set; }
        public string? Description { get; set; }
    }

}
