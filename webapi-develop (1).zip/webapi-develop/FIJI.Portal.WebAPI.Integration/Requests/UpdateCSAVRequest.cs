﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class UpdateCSAVRequest
    {
        public bool? ExtendModel { get; set; }

        public string ProductComponentId { get; set; }

        public string ModelId { get; set; }

        public string ModelName { get; set; }

        public string BomId { get; set; }

        public bool requiredAdditionalInfo { get; set; }
    }
}
