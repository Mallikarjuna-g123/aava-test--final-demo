﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    namespace Project
    {
        public class GetProjectByRequestIDRequest
        {
            public string RequestID { get; set; }
        }
    }

}
