﻿namespace FIJI.Portal.WebAPI.Integration.Requests
{
    public class Filter
    {
        public string? factory { get; set; }
    }

    public class ScheduleRequest
    {
        public string? timeZone { get; set; }
        public string? contact { get; set; }
        public Page? page { get; set; }
        public Sort? sort { get; set; }
        public Filter? filter { get; set; }
    }
}