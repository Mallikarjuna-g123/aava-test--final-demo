# FIJI Portal Integration Solution

## 1. Project Overview

This repository contains a multi-project .NET solution for FIJI portal integrations:

- `FIJI.Portal.WebAPI.Integration` (`net10.0`): ASP.NET Core Web API for portal operations (projects, BOM, product components, OCI integration, and Dataverse-backed workflows).
- `FIJI.Portal.FileReception.WinService` (`net8.0`): Windows worker service that processes Service Bus messages for file verification, malware scanning, and metadata updates.
- `FIJI.Portal.FileReception.Commons`: shared helpers, models, and constants used by both applications.

## 2. Project Structure

The solution file `FIJI.Portal.Integration.sln` contains three projects:

- `FIJI.Portal.WebAPI.Integration`
  - `Program.cs`: app startup, DI, authentication, OpenTelemetry/Azure Monitor setup, middleware pipeline.
  - `Controllers/`: API endpoints and HTTP-level error handling.
  - `Model/`: business/domain operations (many use `OperationTraceHelper`).
  - `Observability/`: central observability components:
    - `CorrelationAndRequestLoggingMiddleware`
    - `ControllerActionLoggingFilter`
    - `OperationTraceHelper`
    - `ObservabilityTelemetry`
    - `OrganizationServiceLoggingProxy`
    - `OutboundHttpLoggingHandler`
    - `AzureIdentitySpanExclusionSampler`
  - `Utilities/`, `Integration/`, `Requests/`, `Responses/`: shared utilities, integrations, request/response contracts.

- `FIJI.Portal.FileReception.WinService`
  - `Program.cs`: Windows service host + Application Insights worker telemetry.
  - `Worker.cs`: startup, config binding, queue listener bootstrapping.
  - `ServiceBus.cs`: Service Bus processors and message/error handlers.
  - `FileVerification.cs`: queue message processing, file validation, Dataverse updates.
  - `Wimg/`: WIM-related file/image helpers and interop wrappers.

- `FIJI.Portal.FileReception.Commons`
  - `Helpers/`: reusable helpers (Dataverse, authentication, storage, logging, notification).
  - `Model/`: shared configuration and domain model types.
  - `Constants.cs`: shared constants.

### Documentation Index (All Markdown Files)

Use this index to quickly navigate project documentation by audience and purpose.

Product owners, release managers, and team leads:

- Branching/deployment governance: [Branching_Deployment_Strategy.md](Branching_Deployment_Strategy.md)

Developers and testers (WebAPI guidance set):

- Guidance index: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/README.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/README.md)
- Project structure deep-dive: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/01-Project-Structure.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/01-Project-Structure.md)
- Architectural conventions: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/02-Architectural-Conventions.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/02-Architectural-Conventions.md)
- Technology stack: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/03-Technology-Stack.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/03-Technology-Stack.md)
- Code/API best practices: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/04-Code-and-API-Best-Practices.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/04-Code-and-API-Best-Practices.md)

Detailed implementation instructions:

- Controller/endpoint patterns: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/api-controller-pattern.instructions.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/api-controller-pattern.instructions.md)
- Dataverse integration guidance: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/dataverse-integration.instructions.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/dataverse-integration.instructions.md)
- Observability/logging guidance: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/observability-and-logging.instructions.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/observability-and-logging.instructions.md)
- Security/configuration guidance: [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/security-and-config.instructions.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/security-and-config.instructions.md)

Maintainers and AI-assisted documentation workflows:

- Observability reviewer agent definition: [.github/agents/fiji-observability-reviewer.agent.md](.github/agents/fiji-observability-reviewer.agent.md)
- Project guidance update prompt: [.github/prompts/project-guidance-update.prompt.md](.github/prompts/project-guidance-update.prompt.md)
- Observability update prompt: [.github/prompts/observability-update.prompt.md](.github/prompts/observability-update.prompt.md)
- Controller guidance update prompt: [.github/prompts/controller-guidance-update.prompt.md](.github/prompts/controller-guidance-update.prompt.md)
- API controller docs update prompt: [.github/prompts/api-controller-docs-update.prompt.md](.github/prompts/api-controller-docs-update.prompt.md)

## 3. Observability Summary (Audience: Product Owners)

### What is implemented

- Request correlation: each API request gets a correlation ID (`X-Correlation-ID`) that is propagated through logs and API error responses.
- Structured operational logging: middleware, controller filter, model operations, outbound dependencies, and unhandled exceptions are logged with context.
- Distributed tracing and dependency telemetry:
  - OpenTelemetry + Azure Monitor are enabled in the Web API.
  - Dataverse calls are wrapped and measured via an `IOrganizationService` proxy.
  - Outbound HTTP calls from the named `OCI` client are instrumented.
- Custom metrics: counters and histograms are emitted for requests, controller actions, internal operations, dependencies, and retries.
- Worker telemetry: the Windows service is integrated with Application Insights Worker Service and emits telemetry traces during queue processing.

### Why it matters

- Faster issue triage with end-to-end correlation IDs.
- Better reliability monitoring with timings, failures, and retry visibility.
- Easier root-cause analysis across API actions and downstream dependencies.

## 4. Architecture Overview

The Web API observability path is layered:

- `CorrelationAndRequestLoggingMiddleware` initializes correlation and request-level timing.
- `ControllerActionLoggingFilter` tracks controller action execution/failure.
- Domain/model methods use `OperationTraceHelper` for operation spans, scoped logs, duration, and failure metrics.
- Dataverse and HTTP dependencies are instrumented via dedicated wrappers/handlers.
- OpenTelemetry data is exported through Azure Monitor integration.

```mermaid
flowchart LR
    Client[Client] --> MW[CorrelationAndRequestLoggingMiddleware]
    MW --> AF[ControllerActionLoggingFilter]
    AF --> CTL[Controllers]
    CTL --> OP[OperationTraceHelper in Models/Utilities]
    OP --> DV[OrganizationServiceLoggingProxy - Dataverse]
    OP --> HTTP[OutboundHttpLoggingHandler - OCI HttpClient]
    MW --> MET[ObservabilityTelemetry - request metrics]
    AF --> MET2[ObservabilityTelemetry - action metrics]
    OP --> MET3[ObservabilityTelemetry - operation/retry metrics]
    DV --> MET4[ObservabilityTelemetry - dependency metrics]
    HTTP --> MET4
    MW --> OTEL[OpenTelemetry + Azure Monitor]
    AF --> OTEL
    OP --> OTEL
    DV --> OTEL
    HTTP --> OTEL
```

## 5. Logging (Audience: Developers)

### Frameworks and components

- `Microsoft.Extensions.Logging` (default ASP.NET Core logging abstractions/providers).
- JWT auth event logging in `Program.cs` (`OnAuthenticationFailed`, `OnChallenge`).
- Global exception handler logs unhandled exceptions and returns JSON with `correlationId`.
- Scope-based logging in middleware/filter/helpers to enrich logs with operation context.

### Where logs are produced

- Incoming request start/finish with status and elapsed time.
- Controller action start/completion/failure with controller/action names.
- Domain/model operations through `OperationTraceHelper`:
  - `... started`
  - `... completed in X ms`
  - `... failed in X ms`
- Dataverse operation success/failure/duration in `OrganizationServiceLoggingProxy`.
- Outbound HTTP success/failure/duration in `OutboundHttpLoggingHandler`.
- Worker service startup and queue processing traces (`TelemetryClient.TrackTrace`).

### Configuration highlights

- Web API logging filters in `Program.cs` reduce noise from identity/platform categories (`MSAL`, `Microsoft.Identity`, `Azure.Identity`, `Azure.Core`, etc.).
- Web API appsettings defines `Logging:LogLevel` defaults.
- Worker service appsettings defines `Logging:LogLevel` and `EventLog` settings.

### How to extend logging safely

1. Prefer structured templates with named placeholders.
2. Add operation-level instrumentation via `OperationTraceHelper` instead of ad-hoc timing code.
3. Include business identifiers that are safe to log (for example IDs, not secrets or tokens).
4. Preserve correlation by using existing request scope and `HttpContext.TraceIdentifier` in API responses/logs.

## 6. Tracing (Audience: Developers)

### Tools/libraries used

- `Azure.Monitor.OpenTelemetry.AspNetCore`
- `OpenTelemetry.Trace`
- `System.Diagnostics.ActivitySource` (`ObservabilityTelemetry.ActivitySource`)

### Trace generation and propagation

- OpenTelemetry is wired in Web API startup via:
  - `AddOpenTelemetry()`
  - `UseAzureMonitor()`
  - Custom sampler registration in tracing pipeline.
- `OperationTraceHelper` starts internal spans per business/model operation.
- `OrganizationServiceLoggingProxy` creates client spans for Dataverse operations.
- Middleware sets correlation and HTTP tags on current activity.
- Action filter adds controller/action tags and status tags.

### Sampling behavior

- `AzureIdentitySpanExclusionSampler` drops known Azure Identity token acquisition spans to reduce trace noise.
- Other spans use parent-based, always-on root semantics through the fallback sampler.

## 7. Metrics

### Implemented metrics (Web API)

Custom metrics are defined in `ObservabilityTelemetry` using `System.Diagnostics.Metrics`:

- Request: `http.server.request.count`, `http.server.request.failure.count`, `http.server.request.duration.ms`
- Action: `app.action.count`, `app.action.failure.count`, `app.action.duration.ms`
- Operation: `app.operation.count`, `app.operation.failure.count`, `app.operation.duration.ms`
- Dependency: `app.dependency.count`, `app.dependency.failure.count`, `app.dependency.duration.ms`
- Retry: `app.retry.attempt.count`, `app.retry.exhausted.count`

### Current usage notes

- Retry metrics are currently emitted from retry logic in `Project` (`ExecuteWithRetryAsync`).
- No Prometheus endpoint or dedicated metrics scrape endpoint is implemented in this repository.

## 8. Validation & Testing (Audience: Testers)

### How to verify observability behavior

1. Start the Web API and call any endpoint with a custom header `X-Correlation-ID`.
2. Confirm the same correlation ID appears in:
   - Response header `X-Correlation-ID`.
   - API error payloads (`correlationId`) on handled failures.
   - Application logs for request/action/operation entries.
3. Trigger an endpoint failure path and verify:
   - Error logs contain controller/action and elapsed time.
   - Global exception response includes `correlationId` for unhandled faults.
4. Call OCI-integrated endpoints and verify outbound dependency logging.
5. Execute Dataverse-backed operations and verify Dataverse dependency logs/trace spans.

### Suggested scenarios

- Authentication failure (missing/invalid bearer token): verify JWT warning logs.
- Controller exception path: verify `Action failed` / `Action error` and 5xx behavior.
- Retry path in project operations (transient failure simulation): verify retry warning logs and retry metrics counters.

### Test asset status

- No dedicated unit/integration test project is present in this repository at the time of writing.

## 9. Configuration

### Web API (`FIJI.Portal.WebAPI.Integration/appsettings*.json`)

Relevant observability and related keys:

- `Logging:LogLevel:*`
- `APPLICATIONINSIGHTS_CONNECTION_STRING`

Also present (non-observability runtime keys): JWT, Dataverse, storage, queue, and service bus settings.

### Worker Service (`FIJI.Portal.FileReception.WinService/appsettings*.json`)

Relevant observability keys:

- `ApplicationInsights:ConnectionString`
- `Logging:LogLevel:*`
- `EventLog:*`

Additional worker runtime keys are under `AppSettings` (queues, temp folder, storage/dataverse, malware scan settings).

### Security note

- Keep all secrets and connection strings out of source control for real environments.
- Use environment variables, secure secret stores, or user-secrets for local development.

## 10. How To Run / Setup

### Prerequisites

- .NET SDKs required by the solution:
  - .NET 10 SDK (Web API project target: `net10.0`)
  - .NET 8 SDK (WinService project target: `net8.0`)
- Access to required external dependencies (Dataverse, Service Bus, Storage, and Application Insights) for full end-to-end behavior.

### Build

```bash
dotnet restore
dotnet build FIJI.Portal.Integration.sln
```

### Run Web API locally

```bash
dotnet run --project FIJI.Portal.WebAPI.Integration/FIJI.Portal.WebAPI.Integration.csproj
```

### Run Worker service locally (console mode)

```bash
dotnet run --project FIJI.Portal.FileReception.WinService/FIJI.Portal.FileReception.WinService.csproj
```

### Enable observability locally

Set valid local configuration values (without committing secrets), especially:

- Web API: `APPLICATIONINSIGHTS_CONNECTION_STRING`
- Worker: `ApplicationInsights:ConnectionString`

## 11. Best Practices / Notes

- Reuse centralized observability components before adding new logging patterns:
  - Middleware: request correlation/timing.
  - Action filter: controller lifecycle telemetry.
  - `OperationTraceHelper`: operation-level tracing/logging.
  - Dependency wrappers: Dataverse and outbound HTTP.
- Keep noisy framework categories filtered unless actively debugging lower layers.
- Return/propagate correlation IDs in API failures so support teams can find exact traces and logs quickly.
- For new external dependencies, follow the existing pattern: instrument duration, status/failure, and tags, then record dependency metrics.

## 12. Troubleshooting

Tags:

- `Code-verified`: confirmed in current code/config.
- `Operational`: carried-forward environment/process guidance.

1. `Code-verified` - 401 on secured endpoints.
  - Validate bearer token and `JWT_Secret` alignment.
  - Check JwtBearer failure/challenge logs in `Program.cs`.

2. `Code-verified` - 500 response with `correlationId`.
  - Expected for unhandled exceptions via global exception handler.
  - Use `correlationId` (`HttpContext.TraceIdentifier`) to trace logs/spans.

3. `Code-verified` - Dataverse auth/connection failure.
  - Set `crm_connection_string`, or set `crm_url` for token flow.
  - `Dataverse.CreateConnection` throws if token flow is used without `crmUrl`.

4. `Code-verified` - Missing Azure Monitor/App Insights telemetry.
  - Web API needs valid `APPLICATIONINSIGHTS_CONNECTION_STRING`.
  - Worker needs `AddApplicationInsightsTelemetryWorkerService` + `ApplicationInsights:ConnectionString`.

5. `Code-verified` - Worker starts but does not process queues.
  - Verify `AppSettings`: `ServiceBusEndPoint`, `Queues`, `MaxConcurrentCalls`.
  - `ServiceBus.RegisterListener` creates one processor per queue.

6. `Code-verified` - Worker file processing fails mid-flow.
  - Review `LogHelper` output and worker traces.
  - Validate `AppSettings.Storages`, credentials, and Dataverse config.
  - If malware scanning is used, verify scanner path and temp-folder access.

7. `Code-verified` - Browser automation dependency errors.
  - `PlaywrightInstaller` runs as hosted service and logs install failures.

8. `Code-verified` - SDK/toolchain build mismatch.
  - Targets are `net10.0` (Web API) and `net8.0` (WinService).
  - Install missing SDKs and run `dotnet --list-sdks`.

9. `Code-verified` - Intermittent 503 during startup/recycle.
  - Warm-up can be affected by hosted-service/dependency initialization.
  - Retry after warm-up and inspect startup logs.

10. `Operational` - Swagger/OpenAPI returns 500.
  - Often tied to startup exceptions or contract conflicts.
  - Check startup logs, controller metadata/tagging, and DTO names.

11. `Operational` - Entity not found due to environment mismatch.
  - Payload IDs may belong to another environment.
  - Validate IDs in the active Dataverse environment.

12. `Operational` - Swagger UI is limiting for some test scenarios.
  - Use Postman/curl when payload shape is hard to express in Swagger UI.

13. `Operational` - Runtime crash (possible circular graph/runtime fault).
  - Inspect recent model/controller changes and correlate exception logs.

14. `Operational` - Dataverse plugin/workflow exceptions via API.
  - Capture correlation ID + exception details and coordinate with CRM/Dataverse maintainers.

## 13. FAQ

### Q1. How do I correlate a failing API response to logs and traces?

Use `X-Correlation-ID`. If missing, middleware generates it. The value is returned in response headers and in many error payloads as `correlationId`.

### Q2. Where is observability implemented for the Web API?

In `Observability/` plus startup wiring in `Program.cs`: middleware -> action filter -> operation helper -> dependency wrappers.

### Q3. Are metrics implemented?

Yes. `ObservabilityTelemetry` defines counters/histograms for requests, actions, operations, dependencies, and retries.

### Q4. Is there a Prometheus scrape endpoint?

No. A Prometheus scrape endpoint is not implemented in this repository.

### Q5. How are Dataverse operations instrumented?

`IOrganizationService` is wrapped by `OrganizationServiceLoggingProxy`, which records duration, success/failure, and dependency telemetry.

### Q6. How do I instrument a new business operation?

Use `OperationTraceHelper.TraceOperation(...)` or `TraceOperationAsync(...)` and include context as key/value tuples.

### Q7. Do we currently have a dedicated automated test project in this repo?

No. The current solution has no separate unit/integration test project.

### Q8. Which logging and telemetry platforms are used?

- Web API: OpenTelemetry with Azure Monitor exporter.
- Worker: Application Insights Worker Service telemetry.

### Q9. What details should I always collect before escalation?

Capture endpoint/route, request payload, environment, response status/body, and correlation ID.

### Q10. Why might merged code not appear in a target environment immediately?

Deployment flow can vary by environment/pipeline policy. Check deployment status and release pipeline logs.

### Q11. Should SQL mutation operations be executed directly for debugging?

Carried-forward operational guidance recommends read-only checks in production-like environments.

### Q12. How do I validate DEV/UAT endpoint parity?

Use environment-specific base URLs and verify payload IDs match the target environment.

### Q13. What are the legacy environment URLs?

- DEV Swagger: `https://fiji-portal-api-dev.azurewebsites.net/swagger/index.html`
- UAT/SIT Swagger: `https://fiji-portal-api-uat2.azurewebsites.net/swagger/index.html`

### Q14. What contact references to reach out?

- Deployment follow-up: `ashok.arepally@hp.com`
- Repository/access, Additional access/process contacts:
  - `maykon.alves@hp.com`
  - `ruksar.ruksar@hp.com`
- UAT deployment contacts:
  - `saiteja.c@hp.com`
  - `safiya-anjum.shaik@hp.com`
- Dataverse plugin/workflow contacts:
  - `maykon.alves@hp.com`
  - `ruksar.ruksar@hp.com`
  - `ashwani.tripathi1@hp.com`

## 14. Azure Dashboard (Operations + Development)

This section explains how to build and use an Azure Portal dashboard from the telemetry already emitted by this solution.

### Scope and prerequisites

- Data source: Application Insights telemetry tables (`requests`, `dependencies`, `traces`, `exceptions`, `customMetrics`).
- appName strategy:
  - Use `appName == "Portal WebAPI"` filters where supported to isolate this application in shared telemetry stores.
  - Current metric-tag coverage includes `appName` for `app.operation.*` and `app.retry.*`.
  - Current metric-tag coverage does not include `appName` for `app.action.*`, `http.server.request.*`, and `app.dependency.*`.
- Expected telemetry emitters:
  - Request and correlation logs from `CorrelationAndRequestLoggingMiddleware`.
  - Action metrics from `ControllerActionLoggingFilter` and `ObservabilityTelemetry`.
  - Dataverse and outbound HTTP dependency telemetry from `OrganizationServiceLoggingProxy` and `OutboundHttpLoggingHandler`.
  - Queue processing traces from Worker `ServiceBus` (`Received:` and `Finished:` entries).
- Access model:
  - Viewer: Monitoring Reader (or equivalent read access to telemetry + dashboard resource).
  - Editor: Monitoring Contributor (or equivalent write access for shared dashboards).

### Telemetry inventory from implementation

- Web API request lifecycle (`traces`, `requests`, `customMetrics`):
  - Middleware logs `Request started` and `Request finished` with `CorrelationId`, `RequestPath`, `RequestMethod`, and `appName`.
  - Request counters/histograms: `http.server.request.count`, `http.server.request.failure.count`, `http.server.request.duration.ms`.
- Controller action execution (`traces`, `customMetrics`):
  - Filter logs `Action started`, `Action completed`, and `Action failed` with `Controller`, `Action`, `CorrelationId`.
  - Action metrics: `app.action.count`, `app.action.failure.count`, `app.action.duration.ms`.
- Model/business operations (`traces`, `customMetrics`):
  - `OperationTraceHelper` logs started/completed/failed operations with scoped `Component`, `Operation`, and `appName`.
  - Metrics: `app.operation.count`, `app.operation.failure.count`, `app.operation.duration.ms`.
- Dependencies (`dependencies`, `traces`, `customMetrics`):
  - Dataverse proxy emits operation success/failure and latency.
  - Outbound HTTP handler emits start/completion/failure and latency.
  - Metrics: `app.dependency.count`, `app.dependency.failure.count`, `app.dependency.duration.ms`.
- Retry behavior (`customMetrics`, `traces`):
  - `Project.ExecuteWithRetryAsync` emits retry metrics and warning logs.
  - Metrics: `app.retry.attempt.count`, `app.retry.exhausted.count`.
- Security/auth and unhandled failures (`traces`, `exceptions`):
  - JWT bearer events log authentication failures/challenges.
  - Global exception handler logs unhandled exceptions and preserves correlation id in API response.
- Worker service processing (`traces`):
  - Worker startup trace: `Portal File Reception service started`.
  - Queue processing traces: `Received:` and `Finished:` from `ServiceBus`.
  - Worker traces currently do not include `appName`, so worker queries must use message-based filtering.

#### FIJI DEV INV - Correlation Timeline Drill-Through

```kusto

let correlationId = "PUT-CORRELATION-ID-HERE";
union withsource=TableName requests, dependencies, traces, exceptions
| extend timestamp = column_ifexists("timestamp", datetime(null))
| extend dims = coalesce(column_ifexists("customDimensions", dynamic(null)), dynamic({}))
| extend AppName = tostring(dims["appName"])
| extend OperationIdValue = coalesce(tostring(column_ifexists("operation_Id", "")), tostring(column_ifexists("OperationId", "")))
| extend CorrelationId = coalesce(tostring(dims["correlation.id"]), tostring(dims["CorrelationId"]), OperationIdValue)
| extend NameValue = coalesce(tostring(column_ifexists("name", "")), tostring(column_ifexists("Name", "")), tostring(column_ifexists("OperationName", "")))
| extend MessageValue = coalesce(tostring(column_ifexists("message", "")), tostring(column_ifexists("Message", "")), tostring(column_ifexists("outerMessage", "")), tostring(column_ifexists("OuterMessage", "")))
| extend ResultCodeValue = coalesce(tostring(column_ifexists("resultCode", "")), tostring(column_ifexists("ResultCode", "")))
| extend SuccessValue = coalesce(tostring(column_ifexists("success", "")), tostring(column_ifexists("Success", "")))
| extend DurationValue = coalesce(tostring(column_ifexists("duration", "")), tostring(column_ifexists("Duration", "")), tostring(column_ifexists("DurationMs", "")))
| extend ItemTypeValue = tostring(
    iff(TableName has "requests", "request",
    iff(TableName has "dependencies", "dependency",
    iff(TableName has "traces", "trace",
    iff(TableName has "exceptions", "exception", "unknown")))))
| where AppName == "Portal WebAPI" or isempty(AppName)
| where CorrelationId == correlationId or OperationIdValue == correlationId
| project timestamp, itemType = ItemTypeValue, AppName, Name = NameValue, Message = MessageValue, ResultCode = ResultCodeValue, Success = SuccessValue, Duration = DurationValue, operation_Id = OperationIdValue, CorrelationId
| order by timestamp asc
```

### appName coverage notes

- appName filtering is supported in operation scope logs and in these metric families:
  - `app.operation.*`
  - `app.retry.*`
- appName filtering is currently unavailable in these metric families:
  - `app.action.*`
  - `http.server.request.*`
  - `app.dependency.*`
- Worker queue traces in `FIJI.Portal.FileReception.WinService` currently do not emit `appName`; use message-prefix filters for worker tiles.
- For unsupported metric families, use app-scoped resources/workspaces or complementary trace/request filters for investigation.

### Daily usage workflow

1. Ops checks request failure rate, latency, dependency failures, worker completion gap, and exception trend first.
2. If an anomaly is detected, copy a correlation ID from logs/responses and run the correlation drill-through query.
3. Dev pivots to failing actions, slow operations, and retry pressure for root-cause isolation.
4. Capture findings and link exact query/time range plus correlation ID for incident traceability.

### Related guidance

- Detailed observability instructions and investigation cookbook:
  [FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/observability-and-logging.instructions.md](FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/observability-and-logging.instructions.md)
