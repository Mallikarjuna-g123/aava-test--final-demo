using Azure.Identity;
using FIJI.Portal.FileReception.Commons;
using FIJI.Portal.IAM.WinService;
using Microsoft.Extensions.Logging.Configuration;
using Microsoft.Extensions.Logging.EventLog;

IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService(options =>
    {
        options.ServiceName = Constants.Generic.WimgServiceValidation;
    })
    .ConfigureServices(services =>
    {
        LoggerProviderOptions.RegisterProviderOptions<EventLogSettings, EventLogLoggerProvider>(services);
        services.BuildServiceProvider();
        services.AddHostedService<Worker>();
        services.AddApplicationInsightsTelemetryWorkerService();
        services.AddMemoryCache();
        services.AddSingleton(new DefaultAzureCredential());
    })
    .Build();

await host.RunAsync();
