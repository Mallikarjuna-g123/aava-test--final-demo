﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using FIJI.Portal.FileReception.Commons;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.FileReception.Commons.Model;
using FIJI.Portal.FileReception.Model;
using FIJI.Portal.FileReception.WinService;
using Microsoft.ApplicationInsights;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Text.Json;
using static FIJI.Portal.FileReception.Commons.Constants;
using static FIJI.Portal.FileReception.Commons.Helpers.VirusScanning;
using static FIJI.Portal.FileReception.Commons.Model.PortalManagementInfo;
using static FIJI.Portal.FileReception.Model.Enums;


namespace FIJI.Portal.IAM.WinService
{
    /// <summary>
    /// FileVerification class
    /// </summary>
    internal class FileVerification
    {

        /// <summary>
        /// Settings
        /// </summary>
        private ConfigSettings? settings;

        /// <summary>
        /// Temp Folder
        /// </summary>
        private string tempFolder;

        /// <summary>
        /// Portal Management Info Instance
        /// </summary>
        private PortalManagementInfo _portalInfo;

        /// <summary>
        /// Service Provider Instance
        /// </summary>
        private IServiceProvider _provider;


        private VirusScanning _virusScanning;

        private ServiceClient _serviceClient;

        /// <summary>
        /// FileVerification constructor
        /// </summary>
        /// <param name="settingsInstance">Configuration settings</param>
        /// <param name="tc">Telemetry client</param>
        public FileVerification(IServiceProvider provider, ConfigSettings? settingsInstance, TelemetryClient tc)
        {
            settings = settingsInstance;
            _provider = provider;
            _virusScanning = new VirusScanning(settings?.WindowsDefenderPath);

            if (!Directory.Exists(settings?.RootTempFolder))
                Directory.CreateDirectory(settings?.RootTempFolder);

            tempFolder = Path.Combine(settings.RootTempFolder, Guid.NewGuid().ToString().Replace("-", ""));

            if (!Directory.Exists(tempFolder))
                Directory.CreateDirectory(tempFolder);
        }

        private BlobFile GetBlobFile(Uri url)
        {
            LogHelper.Log("GetBlobFile");
            
            LogHelper.Log($"GetBlobFile: URL:{url}");
           

            if (!string.IsNullOrEmpty(settings?.AccountName) && !string.IsNullOrEmpty(settings.AccountKey))
            {
                LogHelper.Log("GetBlobFile: Success");
                return new BlobFile(url, settings.AccountName, settings.AccountKey);
            }
            else
            {
                LogHelper.Log($"GetBlobFile: else case:{url}");
                return new BlobFile(url);
            }
        }
        private void CheckIAMFile(string url)
        {

        }

        /// <summary>
        /// Check whether is a IAM Blob File
        /// </summary>
        /// <param name="blob">Blob File</param>
        /// <returns>Boolean</returns>
        private bool IsIAMFile(BlobFile blob, IDictionary<string, string> metadata)
        {
            return (metadata.ContainsKey(eMetadataProps.fileType.ToString())
                   && Convert.ToInt32(metadata[eMetadataProps.fileType.ToString()]) == (int)BlobFile.eFileType.IAM);
        }

        /// <summary>
        /// Execute File verification
        /// </summary>
        /// <param name="fileUrl">File Url</param>
        /// <param name="storage">Storage account name</param>
        internal void Execute(QueueMessage message)
        {
            string? customerSHA256 = "", sha256Generated = "";
            ConfigStorage? config = settings?.Storages?.FirstOrDefault(s => message.Topic.Contains(s.name.Trim().ToLower(), StringComparison.InvariantCultureIgnoreCase));

            if (config == null)
                throw new Exception(Constants.Generic.ConfigurationStorageNotFound);

            _serviceClient = Dataverse.CreateConnection(_provider, config.crmUrl, config.connectionString);
            _portalInfo = new PortalManagementInfo(_serviceClient);
      
            string messageJson = JsonSerializer.Serialize(message, new JsonSerializerOptions
            {
                WriteIndented = true // makes it pretty-printed
            });

            LogHelper.Log($"Queue Message: {messageJson}");
            if (message.Data.FileId != null)
                message.Data.BlobUrl = _portalInfo.GetBlobUrlAndCustomerSHA256(message.Data.FileId.Value, out customerSHA256) ?? "";
            LogHelper.Log($"message.Data.Api1: {message.Data.Api}");
            //Skip processing
            if (message.Data.BlobUrl == null || message.Data.Api == Constants.Api.SftpCreate || message.Data.Api == Constants.Api.SftpWrite)
                return;
            LogHelper.Log($"message.Data.Api2: {message.Data.Api}");
            //Means we received a file on temporary folder
            if (message.Data.Api == Constants.Api.SftpCommit)
            {
                LogHelper.Log("File Verification: SftpCommit");
                this.MoveFileInternalContainer(config, new Uri(message.Data.BlobUrl));
                LogHelper.Log("File Verification:MoveFileInternalContainer - Completed SftpCommit");
                return;
            }

            LogHelper.Log("File Verification :GetBlobFile - Started");
            BlobFile blob = this.GetBlobFile(new Uri(message.Data.BlobUrl));
            LogHelper.Log($"File Verification : blob.Exists Check :{blob.Exists()}");
            LogHelper.Log($"File Verification : blob: {JsonSerializer.Serialize(blob)}");
            if (blob.Exists())
            {
                IDictionary<string, string> metadata = blob.GetProperties().Metadata;

                if (metadata.TryGetValue(eMetadataProps.source.ToString(), out string? source) && source?.ToLower() == Constants.Generic.CDO)
                {
                    LogHelper.Log($"Source CDO: Skip File Validation: {message.Data.BlobUrl}");
                    return;
                }


                LogHelper.Log("File Verification:blob.Exists");
                bool isIAMfile = IsIAMFile(blob, metadata);

                LogHelper.Log($"File Verification : isIAMfile Value:{isIAMfile}");
                //Process IAM files only on PutBlockList and SetSHA256 events
                if (isIAMfile && message.Data.Api != Constants.Api.PutBlockList
                              && message.Data.Api != Constants.Api.SetSHA256
                              && message.Data.Api != Constants.Api.CopyBlob
                              && message.Data.Api != Constants.Api.PutBlob) 
                            
                {
                    return;
                }
                





                string tempFile = blob.Download(tempFolder);

                if (File.Exists(tempFile))
                {
                    LogHelper.Log($"File Exists Inside If");
                    FileInfo fileInfo = new FileInfo(tempFile);

                    
                    Guid? fileId = null;
                    CheckVirusStatus checkVirusResult;

                    PortalManagementInfo.FileStatusValues fileStatus = PortalManagementInfo.FileStatusValues.InProgress;

                    if(!isIAMfile)
                    {
                        fileStatus = FileStatusValues.Completed;
                        LogHelper.Log($"File Verification : fileStatus :Completed");
                    }

                    if (!metadata.ContainsKey(eMetadataProps.transferType.ToString()) || fileInfo.Extension.ToLower() == Generic.WIMExtension)
                    {
                        LogHelper.Log($"File Verification : fileStatus :InProgress");
                        LogHelper.Log($"File Verification : fileStatus :Second Virus scan");
                        IDictionary<string, string> newMetadata = new Dictionary<string, string>();
                        var virusScanResult = PerformVirusScanning(config, fileInfo, tempFile, message.Data.BlobUrl, blob, fileStatus, false);
                        fileStatus = virusScanResult.status;
                        checkVirusResult = virusScanResult.virusResult;
                        if (isIAMfile && checkVirusResult == CheckVirusStatus.ThreatFound)
                        {
                            LogHelper.Log($"File Verification : checkVirusResult :True : Blob Delete");
                            blob.Delete();
                            message.Data.BlobUrl = string.Empty;
                            if (metadata.ContainsKey(eMetadataProps.fileId.ToString()))
                                fileId = new Guid(metadata[eMetadataProps.fileId.ToString()]);
                            LogHelper.Log($"File Verification : fileId :{fileId}");
                            LogHelper.Log($"File Verification : fileStatus :{fileStatus}");
                            LogHelper.Log($"File Verification : sha256Generated :{sha256Generated}");
                            LogHelper.Log($"File Verification : message.Data.BlobUrl :{message.Data.BlobUrl}");
                            if (fileId.HasValue)
                            {
                                _portalInfo.UpdateRecord(fileId.Value, fileStatus, sha256Generated, message.Data.BlobUrl);
                                LogHelper.Log("File Verification : Virus Detected - DB updated");
                            }
                            else
                            {
                                LogHelper.Log("File Verification : Virus Detected but fileId is missing — skipping DB update");
                            }
                            try
                            {
                                if (File.Exists(fileInfo.FullName))
                                    File.Delete(fileInfo.FullName);
                            }
                            catch (Exception ex)
                            {
                                LogHelper.Log($"File Verification : Failed to delete local infected file. Error: {ex.Message}");
                            }
                            return;
                        }
                        else
                        {
                            newMetadata[eMetadataProps.MalwareScanningscanresult.ToString()] = checkVirusResult.ToString();
                            blob.MergeAndSetMetadata(newMetadata);
                            LogHelper.Log($"File Verification : checkVirusResult :False : Blob Merge");
                        }
                    }

                    if (isIAMfile)
                    {
                        LogHelper.Log($"File Verification : isIAMfile Inside If");
                        if (metadata.ContainsKey(eMetadataProps.fileId.ToString()))
                            fileId = new Guid(metadata[eMetadataProps.fileId.ToString()]);
                        LogHelper.Log($"File Verification : fileId :{fileId}");
                        LogHelper.Log($"File Verification : customerSHA256 :{customerSHA256}");

                       if (string.IsNullOrEmpty(customerSHA256) && !metadata.ContainsKey(eMetadataProps.transferType.ToString()))
                       {
                            customerSHA256 = _portalInfo.GetCustomerSHA256(message.Data.BlobUrl) ?? "";
                            LogHelper.Log($"File Verification : customerSHA256 :{customerSHA256}");
                       }

                        if (string.IsNullOrEmpty(customerSHA256))
                        {
                            LogHelper.Log($"File Verification : customerSHA256 is Null");

                            int retryCount = 5;

                            for (int i = 0; i < retryCount; i++)
                            {
                                try
                                {
                                    customerSHA256 = _portalInfo.GetSHA256Provided(fileId.Value);

                                    if (!string.IsNullOrEmpty(customerSHA256))
                                    {
                                        LogHelper.Log($"File Verification : customerSHA256 :{customerSHA256}");
                                        break;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    LogHelper.Log($"Retry {i + 1} Failed : {ex.Message}");

                                    Thread.Sleep(10000);
                                }
                            }
                        }
                        //if (string.IsNullOrEmpty(customerSHA256))
                        //{
                        //    LogHelper.Log($"File Verification : customerSHA256 is Null");
                        //    customerSHA256 = _portalInfo.GetSHA256Provided(fileId.Value);
                        //    LogHelper.Log($"File Verification : customerSHA256 :{customerSHA256}");
                        //}

                        fileStatus = this.CheckSHA256(tempFile, blob, customerSHA256, out sha256Generated);
                        LogHelper.Log($"File Verification : sha256Generated :{sha256Generated}");
                        LogHelper.Log($"File Verification : fileStatus :{fileStatus}");
                    }    
                    if (message.Data.FileId == null && (!metadata.ContainsKey(eMetadataProps.transferType.ToString())))
                    {
                        LogHelper.Log($"Inside Generation of FileID");
                        fileId = _portalInfo.GetFileId(message.Data.BlobUrl);
                        LogHelper.Log($"fileId:{fileId}");
                    }
                    if (fileId != null)
                    {    
                        _portalInfo.UpdateRecord(fileId.Value, fileStatus, sha256Generated, message.Data.BlobUrl);
                        LogHelper.Log($"File Verification : Portal Record Updated");
                    }
                    try
                    {
                        if (File.Exists(fileInfo.FullName))
                            File.Delete(fileInfo.FullName);

                    }
                    catch { }
                }
                else
                {
                    LogHelper.Log($"File Verification : Exception: FailedToDownloadFile");
                    throw new Exception($"{Constants.Generic.FailedToDownloadFile} {message.Data.BlobUrl}");
                }
            }
            

        }

        /// <summary>
        /// SHA256 checksum verification
        /// </summary>
        /// <param name="blobClient">Blob File</param>
        /// <param name="props">metadata properties</param>
        /// <param name="log">ILogger</param>
        /// <returns>Status <see cref="eStatus"/></returns>
        private FileStatusValues CheckSHA256(string filePath, BlobFile blobClient, string? customerSHA256, out string sha256Generated)
        {
            LogHelper.Log("CheckSHA256: Inside");
            DateTime dtStart = DateTime.UtcNow;
            FileStatusValues status = FileStatusValues.Completed;
           
            sha256Generated = string.Empty;

            using (Stream streamIn = File.OpenRead(filePath))
            {
                sha256Generated = Utility.GetChecksum(streamIn);
            }
            LogHelper.Log($"sha256Generated: {sha256Generated}");
            //Validate if the user provide the SHA256 on CRM
            if (!string.IsNullOrEmpty(customerSHA256))
            {
                LogHelper.Log($"Inside Customer 256 is not null");
                status = FileStatusValues.InvalidSHA256;
                LogHelper.Log($"status: {status}");
                if (!string.IsNullOrEmpty(customerSHA256))
                {
                    LogHelper.Log($"2 Inside Customer 256 is not null");
                    if (customerSHA256.Trim().ToUpper() == sha256Generated)
                        status = FileStatusValues.Completed;
                    LogHelper.Log($"File status: {status}");
                }
            }
            else
                status = FileStatusValues.ProvideSHA256;

            return status;
        }


        /// <summary>
        /// Move file to internal container
        /// </summary>
        /// <param name="blobUrl"></param>
        private void MoveFileInternalContainer(ConfigStorage config, Uri blobUrl)
        {
            LogHelper.Log("CreateConnection started");
            _serviceClient = Dataverse.CreateConnection(_provider, config.crmUrl, config.connectionString);
            LogHelper.Log("CreateConnection Completed");
            BlobFile currentBlob = this.GetBlobFile(blobUrl);
            LogHelper.Log("GetBlobFile Completed");
            BlobProperties props = currentBlob.GetProperties();
            LogHelper.Log("props");
            LogHelper.Log($"props Settings: {props}");
            LogHelper.Log("GetProperties Completed");

            string accountId = currentBlob.Uri.Segments[2]
                .Trim('/')
                .Substring(0, 36);
            LogHelper.Log($"customer account id: {accountId}");

            int version = 0;

            LogHelper.Log("GenerateFileName started");
            LogHelper.Log($"currentBlob.Uri: {currentBlob.Uri}");
            LogHelper.Log($"currentBlob.Uri.Segments[3]: {currentBlob.Uri.Segments[3]}");
            string onceDecoded = Uri.UnescapeDataString(currentBlob.Uri.Segments[3]);
            LogHelper.Log($"onceDecoded: {onceDecoded}");
            // Decode again to convert %20 to space
            string fullyDecoded = Uri.UnescapeDataString(onceDecoded);
            LogHelper.Log($"fullyDecoded: {fullyDecoded}");

            StorageAccountHelper storageHelper = new StorageAccountHelper(config.name, config.key);
            BlobClient newBlob = storageHelper.GenerateFileName(accountId, fullyDecoded, BlobFile.eFileType.IAM, out version);

            var blobInfo = new
            {
                Uri = newBlob.Uri.ToString(),
                Name = newBlob.Name,
                ContainerName = newBlob.BlobContainerName,
                AccountName = newBlob.AccountName
            };

            string logJson = JsonSerializer.Serialize(blobInfo);
            LogHelper.Log($"newBlob Info: {logJson}");

            FileStatusValues status = FileStatusValues.InProgress;

            if (!this.IsValidExtension(blobUrl.ToString()))
                status = FileStatusValues.InvalidExtension;

            string tempFile = currentBlob.Download(tempFolder);
            FileInfo fileInfo = new FileInfo(tempFile);

            if (fileInfo.Length == 0)
            {
                LogHelper.Log($"File Verification : File is empty (zero bytes), skipping processing: {blobUrl}");
                return;

            }
           var fileDetails = new
            {
                FileName = fileInfo.Name,
                FullPath = fileInfo.FullName,
                Extension = fileInfo.Extension,
                SizeBytes = fileInfo.Length,
                CreatedOn = fileInfo.CreationTime,
                LastModified = fileInfo.LastWriteTime,
                IsReadOnly = fileInfo.IsReadOnly
            };

            string json = JsonSerializer.Serialize(fileDetails, new JsonSerializerOptions { WriteIndented = true });

            LogHelper.Log($"File Info: {json}");

            var virusScanResult = PerformVirusScanning(config, fileInfo, tempFile, blobUrl.ToString(), currentBlob, status, false);
            status = virusScanResult.status;
            CheckVirusStatus checkVirusResult = virusScanResult.virusResult;
            LogHelper.Log($"MFIC- file status-{status}");
            LogHelper.Log($"MFIC- Virus CheckResult-{checkVirusResult}");

            //Create Portal Management info record

            LogHelper.Log("Create Portal Management info record");
            string extension = Path.GetExtension(blobUrl.AbsolutePath).ToLower();
            long fileSizeInBytes = props.ContentLength * 1024;

            Guid fileId = _portalInfo.CreateIAMFileRecord(new Guid(accountId),
                                                         this.GetPrimaryContactIdBy(_serviceClient, accountId),
                                                         fullyDecoded,
                                                         newBlob.Uri.ToString(),
                                                         fileSizeInBytes,
                                                         TransferTypeValues.SFTP,
                                                         status,
                                                         extension);

            if (status != FileStatusValues.InvalidExtension && status != FileStatusValues.VirusDetected)
            {
                LogHelper.Log("Moving file to internal customer storage");
                //Moving file to internal customer storage
                Dictionary<string, string> metadata = new Dictionary<string, string>();
                metadata.Add(eMetadataProps.fileId.ToString(), fileId.ToString());
                metadata.Add(eMetadataProps.fileType.ToString(), ((int)BlobFile.eFileType.IAM).ToString());
                metadata.Add(eMetadataProps.transferType.ToString(), ((int)TransferTypeValues.SFTP).ToString());
                newBlob.StartCopyFromUri(blobUrl, new BlobCopyFromUriOptions() { Metadata = metadata });
                LogHelper.Log("Moving file to internal customer storage - completed");
            }
            LogHelper.Log("MTIS :Before currentBlob Exists");
            LogHelper.Log($"File Verification : blob: {JsonSerializer.Serialize(currentBlob)}");
            //Delete temporary file
            if (currentBlob.Exists())
            {
                LogHelper.Log("MTIS : Inside Condition currentBlob Exists");
                currentBlob.Delete();
            }
        }

        private static List<string> _validExtensions;
        private object _lockLoadExtensions = new object();

        private bool IsValidExtension(string blobUrl)
        {
            lock (_lockLoadExtensions)
            {
                if (_validExtensions == null)
                    _validExtensions = Utility.LoadIAMValidExtensions(_serviceClient);
            }
            string blobPath = new Uri(blobUrl).AbsolutePath;
            string fileName = Path.GetFileName(blobPath);
            string extension = Path.GetExtension(fileName).ToLowerInvariant();

            return (_validExtensions.Count == 0 || _validExtensions.Contains(extension));
        }

        /// <summary>
        /// Get primary contactid by accountid
        /// </summary>
        /// <param name="accountId">Account ID</param>
        /// <returns>Primary Contact Id</returns>
        public Guid? GetPrimaryContactIdBy(ServiceClient serviceClient, string accountId)
        {
            QueryExpression query = new QueryExpression("account");
            query.ColumnSet.AddColumn("primarycontactid");
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            query.Criteria.AddCondition("accountid", ConditionOperator.Equal, accountId);
            query.Criteria.AddCondition("primarycontactid", ConditionOperator.NotNull);

            var result = serviceClient.RetrieveMultiple(query);

            if (result.Entities.Count > 0)
                return result.Entities.First().GetAttributeValue<EntityReference>("primarycontactid").Id;

            return null;
        }

        internal void DeleteTempFolder()
        {
            try
            {
                Directory.Delete(tempFolder, true);
            }
            //Ignore
            catch { }
        }

        private (FileStatusValues status, CheckVirusStatus virusResult) PerformVirusScanning(ConfigStorage config, FileInfo fileInfo, string tempFile, string blobUrl, BlobFile currentBlob, FileStatusValues status, bool deleteTempFolder)
        {
            CheckVirusStatus checkVirusResult;
            LogHelper.Log("Inside PerformVirusScanning");
            if (fileInfo.Extension.ToLower() != Generic.WIMExtension)
            {
                checkVirusResult = _virusScanning.Check(fileInfo);
                if (checkVirusResult == CheckVirusStatus.ThreatFound)
                    status = FileStatusValues.VirusDetected;
            }
            else
            {
                status = new WIMFileVerification(config, _virusScanning, currentBlob, tempFolder, tempFile, blobUrl, deleteTempFolder).Execute();
                checkVirusResult = (status == FileStatusValues.VirusDetected) ? CheckVirusStatus.ThreatFound : CheckVirusStatus.NoThreatFound;
            }
            return (status, checkVirusResult);
        }
    }
}