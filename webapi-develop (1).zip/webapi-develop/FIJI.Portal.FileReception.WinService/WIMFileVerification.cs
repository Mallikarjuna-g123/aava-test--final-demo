﻿using FIJI.Portal.FileReception.Commons;
using FIJI.Portal.FileReception.Commons.Helpers;
using FIJI.Portal.FileReception.Model;
using FIJI.Portal.IAM.WinService;
using System.ComponentModel;
using static FIJI.Portal.FileReception.Commons.Model.PortalManagementInfo;

namespace FIJI.Portal.FileReception.WinService
{
    internal class WIMFileVerification
    {
        public string TempFolder { get; }
        public string TempFile { get; }
        public string BlobUrl { get; }
        public ConfigStorage Settings { get; }
        public BlobFile BlobInstance { get; }

        public VirusScanning VirusScanningInstance { get; set; }

        public bool deleteTempFolder { get; }

        public WIMFileVerification(ConfigStorage settings, VirusScanning virusScanning, BlobFile blob, string tempFolder, string tempFile, string blobUrl, bool deleteTempFolder)
        {
            this.TempFolder = tempFolder;
            this.TempFile = tempFile;
            this.BlobUrl = blobUrl;
            this.Settings = settings;
            this.BlobInstance = blob;
            this.VirusScanningInstance = virusScanning;
            this.deleteTempFolder = deleteTempFolder;
        }

        /// <summary>
        /// Get Wim image files
        /// </summary>
        /// <param name="file">File</param>
        /// <param name="imageHandle">Image Handle</param>
        /// <returns>List files <see cref="WimMessageFileInfo"/></returns>
        public IEnumerable<WimMessageFileInfo> GetImageFiles(WimHandle file, WimHandle imageHandle)
        {
            List<WimMessageFileInfo> files = new List<WimMessageFileInfo>();

            WimMessageResult MessageCallback(WimMessageType messageType, object message, object userData)
            {
                if (messageType == WimMessageType.FileInfo)
                {
                    WimMessageFileInfo messageFileInfo = (WimMessageFileInfo)message;

                    if ((messageFileInfo.FileInfo.Attributes | FileAttributes.Directory) != FileAttributes.Directory)
                    {
                        ((List<WimMessageFileInfo>)userData).Add(messageFileInfo);
                    }
                }

                return WimMessageResult.Done;
            }

            WimgApi.RegisterMessageCallback(file, MessageCallback, files);

            try
            {
                WimgApi.ApplyImage(imageHandle, this.TempFolder, WimApplyImageOptions.NoApply | WimApplyImageOptions.FileInfo);
            }
            catch (Win32Exception win32Exception)
            {
                if (win32Exception.NativeErrorCode != 1235)
                {
                    throw;
                }
            }
            finally
            {
                WimgApi.UnregisterMessageCallback(file, MessageCallback);
            }

            return files;
        }



        /// <summary>
        /// Check if exists infected Files
        /// </summary>
        /// <param name="folder">Folder </param>
        /// <param name="files">Files</param>
        /// <param name="openFiles">Open file to check</param>
        /// <returns>Infected file</returns>
        private bool CheckExistsInfectedFilesWinDefender(string folder, List<WimMessageFileInfo> files)
        {
            VirusScanning.CheckVirusStatus result = this.VirusScanningInstance.Check(folder);

            if (result != VirusScanning.CheckVirusStatus.ThreatFound)
            {
                List<string> pdfFiles = FileHelper.GetAllFiles(folder, "*.pdf");

                foreach (string pdfFile in pdfFiles)
                {
                    if (this.VirusScanningInstance.IsTherePossibleXXEDetected(pdfFile))
                    {
                        result = VirusScanning.CheckVirusStatus.ThreatFound;
                        break;
                    }
                }
            }

            return (result == VirusScanning.CheckVirusStatus.ThreatFound);
        }

        /// <summary>
        /// Check if exists infected Files
        /// </summary>
        /// <param name="folder">Folder </param>
        /// <param name="files">Files</param>
        /// <param name="openFiles">Open file to check</param>
        /// <returns>Infected file</returns>
        private string CheckExistsInfectedFilesMcAfee(string folder, List<WimMessageFileInfo> files, bool openFiles)
        {
            string infectedFile = "";

            Parallel.ForEach(files, new ParallelOptions() { MaxDegreeOfParallelism = 10 }, (item, state) =>
            {
                if (item.FileInfo.Length > 0 && item.FileInfo.Attributes.HasFlag(FileAttributes.Archive))
                {
                    string file = item.Path.Replace(this.TempFolder, folder);
                    try
                    {
                        File.GetAttributes(file);
                        if (openFiles)
                        {
                            using (var fl = File.OpenRead(file))
                            {
                                var buffer = new byte[1024];
                                fl.Read(buffer, 0, buffer.Length);
                            }
                        }
                    }
                    catch (FileNotFoundException notFound)
                    {
                        infectedFile = file.Replace(folder, "");
                        state.Break();
                    }
                    catch (Exception ex)
                    {
                        if (!(ex is IOException || ex is UnauthorizedAccessException))
                        {
                            LogHelper.Log(ex);
                        }
                    }

                }
            });
            return infectedFile;
        }


        public FileStatusValues Execute()
        {
            int tentative = 0;
            bool hasMounted = false;

            string? extractFolder = Path.Combine(this.TempFolder, Constants.Generic.Extract);

            if (!Directory.Exists(extractFolder))
                Directory.CreateDirectory(extractFolder);


            Thread.Sleep(5000);
            IDictionary<string, string> newMetadata = new Dictionary<string, string>();
            Dictionary<string, string> infTrack = new Dictionary<string, string>();
            infTrack.Add(Constants.Generic.File, this.BlobUrl);
            WimHandle imageHandle = null;
            WimHandle img = null;
            FileStatusValues status =  FileStatusValues.Completed;
            try
            {
                img = WimgApi.CreateFile(this.TempFile, WimFileAccess.Read | WimFileAccess.Query | WimFileAccess.Mount, WimCreationDisposition.OpenAlways, WimCreateFileOptions.None, WimCompressionType.None);

                WimgApi.SetTemporaryPath(img, extractFolder);

                imageHandle = WimgApi.LoadImage(img, 1);
                WimInfo wimInfo = WimgApi.GetAttributes(img);

                List<WimMessageFileInfo> files = GetImageFiles(img, imageHandle).ToList();
                WimMessageFileInfo? dotSavFile = files.FirstOrDefault(x => x.Path.ToLower().Contains(Constants.Generic.SystemDotSav));

                if (dotSavFile != null)
                    status = FileStatusValues.InvalidSystemSavFolder;
                
                else
                {
                    LogHelper.Log($"Mount Image - File : {this.TempFile}");
                    WimgApi.MountImage(imageHandle, extractFolder, WimMountImageOptions.None);
                    hasMounted = true;
                    LogHelper.Log($"Finished Mount Image - File: {this.TempFile}");

                    LogHelper.Log($"WimFile: {this.TempFile} - Start virus scanning");

                    if (CheckExistsInfectedFilesWinDefender(extractFolder, files))
                        status = FileStatusValues.VirusDetected;
                }
            }
            catch (Win32Exception exWin32)
            {
                status = FileStatusValues.InvalidWIMfile;
                LogHelper.Log(exWin32);
            }
            catch (Exception ex)
            {
                status = FileStatusValues.InvalidWIMfile;
                LogHelper.Log(ex);
            }
            finally
            {

                if (hasMounted)
                {
                    if (imageHandle != null)
                    {
                        tentative = 0;
                        while (tentative < 3)
                        {
                            try
                            {
                                WimgApi.UnmountImage(imageHandle);
                                break;
                            }
                            catch { Thread.Sleep(TimeSpan.FromSeconds(30)); }

                            tentative++;
                        }
                    }
                }

                if (img != null)
                {
                    while (tentative < 3)
                    {
                        try
                        {
                            if (imageHandle != null)
                            {
                                imageHandle.Close();
                                imageHandle.Dispose();
                            }
                            img.Close();
                            img.Dispose();
                            break;
                        }
                        catch { Thread.Sleep(TimeSpan.FromSeconds(30)); }

                        tentative++;
                    }
                }


                Thread.Sleep(TimeSpan.FromSeconds(30));
                while (tentative < 5)
                {
                    try
                    {
                        if (Directory.Exists(this.TempFolder) && this.deleteTempFolder)
                            Directory.Delete(this.TempFolder, true);
                        break;
                    }
                    catch { Thread.Sleep(TimeSpan.FromMinutes(1)); }

                    tentative++;
                }
            }

            return status;
        }
    }
}
