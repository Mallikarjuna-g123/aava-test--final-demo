using FIJI.Portal.FileReception.Commons;
using FIJI.Portal.FileReception.Model;
using Microsoft.ApplicationInsights;

namespace FIJI.Portal.IAM.WinService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private TelemetryClient _telemetryClient;
        private readonly ConfigSettings _settings;
        private IServiceProvider _serviceProvider;

        public Worker(ILogger<Worker> logger, TelemetryClient tc, IConfiguration configRoot, IHost host)
        {

            _logger = logger;
            _telemetryClient = tc;
            _serviceProvider = host.Services;
            _settings = new ConfigSettings();
            _telemetryClient.TrackTrace("Portal File Reception service started");
            
            configRoot.GetSection(Constants.Generic.AppSettings).Bind(_settings);
            LogHelper.InitializeLogFile(_settings.RootTempFolder);
            LogHelper.Log("Service Initialized");
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {

            _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
            await ServiceBus.RegisterListener(_serviceProvider, _settings, _logger, _telemetryClient, stoppingToken);
        }
    }
}