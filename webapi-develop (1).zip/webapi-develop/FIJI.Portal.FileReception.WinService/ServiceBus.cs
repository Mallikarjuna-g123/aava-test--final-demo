﻿using Azure.Messaging.ServiceBus;
using FIJI.Portal.FileReception.Commons;
using FIJI.Portal.FileReception.Model;
using Microsoft.ApplicationInsights;
using Newtonsoft.Json;

namespace FIJI.Portal.IAM.WinService
{


    internal class ServiceBus
    {
        private static ServiceBusClient? client;
        private static ConfigSettings? _settings;
        private static List<ServiceBusProcessor> processorList = new List<ServiceBusProcessor>();
        private static ILogger<Worker>? _log;
        private static TelemetryClient? _telemetryClient;
        private static IServiceProvider? _provider;

        public async static Task<bool> RegisterListener(IServiceProvider provider, ConfigSettings settings, ILogger<Worker> log, TelemetryClient tc, CancellationToken stoppingToken)
        {
            _settings = settings;
            _log = log;
            _telemetryClient = tc;
            _provider = provider;

            var clientOptions = new ServiceBusClientOptions()
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            };

            client = new ServiceBusClient(settings.ServiceBusEndpoint, clientOptions);

            foreach (string queue in settings.Queues)
            {
                var processor = client.CreateProcessor(queue, new ServiceBusProcessorOptions() { MaxConcurrentCalls = settings.MaxConcurrentCalls });

                try
                {
                    processor.ProcessMessageAsync += MessageHandler;

                    processor.ProcessErrorAsync += ErrorHandler;

                    // start processing 
                    await processor.StartProcessingAsync(stoppingToken);

                    processorList.Add(processor);
                }
                finally
                {

                }
            }

            return true;
        }

        internal async static Task MessageHandler(ProcessMessageEventArgs args)
        {

            var message = JsonConvert.DeserializeObject<QueueMessage>(args.Message.Body.ToString());
            await args.CompleteMessageAsync(args.Message);
            if ((message != null && !string.IsNullOrEmpty(message.Data.BlobUrl)) || message?.Data?.FileId != null)
            {
                FileVerification? fileVerification = null;
                try
                {
                    fileVerification = new FileVerification(_provider, _settings, _telemetryClient);
                    _telemetryClient.TrackTrace($"Received: {message.ToString()}");
                    fileVerification.Execute(message);
                    _telemetryClient.TrackTrace($"Finished: {message.ToString()}");

                }
                catch (Exception ex)
                {
                    Dictionary<string, string> p = new Dictionary<string, string>();
                    p.Add("Message", args.Message.Body.ToString());
                    LogHelper.Log(ex);
                }
                finally
                {
                    if (fileVerification != null)
                        fileVerification.DeleteTempFolder();
                }
            }
        }
        internal static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            return Task.CompletedTask;
        }
    }
}


