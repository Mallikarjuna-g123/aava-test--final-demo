# Branching and Deployment Strategy – WebAPI

## Purpose

This document describes the branching and deployment strategy for the WebAPI application.  
It supports parallel development for **features (CRs)** and **production bug fixes** using separate environments.

---

## Environments

| Environment | Usage |
|------------|-------|
DEV2 | Feature / CR testing |
UAT2 | Feature / CR UAT |
DEV1 | Production bug fix testing |
UAT1 | Production bug fix UAT |
PROD | Production |

---

## Branch Overview

- **develop**
  - Used for feature / CR development
- **main**
  - Represents production code
  - Used for production bug fixes and releases

---

## Developer Workflow

### 1. Feature / CR Development

- Developer works in a **fork of the `develop` branch**
- Feature changes are implemented in the fork
- A Pull Request (PR) is created to merge changes into `develop`
  
Fork (develop) → develop
---

### 2. Production Bug Fixes

- Developer works in a **fork of the `main` branch**
- Production bug fixes are implemented in the fork
- A Pull Request (PR) is created to merge changes into `main`
  
Fork (main) → main
---

## Deployment Flow

### 3. Feature (CR) Deployment

- Changes in the `develop` branch are deployed to:
  1. **DEV2**
  2. **UAT2**
     
develop → DEV2 → UAT2
---

### 4. Production Bug Fix Deployment

- Changes in the `main` branch are deployed to:
  1. **DEV1**
  2. **UAT1**
  3. **PROD**
     
main → DEV1 → UAT1 → PROD
---

## Feature Promotion to Production

### 5. Feature UAT Completion

When a feature completes UAT successfully in **UAT2**:

1. Code is merged from **`develop` into `main`**
2. The updated `main` branch is deployed sequentially to:
   - **DEV1**
   - **UAT1**
   - **PROD**
     
develop → main → DEV1 → UAT1 → PROD
---

## End‑to‑End Flow Summary

### Feature / CR Flow

**Fork(develop) → develop → DEV2 → UAT2 → main → DEV1 → UAT1 → PROD**


### Production Bug Fix Flow

**Fork(main) → main → DEV1 → UAT1 → PROD**


## Governance Rules

- No direct commits to `develop` or `main`
- All changes must go through Pull Requests
- Feature changes reach production only after UAT2 sign-off
- Production bug fixes are always based on `main`
- `main` always reflects the production state


## Benefits

- Parallel feature and hotfix development
- Clear separation of responsibilities
- Controlled and predictable deployments
- Reduced risk of regression
- Simple and auditable release process
