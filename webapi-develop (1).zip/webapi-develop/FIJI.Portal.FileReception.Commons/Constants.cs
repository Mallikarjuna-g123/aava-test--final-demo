﻿namespace FIJI.Portal.FileReception.Commons
{
    /// <summary>
    /// Constants class
    /// </summary>
    public class Constants
    {
        public class Api
        {
            /// <summary>
            /// PutBlockList
            /// </summary>
            public const string PutBlockList = "PutBlockList";

            /// <summary>
            /// PutBlockList
            /// </summary>
            public const string SetSHA256 = "SetSHA256";

            /// <summary>
            /// CopyBlob
            /// </summary>
            public const string CopyBlob = "CopyBlob";

            /// <summary>
            /// SftpCommit
            /// </summary>
            public const string SftpCommit = "SftpCommit";

            /// <summary>
            /// SftpCommit
            /// </summary>
            public const string SftpCreate = "SftpCreate";

            /// <summary>
            /// SftpWrite
            /// </summary>
            public const string SftpWrite = "SftpWrite";


            /// <summary>
            /// PutBlob
            /// </summary>
            public const string PutBlob = "PutBlob";

            /// <summary>
            /// Bearer
            /// </summary>
            public const string Bearer = "Bearer";

            /// <summary>
            /// WebHookRequestOrigin
            /// </summary>
            public const string WebHookRequestOrigin = "WebHook-Request-Origin";

            /// <summary>
            /// WebHookRequestCallback
            /// </summary>
            public const string WebHookRequestCallback = "WebHook-Request-Callback";

            /// <summary>
            /// WebHookRequestRate
            /// </summary>
            public const string WebHookRequestRate = "WebHook-Request-Rate";

            /// <summary>
            /// WebHookAllowedRate
            /// </summary>
            public const string WebHookAllowedRate = "WebHook-Allowed-Rate";

            /// <summary>
            /// WebHookAllowedOrigin
            /// </summary>
            public const string WebHookAllowedOrigin = "WebHook-Allowed-Origin";
        }

        /// <summary>
        /// Generic class
        /// </summary>
        public class Generic
        {
            /// <summary>
            /// 1970-01-01
            /// </summary>
            public static readonly DateTime _1970_1_1 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            

            /// <summary>
            /// OK
            /// </summary>
            public const string OK = "OK";
            
            /// <summary>
            /// QueueName File Reception
            /// </summary>
            public const string QueueNameFileReception = "QueueNameFileReception";

            /// <summary>
            /// ServiceBusEndPoint
            /// </summary>
            public const string ServiceBusEndPoint = "ServiceBusEndPoint";

            /// <summary>
            /// StorageAccount
            /// </summary>
            public const string StorageAccount = "StorageAccount";

            /// <summary>
            /// StorageAccount
            /// </summary>
            public const string StorageAccountKey = "StorageAccountKey";

            /// <summary>
            /// BufferSize
            /// </summary>
            public const int BufferSize = 1024 * 1024 * 4;
            
            /// <summary>
            /// .wim
            /// </summary>
            public const string WIMExtension = ".wim";

            
            /// <summary>
            /// Failed to download file
            /// </summary>
            public const string FailedToDownloadFile = "Failed to download file";

            /// <summary>
            /// Extract
            /// </summary>
            public const string Extract = "extract";

            /// <summary>
            /// system.sav
            /// </summary>
            public const string SystemDotSav = "system.sav";

            /// <summary>
            /// Wimg Service Validation
            /// </summary>
            public const string WimgServiceValidation = "Portal File Reception Service";

            /// <summary>
            /// Subscription ID
            /// </summary>
            public const string SubscriptionId = "subscriptionid";
            /// <summary>
            /// Resourcer Group name
            /// </summary>
            public const string ResourceGroupName = "resourcegroupname";
            
            /// <summary>
            /// Open Id Json Configuration File
            /// </summary>
            public const string OpenIdConfigurationFile = "openid-configuration.json";

            
            /// <summary>
            /// Portal Configuration Container
            /// </summary>
            public const string PortalConfigurationContainer = "z-portal-configuration";

            /// <summary>
            /// File
            /// </summary>
            public const string File = "File";

            /// <summary>
            /// App Settings
            /// </summary>
            public const string AppSettings = "AppSettings";

            
            /// <summary>
            /// Blob StorageAccount Url
            /// </summary>
            public const string BloStorageAccountUrl = "https://{0}.blob.core.windows.net";

            /// <summary>
            /// Failed to Delete folders message
            /// </summary>
            public const string FailedToDeleteFolders = "Failed to delete folders";

            /// <summary>
            /// SHA256 must be provided!
            /// </summary>
            public const string SHA256MustBeProvided = "SHA256 must be provided!";

            /// <summary>
            /// FileUrl must be provided!
            /// </summary>
            public const string FileUrlMustBeProvided = "FileUrl must be provided!";

            /// <summary>
            /// Configuration storage not found!
            /// </summary>
            public const string ConfigurationStorageNotFound = "Configuration storage not found!";

            /// <summary>
            /// Threat Found
            /// </summary>
            public const string ThreatFound = "ThreatFound";

            /// <summary>
            /// File not uploaded;
            /// </summary>
            public const string FileNotUploaded = "File not uploaded.";

            /// <summary>
            /// File uploaded successfully
            /// </summary>
            public const string FileUploadSuccessfully = "File uploaded successfully.";

            /// <summary>
            /// 
            /// </summary>
            public const string PDFExtension = ".pdf";

            /// <summary>
            /// EmptyFileURL
            /// </summary>
            public const string EmptyFileURL = "File Url cannot be empty!";

            /// <summary>
            /// EmptyCustomerID
            /// </summary>
            public const string EmptyCustomerID = "Customer Id and filename must be provided!";

            /// <summary>
            /// NoContent
            /// </summary>
            public const string NoContent = "204 No Content";

            /// <summary>
            /// ODataMaxVersion
            /// </summary>
            public const string ODataMaxVersion = "OData-MaxVersion";

            /// <summary>
            /// ODataVersion
            /// </summary>
            public const string ODataVersion = "OData-Version";

            /// <summary>
            /// Version4.0
            /// </summary>
            public const string Version4 = "4.0";

            /// <summary>
            /// ApiQuery
            /// </summary>
            public const string ApiQuery = "/api/data/v9.1/";

            /// <summary>
            /// FetchXml
            /// </summary>
            public const string FetchXml = "?fetchXml=";

            /// <summary>
            /// JsonApplication
            /// </summary>
            public const string JsonApplication = "application/json";

            /// <summary>
            /// Comma
            /// </summary>
            public const string Comma = ",";

            /// <summary>
            /// Prefer
            /// </summary>
            public const string Prefer = "Prefer";

            /// <summary>
            /// ODataIncludeAnnotations
            /// </summary>
            public const string ODataIncludeAnnotations = "odata.include-annotations=*";

            /// <summary>
            /// CacheControl
            /// </summary>
            public const string CacheControl = "Cache-Control";

            /// <summary>
            /// NoCache
            /// </summary>
            public const string NoCache = "no-cache";

            /// <summary>
            /// ODataEntityId
            /// </summary>
            public const string ODataEntityId = "OData-EntityId";

            /// <summary>
            /// ErrorProcessingReports
            /// </summary>
            public const string ErrorProcessingReports = "An error occurred while processing reports";

            /// <summary>
            /// FileProcessed
            /// </summary>
            public const string FileProcessed = "Files processed successfully";

            /// <summary>
            /// Star
            /// </summary>
            public const string Star = "*";

            /// <summary>
            /// DeviceRegistrationReportFolder
            /// </summary>
            public const string DeviceRegistrationReportFolder = "deviceregistrationreport-ssh";

            /// <summary>
            /// EmptyCustomerAccountNumber
            /// </summary>
            public const string EmptyCustomerAccountNumber = "Customer Account Number is required";

            /// <summary>
            /// AzureADRReportStorageAccount
            /// </summary>
            public const string AzureADRReportStorageAccount = "AzureADRReportStorageAccount";

            /// <summary>
            /// ApplicationExtension
            /// </summary>
            public const string ApplicationExtension = ".msi,.exe";
            /// <summary>
            /// CDO
            /// </summary>
            public const string CDO = "cdo";
            /// <summary>
            /// ADRContainer
            /// </summary>
            public const string ADRContainer = "adrreports";
            /// <summary>
            /// MuleSoftFTPUserName
            /// </summary>
            public const string MuleSoftFTPUserName = "MuleSoftFTPUserName";

            public const string ADRClientId = "CLIENT_ID";

            public const string ADRClientSecret = "CLIENT_SECRET";

        }

    }
}
