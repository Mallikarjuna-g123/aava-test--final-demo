﻿
namespace FIJI.Portal.FileReception.Model
{
    /// <summary>
    /// ConfigStorage class
    /// </summary>
    public class ConfigStorage
    {
        /// <summary>
        /// Account Name
        /// </summary>
        public string? name { get; set; }

        /// <summary>
        /// Account Key
        /// </summary>
        public string? key { get; set; }

        /// <summary>
        /// notiticationurl
        /// </summary>
        public string? crmUrl { get; set; }

        /// <summary>
        /// Connection string
        /// </summary>
        public string? connectionString { get; set; }

    }

    /// <summary>
    /// ConfigSettings class
    /// </summary>
    public class ConfigSettings
    {
        /// <summary>
        /// ServiceBusEndpoint
        /// </summary>
        public string? ServiceBusEndpoint { get; set; }

        /// <summary>
        /// Windows Defender Path
        /// </summary>
        public string WindowsDefenderPath { get; set; }

        /// <summary>
        /// Max ConcurrentCalls to get item from Queue
        /// </summary>
        public int MaxConcurrentCalls { get; set; }


        /// <summary>
        /// AccountName
        /// </summary>
        public string? AccountName { get; set; }


        /// <summary>
        /// Account Key
        /// </summary>
        public string? AccountKey { get; set; }

        /// <summary>
        /// Queues
        /// </summary>
        public List<string>? Queues { get; set; }

        /// <summary>
        /// Storages
        /// </summary>
        public List<ConfigStorage>? Storages { get; set; }

        /// <summary>
        /// RootTempFolder
        /// </summary>
        public string? RootTempFolder { get; set; }

        /// <summary>
        /// Clamavip
        /// </summary>
        public string? Clamavip { get; set; }

        /// <summary>
        /// Clamavport
        /// </summary>
        public string? Clamavport { get; set; }

        /// <summary>
        /// ConnectionStringAppInsighs
        /// </summary>
        public string? ConnectionStringAppInsighs { get; set; }
    }
}
