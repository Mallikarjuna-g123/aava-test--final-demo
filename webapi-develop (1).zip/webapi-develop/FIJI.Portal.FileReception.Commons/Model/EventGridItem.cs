﻿
namespace FIJI.Portal.FileReception.Model
{
    /// <summary>
    /// EventGridItem class
    /// </summary>
    public class EventGridItem
    {
        /// <summary>
        /// api
        /// </summary>
        public string? api { get; set; }

        /// <summary>
        /// clientRequestId
        /// </summary>
        public string? clientRequestId { get; set; }

        /// <summary>
        /// requestId
        /// </summary>
        public string? requestId { get; set; }

        /// <summary>
        /// eTag
        /// </summary>
        public string? eTag { get; set; }

        /// <summary>
        /// contentType
        /// </summary>
        public string? contentType { get; set; }

        /// <summary>
        /// contentLength
        /// </summary>
        public long contentLength { get; set; }

        /// <summary>
        /// blobType
        /// </summary>
        public string? blobType { get; set; }

        /// <summary>
        /// blobUrl
        /// </summary>
        public string? blobUrl { get; set; }

        /// <summary>
        /// url
        /// </summary>
        public string? url { get; set; }

        /// <summary>
        /// sequencer
        /// </summary>
        public string? sequencer { get; set; }

        /// <summary>
        /// identity
        /// </summary>
        public string? identity { get; set; }

        /// <summary>
        /// Run checksum
        /// </summary>
        public bool runChecksum { get; set; }

    }
}