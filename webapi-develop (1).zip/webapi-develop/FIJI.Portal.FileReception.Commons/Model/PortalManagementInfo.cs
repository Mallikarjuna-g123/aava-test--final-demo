﻿using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace FIJI.Portal.FileReception.Commons.Model
{
    public class PortalManagementInfo
    {
        private readonly ILogger _logger;
        private ServiceClient _serviceClient;
        public const string LogicalName = "fiji_portalmanagementinfo";

        public enum FileStatusValues
        {
            Inactive = 4,
            Active = 3,
            Failed = 1,
            Completed = 2,
            VirusDetected = 5,
            ProvideSHA256 = 6,
            InvalidSHA256 = 7,
            InvalidWIMfile = 8,
            InProgress = 9,
            InvalidSystemSavFolder = 10,
            InvalidExtension = 11
        }

        public enum UseByValues
        {
            ImageApplicationManager = 1,
            VolumeLicenseManager = 2,
            RangeManagement = 3,
            AY108AVBIOSRevision = 4,
            ImageCloningTool = 5
        }

        public enum IAMTypeValues
        {
            Image = 1,
            Application = 2,
            PPKG = 3
        }

        public enum TransferTypeValues
        {
            SFTP = 1,
            CD_DVD_USB = 622490001,
            Portal = 3
        }
        public PortalManagementInfo(ServiceClient dataverseClient) => _serviceClient = dataverseClient;

        public Entity? GetBy(Guid id, params string[] columns)
        {
            return _serviceClient.Retrieve(LogicalName, id, new ColumnSet(columns));
        }

        public void UpdateRecord(Guid id, FileStatusValues status,  string generatedSHA256, string fileUrl)
        {
                Entity entity = new Entity(LogicalName, id);
                entity["fiji_filestatus"] = new OptionSetValue((int)status);

                if (!string.IsNullOrEmpty(generatedSHA256))
                    entity["fiji_sha256_generated_by_system"] = generatedSHA256;

                entity["fiji_iamuploadurl"] = fileUrl;

                this._serviceClient.Update(entity);
        }

        public string? GetSHA256Provided(Guid fileId)
        {
            var entity = this.GetBy(fileId, new string[] { "fiji_sha256" });

            if (entity != null)
                return entity.GetAttributeValue<string?>("fiji_sha256");

            return null;
        }

        public void SetSHA256(Guid id, string sha256)
        {
            Entity entity = new Entity(LogicalName, id);
            entity["fiji_sha256"] = sha256;
            entity["fiji_filestatus"] = new OptionSetValue((int)FileStatusValues.InProgress);
            _serviceClient.Update(entity);
        }

        public string? GetBlobUrlAndCustomerSHA256(Guid fileId, out string? customerSHA256)
        {
            var entity = this.GetBy(fileId, new string[] { "fiji_iamuploadurl", "fiji_sha256" });
            customerSHA256 = "";

            if (entity != null)
            {
                customerSHA256 = entity.GetAttributeValue<string?>("fiji_sha256");
                return entity.GetAttributeValue<string?>("fiji_iamuploadurl");
            }

            return null;
        }

        public void Delete(Guid? fileId)
        {
            QueryExpression query = new QueryExpression(LogicalName);
            query.PageInfo = new PagingInfo() { PageNumber = 1, Count = 1 };
            query.Criteria.AddCondition("fiji_portalmanagementinfoid", ConditionOperator.Equal, fileId.ToString());
            if (_serviceClient.RetrieveMultiple(query).Entities.Count > 0)
                _serviceClient.Delete(LogicalName, fileId.Value);
        }

        public Guid CreateIAMFileRecord(Guid accountId, Guid? contactId, string fileName, string blobUrl, long length, TransferTypeValues transferType, FileStatusValues status, string extension)
        {
            Entity entity = new Entity(LogicalName);
            IAMTypeValues iamType;
            FileStatusValues fileStatus;
            TransferTypeValues transferTypeValues;

            var appExtensions = new[] { ".bat", ".cmd" };

            var imageExtensions = new[] { ".7z", ".exe", ".ffu", ".gho", ".ghs", ".img", ".iso", ".msi", ".swm", ".tibx", ".v2i", ".wim", ".zip", ".rar", ".msix" }
                                  .Concat(Enumerable.Range(1, 999).Select(i => $".{i:D3}"))
                                  .ToHashSet();

            if (status == FileStatusValues.InvalidExtension)
            {
                // Invalid extension
                iamType = IAMTypeValues.Image; 
                transferTypeValues = TransferTypeValues.Portal;
                fileStatus = FileStatusValues.InvalidExtension;
            }
            else if (extension == ".ppkg")
            {
                iamType = IAMTypeValues.PPKG;
                transferTypeValues = TransferTypeValues.Portal;
                fileStatus = status;
            }
            else if (appExtensions.Contains(extension))
            {
                iamType = IAMTypeValues.Application;
                transferTypeValues = TransferTypeValues.Portal;
                fileStatus = status;
            }
            else if (imageExtensions.Contains(extension))
            {
                iamType = IAMTypeValues.Image;
                transferTypeValues = TransferTypeValues.Portal;
                fileStatus = status;
            }
            else
            {
                // Default 
                iamType = IAMTypeValues.Image;
                transferTypeValues = transferType;
                fileStatus = status;
            }
        
            entity["fiji_filestatus"] = new OptionSetValue((int)fileStatus);
            entity["fiji_customer"] = new EntityReference() { Id = accountId };
            entity["fiji_useby"] = new OptionSetValue((int)UseByValues.ImageApplicationManager);
            entity["fiji_iamtype"] = new OptionSetValue((int)iamType); 
            entity["fiji_ftotype"] = new OptionSetValue((int)transferTypeValues);
            entity["fiji_filename"] = fileName;
            entity["fiji_name"] = fileName;
            entity["fiji_filesize"] = Math.Round(Convert.ToDecimal((length / 1024)), 0).ToString();
            entity["fiji_version"] = string.Empty;

            if (contactId != null)
                entity["fiji_contact"] = new EntityReference() { Id = contactId.Value };
           
            if(fileStatus == FileStatusValues.InvalidExtension || fileStatus == FileStatusValues.VirusDetected)
            {
                entity["fiji_iamuploadurl"] = string.Empty;
            }
            else
            {
                entity["fiji_iamuploadurl"] = blobUrl;
            }     

            return this._serviceClient.Create(entity);
        }

        public string? GetCustomerSHA256(string uploadUrl)
        {
            try
            {
                Entity entity = GetEntityByUploadUrl(uploadUrl);

                if (entity != null)
                {
                    return entity.GetAttributeValue<string?>("fiji_sha256");
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Error retrieving customer SHA256 for upload URL: {uploadUrl}", uploadUrl);
                throw; 
            }
        }

        public Entity? GetEntityByUploadUrl(string uploadUrl)
        {
            var query = new QueryExpression(LogicalName)
            {
                ColumnSet = new ColumnSet("fiji_name", "fiji_iamuploadurl", "fiji_sha256", "fiji_portalmanagementinfoid")
            };

            // Add conditions
            query.Criteria.AddCondition("fiji_iamuploadurl", ConditionOperator.Equal, uploadUrl);

            var result = _serviceClient.RetrieveMultiple(query);

            return result.Entities.FirstOrDefault();
        }


        public Guid? GetFileId(string uploadUrl)
        {
            try
            {
                Entity entity = GetEntityByUploadUrl(uploadUrl);

                if (entity != null)
                {
                    return entity.GetAttributeValue<Guid>("fiji_portalmanagementinfoid");
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Error retrieving fileId for upload URL: {uploadUrl}", uploadUrl);
                throw; 
            }
        }
    }
}
