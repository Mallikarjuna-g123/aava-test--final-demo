﻿using Azure.Identity;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs.Specialized;
using FIJI.Portal.FileReception.Commons.Helpers;
using Newtonsoft.Json;

namespace FIJI.Portal.FileReception.Model
{
    /// <summary>
    /// BlobFile class
    /// </summary>
    public class BlobFile
    {
        public enum eFileType
        {
            Default = 0,
            IAM = 1,
            ICT = 2,
            PPKG = 3
        }
        /// <summary>
        /// name
        /// </summary>
        public string? name { get; set; }

        /// <summary>
        /// ID
        /// </summary>
        public string? id { get; set; }

        /// <summary>
        /// sha256
        /// </summary>
        public string? sha256 { get; set; }

        /// <summary>
        /// version
        /// </summary>
        public string version { get; set; }

        /// <summary>
        /// UTCTicks
        /// </summary>
        public double UTCTicks { get; set; }

        /// <summary>
        /// ModifiedOn
        /// </summary>
        public DateTime ModifiedOn { get; set; }

        /// <summary>
        /// status
        /// </summary>
        public string? status { get; set; }

        /// <summary>
        /// statusType
        /// </summary>
        public string? statusType { get; set; }

        /// <summary>
        /// description
        /// </summary>
        public string description { get; set; }

        /// <summary>
        /// compressionType
        /// </summary>
        public string? compressionType { get; set; }

        /// <summary>
        /// Url
        /// </summary>
        public string? Url { get; set; }

        /// <summary>
        /// contactid
        /// </summary>
        public string? contactid { get; set; }

        /// <summary>
        /// Blob client instance
        /// </summary>
        [JsonIgnore] private BlobClient blob;

        /// <summary>
        /// Name
        /// </summary>
        [JsonIgnore] public string? Name { get { return blob?.Name; } }

        /// <summary>
        /// AccountName
        /// </summary>
        [JsonIgnore] public string? AccountName { get { return blob?.AccountName; } }

        /// <summary>
        /// Uri
        /// </summary>
        [JsonIgnore] public Uri Uri { get; private set; }

        /// <summary>
        /// LeaseId
        /// </summary>
        [JsonIgnore] public string LeaseId { get; private set; }

        /// <summary>
        /// File Name
        /// </summary>
        [JsonIgnore]
        public string FileName
        {
            get
            {
                return blob.Name.Split('/').Last();
            }
        }

        /// <summary>
        /// BlobFile constructor
        /// </summary>
        public BlobFile() { }

        /// <summary>
        /// BlobFile constructor
        /// </summary>
        /// <param name="uri">Uri</param>
        public BlobFile(Uri uri) : this(new BlobClient(uri, new DefaultAzureCredential())) { }

        public BlobFile(Uri uri, string accountName, string accountKey) : this(new BlobClient(uri, new StorageSharedKeyCredential(accountName, accountKey))) { }

        /// <summary>
        /// BlobFile constructor
        /// </summary>
        /// <param name="blob">Blob client service</param>
        public BlobFile(BlobClient blobInstance)
        {
            this.Uri = blobInstance.Uri;
            this.blob = blobInstance;

            if (this.Exists())
            {
                var props = this.GetProperties();
                if (props.LeaseStatus == LeaseStatus.Locked)
                    this.LeaseId = props.Metadata["lid"];
            }
        }

        /// <summary>
        /// Check if the file exists
        /// </summary>
        /// <returns></returns>
        public bool Exists()
        {
            return blob.Exists();
        }

        /// <summary>
        /// Get File properties
        /// </summary>
        /// <returns>Blob properties</returns>
        public BlobProperties GetProperties()
        {
            return blob.GetProperties().Value;
        }

        /// <summary>
        /// Set Metadata file
        /// </summary>
        /// <param name="props">Metadata</param>
        public void SetMetadata(IDictionary<string, string> props)
        {
            BlobRequestConditions conditions = null;

            if (!string.IsNullOrEmpty(this.LeaseId))
                conditions = new BlobRequestConditions() { LeaseId = this.LeaseId };

            blob.SetMetadata(props, conditions);
        }


        /// <summary>
        /// AcquireLease to file
        /// </summary>
        public void AcquireLease()
        {
            var props = blob.GetProperties().Value;

            if (props.LeaseStatus == LeaseStatus.Unlocked)
            {
                this.LeaseId = Guid.NewGuid().ToString();
                blob.GetBlobLeaseClient(this.LeaseId).Acquire(TimeSpan.FromSeconds(-1));
                //props.Metadata["lid"] = this.LeaseId;
                //this.SetMetadata(props.Metadata);
            }
        }


        /// <summary>
        /// Open file to read
        /// </summary>
        /// <param name="blobOpenReadOptions"><see cref="BlobOpenReadOptions"/></param>
        /// <returns>Stream</returns>
        public Stream OpenRead(BlobOpenReadOptions blobOpenReadOptions)
        {
            return this.blob.OpenRead(blobOpenReadOptions);
        }

        /// <summary>
        /// Download file
        /// </summary>
        /// <param name="folder">Folder name</param>
        /// <returns>Temp file path</returns>
        public string Download(string folder)
        {
            string tempFile = Path.Combine(folder, this.FileName);
            blob.DownloadTo(tempFile);
            return tempFile;
        }

        public async Task<string> DownloadContent()
        {
            var binaryData = await blob.DownloadContentAsync();
            return binaryData.Value.Content.ToString();
        }

        public void Delete()
        {
            blob.DeleteIfExists(DeleteSnapshotsOption.IncludeSnapshots);
        }

        /// <summary>
        /// Merge and Set Metadata
        /// </summary>
        /// <param name="values">New values</param>
        public void MergeAndSetMetadata(IDictionary<string, string> values)
        {
            var metadata = blob.GetProperties().Value.Metadata;

            foreach (var item in values)
                metadata[item.Key] = item.Value;

            this.SetMetadata(metadata);
        }

    }
}
