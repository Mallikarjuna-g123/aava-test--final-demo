﻿
using Newtonsoft.Json;


namespace FIJI.Portal.FileReception.Model
{
    /// <summary>
    /// QueueMessage class
    /// </summary>
    public class QueueMessage
    {
        
        /// <summary>
        /// Subject
        /// </summary>
        [JsonProperty("subject")]
        public string? Subject { get; set; }

        /// <summary>
        /// BlobUrl
        /// </summary>
        [JsonProperty("topic")]
        public string? Topic { get; set; }

        [JsonProperty("data")]
        public BlobData? Data { get; set; }


        public class BlobData
        {
            /// <summary>
            /// BlobUrl
            /// </summary>
            [JsonProperty("blobUrl")]
            public string? BlobUrl { get; set; }


            [JsonProperty("fileId")]
            public Guid? FileId { get; set; }

            /// <summary>
            /// BlobUrl
            /// </summary>
            [JsonProperty("url")]
            public string? Url { get; set; }

            /// <summary>
            /// BlobUrl
            /// </summary>
            [JsonProperty("api")]
            public string? Api { get; set; }

        }
    }
}
