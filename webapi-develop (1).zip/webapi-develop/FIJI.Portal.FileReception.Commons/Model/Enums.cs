﻿
namespace FIJI.Portal.FileReception.Model
{
    /// <summary>
    /// Enums class
    /// </summary>
    public class Enums
    {
        /// <summary>
        /// eMetadataProps enum
        /// </summary>
        public enum eMetadataProps
        {
            customersha256,
            description,
            sha256,
            status,
            statusType,
            version,
            compressionType,
            contactid,
            viruscheckresult,
            hide,
            hdi_isfolder,
            fileType,
            fileId,
            MalwareScanningscanresult,
            transferType,
            source
        }

    }
}
