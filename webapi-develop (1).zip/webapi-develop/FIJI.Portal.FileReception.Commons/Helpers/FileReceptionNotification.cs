﻿using Azure.Messaging.ServiceBus;
using FIJI.Portal.FileReception.Model;
using Newtonsoft.Json;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    public class FileReceptionNotification
    {
        private string serviceBusConnection;
        private string storageName;
        private string queueName;
        /// <summary>
        /// Set ServiceBus Connection
        /// </summary>
        /// <param name="connectionString">Connection string</param>
        /// <param name="queue">Queue name</param>
        public FileReceptionNotification(string? serviceBusConnectionString, string? queue, string? storage)
        {
            serviceBusConnection = serviceBusConnectionString ?? "";
            storageName = storage ?? "";
            queueName = queue ?? "";
        }

        /// <summary>
        /// Trigger Service Validation
        /// </summary>
        /// <param name="accountName">File Id</param>
        /// <param name="uri">Uri</param>
        public void TriggerServiceToValidateSHA256(Guid fileId)
        {
            var clientOptions = new ServiceBusClientOptions
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            };

            var client = new ServiceBusClient(serviceBusConnection);
            var sender = client.CreateSender(queueName);

            QueueMessage msg = new QueueMessage
            {
                Data = new QueueMessage.BlobData() { FileId = fileId, Api = Constants.Api.SetSHA256 },
                Topic = storageName,
               
            };
            sender.SendMessageAsync(new ServiceBusMessage(JsonConvert.SerializeObject(msg)));
        }
    }
}
