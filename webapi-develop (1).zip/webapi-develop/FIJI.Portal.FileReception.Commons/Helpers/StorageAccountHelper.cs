﻿using Azure;
using Azure.Identity;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs.Specialized;
using FIJI.Portal.FileReception.Model;
using static FIJI.Portal.FileReception.Model.Enums;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    /// <summary>
    /// StorageAccountHelper class
    /// </summary>
    public class StorageAccountHelper
    {
        /// <summary>
        /// storageAccountUri
        /// </summary>
        private string storageAccountUri = "";

        /// <summary>
        /// Storage Account
        /// </summary>
        private string storageAccountValue = "";

        /// <summary>
        /// Subscription Id
        /// </summary>
        //private string subscriptionIdValue = "";

        /// <summary>
        /// Resource Group Name
        /// </summary>
        //private string resourceGroupNameValue = "";

        /// <summary>
        /// Storage Account credentials
        /// </summary>
        private StorageSharedKeyCredential credentials = null;

        /// <summary>
        /// StorageAccountHelper constructor
        /// </summary>
        /// <param name="storageAccount">Storage account name</param>
        /// <param name="storageAccountKey">Storage account key</param>
        //public StorageAccountHelper(
        //                            string storageAccount,
        //                            string storageAccountKey,
        //                            string subscriptionId = "",
        //                            string resourceGroupName = "",
        //                            string notificationUrl = "")
        //{
        //    storageAccountValue = storageAccount;
        //    subscriptionIdValue = subscriptionId;
        //    resourceGroupNameValue = resourceGroupName;
        //    triggerNotificationUrl = notificationUrl;


        //    if (!string.IsNullOrEmpty(storageAccountKey))
        //        credentials = new StorageSharedKeyCredential(storageAccount, storageAccountKey);

        //    storageAccountUri = string.Format(Constants.Generic.BloStorageAccountUrl, storageAccount);
        //}


        /// <summary>
        /// StorageAccountHelper constructor
        /// </summary>
        /// <param name="storageAccount">Storage account name</param>
        /// <param name="storageAccountKey">Storage account key</param>
        public StorageAccountHelper(string? storageAccount, string? storageAccountKey)
        {
            storageAccountValue = storageAccount ?? "";

            if (!string.IsNullOrEmpty(storageAccountKey))
                credentials = new StorageSharedKeyCredential(storageAccount, storageAccountKey);

            storageAccountUri = string.Format(Constants.Generic.BloStorageAccountUrl, storageAccount);
        }

        /// <summary>
        /// Initialize Account Container
        /// </summary>
        /// <param name="accountId">Account Id </param>
        /// <param name="isTempContainer">Is Temp Container</param>
        /// <returns></returns>
        public BlobContainerClient InitializeAccountContainer(string accountId)
        {
            var containerClient = CreateContainerClient(accountId);

            if (!containerClient.Exists())
            {
                containerClient.CreateIfNotExists();
                string sshContainer = $"{accountId}-ssh";

                //Creates SSH Container
                var sshContainerClient = CreateContainerClient(sshContainer);                
                sshContainerClient.CreateIfNotExists(); 
            }

            //this.CreateFTPUser(sshContainer, fullContainerName.Replace($"{customerId}-", ""));
            
            return containerClient;
        }

        /// <summary>
        /// Initialize account container and handle SFTP usr permissions
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="isAccOnboard"></param>
        /// <returns></returns>
        //public async Task<bool> InitializeAccountContainer(string accountId, bool isAccOnboard)
        //{
        //    try
        //    {
        //        var containerClient = CreateContainerClient(accountId);

        //        containerClient.CreateIfNotExists();
        //        string sshContainer = $"{accountId}-ssh";

        //        //Creates SSH Container
        //        var sshContainerClient = CreateContainerClient(sshContainer);
        //        isAccOnboard = !sshContainerClient.Exists(); // to check if already exist, then don't handle grant permissions
        //        sshContainerClient.CreateIfNotExists();
        //        //if (isAccOnboard)
        //        //await this.GrantRlcToManyContainersAsync(sshContainer);}

        //        //this.CreateFTPUser(sshContainer, fullContainerName.Replace($"{customerId}-", ""));

        //        return isAccOnboard;
        //    }
        //    catch (Exception ex) {
        //        var msg = $"isAccOnboard {isAccOnboard}";
        //        throw new InvalidOperationException(msg + "---" + ex);
        //    }
        //}


        //TODO: need to validate if we still need to implement it
        /// <summary>
        /// Create FTP User associated to SSH Container
        /// </summary>
        /// <param name="sshContainer">SSH Container Name</param>
        /// <param name="username">User Name</param>
        //private void CreateFTPUser(string sshContainer, string username)
        //{
        //    ArmClient armClient = new ArmClient(new DefaultAzureCredential());

        //    if (username.Length > 15)
        //        username = username.Substring(0, 15);

        //    ResourceIdentifier storageAccountLocalUserResourceId =
        //        StorageAccountLocalUserResource.CreateResourceIdentifier(subscriptionIdValue, resourceGroupNameValue, storageAccountValue, username);

        //    StorageAccountLocalUserResource storageAccountLocalUser = armClient.GetStorageAccountLocalUserResource(storageAccountLocalUserResourceId);

        //    StorageAccountLocalUserData data = new StorageAccountLocalUserData()
        //    {
        //        PermissionScopes = { new StoragePermissionScope("rwdl", "blob", sshContainer) },
        //        HomeDirectory = sshContainer,
        //        HasSshPassword = true,
        //    };
        //    ArmOperation<StorageAccountLocalUserResource> lro = storageAccountLocalUser.UpdateAsync(WaitUntil.Completed, data).Result;
        //}

        /// <summary>
        /// Get SA local user and grant permission on new -ssh container
        /// </summary>
        /// <param name="sshContainer"></param>
        //public async Task GrantRlcToManyContainersAsync(string sshContainer)
        //{
        //    try
        //    {
        //        string? localUserName = Environment.GetEnvironmentVariable(Constants.Generic.MuleSoftFTPUserName);
        //        string? resourceGroup = Environment.GetEnvironmentVariable("WEBSITE_RESOURCE_GROUP");
                
        //        if (string.IsNullOrWhiteSpace(localUserName)) throw new InvalidOperationException("Missing MuleSoftFTPUserName env var");
        //        if (string.IsNullOrWhiteSpace(resourceGroup)) throw new InvalidOperationException("Missing WEBSITE_RESOURCE_GROUP env var");
                
        //        string permissionFlagsToGrant = "rwldc";

        //        ArmClient arm = new ArmClient(new DefaultAzureCredential());
        //        if (arm == null) throw new InvalidOperationException($"Missing/invalid arm");
        //        SubscriptionResource subscriptionResource = await arm.GetDefaultSubscriptionAsync();
        //        string? subscriptionIdValue = subscriptionResource.Data.SubscriptionId.ToString();
        //        if (string.IsNullOrWhiteSpace(subscriptionIdValue)) throw new InvalidOperationException($"Missing/invalid subscription id {subscriptionIdValue}");
        //        ResourceIdentifier saId =
        //            StorageAccountLocalUserResource.CreateResourceIdentifier(subscriptionIdValue, resourceGroup, storageAccountValue, localUserName);
        //        if (saId == null) throw new InvalidOperationException($"Missing/invalid said");
        //        StorageAccountLocalUserResource storageAccountLocalUser = arm.GetStorageAccountLocalUserResource(saId);
        //        if (!storageAccountLocalUser.HasData)
        //        {
        //            storageAccountLocalUser = await storageAccountLocalUser.GetAsync();
        //        }

        //        var data = storageAccountLocalUser.Data;
        //        if (!storageAccountLocalUser.HasData) throw new InvalidOperationException("Missing/invalid storageAccountLocalUser");
        //        try
        //        {
        //            UpsertScope(
        //                    scopes: storageAccountLocalUser.Data.PermissionScopes,
        //                    service: "blob",
        //                    resourceName: sshContainer,
        //                    permissionsToAdd: permissionFlagsToGrant);

        //            await storageAccountLocalUser.UpdateAsync(WaitUntil.Completed, storageAccountLocalUser.Data);
        //        } catch(RequestFailedException e)
        //        {

        //            throw new Exception($"ARM update failed. Status={e.Status} ErrorCode={e.ErrorCode} Message={e.Message}");

        //        }
        //    }
        //    catch (Exception ex) {
        //        throw;
        //    }

        //}
        /// <summary>
        /// write permission on identified FTP user
        /// </summary>
        /// <param name="scopes"></param>
        /// <param name="service"></param>
        /// <param name="resourceName"></param>
        /// <param name="permissionsToAdd"></param>
        //private static void UpsertScope(
        //    IList<StoragePermissionScope> scopes,
        //    string service,
        //    string resourceName,
        //    string permissionsToAdd)
        //{
        //    try
        //    {
        //        var existing = scopes.FirstOrDefault(s =>
        //            string.Equals(s.Service, service, StringComparison.OrdinalIgnoreCase) &&
        //            string.Equals(s.ResourceName, resourceName, StringComparison.OrdinalIgnoreCase));

        //        if (existing != null)
        //        {
        //            existing.Permissions = MergePermissionFlags(existing.Permissions, permissionsToAdd);
        //        }
        //        else
        //        {
        //            scopes.Add(new StoragePermissionScope(
        //                NormalizePermissionOrder(permissionsToAdd), service, resourceName
        //                ));
        //        }
        //    }
        //    catch (Exception e) {
        //        throw;
        //    }
        //}
        //private static string MergePermissionFlags(string? existing, string add)
        //{
        //    existing ??= string.Empty;
        //    string combined = new string((existing + add)
        //        .ToLowerInvariant()
        //        .Distinct()
        //        .ToArray());

        //    return NormalizePermissionOrder(combined);
        //}
        //private static string NormalizePermissionOrder(string flags)
        //{
        //    flags = (flags ?? string.Empty).ToLowerInvariant();
        //    char[] order = new[] { 'r', 'w', 'd', 'l', 'c' };
        //    return new string(order.Where(flags.Contains).ToArray());
        //}

        /// <summary>
        /// Initialize BlobContainer client service
        /// </summary>
        /// <param name="container">Container name</param>
        /// <returns>BlobContainer client service</returns>
        private BlobContainerClient CreateContainerClient(string container)
        {
            if (credentials == null)
                return new BlobContainerClient(new Uri($"{storageAccountUri}/{container}"), new DefaultAzureCredential());

            return new BlobContainerClient(new Uri($"{storageAccountUri}/{container}"), credentials);
        }

        /// <summary>
        /// Create Blob Client service
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        private BlobClient CreateBlobClient(Uri uri)
        {
            if (credentials == null)
                return new BlobClient(uri, new DefaultAzureCredential());

            return new BlobClient(uri, credentials);
        }

        /// <summary>
        /// Create Delegation Key
        /// </summary>
        /// <param name="client">Blob service client</param>
        /// <returns>User Delegation key instance</returns>
        private UserDelegationKey CreateDelegationKey(BlobServiceClient client)
        {
            return client.GetUserDelegationKey(DateTimeOffset.UtcNow,
                                                              DateTimeOffset.UtcNow.AddDays(3));
        }

        /// <summary>
        /// Set file metadata
        /// </summary>
        /// <param name="collection">metadata collection</param>
        /// <param name="key">Key</param>
        /// <param name="value">Value</param>
        public static void SetMetadataValue(ref IDictionary<string, string> collection, string key, string value)
        {
            if (collection.ContainsKey(key))
                collection[key] = value;
            else
                collection.Add(key, value);
        }

        /// <summary>
        /// Generate File name
        /// </summary>
        /// <param name="container">Customer Id</param>
        /// <param name="fileName">File name</param>
        /// <param name="blobContainerClient">Blob Container service client</param>
        /// <returns>Blob Client service</returns>
        public BlobClient GenerateFileName(string accountId, string fileName, BlobFile.eFileType type, out int version, BlobContainerClient blobContainerClient = null)
        {
            if (blobContainerClient == null)
                blobContainerClient = InitializeAccountContainer(accountId);

            version = 0;
            BlobClient? blobClient = null;
            string rootFolder = string.Empty;
            //if (projectid != null)
            //    rootFolder = $"{type.ToString()}/{projectid}/files/";
            //else
            rootFolder = $"{type.ToString()}/files/{fileName}";

            // Find the latest folder created 
            int latestVersion = blobContainerClient
                .GetBlobsByHierarchy(prefix: $"{rootFolder}/", delimiter: "/")
                .AsPages()
                .SelectMany(p => p.Values)
                .Where(i => i.IsPrefix)
                .Select(i => int.TryParse(i.Prefix.TrimEnd('/').Split('/').Last(), out int n) ? n : 0)
                .DefaultIfEmpty(0)
                .Max();

            version = latestVersion;

            do
            {
                version++;
                string newFolder = $"{rootFolder}/{version.ToString().PadLeft(3, '0')}";
                string newBlobPath = $"{newFolder}/{fileName}";

                blobClient = blobContainerClient.GetBlobClient(newBlobPath);

            } while (blobClient.Exists());  

            return blobClient;
        }

    /// <summary>
    /// Load the OpenId configuration from portal configuration container
    /// </summary>
    /// <returns>OpenId Configuration</returns>
        public async Task<string> LoadPortalOpenIdConfiguration()
        {
            var containerClient = CreateContainerClient(Constants.Generic.PortalConfigurationContainer);
            BlobFile blobFile = new BlobFile(containerClient.GetBlobClient(Constants.Generic.OpenIdConfigurationFile));
            return await blobFile.DownloadContent();
        }

        public Uri GetPortalWebFilesDownloadUrl(string host, string fileName)
        {
            return GetDownloadUrl(host, new Uri($"{storageAccountUri}/{"portal-web-files"}/{fileName}"));
        }
        public Uri GetDownloadUrl(string host, Uri file)
        {
            //var containerClient = InitializeCustomerContainer(container);
            var blobClient = this.CreateBlobClient(file);
            return new Uri($"{host}/{blobClient.BlobContainerName}?file={blobClient.Name}");

            //UserDelegationKey userDelegationKey = CreateDelegationKey(blobClient.GetParentBlobContainerClient()
            //                                                          .GetParentBlobServiceClient());

            //BlobSasBuilder sasBuilder = new BlobSasBuilder()
            //{
            //    BlobContainerName = blobClient.BlobContainerName,
            //    BlobName = blobClient.Name,
            //    Resource = "b",
            //    StartsOn = DateTimeOffset.UtcNow,
            //    ExpiresOn = DateTimeOffset.UtcNow.AddHours(12)
            //};

            //sasBuilder.SetPermissions(BlobSasPermissions.Read);

            //BlobUriBuilder blobUriBuilder = new BlobUriBuilder(new Uri($"{storageAccountUri}/{blobClient.BlobContainerName}/{blobClient.Name}"))
            //{
            //    Sas = sasBuilder.ToSasQueryParameters(userDelegationKey,
            //                                          blobClient.AccountName)
            //};



            //return blobUriBuilder.ToUri();

        }


        /// <summary>
        /// Create Temp file and Generate SAS Uri
        /// </summary>
        /// <param name="container">Container name</param>
        /// <param name="file">File</param>
        /// <returns>Uri</returns>
        public Uri CreateFileAndGenerateSASUri(string host, string accountId, string fileName, BlobFile.eFileType type, out Guid? fileId, out string storageFileUrl)
        {
            var blobContainerClient = InitializeAccountContainer(accountId);
            fileId = Guid.NewGuid();
            fileName = Utility.SanitizeFilename(fileName);

            IDictionary<string, string> metadata = new Dictionary<string, string>
            {
                { eMetadataProps.fileType.ToString(), ((int)type).ToString() },
                { eMetadataProps.fileId.ToString(), fileId.Value.ToString() }
            };

            var blobClient = this.GenerateFileName(accountId, fileName, type, out _, blobContainerClient);

            blobClient.Upload(Stream.Null);

            blobClient.SetMetadata(metadata);

            storageFileUrl = $"{storageAccountUri}/{blobClient.BlobContainerName}/{blobClient.Name}";

            return new Uri($"{host}/{blobClient.BlobContainerName}?file={blobClient.Name}");

            //BlobSasBuilder sasBuilder = new BlobSasBuilder()
            //{
            //    BlobContainerName = blobClient.BlobContainerName,
            //    BlobName = blobClient.Name,
            //    Resource = "b",
            //    StartsOn = DateTimeOffset.UtcNow,
            //    ExpiresOn = DateTimeOffset.UtcNow.AddDays(1)
            //};

            //sasBuilder.SetPermissions(BlobSasPermissions.Read |
            //                          BlobSasPermissions.Write);


            //BlobUriBuilder blobUriBuilder = new BlobUriBuilder(new Uri($"{storageAccountUri}/{blobClient.BlobContainerName}/{blobClient.Name}"))
            //{
            //    Sas = sasBuilder.ToSasQueryParameters(this.CreateDelegationKey(blobContainerClient.GetParentBlobServiceClient()), blobClient.AccountName)
            //};



            //return blobUriBuilder.ToUri();
        }

        /// <summary>
        /// Delete File
        /// </summary>
        /// <param name="fileUrl">File Url</param>
        public void Delete(string fileUrl)
        {
            BlobClient blobClient = this.CreateBlobClient(new Uri(fileUrl));
            blobClient.DeleteIfExists(DeleteSnapshotsOption.IncludeSnapshots);
        }

        public BlobServiceClient GetBlobServiceClient(Uri file)
        {
            var blobClient = this.CreateBlobClient(file);

            return blobClient.GetParentBlobContainerClient().GetParentBlobServiceClient();

        }
                
        public BlobContainerClient InitializeADRContainer(string containerName)
        {
            var containerClient = CreateContainerClient(containerName);

            if (!containerClient.Exists())
            {
                containerClient.CreateIfNotExists();
            }
            return containerClient;
        }

        public async Task<Response<BlockInfo>> StageBlock(string container, string fileName, Stream stream, string blockId)
        {
            BlobContainerClient blobContainerClient = CreateContainerClient(container);
            BlockBlobClient client = blobContainerClient.GetBlockBlobClient(fileName);
            return await client.StageBlockAsync(blockId, stream);
        }
        public async Task<Response<BlobContentInfo>> CommitBlockList(string container, string fileName, List<string> blockList)
        {
            BlobContainerClient blobContainerClient = CreateContainerClient(container);
            BlockBlobClient client = blobContainerClient.GetBlockBlobClient(fileName);
            IDictionary<string, string> metadata = client.GetProperties().Value.Metadata;
            return await client.CommitBlockListAsync(blockList, new CommitBlockListOptions() { Metadata = metadata });
        }

        public async Task<Response<BlobDownloadStreamingResult>> DownloadStreamingAsync(string container, string fileName, CancellationToken ct)
        {
                BlobContainerClient blobContainerClient = CreateContainerClient(container);
                BlockBlobClient client = blobContainerClient.GetBlockBlobClient(fileName);
                return await client.DownloadStreamingAsync(new BlobDownloadOptions(), ct);
        }

        public async Task<Response<BlobDownloadStreamingResult>> DownloadADRStreamingAsync(string container, string fileName, CancellationToken ct, string storageAccount)
        {
            BlobContainerClient blobContainerClient;
            //if (!string.IsNullOrEmpty(storageAccountKey))
            //    credentials = new StorageSharedKeyCredential(storageAccountName, storageAccountKey);

            string? storageadrAccountUri = string.Format(Constants.Generic.BloStorageAccountUrl, storageAccount);
            if (credentials == null)
                blobContainerClient = new BlobContainerClient(new Uri($"{storageadrAccountUri}/{container}"), new DefaultAzureCredential());
            else
                blobContainerClient = new BlobContainerClient(new Uri($"{storageadrAccountUri}/{container}"), credentials);
            BlockBlobClient client = blobContainerClient.GetBlockBlobClient(fileName);
            return await client.DownloadStreamingAsync(new BlobDownloadOptions(), ct);
        }
    }
}
