﻿using Azure.Identity;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    public class Dataverse
    {
        public static ServiceClient CreateConnection(IServiceProvider? provider, string? crmUrl, string? connectionString)
        {
            var managedIdentity = provider.GetRequiredService<DefaultAzureCredential>();
            var cache = provider.GetService<IMemoryCache>();

            if (string.IsNullOrEmpty(connectionString))
            {
                if (string.IsNullOrEmpty(crmUrl))
                    throw new ArgumentNullException(nameof(crmUrl));

                return new ServiceClient(tokenProviderFunction: f => Authentication.GetToken(crmUrl, managedIdentity, cache),
                                                instanceUrl: new Uri(crmUrl), useUniqueInstance: true);
            }

            else
                return new ServiceClient(connectionString);
        }
    }
}
