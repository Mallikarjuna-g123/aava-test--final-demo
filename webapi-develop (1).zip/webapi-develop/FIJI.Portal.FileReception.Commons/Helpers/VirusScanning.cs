﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    public class VirusScanning
    {
        /// <summary>
        /// Lock file process
        /// </summary>
        public static object _lock = new object();

        /// <summary>
        /// Windows Defender EXE path
        /// </summary>
        private string? _winDefenderPath;


        /// <summary>
        /// Check Virus Status
        /// </summary>
        public enum CheckVirusStatus
        {
            Error,
            Timeout,
            ThreatFound,
            NoThreatFound
        }

        public VirusScanning(string? winDefenderPath) => _winDefenderPath = winDefenderPath;


        /// <summary>
        /// Check Virus using Windows Defender
        /// </summary>
        /// <param name="path">Path or File</param>
        /// <param name="timeout">Timeout</param>
        /// <returns>Virus Status</returns>
        public CheckVirusStatus Check(string path, int timeout = -1)
        {
            var process = new Process();

            var startInfo = new ProcessStartInfo(_winDefenderPath)
            {
                Arguments = $"-Scan -ScanType 3 -File \"{path}\" -DisableRemediation",
                CreateNoWindow = true,
                ErrorDialog = false,
                WindowStyle = ProcessWindowStyle.Hidden,
                UseShellExecute = false
            };

            process.StartInfo = startInfo;

            if (timeout != -1)
            {
                lock (_lock)
                {
                    process.Start();
                    process.WaitForExit(timeout);
                }
            }
            else
            {
                process.Start();
                process.WaitForExit(timeout);
            }

            if (!process.HasExited)
            {
                process.Kill();
                return CheckVirusStatus.Timeout;
            }

            LogHelper.Log($"Virus Scan Code: {process.ExitCode} - File: {path}");

            switch (process.ExitCode)
            {
                case 0:
                    return CheckVirusStatus.NoThreatFound;
                case 2:
                    return CheckVirusStatus.ThreatFound;
                default:
                    return CheckVirusStatus.Error;
            }
        }


        /// <summary>
        /// Check Virus using Windows Defender
        /// </summary>
        /// <param name="file">File</param>
        /// <returns></returns>
        public CheckVirusStatus Check(FileInfo file)
        {
            int timeoutInMs = 20000;

            if (file.Length == 0)
                return CheckVirusStatus.NoThreatFound;

            if (!File.Exists(file.FullName))
                return CheckVirusStatus.ThreatFound;


            LogHelper.Log($"Starting Check Virus Scanning");

            CheckVirusStatus result = this.Check(file.FullName, timeoutInMs);

            if (result != CheckVirusStatus.ThreatFound && file.Extension == Constants.Generic.PDFExtension && IsTherePossibleXXEDetected(file.FullName))
                result = CheckVirusStatus.ThreatFound;

            return result;
        }

        /// <summary>
        /// It detects if the file has a possible XXE thread detected
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns>true if XXE threat is detected, otherwise false</returns>
        public bool IsTherePossibleXXEDetected(string filePath)
        {
            string content;
            try
            {
                content = File.ReadAllText(filePath);
            }
            catch
            {
                return false;
            }

            // Regular expression to detect <!ENTITY ... SYSTEM ... >
            string xxePattern = @"<!ENTITY\s+\w+\s+SYSTEM\s+['""][\s\S]*?['""]\s*>";
            return Regex.IsMatch(content, xxePattern, RegexOptions.IgnoreCase);
        }
    }
}
