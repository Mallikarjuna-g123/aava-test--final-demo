﻿
namespace FIJI.Portal.FileReception.Commons
{
    public class LogHelper
    {
        public static object _lock = new object();
        private static string _rootFolder;
        private static string _file;
        public static void Log(Exception ex)
        {
            string text = $"Message: {ex.Message}, Stack: {ex.StackTrace}";
            Log(text);
        }

        public static void Log(string message)
        {
            message = $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} - {message}";

            lock (_lock)
            {
                
                using (var sw = File.AppendText(_file))
                {
                    sw.WriteLine(message);
                }
            }
        }

        public static void InitializeLogFile(string rootTempFolder)
        {
            _rootFolder = rootTempFolder;
            string path = Path.Combine(_rootFolder, "log");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            _file = string.Concat(path, "\\log.txt");
            if (!File.Exists(_file))
            {
                File.Create(_file).Close();
            }
        }
    }
}
