﻿using System.Text;
using System.Runtime.Serialization.Json;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    /// <summary>
    /// Utility class
    /// </summary>
    public class Utility
    {



        /// <summary>
        /// Valida extensions
        /// </summary>
        private static List<string> validExtensions = null;
        /// <summary>
        /// clamav Host
        /// </summary>
        private static string clamavHost = "";
        /// <summary>
        /// clamav Port
        /// </summary>
        private static int clamavPort = 0;
        /// <summary>
        /// ServiceBus Connection
        /// </summary>
        private static string serviceBusConnection = "";

        /// <summary>
        /// Queue name
        /// </summary>
        private static string queueName = "";

        /// <summary>
        /// Queue name Imagem Reception
        /// </summary>
        private static string queueNameImageReception = "";

        /// <summary>
        /// Trigger Notification Url
        /// </summary>
        private static string triggerNotificationUrl = "";

        /// <summary>
        /// HttpClient
        /// </summary>
        private static readonly HttpClient client = new HttpClient();

        /// <summary>
        /// Convert To TimeZoneInfo from DateTime UTC
        /// </summary>
        /// <param name="timeZone">TimeZoneInfo</param>
        /// <param name="dateTime">DateTime value</param>
        /// <returns>DateTime value on specific Timezone</returns>
        public static DateTime ConvertDateTimeFromUtc(TimeZoneInfo timeZone, DateTime dateTime)
        {
            dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
            return TimeZoneInfo.ConvertTime(dateTime, timeZone);
        }
        /// <summary>
        /// Convert To TimeZoneInfo from string DateTime UTC
        /// </summary>
        /// <param name="timeZone">TimeZoneInfo</param>
        /// <param name="dateTime">DateTime value</param>
        /// <returns>DateTime value on specific Timezone</returns>
        public static DateTime ConvertDateTimeFromUtc(TimeZoneInfo timeZone, string dateTime)
        {
            return ConvertDateTimeFromUtc(timeZone, DateTime.Parse(dateTime));
        }

        /// <summary>
        /// Parse Valid extensions
        /// </summary>
        /// <param name="extensions">Extensions separated by comma</param>
        /// <returns>list of extensions</returns>
        public static List<string> ParseValidExtensions(string extensions)
        {
            if (validExtensions == null)
            {
                validExtensions = extensions.ToLower().Split(',').ToList();
                for (int index = 1; index < 1000; index++)
                    validExtensions.Add($".{index.ToString().PadLeft(3, '0')}");

                validExtensions.Sort();
            }
            return validExtensions;
        }

        /// <summary>
        /// Check it's a valid extension
        /// </summary>
        /// <param name="name">File name</param>
        /// <returns>True or False</returns>
        public static bool IsValidExtension(string name)
        {
            FileInfo fl = new FileInfo(name);
            return validExtensions.Contains(fl.Extension.ToLower());
        }


        /// <summary>
        /// Convert Json to Object
        /// </summary>
        /// <typeparam name="T">Generic Object</typeparam>
        /// <param name="jsonObject">Object</param>
        /// <returns>String Content</returns>
        public static string ConvertToJson<T>(T jsonObject)
        {
            string jsonText = string.Empty;
            using (var ms = new MemoryStream())
            {
                var ser = new DataContractJsonSerializer(typeof(T));
                ser.WriteObject(ms, jsonObject);
                jsonText = Encoding.UTF8.GetString(ms.ToArray());
            }
            return jsonText;
        }

        public static string SanitizeFilename(string filename)
        {
            // Regex to match invalid filename characters
            string invalidCharsPattern = @"[\/:*?""<>|·]";
            // Replace invalid characters with an empty string
            return Regex.Replace(filename, invalidCharsPattern, string.Empty);
        }

        /// <summary>
        /// Get File checksum
        /// </summary>
        /// <param name="streamIn">Stream In </param>
        /// <param name="log">ILogger</param>
        /// <returns>Checksum SHA256</returns>
        public static string GetChecksum(Stream streamIn)
        {
            string SHA256Hash;

            try
            {
                using (var md5Prov = SHA256.Create())
                {
                    int readCount;
                    long bytesTransfered = 0;
                    var buffer = new byte[Constants.Generic.BufferSize];
                    while ((readCount = streamIn.Read(buffer, 0, buffer.Length)) != 0)
                    {
                        if (bytesTransfered + readCount == streamIn.Length)
                            md5Prov.TransformFinalBlock(buffer, 0, readCount);
                        else
                            md5Prov.TransformBlock(buffer, 0, Constants.Generic.BufferSize, buffer, 0);

                        bytesTransfered += readCount;

                    }
                    SHA256Hash = BitConverter.ToString(md5Prov.Hash).Replace("-", string.Empty);
                    md5Prov.Clear();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    streamIn.Close();
                }
                catch { }

                throw;
            }

            return SHA256Hash.ToUpper();
        }

        /// <summary>
        /// Load IAM Valid Extensions
        /// </summary>
        /// <param name="extension">Extensions separated by comma</param>
        /// <returns></returns>
        public static List<string> LoadIAMValidExtensions(ServiceClient _serviceClient)
        {
            QueryExpression query = new QueryExpression("fiji_configuration");
            query.ColumnSet.AddColumn("fiji_value");
            query.Criteria.AddCondition("fiji_key", ConditionOperator.Equal, "IAMValidFileExtension");
            query.Criteria.AddCondition("fiji_value", ConditionOperator.NotNull);
            var entity = _serviceClient.RetrieveMultiple(query).Entities.FirstOrDefault();

            List<string> result = new List<string>();
            if (entity != null)
            {
                string extensions = entity.GetAttributeValue<string>("fiji_value");

                foreach (var item in extensions.Split(','))
                {
                    string extension = item.Trim();
                    if (extension.Contains("-"))
                    {
                        extension = extension.Replace(".", "");
                        string[] fromTo = extension.Split("-");

                        if (fromTo.Length > 1)
                        {
                            int from = 0, to = 0;

                            if (int.TryParse(fromTo[0], out from) && int.TryParse(fromTo[1], out to))
                            {
                                for (int i = from; i <= to; i++)
                                    result.Add($".{i.ToString().PadLeft(fromTo[1].Length, '0')}");
                            }
                        }
                    }
                    else
                        result.Add(extension.ToLower());
                }
                result.Sort();
            }

            return result;
        }
    }
}
