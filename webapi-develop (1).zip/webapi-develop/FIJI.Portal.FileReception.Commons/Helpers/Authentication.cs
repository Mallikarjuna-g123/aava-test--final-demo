﻿using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    public class Authentication
    {
        private static readonly string webAPIAppAuthorityUrl = "https://login.microsoftonline.com/hp.com";
        public static async Task<string> GetToken(string environment, DefaultAzureCredential credential, IMemoryCache cache)
        {
            if (!environment.Contains("/.default"))
                environment = $"{environment}/.default";

            var token = (await credential.GetTokenAsync(new TokenRequestContext(new[] { environment })));
            return token.Token;
        }

        public static async Task<string> AccessTokenGenerator(string? clientId, string? clientSecret, string? url)
        {
            AuthenticationContext authContext = new AuthenticationContext(webAPIAppAuthorityUrl);
            ClientCredential clientcredentials = new ClientCredential(clientId, clientSecret);
            var result = await authContext.AcquireTokenAsync(url, clientcredentials);
            return result.AccessToken;

        }

        public static async Task<string> GetADRToken(HttpClient httpClient, string tokenUrl, string clientId, string clientSecret, string scope)
        {
            var form = new Dictionary<string, string>
            {
                ["grant_type"] = "client_credentials",
                ["client_id"] = clientId,
                ["client_secret"] = clientSecret,
                ["scope"] = scope
            };

            using var response = await httpClient.PostAsync(tokenUrl, new FormUrlEncodedContent(form));

            response.EnsureSuccessStatusCode();
            string json = await response.Content.ReadAsStringAsync();
            dynamic tokenResponse = Newtonsoft.Json.JsonConvert.DeserializeObject(json);
            return (string)tokenResponse.access_token;
        }
    }
}
