﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIJI.Portal.FileReception.Commons.Helpers
{
    public class FileHelper
    {
        public static List<string> GetAllFiles(string rootPath, string searchPattern)
        {
            List<string> files = new List<string>();
            GetDirectoriesRecursive(rootPath, searchPattern, files);
            return files;
        }

        private static void GetDirectoriesRecursive(string currentPath, string searchPattern, List<string> files)
        {
            try
            {
                string[] listFiles = Directory.GetFiles(currentPath, searchPattern);
                files.AddRange(listFiles);

                // Get all subdirectories
                string[] subDirectories = Directory.GetDirectories(currentPath);

                // Recursively get directories for each subdirectory
                foreach (string subDirectory in subDirectories)
                {
                    GetDirectoriesRecursive(subDirectory, searchPattern, files);
                }
            }
            //Skip directory
            catch (UnauthorizedAccessException) { }
        }
    }
}
