﻿
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using static FIJI.Portal.FileReception.Model.Enums;

namespace FIJI.Portal.FileReception.Common.Helpers
{
    /// <summary>
    /// CRM Helper Class
    /// </summary>
    public class DataverseHelper
    {
        /// <summary>
        /// Organization Service instance
        /// </summary>
        private IOrganizationService serviceClient;

        /// <summary>
        /// CRMHelper constructor
        /// </summary>
        /// <param name="organizationService">Organization service</param>
        public DataverseHelper(IOrganizationService organizationService)
        {
            serviceClient = organizationService;
        }
       

        /// <summary>
        /// Ger metadata entity by entity name
        /// </summary>
        /// <param name="entity">Entity name</param>
        /// <param name="filters"><see cref="EntityFilters"/></param>
        /// <returns>Entity metadata <see cref="EntityMetadata"/></returns>
        public EntityMetadata GetMetadataEntity(string entity, EntityFilters filters = EntityFilters.Attributes)
        {
            RetrieveEntityRequest request = new RetrieveEntityRequest()
            {
                LogicalName = entity,
                EntityFilters = filters
            };

            return ((RetrieveEntityResponse)serviceClient.Execute(request)).EntityMetadata;
        }

        /// <summary>
        /// Get primary contactid by accountid
        /// </summary>
        /// <param name="accountId">Account ID</param>
        /// <returns>Primary Contact Id</returns>
        public string GetPrimaryContactIdBy(string accountId)
        {
            string contactId = "";
            string query = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' page='1' count='1'>
                              <entity name='account'>
                                <attribute name='primarycontactid' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='accountid' operator='eq' value='{0}' />
                                  <condition attribute='primarycontactid' operator='not-null' />
                                </filter>
                              </entity>
                            </fetch>", accountId);


            var result = serviceClient.RetrieveMultiple(new FetchExpression(query));
            if (result.Entities.Count > 0)
                contactId = result.Entities.First().GetAttributeValue<EntityReference>(Entities.Account.PrimaryContactid).Id.ToString();

            return contactId;
        }

        /// <summary>
        /// Return the string values according to the attribute type
        /// </summary>
        /// <param name="metadata">Entity metadata</param>
        /// <param name="attribute">Attribute name</param>
        /// <param name="values">List of values to be replaced</param>
        /// <returns>New string values</returns>
        public string[] ParseAttributesValue(EntityMetadata metadata, string attribute, params string[] values)
        {
            AttributeMetadata attr = metadata.Attributes.FirstOrDefault(a => a.LogicalName == attribute);

            List<EntityMetadata> entityMetadataLookup = new List<EntityMetadata>();

            if (attr is LookupAttributeMetadata)
            {
                foreach (var entity in ((LookupAttributeMetadata)attr).Targets)
                    entityMetadataLookup.Add(GetMetadataEntity(entity, EntityFilters.Entity));
            }


            for (int index = 0; index < values.Length; index++)
            {
                if (!string.IsNullOrEmpty(values[index]))
                {
                    if (attr is PicklistAttributeMetadata)
                        values[index] = this.GetLabelOption(((PicklistAttributeMetadata)attr).OptionSet, values[index]);
                    if (attr is MultiSelectPicklistAttributeMetadata)
                        values[index] = this.GetLabelOption(((MultiSelectPicklistAttributeMetadata)attr).OptionSet, values[index].Split(','));
                    else if (attr is StatusAttributeMetadata)
                        values[index] = this.GetLabelOption(((StatusAttributeMetadata)attr).OptionSet, values[index]);
                    else if (attr is StateAttributeMetadata)
                        values[index] = this.GetLabelOption(((StateAttributeMetadata)attr).OptionSet, values[index]);
                    else if (attr is BooleanAttributeMetadata)
                        values[index] = this.GetLabelBoolean(((BooleanAttributeMetadata)attr).OptionSet, values[index]);
                    else if (attr is LookupAttributeMetadata)
                        values[index] = this.GetLookupPrimaryName(entityMetadataLookup, values[index]);
                    else if (attr is DateTimeAttributeMetadata)
                        values[index] = values[index];
                }
            }
            return values;
        }

        /// <summary>
        /// Get Label by Boolean attribute
        /// </summary>
        /// <param name="optionSet">Attribute Metadata</param>
        /// <param name="value">value</param>
        /// <returns>Label</returns>
        private string GetLabelBoolean(BooleanOptionSetMetadata optionSet, string value)
        {
            if (value == "1")
                return optionSet.TrueOption.Label.UserLocalizedLabel.Label;

            return optionSet.FalseOption.Label.UserLocalizedLabel.Label;
        }

        /// <summary>
        /// Get Label by Lookup attribute
        /// </summary>
        /// <param name="entityMetadataLookup">List of Attribute Metadata</param>
        /// <param name="value">Record Id</param>
        /// <returns>String value</returns>
        private string GetLookupPrimaryName(List<EntityMetadata> entityMetadataLookup, string value)
        {
            foreach (var entity in entityMetadataLookup)
            {
                value = GetLookupPrimaryName(entity, value);
                if (!string.IsNullOrEmpty(value))
                    break;
            }
            return value;
        }

        /// <summary>
        /// Get Lookup primary name
        /// </summary>
        /// <param name="entityMetadata">Attribute Metadata</param>
        /// <param name="value">Record Id</param>
        /// <returns>Primary name</returns>
        public string GetLookupPrimaryName(EntityMetadata entityMetadata, string value)
        {
            string returnValue = string.Empty;

            string query = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' page='1' count='1'>
                              <entity name='{0}'>
                                <attribute name='{1}' />
                                <filter type='and'>
                                  <condition attribute='{2}' operator='eq' value='{3}' />
                                </filter>
                              </entity>
                            </fetch>", entityMetadata.LogicalName, entityMetadata.PrimaryNameAttribute, entityMetadata.PrimaryIdAttribute, value);


            var result = serviceClient.RetrieveMultiple(new FetchExpression(query));

            if (result.Entities.Count > 0)
            {
                if (result.Entities[0].Contains(entityMetadata.PrimaryNameAttribute))
                    returnValue = result.Entities.First()[entityMetadata.PrimaryNameAttribute].ToString();
            }
            return returnValue;
        }

        /// <summary>
        /// Get OptionSet label
        /// </summary>
        /// <param name="options">Optionset Attribute metadata</param>
        /// <param name="value">list of integer values</param>
        /// <returns>Optionset Label</returns>
        private string GetLabelOption(OptionSetMetadata options, string[] value)
        {
            if (value?.Length > 0)
                return string.Join(", ", value.Select(x => GetLabelOption(options, x.Trim()))).Trim();

            return string.Empty;
        }

        /// <summary>
        /// Get OptionSet label
        /// </summary>
        /// <param name="options">Optionset Attribute metadata</param>
        /// <param name="value">Integer option</param>
        /// <returns>Label option</returns>
        private string GetLabelOption(OptionSetMetadata options, string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                var label = options.Options.FirstOrDefault(o => o.Value == int.Parse(value));
                if (label != null)
                    value = label.Label?.UserLocalizedLabel?.Label;
            }
            return value;
        }

        /// <summary>
        /// Send Notification by portal management info entity
        /// </summary>
        /// <param name="fileName">File name</param>
        /// <param name="sha256">SHA256</param>
        /// <param name="description">Description</param>
        /// <param name="status">Status</param>
        /// <param name="contactid">Contact Id</param>
        /// <param name="accountId">Account Id</param>
        internal void SendNotification(string fileName, string sha256, string description, eStatus status, string contactid, string accountId)
        {
            Entity portalManagementInfo = new Entity(Entities.PortalManagementInfo.LogicalName);
            portalManagementInfo[Entities.PortalManagementInfo.Name] = fileName;
            portalManagementInfo[Entities.PortalManagementInfo.SHA256] = sha256;
            portalManagementInfo[Entities.PortalManagementInfo.Description] = description;
            portalManagementInfo[Entities.PortalManagementInfo.Filestatus] = new OptionSetValue((int)status);
            portalManagementInfo[Entities.PortalManagementInfo.Useby] = new OptionSetValue(1);
            portalManagementInfo[Entities.PortalManagementInfo.Contact] = new EntityReference(Entities.Contact.LogicalName, new Guid(contactid));
            portalManagementInfo[Entities.PortalManagementInfo.Customer] = new EntityReference(Entities.Account.LogicalName, new Guid(accountId));
            portalManagementInfo[Entities.PortalManagementInfo.Filename] = fileName;
            serviceClient.Create(portalManagementInfo);
        }

    }
}
