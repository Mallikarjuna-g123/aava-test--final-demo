---
mode: agent
tools: ['codebase', 'editFiles', 'search']
description: Review FIJI WebAPI controllers and update controller guidance references from source code
---

# Objective

Review endpoint behavior for all controllers in FIJI.Portal.WebAPI.Integration based on current source code and update project guidance where needed.

# Scope

- Source controllers: FIJI.Portal.WebAPI.Integration/Controllers/**/*.cs
- Supporting code for analysis:
  - FIJI.Portal.WebAPI.Integration/Model/**/*.cs
  - FIJI.Portal.WebAPI.Integration/Integration/**/*.cs
  - FIJI.Portal.WebAPI.Integration/Service/**/*.cs
  - FIJI.Portal.WebAPI.Integration/Requests/**/*.cs
  - FIJI.Portal.WebAPI.Integration/Responses/**/*.cs
  - FIJI.Portal.WebAPI.Integration/Utilities/RouteConstants.cs
  - FIJI.Portal.FileReception.Commons/**/* where referenced by controllers
- Target guidance files:
  - FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/api-controller-pattern.instructions.md
  - FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/04-Code-and-API-Best-Practices.md

# Required Output Rules

1. Keep links and references valid; do not point to removed Docs/API-Controllers pages.
2. For every endpoint pattern update include:
- HTTP verb and route
- payload/query inputs
- key processing logic summary
- success and error behavior
3. Include key classes, methods, and notable variables used by controller logic.
4. Keep content readable for product owners, developers, and testers.
5. Preserve existing file structure and naming.

# Quality Checklist

- Verify all markdown links resolve with correct relative paths.
- Verify route names against current attributes and RouteConstants.
- Ensure behavior notes match real code paths, including validation and error handling.
- Keep wording concise and public-readable.

# Final Response Format

When done, provide:
1. List of updated guidance files.
2. Any controllers with ambiguous behavior requiring manual clarification.
3. Optional improvement suggestions (for example telemetry or API consistency opportunities).
