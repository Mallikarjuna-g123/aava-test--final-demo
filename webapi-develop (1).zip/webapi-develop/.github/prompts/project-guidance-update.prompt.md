---
mode: agent
tools: ['codebase', 'editFiles', 'search']
description: Update project-level architecture and guidance docs for FIJI.Portal.WebAPI.Integration
---

# Objective

Maintain project-level guidance files under FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance so they stay aligned with current source code and architecture.

# Scope

- FIJI.Portal.WebAPI.Integration/Program.cs
- FIJI.Portal.WebAPI.Integration/FIJI.Portal.WebAPI.Integration.csproj
- FIJI.Portal.WebAPI.Integration/appsettings*.json
- FIJI.Portal.WebAPI.Integration/Controllers/**/*.cs
- FIJI.Portal.WebAPI.Integration/Model/**/*.cs
- FIJI.Portal.WebAPI.Integration/Integration/**/*.cs
- FIJI.Portal.WebAPI.Integration/Utilities/**/*.cs
- FIJI.Portal.FileReception.Commons/**/* where used by WebAPI
- FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/**/*

# Required Output

1. Update these files:
- Docs/Project-Guidance/README.md
- Docs/Project-Guidance/01-Project-Structure.md
- Docs/Project-Guidance/02-Architectural-Conventions.md
- Docs/Project-Guidance/03-Technology-Stack.md
- Docs/Project-Guidance/instructions/*.instructions.md

2. Keep content readable for product owners, developers, and testers.
3. Keep relative links valid and consistent.
4. Include Mermaid diagrams where architecture or flow changed.
5. Mention security-sensitive configuration risks without exposing secrets.

# Validation Checklist

- Routes and conventions align with current controllers and RouteConstants.
- Stack aligns with csproj package references and startup pipeline.
- Guidance instructions align with current coding patterns.
- Links resolve correctly from each markdown file location.

# Final Response

Return:
1. Updated files list.
2. Architecture or convention gaps found.
3. Suggested follow-up improvements (if any).
