---
mode: agent
tools: ['codebase', 'editFiles', 'search']
description: Review and extend observability, logging, and telemetry across FIJI.Portal.WebAPI.Integration
---

# Objective

Audit and improve observability coverage in FIJI.Portal.WebAPI.Integration based on current source code and established patterns.

# Audience

This content supports:
- **Product Owners**: understand what is monitored and where blind spots exist.
- **Developers**: know where to add or extend telemetry without breaking patterns.
- **Testers**: verify that telemetry appears correctly in Application Insights.

# Scope

Source files to audit:
- FIJI.Portal.WebAPI.Integration/Program.cs
- FIJI.Portal.WebAPI.Integration/Observability/**/*.cs
- FIJI.Portal.WebAPI.Integration/Controllers/**/*.cs
- FIJI.Portal.WebAPI.Integration/Integration/**/*.cs
- FIJI.Portal.WebAPI.Integration/Model/**/*.cs
- FIJI.Portal.WebAPI.Integration/Service/**/*.cs

Guidance files to update:
- FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/04-Code-and-API-Best-Practices.md
- FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/instructions/observability-and-logging.instructions.md
- FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/01-Project-Structure.md
- FIJI.Portal.WebAPI.Integration/Docs/Project-Guidance/02-Architectural-Conventions.md

# Established Patterns (Follow These)

1. **Centralized instrumentation over per-controller logging.**
   - Use global filters, middleware, proxies, and DelegatingHandlers.
   - Do NOT add per-endpoint logging unless the endpoint has unique domain-critical needs.

2. **Observability components in the project:**
   - `CorrelationAndRequestLoggingMiddleware` — correlation ID propagation, request timing.
   - `ControllerActionLoggingFilter` — global action start/end/error with duration.
   - `OrganizationServiceLoggingProxy` — all Dataverse SDK calls via DispatchProxy.
   - `OutboundHttpLoggingHandler` — all outbound HTTP calls via IHttpClientFactory.
   - JWT bearer events — authentication failure/challenge warnings.
   - Global exception handler — unhandled exception safety net.

3. **Structured logging rules:**
   - Use `ILogger` with message templates (not string interpolation).
   - Include correlation context via `BeginScope`.
   - Set `Activity.Current` tags for distributed tracing.
   - Severity: Information for milestones, Warning for recoverable issues, Error for failures.
   - Never log secrets, tokens, connection strings, or full sensitive payloads.

4. **When adding new integrations:**
   - Register a named `HttpClient` with `OutboundHttpLoggingHandler` for external APIs.
   - If the integration uses IOrganizationService, it inherits proxy instrumentation automatically.
   - If a new background process is added, include startup/completion logging.

# Review Checklist

- [ ] Every external dependency call (HTTP, Storage, Service Bus) has logging coverage.
- [ ] Dataverse operations go through IOrganizationService (proxy-instrumented).
- [ ] No secrets or tokens appear in log output.
- [ ] Structured message templates are used (not string concatenation).
- [ ] Activity tags are set for key operations to enable distributed trace filtering.
- [ ] appsettings log levels are appropriate (not suppressing project-level logs).
- [ ] Guidance docs match the current implementation.

# Required Actions

1. Identify any new controllers, integrations, or services lacking observability.
2. Implement missing telemetry using established centralized patterns.
3. Update guidance docs to reflect any new instrumentation.
4. Do NOT modify other projects in this solution.

# Final Response Format

Provide:
1. Summary of coverage: what is instrumented vs. gaps found.
2. List of files created or modified.
3. Any recommendations for future improvement.
